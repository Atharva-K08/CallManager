import httpStatus from 'http-status';
import { ApiResponse, PaginatedResponse, AuthResponse, ValidationResponse, ApiErrorResponse } from '../types/response.types.js';

/**
 * Response utility functions for consistent API responses
 */

/**
 * Sends a successful response
 * @param {Object} res - Express response object
 * @param {any} data - Response data
 * @param {string} message - Success message
 * @param {number} statusCode - HTTP status code
 */
export const sendSuccess = (res, data, message = 'Success', statusCode = httpStatus.OK) => {
    const response = ApiResponse.success(data, message);
    res.status(statusCode).json(response);
};

/**
 * Sends a successful response with created status
 * @param {Object} res - Express response object
 * @param {any} data - Response data
 * @param {string} message - Success message
 */
export const sendCreated = (res, data, message = 'Created successfully') => {
    const response = ApiResponse.success(data, message);
    res.status(httpStatus.CREATED).json(response);
};

/**
 * Sends a successful response with no content
 * @param {Object} res - Express response object
 * @param {string} message - Success message
 */
export const sendNoContent = (res, message = 'No content') => {
    const response = ApiResponse.success(null, message);
    res.status(httpStatus.NO_CONTENT).json(response);
};

/**
 * Sends a paginated response
 * @param {Object} res - Express response object
 * @param {Array} data - Array of items
 * @param {Object} pagination - Pagination metadata
 * @param {string} message - Success message
 */
export const sendPaginated = (res, data, pagination, message = 'Data retrieved successfully') => {
    const response = PaginatedResponse.success(data, pagination, message);
    res.status(httpStatus.OK).json(response);
};

/**
 * Sends an authentication success response
 * @param {Object} res - Express response object
 * @param {Object} user - User data
 * @param {Object} tokens - Authentication tokens
 * @param {string} message - Success message
 */
export const sendAuthSuccess = (res, user, tokens, message = 'Authentication successful') => {
    const response = AuthResponse.success(user, tokens, message);
    res.status(httpStatus.OK).json(response);
};

/**
 * Sends an error response
 * @param {Object} res - Express response object
 * @param {string} message - Error message
 * @param {number} statusCode - HTTP status code
 * @param {Object} errors - Optional validation errors
 */
export const sendError = (res, message, statusCode = httpStatus.BAD_REQUEST, errors = null) => {
    const response = ApiErrorResponse.create(message, statusCode, errors);
    res.status(statusCode).json(response);
};

/**
 * Sends a validation error response
 * @param {Object} res - Express response object
 * @param {Object} errors - Validation errors
 * @param {string} message - Error message
 */
export const sendValidationError = (res, errors, message = 'Validation failed') => {
    const response = ValidationResponse.error(errors, message);
    res.status(httpStatus.BAD_REQUEST).json(response);
};

/**
 * Sends an authentication error response
 * @param {Object} res - Express response object
 * @param {string} message - Error message
 * @param {number} statusCode - HTTP status code
 */
export const sendAuthError = (res, message, statusCode = httpStatus.UNAUTHORIZED) => {
    const response = AuthResponse.error(message, statusCode);
    res.status(statusCode).json(response);
};

/**
 * Sends a not found error response
 * @param {Object} res - Express response object
 * @param {string} message - Error message
 */
export const sendNotFound = (res, message = 'Resource not found') => {
    const response = ApiErrorResponse.create(message, httpStatus.NOT_FOUND);
    res.status(httpStatus.NOT_FOUND).json(response);
};

/**
 * Sends an unauthorized error response
 * @param {Object} res - Express response object
 * @param {string} message - Error message
 */
export const sendUnauthorized = (res, message = 'Unauthorized') => {
    const response = AuthResponse.error(message, httpStatus.UNAUTHORIZED);
    res.status(httpStatus.UNAUTHORIZED).json(response);
};

/**
 * Sends a forbidden error response
 * @param {Object} res - Express response object
 * @param {string} message - Error message
 */
export const sendForbidden = (res, message = 'Forbidden') => {
    const response = ApiErrorResponse.create(message, httpStatus.FORBIDDEN);
    res.status(httpStatus.FORBIDDEN).json(response);
};

/**
 * Sends an internal server error response
 * @param {Object} res - Express response object
 * @param {string} message - Error message
 */
export const sendInternalError = (res, message = 'Internal server error') => {
    const response = ApiErrorResponse.create(message, httpStatus.INTERNAL_SERVER_ERROR);
    res.status(httpStatus.INTERNAL_SERVER_ERROR).json(response);
};

/**
 * Creates pagination metadata
 * @param {number} page - Current page
 * @param {number} limit - Items per page
 * @param {number} total - Total items
 * @returns {Object} Pagination metadata
 */
export const createPaginationMeta = (page, limit, total) => {
    const totalPages = Math.ceil(total / limit);
    return {
        current_page: page,
        total_pages: totalPages,
        total_items: total,
        per_page: limit
    };
};
