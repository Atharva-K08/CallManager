import httpStatus from 'http-status';
import Settings from '../models/settings.model.js';
import ApiError from '../utils/ApiError.js';
import { DEFAULT_SETTINGS } from '../config/defaultSettings.js';

/**
 * Get a single setting value
 */
export const getSetting = async (userId, category, key, defaultValue = null) => {
    return await Settings.getSetting(userId, category, key, defaultValue);
};

/**
 * Get all settings for a category
 */
export const getCategorySettings = async (userId, category) => {
    return await Settings.getCategorySettings(userId, category);
};

/**
 * Get all user settings (across all categories)
 */
export const getUserSettings = async (userId) => {
    const settings = await Settings.find({ userId, scope: 'user' });
    const result = {};

    settings.forEach(setting => {
        if (!result[setting.category]) {
            result[setting.category] = {};
        }
        result[setting.category][setting.key] = setting.value;
    });

    // Merge with system and default settings
    const categories = [...new Set(settings.map(s => s.category))];
    for (const category of categories) {
        const categorySettings = await Settings.getCategorySettings(userId, category);
        if (!result[category]) {
            result[category] = {};
        }
        Object.assign(result[category], categorySettings);
    }

    return result;
};

/**
 * Set or update a setting
 */
export const setSetting = async (userId, category, key, value, options = {}) => {
    // Validate data type if provided
    if (options.dataType) {
        value = validateDataType(value, options.dataType);
    }

    return await Settings.setSetting(userId, category, key, value, {
        ...options,
        createdBy: userId,
    });
};

/**
 * Set multiple settings at once
 */
export const setMultipleSettings = async (userId, category, settings) => {
    const operations = Object.entries(settings).map(([key, config]) => {
        const value = typeof config === 'object' && config !== null && 'value' in config
            ? config.value
            : config;

        const options = typeof config === 'object' && config !== null && 'value' in config
            ? config
            : {};

        return Settings.setSetting(userId, category, key, value, {
            ...options,
            createdBy: userId,
        });
    });

    return await Promise.all(operations);
};

/**
 * Delete a user setting (reverts to system/default)
 */
export const deleteUserSetting = async (userId, category, key) => {
    const setting = await Settings.findOne({ userId, category, key, scope: 'user' });
    if (!setting) {
        throw new ApiError(httpStatus.NOT_FOUND, 'Setting not found');
    }

    await Settings.deleteOne({ _id: setting._id });
    return { message: 'Setting deleted, will use system default' };
};

/**
 * Get system-wide settings (admin only)
 */
export const getSystemSettings = async (category = null) => {
    const query = { scope: 'system' };
    if (category) {
        query.category = category;
    }

    const settings = await Settings.find(query);
    const result = {};

    settings.forEach(setting => {
        if (!result[setting.category]) {
            result[setting.category] = {};
        }
        result[setting.category][setting.key] = {
            value: setting.value,
            dataType: setting.dataType,
            description: setting.description,
            isEditable: setting.isEditable,
        };
    });

    return result;
};

/**
 * Set system-wide setting (admin only)
 */
export const setSystemSetting = async (category, key, value, options = {}) => {
    return await Settings.setSetting(null, category, key, value, {
        ...options,
        scope: 'system',
    });
};

/**
 * Initialize default settings for a new feature
 */
export const initializeFeatureDefaults = async (category, defaults, version = '1.0.0') => {
    return await Settings.initializeDefaults(category, defaults, version);
};

/**
 * Validate data type
 */
const validateDataType = (value, dataType) => {
    switch (dataType) {
        case 'number':
            const num = Number(value);
            if (isNaN(num)) {
                throw new ApiError(httpStatus.BAD_REQUEST, `Invalid number value: ${value}`);
            }
            return num;
        case 'boolean':
            if (typeof value === 'string') {
                return value.toLowerCase() === 'true' || value === '1';
            }
            return Boolean(value);
        case 'object':
            if (typeof value === 'string') {
                try {
                    return JSON.parse(value);
                } catch {
                    throw new ApiError(httpStatus.BAD_REQUEST, `Invalid JSON object: ${value}`);
                }
            }
            return value;
        case 'array':
            if (typeof value === 'string') {
                try {
                    const parsed = JSON.parse(value);
                    if (!Array.isArray(parsed)) {
                        throw new Error('Not an array');
                    }
                    return parsed;
                } catch {
                    throw new ApiError(httpStatus.BAD_REQUEST, `Invalid JSON array: ${value}`);
                }
            }
            if (!Array.isArray(value)) {
                throw new ApiError(httpStatus.BAD_REQUEST, `Value must be an array`);
            }
            return value;
        case 'string':
        default:
            return String(value);
    }
};

