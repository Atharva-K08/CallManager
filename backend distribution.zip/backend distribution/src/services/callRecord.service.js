import httpStatus from 'http-status';
import { CallRecord, Lead } from '../models/index.js';
import ApiError from '../utils/ApiError.js';

// Escape user-provided search strings for safe use in Mongo $regex
const escapeRegex = (value = '') => {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
};

export const createCallRecord = async (body) => {
    // Temporary patch: Subtract 5 hours 30 minutes from datetime fields (UTC+5:30 to UTC)
    const timezoneOffset = 5 * 60 * 60 * 1000 + 30 * 60 * 1000; // 5 hours 30 minutes in milliseconds

    const adjustedBody = { ...body };

    // Adjust datetime fields if they exist
    if (adjustedBody.initiatedAt) {
        adjustedBody.initiatedAt = new Date(new Date(adjustedBody.initiatedAt).getTime() - timezoneOffset);
    }
    if (adjustedBody.connectedAt) {
        adjustedBody.connectedAt = new Date(new Date(adjustedBody.connectedAt).getTime() - timezoneOffset);
    }
    if (adjustedBody.endedAt) {
        adjustedBody.endedAt = new Date(new Date(adjustedBody.endedAt).getTime() - timezoneOffset);
    }
    // if (adjustedBody.createdAt) {
    //     adjustedBody.createdAt = new Date(new Date(adjustedBody.createdAt).getTime() - timezoneOffset);
    // }
    // if (adjustedBody.updatedAt) {
    //     adjustedBody.updatedAt = new Date(new Date(adjustedBody.updatedAt).getTime() - timezoneOffset);
    // }

    const doc = await CallRecord.create(adjustedBody);
    return doc;
};

export const queryCallRecords = async (filter, options) => {
    const { page = 1, limit = 10, sortBy = 'initiatedAt:desc' } = options || {};
    const [sortField, sortOrder] = sortBy.split(':');
    const sort = { [sortField]: sortOrder === 'asc' ? 1 : -1 };
    const query = {};

    // Build search conditions
    const searchConditions = [];
    let searchLeadIds = null; // Store leadIds that match search in lead name

    if (filter?.search) {
        const raw = String(filter.search || '').trim();
        const escaped = escapeRegex(raw);
        // Also build a cleaned phone variant to try exact match
        const cleanedPhone = raw.replace(/[\s\-()]/g, '');
        const phoneVariants = [raw, cleanedPhone, cleanedPhone.startsWith('+') ? cleanedPhone.slice(1) : `+${cleanedPhone}`];

        // First, find leads that match the search term by firstName or lastName
        const matchingLeads = await Lead.find({
            $or: [
                { firstName: { $regex: escaped, $options: 'i' } },
                { lastName: { $regex: escaped, $options: 'i' } }
            ]
        }).select('_id').lean();
        searchLeadIds = matchingLeads.map(l => l._id);

        searchConditions.push({
            $or: [
                { contactName: { $regex: escaped, $options: 'i' } },
                { deviceInfo: { $regex: escaped, $options: 'i' } },
                // Prefer exact matches for phoneNumber to avoid regex pitfalls with '+'
                { phoneNumber: { $in: phoneVariants.filter(Boolean) } },
                { phoneNumber: { $regex: escaped, $options: 'i' } },
                // Search in leadId if any leads match
                ...(searchLeadIds.length > 0 ? [{ leadId: { $in: searchLeadIds } }] : []),
            ],
        });
    }

    // Build date range conditions
    if (filter?.from || filter?.to) {
        query.initiatedAt = {};
        if (filter.from) query.initiatedAt.$gte = new Date(filter.from);
        if (filter.to) query.initiatedAt.$lte = new Date(filter.to);
    }

    // Combine all conditions with $and
    const allConditions = [];
    if (searchConditions.length > 0) allConditions.push(...searchConditions);

    if (allConditions.length > 0) {
        query.$and = allConditions;
    }

    if (filter?.status) query.status = filter.status;
    if (filter?.source) query.source = filter.source;
    if (filter?.isOutgoing !== undefined) query.isOutgoing = filter.isOutgoing === 'true' || filter.isOutgoing === true;
    if (filter?.createdBy) query.createdBy = filter.createdBy;
    if (filter?.leadId) query.leadId = filter.leadId;

    const skip = (Number(page) - 1) * Number(limit);
    const [results, total] = await Promise.all([
        CallRecord.find(query).sort(sort).skip(skip).limit(Number(limit)).populate('createdBy', 'name email').populate('leadId', 'firstName lastName phoneNumber'),
        CallRecord.countDocuments(query),
    ]);
    return { results, page: Number(page), limit: Number(limit), totalResults: total, totalPages: Math.ceil(total / Number(limit) || 1) };
};

export const getCallRecordById = async (id) => {
    return CallRecord.findById(id).populate('createdBy', 'name email').populate('leadId', 'firstName lastName phoneNumber');
};

export const updateCallRecordById = async (id, updateBody) => {
    const doc = await getCallRecordById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'Call record not found');
    Object.assign(doc, updateBody);
    await doc.save();
    return doc;
};

export const deleteCallRecordById = async (id) => {
    const doc = await getCallRecordById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'Call record not found');
    await doc.deleteOne();
    return true;
};

export const updateStatus = async (id, status) => {
    const doc = await getCallRecordById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'Call record not found');
    doc.updateStatus(status);
    await doc.save();
    return doc;
};

export const getCallStatistics = async (filter = {}) => {
    return await CallRecord.getCallStatistics(filter);
};

export const getCallRecordsByPhoneNumber = async (phoneNumber) => {
    return await CallRecord.find({ phoneNumber }).sort({ initiatedAt: -1 }).populate('createdBy', 'name email').populate('leadId', 'firstName lastName phoneNumber');
};

export const getCallRecordsByLeadId = async (leadId) => {
    return await CallRecord.find({ leadId }).sort({ initiatedAt: -1 }).populate('createdBy', 'name email');
};

export const syncUpload = async (items = []) => {
    // Temporary patch: Subtract 5 hours 30 minutes from datetime fields (UTC+5:30 to UTC)
    const timezoneOffset = 5 * 60 * 60 * 1000 + 30 * 60 * 1000; // 5 hours 30 minutes in milliseconds

    // Upsert by client-provided id stored in metadata.clientId
    const results = [];
    for (const item of items) {
        // Adjust datetime for filter
        const adjustedInitiatedAt = new Date(new Date(item.initiatedAt).getTime() - timezoneOffset);

        const filter = {
            phoneNumber: item.phoneNumber,
            initiatedAt: adjustedInitiatedAt,
            createdBy: item.createdBy
        };

        // Adjust all datetime fields in update
        const update = {
            phoneNumber: item.phoneNumber,
            contactName: item.contactName ?? null,
            initiatedAt: adjustedInitiatedAt,
            connectedAt: item.connectedAt ? new Date(new Date(item.connectedAt).getTime() - timezoneOffset) : null,
            endedAt: item.endedAt ? new Date(new Date(item.endedAt).getTime() - timezoneOffset) : null,
            durationSeconds: item.durationSeconds ?? null,
            status: item.status,
            source: item.source,
            isOutgoing: item.isOutgoing,
            deviceInfo: item.deviceInfo ?? null,
            metadata: item.metadata ?? null,
            outcomeLabel: item.outcomeLabel ?? null,
            leadId: item.leadId ?? null,
            createdBy: item.createdBy,
            createdAt: item.createdAt ? new Date(new Date(item.createdAt).getTime() - timezoneOffset) : new Date(),
            updatedAt: item.updatedAt ? new Date(new Date(item.updatedAt).getTime() - timezoneOffset) : new Date(),
            isSynced: true,
            syncedAt: new Date(),
        };
        const doc = await CallRecord.findOneAndUpdate(filter, update, { new: true, upsert: true, setDefaultsOnInsert: true });
        results.push(doc);
    }
    return { success: true, imported: results.length };
};

export const syncPull = async (since, limit = 100) => {
    const sinceDate = new Date(since);
    const results = await CallRecord.find({ updatedAt: { $gt: sinceDate } }).sort({ updatedAt: 1 }).limit(Number(limit));
    return { results };
};

export default {
    createCallRecord,
    queryCallRecords,
    getCallRecordById,
    updateCallRecordById,
    deleteCallRecordById,
    updateStatus,
    getCallStatistics,
    getCallRecordsByPhoneNumber,
    getCallRecordsByLeadId,
    syncUpload,
    syncPull,
};

