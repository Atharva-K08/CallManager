import httpStatus from 'http-status';
import bcrypt from 'bcryptjs';
import { User, CallRecord } from '../models/index.js';
import ApiError from '../utils/ApiError.js';
import { logActivity, logUpdate, logSimple } from '../middlewares/activityLog.middleware.js';

/**
 * Create a user
 * @param {Object} userBody
 * @returns {Promise<User>}
 */
const createUser = async (userBody) => {
    if (await User.isEmailTaken(userBody.email)) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'Email already taken');
    }
    userBody.password = await bcrypt.hash(userBody.password, 10);

    const user = await User.create(userBody);
    return user;
};

/**
 * Custom pagination function
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default: 10)
 * @param {number} [options.page] - Current page (default: 1)
 * @returns {Promise<QueryResult>}
 */
const queryUsers = async (filter, options) => {
    const page = parseInt(options.page) || 1;
    const limit = parseInt(options.limit) || 10;
    const skip = (page - 1) * limit;

    // Build sort object
    let sort = {};
    if (options.sortBy) {
        const parts = options.sortBy.split(':');
        sort[parts[0]] = parts[1] === 'desc' ? -1 : 1;
    } else {
        sort = { createdAt: -1 }; // Default sort by creation date
    }

    // Execute query with pagination
    const [users, total] = await Promise.all([
        User.find(filter)
            .sort(sort)
            .skip(skip)
            .limit(limit)
            .lean(),
        User.countDocuments(filter)
    ]);

    const totalPages = Math.ceil(total / limit);

    return {
        results: users,
        page,
        limit,
        totalPages,
        totalResults: total,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
    };
};

/**
 * Get user by id
 * @param {ObjectId} id
 * @returns {Promise<User>}
 */
const getUserById = async (id) => {
    const user = await User.findById(id);
    if (!user) {
        throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
    }
    return user;
};

/**
 * Get user by email
 * @param {string} email
 * @returns {Promise<User>}
 */
const getUserByEmail = async (email) => {
    const user = await User.findOne({ email });
    if (!user) {
        throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
    }
    return user;
};

/**
 * Update user by id
 * @param {ObjectId} userId
 * @param {Object} updateBody
 * @returns {Promise<User>}
 */
const updateUserById = async (userId, updateBody) => {
    const user = await getUserById(userId);

    // Check if email is being updated and if it's already taken
    if (updateBody.email && (await User.isEmailTaken(updateBody.email, userId))) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'Email already taken');
    }

    Object.assign(user, updateBody);
    await user.save();
    return user;
};

/**
 * Delete user by id
 * @param {ObjectId} userId
 * @returns {Promise<User>}
 */
const deleteUserById = async (userId) => {
    const user = await getUserById(userId);
    await user.remove();
    return user;
};

/**
 * Activate user by id
 * @param {ObjectId} userId
 * @returns {Promise<User>}
 */
const activateUserById = async (userId) => {
    const user = await getUserById(userId);
    user.isActive = true;
    await user.save();
    return user;
};

/**
 * Deactivate user by id
 * @param {ObjectId} userId
 * @returns {Promise<User>}
 */
const deactivateUserById = async (userId) => {
    const user = await getUserById(userId);
    user.isActive = false;
    await user.save();
    return user;
};

/**
 * Update user password
 * @param {ObjectId} userId
 * @param {string} currentPassword
 * @param {string} newPassword
 * @returns {Promise<User>}
 */
const updateUserPassword = async (userId, currentPassword, newPassword) => {
    const user = await getUserById(userId);

    if (!(await user.isPasswordMatch(currentPassword))) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'Current password is incorrect');
    }

    // Validate new password format (same as user model validation)
    if (newPassword.length < 8) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'Password must be at least 8 characters long');
    }
    if (!newPassword.match(/\d/) || !newPassword.match(/[a-zA-Z]/)) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'Password must contain at least one letter and one number');
    }

    // Hash the new password before saving
    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();
    return user;
};

/**
 * Update user password by admin (without current password)
 * @param {ObjectId} userId
 * @param {string} newPassword
 * @returns {Promise<User>}
 */
const updateUserPasswordByAdmin = async (userId, newPassword) => {
    const user = await getUserById(userId);

    // Validate new password format (same as user model validation)
    if (newPassword.length < 8) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'Password must be at least 8 characters long');
    }
    if (!newPassword.match(/\d/) || !newPassword.match(/[a-zA-Z]/)) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'Password must contain at least one letter and one number');
    }

    // Hash the new password before saving
    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();
    return user;
};

/**
 * Search users by query
 * @param {string} query
 * @param {Object} options
 * @returns {Promise<QueryResult>}
 */
const searchUsers = async (query, options = {}) => {
    const searchFilter = {
        $or: [
            { name: { $regex: query, $options: 'i' } },
            { email: { $regex: query, $options: 'i' } },
            { phoneNumber: { $regex: query, $options: 'i' } },
        ],
    };

    // Add role filter if provided
    if (options.role) {
        searchFilter.role = options.role;
    }

    // Add active status filter if provided
    if (options.isActive !== undefined) {
        searchFilter.isActive = options.isActive;
    }

    // Use custom pagination for search
    const page = parseInt(options.page) || 1;
    const limit = parseInt(options.limit) || 10;
    const skip = (page - 1) * limit;

    // Build sort object
    let sort = {};
    if (options.sortBy) {
        const parts = options.sortBy.split(':');
        sort[parts[0]] = parts[1] === 'desc' ? -1 : 1;
    } else {
        sort = { createdAt: -1 }; // Default sort by creation date
    }

    // Execute search query with pagination
    const [users, total] = await Promise.all([
        User.find(searchFilter)
            .select('name email role phoneNumber profilePicture isActive createdAt')
            .sort(sort)
            .skip(skip)
            .limit(limit)
            .lean(),
        User.countDocuments(searchFilter)
    ]);

    const totalPages = Math.ceil(total / limit);

    return {
        results: users,
        page,
        limit,
        totalPages,
        totalResults: total,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
    };
};

/**
 * Get user statistics
 * @param {Object} filters
 * @returns {Promise<Object>}
 */
const getUserStats = async (filters = {}) => {
    const matchFilter = {};

    if (filters.startDate || filters.endDate) {
        matchFilter.createdAt = {};
        if (filters.startDate) matchFilter.createdAt.$gte = new Date(filters.startDate);
        if (filters.endDate) matchFilter.createdAt.$lte = new Date(filters.endDate);
    }

    const [
        totalUsers,
        activeUsers,
        inactiveUsers,
        roleStats,
        recentUsers,
        monthlyStats
    ] = await Promise.all([
        User.countDocuments(matchFilter),
        User.countDocuments({ ...matchFilter, isActive: true }),
        User.countDocuments({ ...matchFilter, isActive: false }),
        User.aggregate([
            { $match: matchFilter },
            { $group: { _id: '$role', count: { $sum: 1 } } },
            { $sort: { count: -1 } }
        ]),
        User.find(matchFilter)
            .select('name email role createdAt')
            .sort({ createdAt: -1 })
            .limit(5)
            .lean(),
        User.aggregate([
            { $match: matchFilter },
            {
                $group: {
                    _id: {
                        year: { $year: '$createdAt' },
                        month: { $month: '$createdAt' }
                    },
                    count: { $sum: 1 }
                }
            },
            { $sort: { '_id.year': -1, '_id.month': -1 } },
            { $limit: 12 }
        ])
    ]);

    return {
        totalUsers,
        activeUsers,
        inactiveUsers,
        roleStats,
        recentUsers,
        monthlyStats
    };
};

/**
 * Get user profile (public information)
 * @param {ObjectId} userId
 * @returns {Promise<Object>}
 */
const getUserProfile = async (userId) => {
    const user = await getUserById(userId);
    return {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        phoneNumber: user.phoneNumber,
        profilePicture: user.profilePicture,
        isActive: user.isActive,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
    };
};

/**
 * Update user profile (limited fields)
 * @param {ObjectId} userId
 * @param {Object} updateBody
 * @returns {Promise<User>}
 */
const updateUserProfile = async (userId, updateBody) => {
    const allowedFields = ['name', 'phoneNumber', 'profilePicture'];
    const filteredUpdate = {};

    Object.keys(updateBody).forEach(key => {
        if (allowedFields.includes(key)) {
            filteredUpdate[key] = updateBody[key];
        }
    });

    if (Object.keys(filteredUpdate).length === 0) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'No valid fields to update');
    }

    return updateUserById(userId, filteredUpdate);
};

/**
 * Check if user exists and is active
 * @param {ObjectId} userId
 * @returns {Promise<boolean>}
 */
const isUserActive = async (userId) => {
    const user = await User.findById(userId).select('isActive');
    return user && user.isActive;
};

/**
 * Get users by role
 * @param {string} role
 * @param {Object} options
 * @returns {Promise<QueryResult>}
 */
const getUsersByRole = async (role, options = {}) => {
    const filter = { role, isActive: true };
    return queryUsers(filter, options);
};

/**
 * Bulk update users
 * @param {Array} userIds
 * @param {Object} updateData
 * @returns {Promise<Object>}
 */
const bulkUpdateUsers = async (userIds, updateData) => {
    const result = await User.updateMany(
        { _id: { $in: userIds } },
        updateData
    );
    return result;
};

/**
 * Bulk delete users
 * @param {Array} userIds
 * @returns {Promise<Object>}
 */
const bulkDeleteUsers = async (userIds) => {
    const result = await User.deleteMany({ _id: { $in: userIds } });
    return result;
};

/**
 * Check if any admin user exists
 * @returns {Promise<boolean>}
 */
const hasAdminUser = async () => {
    const adminCount = await User.countDocuments({ role: 'admin' });
    return adminCount > 0;
};

/**
 * Create first admin user
 * @param {Object} userBody
 * @returns {Promise<User>}
 */
const createFirstAdmin = async (userBody) => {
    // Check if any admin already exists
    const adminExists = await hasAdminUser();
    if (adminExists) {
        throw new ApiError(httpStatus.FORBIDDEN, 'Admin user already exists');
    }

    // Force role to admin for first admin
    const adminData = {
        ...userBody,
        role: 'admin',
        isEmailVerified: true, // Auto-verify first admin
        password: await bcrypt.hash(userBody.password, 10),
        isActive: true
    };

    if (await User.isEmailTaken(adminData.email)) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'Email already taken');
    }

    const user = await User.create(adminData);
    return user;
};

/**
 * Get callers (users with recent calls) with call statistics
 * @param {Object} options - Query options
 * @param {number} [options.limit] - Maximum number of results (default: 10)
 * @param {number} [options.page] - Current page (default: 1)
 * @param {string} [options.from] - Filter calls from this date
 * @param {string} [options.to] - Filter calls to this date
 * @param {string} [options.sortBy] - Sort option (default: 'lastCall:desc')
 * @returns {Promise<QueryResult>}
 */
const getCallersWithStats = async (options = {}) => {
    const page = parseInt(options.page) || 1;
    const limit = parseInt(options.limit) || 10;
    const skip = (page - 1) * limit;

    // Build date filter for call records
    const callFilter = {};
    if (options.from || options.to) {
        callFilter.initiatedAt = {};
        if (options.from) callFilter.initiatedAt.$gte = new Date(options.from);
        if (options.to) callFilter.initiatedAt.$lte = new Date(options.to);
    }

    // Aggregation pipeline to get users with call statistics
    const pipeline = [
        // Match call records with date filter
        {
            $match: {
                createdBy: { $exists: true, $ne: null },
                ...callFilter
            }
        },
        // Group by createdBy (user) to calculate statistics
        {
            $group: {
                _id: '$createdBy',
                totalCalls: { $sum: 1 },
                outgoingCalls: {
                    $sum: { $cond: [{ $eq: ['$isOutgoing', true] }, 1, 0] }
                },
                incomingCalls: {
                    $sum: { $cond: [{ $eq: ['$isOutgoing', false] }, 1, 0] }
                },
                connectedCalls: {
                    $sum: {
                        $cond: [
                            {
                                $in: [
                                    '$status',
                                    [
                                        'CALL_CONNECTED',
                                        'CALL_ACTIVE',
                                        'CALL_ENDED_CONNECTED',
                                        'CALL_ENDED_BY_CALLER',
                                        'CALL_ENDED_BY_CALLEE'
                                    ]
                                ]
                            },
                            1,
                            0
                        ]
                    }
                },
                missedCalls: {
                    $sum: {
                        $cond: [
                            {
                                $in: [
                                    '$status',
                                    [
                                        'CALL_NO_ANSWER',
                                        'CALL_ENDED_NO_ANSWER',
                                        'CALL_DECLINED_BY_LEAD',
                                        'CALL_DECLINED_BY_CALLEE',
                                        'CALL_DECLINED_BY_CALLER',
                                        'CALL_MISSED'
                                    ]
                                ]
                            },
                            1,
                            0
                        ]
                    }
                },
                totalDuration: { $sum: '$durationSeconds' },
                avgDuration: { $avg: '$durationSeconds' },
                lastCallAt: { $max: '$initiatedAt' }
            }
        },
        // Lookup user details
        {
            $lookup: {
                from: 'users',
                localField: '_id',
                foreignField: '_id',
                as: 'user'
            }
        },
        // Unwind user array (should be single user)
        {
            $unwind: {
                path: '$user',
                preserveNullAndEmptyArrays: false // Only include users that exist
            }
        },
        // Filter active users only
        {
            $match: {
                'user.isActive': true
            }
        },
        // Project user fields with stats
        {
            $project: {
                _id: '$user._id',
                name: '$user.name',
                email: '$user.email',
                role: '$user.role',
                phoneNumber: '$user.phoneNumber',
                profilePicture: '$user.profilePicture',
                isActive: '$user.isActive',
                createdAt: '$user.createdAt',
                stats: {
                    totalCalls: '$totalCalls',
                    outgoingCalls: '$outgoingCalls',
                    incomingCalls: '$incomingCalls',
                    connectedCalls: '$connectedCalls',
                    missedCalls: '$missedCalls',
                    totalDuration: { $ifNull: ['$totalDuration', 0] },
                    avgDuration: { $ifNull: ['$avgDuration', 0] },
                    lastCallAt: '$lastCallAt'
                }
            }
        }
    ];

    // Determine sort order
    let sortField = 'stats.lastCallAt';
    let sortOrder = -1; // desc by default

    if (options.sortBy) {
        const parts = options.sortBy.split(':');
        if (parts[0] === 'lastCall' || parts[0] === 'lastCallAt') {
            sortField = 'stats.lastCallAt';
        } else if (parts[0] === 'totalCalls') {
            sortField = 'stats.totalCalls';
        } else if (parts[0] === 'name') {
            sortField = 'name';
        }
        sortOrder = parts[1] === 'asc' ? 1 : -1;
    }

    // Add sort stage after projection
    pipeline.push({
        $sort: { [sortField]: sortOrder }
    });

    // Get total count separately
    const countPipeline = [
        ...pipeline,
        {
            $count: 'total'
        }
    ];

    const [results, countResult] = await Promise.all([
        CallRecord.aggregate([...pipeline, { $skip: skip }, { $limit: limit }]),
        CallRecord.aggregate(countPipeline)
    ]);

    const total = countResult[0]?.total || 0;
    const totalPages = Math.ceil(total / limit);

    return {
        results,
        page,
        limit,
        totalPages,
        totalResults: total,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
    };
};

export {
    createUser,
    queryUsers,
    getUserById,
    getUserByEmail,
    updateUserById,
    deleteUserById,
    activateUserById,
    deactivateUserById,
    updateUserPassword,
    updateUserPasswordByAdmin,
    searchUsers,
    getUserStats,
    getUserProfile,
    updateUserProfile,
    isUserActive,
    getUsersByRole,
    bulkUpdateUsers,
    bulkDeleteUsers,
    hasAdminUser,
    createFirstAdmin,
    getCallersWithStats,
};
