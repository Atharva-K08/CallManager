import { Server } from 'socket.io';
import jwt from 'jsonwebtoken';
import config from '../config/config.js';
import { User } from '../models/index.js';

class WebSocketService {
    constructor() {
        this.io = null;
        this.connectedClients = new Map(); // userId -> socketId mapping
        this.heartbeatInterval = null;
        this.heartbeatTimeout = 30000; // 30 seconds
        this.pingInterval = 25000; // 25 seconds
    }

    /**
     * Initialize WebSocket server
     * @param {import('http').Server} httpServer - HTTP server instance
     */
    initialize(httpServer) {
        this.io = new Server(httpServer, {
            cors: {
                origin: process.env.FRONTEND_URL || "*",
                methods: ["GET", "POST"],
                credentials: true
            },
            transports: ['websocket', 'polling'],
            pingTimeout: 60000,
            pingInterval: 25000
        });

        this.setupMiddleware();
        this.setupEventHandlers();
        this.startHeartbeat();

        console.log('[WebSocket] Server initialized with heartbeat system');
    }

    /**
     * Setup authentication middleware
     */
    setupMiddleware() {
        this.io.use(async (socket, next) => {
            try {
                const token = socket.handshake.auth.token || socket.handshake.headers.authorization?.replace('Bearer ', '');

                if (!token) {
                    return next(new Error('Authentication token required'));
                }

                const decoded = jwt.verify(token, config.jwt.secret);
                const user = await User.findById(decoded.sub);

                if (!user) {
                    return next(new Error('User not found'));
                }

                socket.userId = user._id.toString();
                socket.userRole = user.role;
                socket.isAuthenticated = true;

                next();
            } catch (error) {
                console.error('[WebSocket] Authentication error:', error.message);
                next(new Error('Authentication failed'));
            }
        });
    }

    /**
     * Setup event handlers
     */
    setupEventHandlers() {
        this.io.on('connection', (socket) => {
            console.log(`[WebSocket] Client connected: ${socket.id} (User: ${socket.userId})`);

            // Store client connection
            this.connectedClients.set(socket.userId, {
                socketId: socket.id,
                connectedAt: new Date(),
                lastPing: new Date(),
                isAlive: true,
                userRole: socket.userRole
            });

            // Join user to their personal room
            socket.join(`user:${socket.userId}`);

            // Join admin users to admin room
            if (socket.userRole === 'admin' || socket.userRole === 'superAdmin') {
                socket.join('admin');
                console.log(`[WebSocket] Admin user joined admin room: ${socket.userId}`);
            }

            // Handle ping-pong heartbeat
            socket.on('ping', (data) => {
                this.handlePing(socket, data);
            });

            // Handle pong response
            socket.on('pong', (data) => {
                this.handlePong(socket, data);
            });

            // Handle client disconnect
            socket.on('disconnect', (reason) => {
                this.handleDisconnect(socket, reason);
            });

            // Handle client errors
            socket.on('error', (error) => {
                console.error(`[WebSocket] Client error for ${socket.userId}:`, error);
            });

            // Send connection confirmation
            socket.emit('connected', {
                message: 'Connected to server',
                timestamp: new Date().toISOString(),
                userId: socket.userId,
                serverTime: new Date().toISOString()
            });

            console.log(`[WebSocket] Client ${socket.id} fully connected and authenticated`);
        });
    }

    /**
     * Handle ping from client
     */
    handlePing(socket, data) {
        const clientInfo = this.connectedClients.get(socket.userId);
        if (clientInfo) {
            clientInfo.lastPing = new Date();
            clientInfo.isAlive = true;
        }

        // Respond with pong
        socket.emit('pong', {
            timestamp: new Date().toISOString(),
            serverTime: new Date().toISOString(),
            clientData: data
        });

        console.log(`[WebSocket] Ping received from ${socket.userId}, pong sent`);
    }

    /**
     * Handle pong from client
     */
    handlePong(socket, data) {
        const clientInfo = this.connectedClients.get(socket.userId);
        if (clientInfo) {
            clientInfo.lastPing = new Date();
            clientInfo.isAlive = true;
        }

        console.log(`[WebSocket] Pong received from ${socket.userId}`);
    }

    /**
     * Handle client disconnect
     */
    handleDisconnect(socket, reason) {
        console.log(`[WebSocket] Client disconnected: ${socket.id} (User: ${socket.userId}) - Reason: ${reason}`);

        if (socket.userId) {
            this.connectedClients.delete(socket.userId);
        }
    }

    /**
     * Start heartbeat monitoring
     */
    startHeartbeat() {
        this.heartbeatInterval = setInterval(() => {
            this.performHeartbeat();
        }, this.pingInterval);

        console.log(`[WebSocket] Heartbeat system started (interval: ${this.pingInterval}ms)`);
    }

    /**
     * Perform heartbeat check
     */
    performHeartbeat() {
        const now = new Date();
        const deadClients = [];

        // Check all connected clients
        for (const [userId, clientInfo] of this.connectedClients) {
            const timeSinceLastPing = now - clientInfo.lastPing;

            if (timeSinceLastPing > this.heartbeatTimeout) {
                console.log(`[WebSocket] Client ${userId} appears dead (last ping: ${timeSinceLastPing}ms ago)`);
                deadClients.push(userId);
                clientInfo.isAlive = false;
            } else {
                // Send ping to alive clients
                const socket = this.io.sockets.sockets.get(clientInfo.socketId);
                if (socket && socket.connected) {
                    socket.emit('ping', {
                        timestamp: now.toISOString(),
                        serverTime: now.toISOString()
                    });
                }
            }
        }

        // Remove dead clients
        deadClients.forEach(userId => {
            this.connectedClients.delete(userId);
            console.log(`[WebSocket] Removed dead client: ${userId}`);
        });

        // Log connection status
        console.log(`[WebSocket] Heartbeat check - Active clients: ${this.connectedClients.size}`);
    }

    /**
     * Broadcast to all connected clients
     */
    broadcast(event, data) {
        if (this.io) {
            this.io.emit(event, {
                ...data,
                timestamp: new Date().toISOString(),
                serverTime: new Date().toISOString()
            });
            console.log(`[WebSocket] Broadcasted event '${event}' to all clients`);
        }
    }

    /**
     * Send to specific user
     */
    sendToUser(userId, event, data) {
        if (this.io) {
            this.io.to(`user:${userId}`).emit(event, {
                ...data,
                timestamp: new Date().toISOString(),
                serverTime: new Date().toISOString()
            });
            console.log(`[WebSocket] Sent event '${event}' to user ${userId}`);
        }
    }

    /**
     * Send to admin users only
     */
    sendToAdmins(event, data) {
        if (this.io) {
            this.io.to('admin').emit(event, {
                ...data,
                timestamp: new Date().toISOString(),
                serverTime: new Date().toISOString()
            });
            console.log(`[WebSocket] Sent event '${event}' to admin users`);
        }
    }

    /**
     * Send to mobile clients only
     */
    sendToMobile(event, data) {
        if (this.io) {
            this.io.to('mobile').emit(event, {
                ...data,
                timestamp: new Date().toISOString(),
                serverTime: new Date().toISOString()
            });
            console.log(`[WebSocket] Sent event '${event}' to mobile clients`);
        }
    }

    /**
     * Get connection statistics
     */
    getConnectionStats() {
        const stats = {
            totalConnections: this.connectedClients.size,
            connectedClients: Array.from(this.connectedClients.entries()).map(([userId, info]) => ({
                userId,
                connectedAt: info.connectedAt,
                lastPing: info.lastPing,
                isAlive: info.isAlive,
                userRole: info.userRole
            })),
            serverTime: new Date().toISOString(),
            uptime: process.uptime()
        };

        return stats;
    }

    /**
     * Check if user is connected
     */
    isUserConnected(userId) {
        return this.connectedClients.has(userId);
    }

    /**
     * Get connected user info
     */
    getConnectedUser(userId) {
        return this.connectedClients.get(userId);
    }

    /**
     * Stop heartbeat system
     */
    stopHeartbeat() {
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
            this.heartbeatInterval = null;
            console.log('[WebSocket] Heartbeat system stopped');
        }
    }

    /**
     * Cleanup and shutdown
     */
    shutdown() {
        this.stopHeartbeat();
        if (this.io) {
            this.io.close();
            this.io = null;
        }
        this.connectedClients.clear();
        console.log('[WebSocket] Service shutdown complete');
    }
}

// Export singleton instance
export default new WebSocketService();
