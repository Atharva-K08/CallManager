import httpStatus from 'http-status';
import { FollowUp, Lead } from '../models/index.js';
import ApiError from '../utils/ApiError.js';

export const create = async (body, userId) => {
    const lead = await Lead.findById(body.leadId).select('_id');
    if (!lead) throw new ApiError(httpStatus.NOT_FOUND, 'Lead not found');
    const doc = await FollowUp.create({
        leadId: lead._id,
        dueAt: body.dueAt,
        note: body.note,
        status: body.status || 'PENDING',
        createdBy: userId,
        metadata: body.metadata,
    });
    return doc;
};

export const list = async (filter, options) => {
    const query = {};
    if (filter?.leadId) query.leadId = filter.leadId;
    if (filter?.status) query.status = filter.status;
    if (filter?.from || filter?.to) {
        query.dueAt = {};
        if (filter.from) query.dueAt.$gte = new Date(filter.from);
        if (filter.to) query.dueAt.$lte = new Date(filter.to);
    }
    const page = Number(options?.page || 1);
    const limit = Number(options?.limit || 20);
    const skip = (page - 1) * limit;
    const sort = { dueAt: 1 };
    const [results, total] = await Promise.all([
        FollowUp.find(query).populate('leadId', 'firstName lastName').populate('createdBy', 'name').sort(sort).skip(skip).limit(limit),
        FollowUp.countDocuments(query),
    ]);

    // Add dynamic status field to each follow-up
    const now = new Date();

    const resultsWithStatus = results.map(followUp => {
        const followUpObj = followUp.toObject ? followUp.toObject() : followUp;
        const dueAt = new Date(followUpObj.dueAt);
        const followUpStatus = followUpObj.status;

        // Only two statuses: overdue or upcoming
        // If status is DONE or CANCELLED, mark as upcoming (not overdue)
        let status = 'upcoming';
        if (followUpStatus !== 'DONE' && followUpStatus !== 'CANCELLED' && dueAt < now) {
            status = 'overdue';
        }

        return {
            ...followUpObj,
            dynamicStatus: status
        };
    });

    return { results: resultsWithStatus, page, limit, totalResults: total, totalPages: Math.ceil(total / limit || 1) };
};

export const getById = async (id) => FollowUp.findById(id).populate('leadId', 'firstName lastName').populate('createdBy', 'name');

export const updateById = async (id, updateBody) => {
    const doc = await FollowUp.findById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'FollowUp not found');
    Object.assign(doc, updateBody);
    await doc.save();
    return doc;
};

export const removeById = async (id) => {
    const doc = await FollowUp.findById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'FollowUp not found');
    await doc.deleteOne();
    return true;
};

export const resolveFollowUp = async (id, resolutionData) => {
    const doc = await FollowUp.findById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'FollowUp not found');

    // Update metadata with resolution info
    doc.metadata = {
        ...doc.metadata,
        ...resolutionData
    };

    await doc.save();
    return doc;
};

export const unresolveFollowUp = async (id, userId) => {
    const doc = await FollowUp.findById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'FollowUp not found');

    // Remove resolution from metadata
    if (doc.metadata) {
        delete doc.metadata.resolutionStatus;
        delete doc.metadata.resolvedBy;
        delete doc.metadata.resolvedAt;
        delete doc.metadata.resolutionReason;
    }

    await doc.save();
    return doc;
};

export const getResolvedFollowUps = async (filter, options) => {
    const query = { 'metadata.resolutionStatus': 'RESOLVED' };
    if (filter?.resolvedBy) query['metadata.resolvedBy'] = filter.resolvedBy;
    if (filter?.from || filter?.to) {
        query['metadata.resolvedAt'] = {};
        if (filter.from) query['metadata.resolvedAt'].$gte = new Date(filter.from);
        if (filter.to) query['metadata.resolvedAt'].$lte = new Date(filter.to);
    }

    return list(query, options);
};

export default { create, list, getById, updateById, removeById, resolveFollowUp, unresolveFollowUp, getResolvedFollowUps };


