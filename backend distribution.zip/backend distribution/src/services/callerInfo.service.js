import httpStatus from 'http-status';
import ApiError from '../utils/ApiError.js';
import { Lead } from '../models/index.js';

/**
 * Lookup caller information by phone number
 * @param {string} phoneNumber - Phone number to lookup
 * @returns {Promise<Object>} Caller information object
 */
const lookupCaller = async (phoneNumber) => {
    // Validate phone number
    if (!phoneNumber || typeof phoneNumber !== 'string') {
        throw new ApiError(httpStatus.BAD_REQUEST, 'Valid phone number is required');
    }

    // Clean phone number and extract last 10 digits
    const cleanNumber = phoneNumber.replace(/[\s\-\(\)]/g, '');
    const last10Digits = cleanNumber.length >= 10
        ? cleanNumber.slice(-10)
        : cleanNumber;

    try {
        // Look up caller information in the Lead database using last 10 digits
        // Use $regex to match phone numbers that end with the last 10 digits
        const lead = await Lead.findOne({
            phoneNumber: {
                $regex: `${last10Digits}$`,
                $options: 'i'
            }
        }).select('firstName lastName phoneNumber campus status remark').lean();

        if (lead) {
            // Caller found in database
            return {
                name: `${lead.firstName} ${lead.lastName}`.trim(),
                campus: lead.campus,
                status: lead.status,
                remark: lead.remark,
                phone_number: last10Digits,
                found: true
            };
        } else {
            // Caller not found - return unknown status
            return {
                name: null,
                campus: null,
                status: null,
                remark: null,
                phone_number: last10Digits,
                found: false
            };
        }
    } catch (error) {
        // Log the error and return unknown status
        console.error('Error looking up caller information:', error);
        return {
            name: null,
            campus: null,
            status: null,
            remark: null,
            phone_number: last10Digits,
            found: false
        };
    }
};

export { lookupCaller };
