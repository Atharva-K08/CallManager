import xlsx from 'xlsx';
import { Lead, LeadStatus } from '../models/index.js';

// Keep consistent with lead.service.js behavior
const sanitizePhoneNumber = (phoneNumber = '') => {
    if (!phoneNumber) return '';
    const digitsOnly = String(phoneNumber).replace(/\D/g, '');
    return digitsOnly.slice(-10);
};

const normalizeHeader = (h = '') => String(h || '').trim().toLowerCase().replace(/\s+|_/g, '');

const headerAliases = {
    firstName: new Set(['firstname', 'first', 'fname']),
    lastName: new Set(['lastname', 'last', 'lname', 'surname']),
    phoneNumber: new Set(['phonenumber', 'phone', 'mobile', 'mobilenumber', 'contactnumber']),
    email: new Set(['email', 'emailaddress']),
    campus: new Set(['campus']),
    class: new Set(['class', 'grade', 'year']),
    city: new Set(['city', 'location']),
    source: new Set(['source'])
};

const mapHeaders = (headers = []) => {
    const mapping = {};
    headers.forEach((h, idx) => {
        const key = normalizeHeader(h);
        for (const [field, aliases] of Object.entries(headerAliases)) {
            if (aliases.has(key)) {
                mapping[field] = idx;
                return;
            }
        }
    });
    return mapping;
};

export const generateSampleWorkbook = () => {
    const headers = [
        'FirstName',
        'LastName',
        'PhoneNumber',
        'Email',
        'Campus',
        'Class',
        'City',
        'Source'
    ];

    const sampleRows = [
        ['John', 'Doe', '9876543210', 'john@example.com', 'North', 'MBA', 'New York', 'Website'],
        ['Jane', 'Smith', '9123456789', 'jane@example.com', 'South', 'BBA', 'Los Angeles', 'Referral']
    ];

    const worksheet = xlsx.utils.aoa_to_sheet([headers, ...sampleRows]);
    const workbook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(workbook, worksheet, 'Leads Sample');
    return xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });
};

const isValidEmail = (email = '') => {
    if (!email) return true;
    return /^(?:[^\s@]+)@(?:[^\s@]+)\.[^\s@]+$/.test(String(email).trim());
};

export const parseAndValidate = async (fileBuffer) => {
    const workbook = xlsx.read(fileBuffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const rows = xlsx.utils.sheet_to_json(worksheet, { header: 1, raw: false, defval: '' });

    if (!rows || rows.length === 0) {
        return { totalRows: 0, validCount: 0, invalidCount: 0, validRows: [], invalidRows: [] };
    }

    const headerRow = rows[0].map(h => String(h || '').trim());
    const headerMap = mapHeaders(headerRow);

    const requiredHeaders = ['firstName', 'lastName', 'phoneNumber'];
    const missingRequiredHeaders = requiredHeaders.filter(f => headerMap[f] === undefined);
    if (missingRequiredHeaders.length > 0) {
        return {
            totalRows: 0,
            validCount: 0,
            invalidCount: 1,
            validRows: [],
            invalidRows: [{ rowNumber: 1, data: {}, errors: [`Missing required headers: ${missingRequiredHeaders.join(', ')}`] }]
        };
    }

    // Preload existing phoneNumbers for duplicate detection
    const dataRows = rows.slice(1);
    const incomingPhones = new Set();
    for (const r of dataRows) {
        const raw = r[headerMap.phoneNumber];
        const sanitized = sanitizePhoneNumber(raw);
        if (sanitized) incomingPhones.add(sanitized);
    }
    const existing = await Lead.find({ phoneNumber: { $in: Array.from(incomingPhones) } }, { phoneNumber: 1 }).lean();
    const existingSet = new Set(existing.map(e => e.phoneNumber));

    const validRows = [];
    const invalidRows = [];

    dataRows.forEach((r, i) => {
        const rowNumber = i + 2; // +1 for zero-index, +1 for header
        const row = {
            firstName: String(r[headerMap.firstName] ?? '').trim(),
            lastName: String(r[headerMap.lastName] ?? '').trim(),
            phoneNumber: sanitizePhoneNumber(r[headerMap.phoneNumber]),
            email: String(r[headerMap.email] ?? '').trim() || undefined,
            campus: String(r[headerMap.campus] ?? '').trim() || undefined,
            class: String(r[headerMap.class] ?? '').trim() || undefined,
            city: String(r[headerMap.city] ?? '').trim() || undefined,
            source: String(r[headerMap.source] ?? '').trim() || undefined
        };

        const errors = [];
        if (!row.firstName) errors.push('First name is required');
        if (!row.lastName) errors.push('Last name is required');
        if (!row.phoneNumber || row.phoneNumber.length < 10) errors.push('Phone number must have at least 10 digits');
        if (row.email && !isValidEmail(row.email)) errors.push('Invalid email format');
        // Excluded fields are not validated or used

        // Duplicate by phoneNumber policy A: skip duplicates (mark invalid)
        if (row.phoneNumber && existingSet.has(row.phoneNumber)) {
            errors.push('Duplicate phone number');
        }

        if (errors.length > 0) {
            invalidRows.push({ rowNumber, data: row, errors });
        } else {
            validRows.push(row);
        }
    });

    return {
        totalRows: dataRows.length,
        validCount: validRows.length,
        invalidCount: invalidRows.length,
        validRows,
        invalidRows
    };
};

export const bulkInsert = async (validRows = [], user) => {
    if (!validRows || validRows.length === 0) return { imported: 0, skipped: 0 };

    // Get default import lead status (active leadStatus with isDefaultForImport=true)
    const defaultStatusDoc = await LeadStatus.findOne({
        type: 'leadStatus',
        isDefaultForImport: true,
        isActive: true
    }).lean();
    const defaultStatus = defaultStatusDoc?.name || 'New'; // Fallback to 'New' if no default set

    // Sanitize and prefilter duplicates against DB again (race-safe)
    // Set required fields: status is required, callStatus has default 'Not Called', priority has default 0
    const sanitized = validRows.map(v => ({
        ...v,
        phoneNumber: sanitizePhoneNumber(v.phoneNumber),
        status: v.status || defaultStatus, // Use dynamic default from system setting
        callStatus: v.callStatus || 'Not Called', // Default from model schema
        priority: v.priority !== undefined ? v.priority : 0, // Default from model schema
        createdBy: user?._id
    }));

    const phones = sanitized.map(v => v.phoneNumber).filter(Boolean);
    const existing = await Lead.find({ phoneNumber: { $in: phones } }, { phoneNumber: 1 }).lean();
    const existingSet = new Set(existing.map(e => e.phoneNumber));
    const toInsert = sanitized.filter(v => v.phoneNumber && !existingSet.has(v.phoneNumber));

    if (toInsert.length === 0) return { imported: 0, skipped: sanitized.length };

    await Lead.insertMany(toInsert, { ordered: false });
    return { imported: toInsert.length, skipped: sanitized.length - toInsert.length };
};

export default { generateSampleWorkbook, parseAndValidate, bulkInsert };


