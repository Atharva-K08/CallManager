import httpStatus from 'http-status';
import { LeadStatus } from '../models/index.js';
import ApiError from '../utils/ApiError.js';

export const createLeadStatus = async (body) => {
    const exists = await LeadStatus.findOne({ type: body.type, name: body.name });
    if (exists) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'Status with this name already exists for this type');
    }
    const doc = await LeadStatus.create(body);
    return doc;
};

export const queryLeadStatuses = async (filter, options) => {
    const { page = 1, limit = 10, sortBy = 'order:asc' } = options || {};
    const [sortField, sortOrder] = sortBy.split(':');
    const sort = { [sortField]: sortOrder === 'desc' ? -1 : 1 };

    const query = {};
    if (filter?.type) query.type = filter.type;
    if (filter?.isActive !== undefined) query.isActive = filter.isActive === 'true' || filter.isActive === true;
    if (filter?.search) query.name = { $regex: filter.search, $options: 'i' };

    const skip = (Number(page) - 1) * Number(limit);
    const [results, total] = await Promise.all([
        LeadStatus.find(query).sort(sort).skip(skip).limit(Number(limit)),
        LeadStatus.countDocuments(query),
    ]);

    return {
        results,
        page: Number(page),
        limit: Number(limit),
        totalResults: total,
        totalPages: Math.ceil(total / Number(limit) || 1),
    };
};

export const getLeadStatusById = async (id) => {
    const doc = await LeadStatus.findById(id);
    return doc;
};

export const updateLeadStatusById = async (id, updateBody) => {
    const doc = await getLeadStatusById(id);
    if (!doc) {
        throw new ApiError(httpStatus.NOT_FOUND, 'LeadStatus not found');
    }
    if (updateBody.name && updateBody.type) {
        const exists = await LeadStatus.findOne({ _id: { $ne: id }, type: updateBody.type, name: updateBody.name });
        if (exists) {
            throw new ApiError(httpStatus.BAD_REQUEST, 'Status with this name already exists for this type');
        }
    }
    Object.assign(doc, updateBody);
    await doc.save();
    return doc;
};

export const deleteLeadStatusById = async (id) => {
    const doc = await getLeadStatusById(id);
    if (!doc) {
        throw new ApiError(httpStatus.NOT_FOUND, 'LeadStatus not found');
    }
    await doc.deleteOne();
    return true;
};

export const setActiveState = async (id, active) => {
    const doc = await getLeadStatusById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'LeadStatus not found');
    doc.isActive = !!active;
    await doc.save();
    return doc;
};

export const getDefaultImportLeadStatus = async () => {
    const doc = await LeadStatus.findOne({
        type: 'leadStatus',
        isDefaultForImport: true,
        isActive: true
    }).lean();
    return doc;
};

export const setDefaultImportLeadStatus = async (id) => {
    const doc = await getLeadStatusById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'LeadStatus not found');
    
    // Validate it's a leadStatus type and is active
    if (doc.type !== 'leadStatus') {
        throw new ApiError(httpStatus.BAD_REQUEST, 'Only leadStatus type can be set as default for import');
    }
    if (!doc.isActive) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'Cannot set inactive status as default for import');
    }

    // Unset any existing default for leadStatus type
    await LeadStatus.updateMany(
        { type: 'leadStatus', isDefaultForImport: true },
        { $set: { isDefaultForImport: false } }
    );

    // Set this one as default
    doc.isDefaultForImport = true;
    await doc.save();
    return doc;
};

export default {
    createLeadStatus,
    queryLeadStatuses,
    getLeadStatusById,
    updateLeadStatusById,
    deleteLeadStatusById,
    setActiveState,
    getDefaultImportLeadStatus,
    setDefaultImportLeadStatus,
};


