import httpStatus from 'http-status';
import ApiError from '../utils/ApiError.js';
import { userService } from './index.js';
import * as tokenService from './token.service.js';
import { User } from '../models/index.js';

/**
 * Login with username and password
 * @param {string} email
 * @param {string} password
 * @returns {Promise<{user: User, tokens: Object}>}
 */
export const loginUserWithEmailAndPassword = async (email, password) => {
  // Find a regular user
  const user = await User.findOne({ email });
  if (!user || !(await user.isPasswordMatch(password))) {
    throw new ApiError(httpStatus.UNAUTHORIZED, 'Incorrect email or password');
  }
  // if user is not active, throw an error
  if (!user.isActive) {
    throw new ApiError(httpStatus.UNAUTHORIZED, 'User is not active');
  }
  delete user.password;
  const tokens = await tokenService.generateAuthTokens(user);
  return { user, tokens };
};

/**
 * Logout
 * @param {string} refreshToken
 * @returns {Promise}
 */
export const logout = async (refreshToken) => {
  const refreshTokenDoc = await tokenService.verifyToken(refreshToken, 'refresh');
  if (!refreshTokenDoc) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Not found');
  }
  await tokenService.deleteTokenDoc(refreshTokenDoc);
};

/**
 * Refresh auth tokens
 * @param {string} refreshToken
 * @returns {Promise<Object>}
 */
export const refreshAuth = async (refreshToken) => {
  const refreshTokenDoc = await tokenService.verifyToken(refreshToken, 'refresh');
  if (!refreshTokenDoc) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Not found');
  }
  const user = await userService.getUserById(refreshTokenDoc.user);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  await tokenService.deleteTokenDoc(refreshTokenDoc);
  const tokens = await tokenService.generateAuthTokens(user);
  return tokens;
}; 