import admin from 'firebase-admin';
import config from '../config/config.js';

// Debug logger gated by env
const __showFollowUpLogs = process.env.SHOWFOLLOWUPLOGS === 'true' || process.env.SHOW_FOLLOW_UP_LOGS === 'true';
const debug = (...args) => { if (__showFollowUpLogs) console.log('[FOLLOWUP-DEBUG][FCM]', ...args); };

// Initialize Firebase Admin SDK
let firebaseApp;
try {
    if (!admin.apps.length) {
        const serviceAccount = {
            type: 'service_account',
            project_id: config.firebase.projectId,
            private_key_id: config.firebase.privateKeyId,
            private_key: config.firebase.privateKey?.replace(/\\n/g, '\n'),
            client_email: config.firebase.clientEmail,
            client_id: config.firebase.clientId,
            auth_uri: 'https://accounts.google.com/o/oauth2/auth',
            token_uri: 'https://oauth2.googleapis.com/token',
            auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
            client_x509_cert_url: `https://www.googleapis.com/robot/v1/metadata/x509/${config.firebase.clientEmail}`,
        };

        firebaseApp = admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
            projectId: config.firebase.projectId,
        });
    } else {
        firebaseApp = admin.app();
    }
    debug('Firebase Admin initialized:', !!firebaseApp, 'projectId=', config.firebase?.projectId);
} catch (error) {
    console.error('❌ Firebase Admin SDK initialization failed:', error);
}

/**
 * Send FCM notification to a specific user
 */
export const sendFCMNotification = async (userId, notificationData) => {
    try {
        if (!firebaseApp) {
            throw new Error('Firebase Admin SDK not initialized');
        }

        const { title, body, data, imageUrl } = notificationData;
        // FCM requires data map values to be strings
        const stringData = Object.fromEntries(
            Object.entries(data || {}).map(([k, v]) => [k, v === null || v === undefined ? '' : String(v)])
        );
        debug('Preparing to send FCM to user:', userId, 'title=', title, 'data=', data);

        // Get user's FCM token from database
        const { User } = await import('../models/index.js');
        const user = await User.findById(userId).select('fcmToken');

        if (!user || !user.fcmToken) {
            console.log(`⚠️ No FCM token found for user ${userId}`);
            return { success: false, error: 'No FCM token found' };
        }
        debug('Found FCM token for user:', userId);

        // Prepare message
        const message = {
            token: user.fcmToken,
            notification: {
                title: title,
                body: body,
                imageUrl: imageUrl,
            },
            data: {
                ...stringData,
                timestamp: new Date().toISOString(),
            },
            android: {
                priority: 'high',
                notification: {
                    icon: 'ic_notification',
                    color: '#FF6B35',
                    sound: 'default',
                    channelId: data?.type?.startsWith('TASK_') ? 'task_notifications' : 'follow_up_reminders',
                },
            },
            apns: {
                payload: {
                    aps: {
                        alert: {
                            title: title,
                            body: body,
                        },
                        badge: 1,
                        sound: 'default',
                        category: data?.type?.startsWith('TASK_') ? 'TASK_NOTIFICATION' : 'FOLLOW_UP_REMINDER',
                    },
                },
            },
        };

        // Send notification
        const response = await admin.messaging().send(message);

        console.log(`✅ FCM notification sent successfully: ${response}`);
        debug('FCM send response:', response);

        return {
            success: true,
            messageId: response,
            userId: userId,
        };

    } catch (error) {
        console.error(`❌ Error sending FCM notification to user ${userId}:`, error);
        debug('FCM send error details:', error?.message);
        return {
            success: false,
            error: error.message,
            userId: userId,
        };
    }
};

/**
 * Send FCM notification to multiple users
 */
export const sendBulkFCMNotification = async (userIds, notificationData) => {
    try {
        if (!firebaseApp) {
            throw new Error('Firebase Admin SDK not initialized');
        }

        const { User } = await import('../models/index.js');
        const users = await User.find({ _id: { $in: userIds } }).select('fcmToken');

        const validTokens = users
            .filter(user => user.fcmToken)
            .map(user => user.fcmToken);

        if (validTokens.length === 0) {
            console.log('⚠️ No valid FCM tokens found for bulk notification');
            return { success: false, error: 'No valid FCM tokens found' };
        }

        const { title, body, data, imageUrl } = notificationData;

        // Prepare multicast message
        const message = {
            tokens: validTokens,
            notification: {
                title: title,
                body: body,
                imageUrl: imageUrl,
            },
            data: {
                ...data,
                timestamp: new Date().toISOString(),
            },
            android: {
                priority: 'high',
                notification: {
                    icon: 'ic_notification',
                    color: '#FF6B35',
                    sound: 'default',
                    channelId: 'follow_up_reminders',
                },
            },
            apns: {
                payload: {
                    aps: {
                        alert: {
                            title: title,
                            body: body,
                        },
                        badge: 1,
                        sound: 'default',
                        category: 'FOLLOW_UP_REMINDER',
                    },
                },
            },
        };

        // Send multicast notification
        const response = await admin.messaging().sendMulticast(message);

        console.log(`✅ Bulk FCM notification sent: ${response.successCount}/${response.failureCount}`);

        return {
            success: true,
            successCount: response.successCount,
            failureCount: response.failureCount,
            responses: response.responses,
        };

    } catch (error) {
        console.error('❌ Error sending bulk FCM notification:', error);
        return {
            success: false,
            error: error.message,
        };
    }
};

/**
 * Send FCM notification to topic subscribers
 */
export const sendTopicFCMNotification = async (topic, notificationData) => {
    try {
        if (!firebaseApp) {
            throw new Error('Firebase Admin SDK not initialized');
        }

        const { title, body, data, imageUrl } = notificationData;

        // Prepare message
        const message = {
            topic: topic,
            notification: {
                title: title,
                body: body,
                imageUrl: imageUrl,
            },
            data: {
                ...data,
                timestamp: new Date().toISOString(),
            },
            android: {
                priority: 'high',
                notification: {
                    icon: 'ic_notification',
                    color: '#FF6B35',
                    sound: 'default',
                    channelId: 'follow_up_reminders',
                },
            },
            apns: {
                payload: {
                    aps: {
                        alert: {
                            title: title,
                            body: body,
                        },
                        badge: 1,
                        sound: 'default',
                        category: 'FOLLOW_UP_REMINDER',
                    },
                },
            },
        };

        // Send topic notification
        const response = await admin.messaging().send(message);

        console.log(`✅ Topic FCM notification sent to ${topic}: ${response}`);

        return {
            success: true,
            messageId: response,
            topic: topic,
        };

    } catch (error) {
        console.error(`❌ Error sending topic FCM notification to ${topic}:`, error);
        return {
            success: false,
            error: error.message,
            topic: topic,
        };
    }
};

/**
 * Subscribe user to topic
 */
export const subscribeToTopic = async (fcmToken, topic) => {
    try {
        if (!firebaseApp) {
            throw new Error('Firebase Admin SDK not initialized');
        }

        const response = await admin.messaging().subscribeToTopic([fcmToken], topic);

        console.log(`✅ Subscribed to topic ${topic}: ${response.successCount} success, ${response.failureCount} failures`);

        return {
            success: true,
            successCount: response.successCount,
            failureCount: response.failureCount,
        };

    } catch (error) {
        console.error(`❌ Error subscribing to topic ${topic}:`, error);
        return {
            success: false,
            error: error.message,
        };
    }
};

/**
 * Unsubscribe user from topic
 */
export const unsubscribeFromTopic = async (fcmToken, topic) => {
    try {
        if (!firebaseApp) {
            throw new Error('Firebase Admin SDK not initialized');
        }

        const response = await admin.messaging().unsubscribeFromTopic([fcmToken], topic);

        console.log(`✅ Unsubscribed from topic ${topic}: ${response.successCount} success, ${response.failureCount} failures`);

        return {
            success: true,
            successCount: response.successCount,
            failureCount: response.failureCount,
        };

    } catch (error) {
        console.error(`❌ Error unsubscribing from topic ${topic}:`, error);
        return {
            success: false,
            error: error.message,
        };
    }
};

/**
 * Validate FCM token
 */
export const validateFCMToken = async (fcmToken) => {
    try {
        if (!firebaseApp) {
            throw new Error('Firebase Admin SDK not initialized');
        }

        // Try to send a test message to validate the token
        const message = {
            token: fcmToken,
            data: {
                test: 'true',
            },
        };

        await admin.messaging().send(message);

        return { valid: true };

    } catch (error) {
        console.error(`❌ FCM token validation failed:`, error);
        return { valid: false, error: error.message };
    }
};
