import { Lead, FollowUp } from '../models/index.js';
import { reminderQueue } from '../config/queue.js';
import { sendFCMNotification } from './fcm.service.js';
import websocketService from './websocket.service.js';

const __showFollowUpLogs = process.env.SHOWFOLLOWUPLOGS === 'true' || process.env.SHOW_FOLLOW_UP_LOGS === 'true';
const debug = (...args) => { if (__showFollowUpLogs) console.log('[FOLLOWUP-DEBUG][Service]', ...args); };

/**
 * Schedule a follow-up reminder
 */
export const scheduleFollowUpReminder = async (reminderData) => {
    try {
        const { followUpId, leadId, leadName, followUpDate, message, userId, userEmail, reminderIntervalDays = 7 } = reminderData;

        // Validate lead exists
        const lead = await Lead.findById(leadId);
        if (!lead) {
            throw new Error(`Lead ${leadId} not found`);
        }
        debug('Scheduling reminder for lead:', leadId, 'assignedTo=', lead.assignedTo?.toString?.());

        // Calculate delay until reminder
        const now = new Date();
        const reminderTime = new Date(followUpDate);
        const delay = reminderTime - now;

        if (delay <= 0) {
            throw new Error('Follow-up date must be in the future');
        }
        debug('Reminder delay ms:', delay);

        // Use existing follow-up if provided, otherwise create new one
        let followUp;
        if (followUpId) {
            // Use existing follow-up
            followUp = await FollowUp.findById(followUpId);
            if (!followUp) {
                throw new Error(`Follow-up ${followUpId} not found`);
            }
            debug('Using existing FollowUp id:', followUp._id.toString());
        } else {
            // Create new FollowUp document (no assignedTo, derive from lead when sending)
            followUp = await FollowUp.create({
                leadId: lead._id,
                dueAt: followUpDate,
                note: message,
                status: 'PENDING',
                createdBy: userId,
                metadata: { reminderIntervalDays },
            });
            debug('Created FollowUp id:', followUp._id.toString());
        }

        // Schedule Bull job
        const job = await reminderQueue.add(
            'follow-up-reminder',
            {
                followUpId: followUp._id.toString(),
                leadId,
                leadName,
                followUpDate,
                message,
                userId,
                userEmail,
                reminderIntervalDays,
            },
            {
                delay: delay,
                jobId: `followup-${followUp._id}-${Date.now()}`,
            }
        );
        debug('Scheduled job id:', job.id);

        console.log(`✅ Reminder scheduled for lead ${leadName} at ${followUpDate} (Job ID: ${job.id})`);

        return {
            success: true,
            jobId: job.id,
            followUpId: followUp._id,
            leadId,
            scheduledFor: followUpDate,
        };

    } catch (error) {
        console.error('❌ Error scheduling reminder:', error);
        debug('Schedule error:', error?.message);
        throw error;
    }
};

/**
 * Cancel a follow-up reminder
 */
export const cancelFollowUpReminder = async (leadId) => {
    try {
        debug('Cancelling reminders for lead:', leadId);
        // Find pending follow ups for this lead and cancel
        const followUps = await FollowUp.find({ leadId, status: 'PENDING' });
        for (const f of followUps) {
            f.status = 'CANCELLED';
            f.cancelledAt = new Date();
            await f.save();
            debug('Cancelled FollowUp:', f._id.toString());
        }

        // Cancel Bull job
        const jobs = await reminderQueue.getJobs(['delayed', 'waiting']);
        for (const job of jobs) {
            if (job.name === 'follow-up-reminder' && job.data.leadId === leadId) {
                await job.remove();
                console.log(`✅ Reminder cancelled for lead ${leadId} (Job ID: ${job.id})`);
                debug('Removed job id:', job.id);
            }
        }

        return {
            success: true,
            leadId,
            cancelled: true,
        };

    } catch (error) {
        console.error('❌ Error cancelling reminder:', error);
        debug('Cancel error:', error?.message);
        throw error;
    }
};

/**
 * Update a follow-up reminder
 */
export const updateFollowUpReminder = async (leadId, newReminderData) => {
    try {
        // Cancel existing reminder
        await cancelFollowUpReminder(leadId);

        // Schedule new reminder
        const result = await scheduleFollowUpReminder({
            ...newReminderData,
            leadId,
        });
        debug('Updated reminder result:', result);

        return result;

    } catch (error) {
        console.error('❌ Error updating reminder:', error);
        debug('Update error:', error?.message);
        throw error;
    }
};

/**
 * Get scheduled reminders for a user
 */
export const getScheduledReminders = async (userId) => {
    try {
        debug('Fetching scheduled reminders for user:', userId);
        const leads = await Lead.find({ assignedTo: userId }).select('_id firstName lastName');
        const leadIdToName = new Map(leads.map(l => [l._id.toString(), `${l.firstName} ${l.lastName}`.trim()]));
        const followUps = await FollowUp.find({
            leadId: { $in: [...leadIdToName.keys()] },
            status: 'PENDING',
        }).sort({ dueAt: 1 });
        debug('Found PENDING followUps:', followUps.length);

        return followUps.map(f => ({
            followUpId: f._id,
            leadId: f.leadId,
            leadName: leadIdToName.get(f.leadId.toString()) || 'Lead',
            followUpDate: f.dueAt,
            message: f.note,
            reminderIntervalDays: f.metadata?.reminderIntervalDays,
            isOverdue: f.dueAt < new Date(),
        }));

    } catch (error) {
        console.error('❌ Error getting scheduled reminders:', error);
        debug('Get scheduled error:', error?.message);
        throw error;
    }
};

/**
 * Get overdue reminders for a user
 */
export const getOverdueReminders = async (userId) => {
    try {
        debug('Fetching overdue reminders for user:', userId);
        const now = new Date();
        const leads = await Lead.find({ assignedTo: userId }).select('_id firstName lastName');
        const leadIdToName = new Map(leads.map(l => [l._id.toString(), `${l.firstName} ${l.lastName}`.trim()]));
        const followUps = await FollowUp.find({
            leadId: { $in: [...leadIdToName.keys()] },
            status: 'PENDING',
            dueAt: { $lt: now },
        }).sort({ dueAt: 1 });
        debug('Found overdue followUps:', followUps.length);

        return followUps.map(f => ({
            followUpId: f._id,
            leadId: f.leadId,
            leadName: leadIdToName.get(f.leadId.toString()) || 'Lead',
            followUpDate: f.dueAt,
            message: f.note,
            daysOverdue: Math.floor((now - f.dueAt) / (1000 * 60 * 60 * 24)),
        }));

    } catch (error) {
        console.error('❌ Error getting overdue reminders:', error);
        debug('Get overdue error:', error?.message);
        throw error;
    }
};

/**
 * Process overdue reminders (cron job)
 */
export const processOverdueReminders = async () => {
    try {
        console.log('🔄 Processing overdue reminders...');
        debug('Starting overdue processing');

        const now = new Date();
        const overdueFollowUps = await FollowUp.find({ status: 'PENDING', dueAt: { $lt: now } }).lean();
        const leadIds = overdueFollowUps.map(f => f.leadId);
        const leads = await Lead.find({ _id: { $in: leadIds } }).populate('assignedTo', 'email fcmToken name').lean();
        const leadById = new Map(leads.map(l => [l._id.toString(), l]));

        if (overdueFollowUps.length === 0) {
            console.log('✅ No overdue reminders found');
            return { success: true, processed: 0 };
        }

        console.log(`📋 Found ${overdueFollowUps.length} overdue reminders`);

        const results = [];

        for (const f of overdueFollowUps) {
            try {
                const lead = leadById.get(f.leadId.toString());
                if (!lead) continue;
                const leadFullName = `${lead.firstName || ''} ${lead.lastName || ''}`.trim() || 'Lead';
                // Send FCM notification
                if (lead.assignedTo?.fcmToken) {
                    await sendFCMNotification(lead.assignedTo._id.toString(), {
                        title: 'Overdue Follow-up',
                        body: `Follow up with ${leadFullName} is overdue`,
                        data: {
                            type: 'overdue_reminder',
                            followUpId: f._id.toString(),
                            leadId: f.leadId.toString(),
                            leadName: leadFullName,
                        },
                    });
                    debug('Sent overdue FCM for followUp:', f._id.toString());
                }

                // Emit WebSocket event
                websocketService.sendToUser(lead.assignedTo?._id?.toString(), 'call_reminder', {
                    followUpId: f._id.toString(),
                    leadId: f.leadId.toString(),
                    leadName: leadFullName,
                    studentName: leadFullName,
                    followUpDate: f.dueAt,
                    message: 'Overdue follow-up reminder',
                    userId: lead.assignedTo?._id?.toString(),
                });

                results.push({
                    success: true,
                    followUpId: f._id.toString(),
                    leadId: f.leadId.toString(),
                    leadName: leadFullName,
                });

            } catch (error) {
                console.error(`❌ Error processing overdue reminder for followUp ${f._id}:`, error);
                debug('Overdue processing error:', f._id.toString(), error?.message);
                results.push({
                    success: false,
                    followUpId: f._id.toString(),
                    error: error.message,
                });
            }
        }

        const successCount = results.filter(r => r.success).length;
        console.log(`✅ Processed ${successCount}/${overdueFollowUps.length} overdue reminders`);

        return {
            success: true,
            processed: overdueFollowUps.length,
            successCount,
            results,
        };

    } catch (error) {
        console.error('❌ Error processing overdue reminders:', error);
        debug('Overdue batch error:', error?.message);
        throw error;
    }
};

/**
 * Schedule bulk reminders
 */
export const scheduleBulkReminders = async (reminders) => {
    try {
        const job = await reminderQueue.add(
            'bulk-reminders',
            { reminders },
            {
                jobId: `bulk-reminders-${Date.now()}`,
            }
        );

        console.log(`✅ Bulk reminders scheduled (Job ID: ${job.id})`);

        return {
            success: true,
            jobId: job.id,
            count: reminders.length,
        };

    } catch (error) {
        console.error('❌ Error scheduling bulk reminders:', error);
        throw error;
    }
};

/**
 * Get reminder statistics
 */
export const getReminderStatistics = async (userId) => {
    try {
        const now = new Date();
        const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);

        const [
            totalScheduled,
            overdue,
            upcoming,
            completed,
        ] = await Promise.all([
            Lead.countDocuments({
                assignedTo: userId,
                reminderScheduled: true,
            }),
            Lead.countDocuments({
                assignedTo: userId,
                reminderScheduled: true,
                followUpDate: { $lt: now },
            }),
            Lead.countDocuments({
                assignedTo: userId,
                reminderScheduled: true,
                followUpDate: { $gte: now, $lte: tomorrow },
            }),
            Lead.countDocuments({
                assignedTo: userId,
                reminderScheduled: false,
                followUpDate: { $exists: true },
            }),
        ]);

        return {
            totalScheduled,
            overdue,
            upcoming,
            completed,
        };

    } catch (error) {
        console.error('❌ Error getting reminder statistics:', error);
        throw error;
    }
};
