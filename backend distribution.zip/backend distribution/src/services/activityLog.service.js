import ActivityLog from '../models/activityLog.model.js';

/**
 * Create a new activity log entry
 * @param {Object} logData - The log data
 * @returns {Promise<Object|null>} Created activity log or null if error
 */
export const createActivityLog = async (logData) => {
    try {
        const activityLog = await ActivityLog.create(logData);
        return activityLog;
    } catch (error) {
        console.error('Error creating activity log:', error);
        // Don't throw - logging should not break the main flow
        return null;
    }
};

/**
 * Get activity logs with filtering and pagination
 * @param {Object} filters - Filter options
 * @returns {Promise<Object>} Paginated activity logs
 */
export const getActivityLogs = async (filters = {}) => {
    try {
        const {
            user,
            targetModel,
            targetId,
            action,
            startDate,
            endDate,
            page = 1,
            limit = 20
        } = filters;

        // Build query
        const query = {};
        if (user) query.user = user;
        if (targetModel) query.targetModel = targetModel;
        if (targetId) query.targetId = targetId;
        if (action) query.action = action;

        if (startDate || endDate) {
            query.createdAt = {};
            if (startDate) query.createdAt.$gte = new Date(startDate);
            if (endDate) query.createdAt.$lte = new Date(endDate);
        }

        // Calculate pagination
        const skip = (page - 1) * limit;

        // Execute query
        const [logs, total] = await Promise.all([
            ActivityLog.find(query)
                .populate('user', 'name email')
                .sort({ createdAt: -1 })
                .skip(skip)
                .limit(limit)
                .lean(),
            ActivityLog.countDocuments(query)
        ]);

        return {
            logs,
            pagination: {
                current_page: page,
                per_page: limit,
                total_items: total,
                total_pages: Math.ceil(total / limit)
            }
        };
    } catch (error) {
        console.error('Error fetching activity logs:', error);
        throw error;
    }
};

/**
 * Get activity logs for a specific target
 * @param {String} targetModel - Target model name
 * @param {String} targetId - Target document ID
 * @param {Number} limit - Number of logs to return
 * @returns {Promise<Array>} Activity logs for the target
 */
export const getTargetActivityLogs = async (targetModel, targetId, limit = 10) => {
    try {
        const logs = await ActivityLog.find({ targetModel, targetId })
            .populate('user', 'name email')
            .sort({ createdAt: -1 })
            .limit(limit)
            .lean();

        return logs;
    } catch (error) {
        console.error('Error fetching target activity logs:', error);
        throw error;
    }
};

/**
 * Get user activity logs
 * @param {String} userId - User ID
 * @param {Number} limit - Number of logs to return
 * @returns {Promise<Array>} User activity logs
 */
export const getUserActivityLogs = async (userId, limit = 20) => {
    try {
        const logs = await ActivityLog.find({ user: userId })
            .populate('user', 'name email')
            .sort({ createdAt: -1 })
            .limit(limit)
            .lean();

        return logs;
    } catch (error) {
        console.error('Error fetching user activity logs:', error);
        throw error;
    }
};

/**
 * Get activity statistics
 * @param {Object} filters - Filter options
 * @returns {Promise<Object>} Activity statistics
 */
export const getActivityStats = async (filters = {}) => {
    try {
        const query = {};

        if (filters.startDate || filters.endDate) {
            query.createdAt = {};
            if (filters.startDate) query.createdAt.$gte = new Date(filters.startDate);
            if (filters.endDate) query.createdAt.$lte = new Date(filters.endDate);
        }

        const [totalLogs, actionStats, targetStats] = await Promise.all([
            ActivityLog.countDocuments(query),
            ActivityLog.aggregate([
                { $match: query },
                { $group: { _id: '$action', count: { $sum: 1 } } },
                { $sort: { count: -1 } }
            ]),
            ActivityLog.aggregate([
                { $match: query },
                { $group: { _id: '$targetModel', count: { $sum: 1 } } },
                { $sort: { count: -1 } }
            ])
        ]);

        return {
            totalLogs,
            actionStats,
            targetStats
        };
    } catch (error) {
        console.error('Error fetching activity stats:', error);
        throw error;
    }
};

/**
 * Delete activity log (hard delete)
 * @param {String} logId - Log ID
 * @returns {Promise<Object>} Deleted log
 */
export const deleteActivityLog = async (logId) => {
    try {
        const log = await ActivityLog.findByIdAndDelete(logId);
        if (!log) {
            throw new Error('Activity log not found');
        }
        return log;
    } catch (error) {
        console.error('Error deleting activity log:', error);
        throw error;
    }
};

/**
 * Clean up old activity logs
 * @param {Number} daysOld - Number of days old logs to delete
 * @returns {Promise<Number>} Number of deleted logs
 */
export const cleanupOldLogs = async (daysOld = 365) => {
    try {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - daysOld);

        const result = await ActivityLog.deleteMany({
            createdAt: { $lt: cutoffDate }
        });

        console.log(`Cleaned up ${result.deletedCount} old activity logs`);
        return result.deletedCount;
    } catch (error) {
        console.error('Error cleaning up old logs:', error);
        throw error;
    }
};

// Legacy function stubs for backward compatibility
export const getProjectLogs = async (projectId, options = {}) => {
    return getTargetActivityLogs('Project', projectId, options.limit || 100);
};

export const getProjectLogStats = async (projectId, options = {}) => {
    return getActivityStats({
        targetModel: 'Project',
        targetId: projectId,
        ...options
    });
};