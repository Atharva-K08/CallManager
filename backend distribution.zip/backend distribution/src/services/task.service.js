import httpStatus from 'http-status';
import { Task, Lead } from '../models/index.js';
import ApiError from '../utils/ApiError.js';
import * as settingsService from './settings.service.js';

/**
 * Get current task counter value (without incrementing)
 */
const getCurrentTaskCounter = async () => {
    try {
        const currentCounter = await settingsService.getSetting(
            null,
            'tasks',
            'counter',
            0
        );
        return Number(currentCounter) || 0;
    } catch (error) {
        console.error('Error getting task counter:', error);
        return 0;
    }
};

/**
 * Increment task counter and return the new value
 */
export const incrementTaskCounter = async () => {
    try {
        // Get current counter value (default to 0 if not exists)
        const currentCounter = await getCurrentTaskCounter();

        // Increment counter
        const newCounter = currentCounter + 1;

        // Update counter setting (system-wide)
        await settingsService.setSystemSetting(
            'tasks',
            'counter',
            newCounter,
            {
                dataType: 'number',
                description: 'Task counter for auto-generating task numbers',
                isEditable: true,
            }
        );

        return newCounter;
    } catch (error) {
        console.error('Error incrementing task counter:', error);
        // Return a fallback value if counter fails
        return null;
    }
};

export const createTask = async (body) => {
    // Get current counter value (without incrementing) to calculate next task number
    let currentCounter = await getCurrentTaskCounter();

    // Fallback: if getting counter failed, get max taskNumber from existing tasks
    if (currentCounter === 0) {
        try {
            const maxTask = await Task.findOne({ taskNumber: { $ne: null } })
                .sort({ taskNumber: -1 })
                .select('taskNumber')
                .lean();
            if (maxTask?.taskNumber) {
                currentCounter = maxTask.taskNumber;
            }
        } catch (error) {
            console.error('Error getting fallback taskNumber:', error);
        }
    }

    // Calculate next task number (will be used after successful creation)
    const nextTaskNumber = currentCounter + 1;

    // Auto-generate title if missing or empty
    let title = body.title?.trim() || '';
    if (!title) {
        const leadCount = body.leadIds?.length || 0;
        const today = new Date();
        const dd = String(today.getDate()).padStart(2, '0');
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const yyyy = today.getFullYear();
        const todayDate = `${dd}-${mm}-${yyyy}`;

        const parts = [`Task #${nextTaskNumber}`];
        if (leadCount > 0) {
            parts.push(`${leadCount} lead${leadCount === 1 ? '' : 's'}`);
        }
        parts.push(todayDate);
        title = parts.join(' - ');
    }

    // Add taskNumber and generated title to the body
    const taskData = {
        ...body,
        taskNumber: nextTaskNumber,
        title: title,
    };

    // Create the task first
    const doc = await Task.create(taskData);

    // Only increment counter after successful task creation
    try {
        await incrementTaskCounter();
    } catch (error) {
        console.error('⚠️ Task created but failed to increment counter:', error);
        // Task is already created, so we continue - counter will be out of sync but task has correct number
    }

    // Assign leads to the task performer
    if (doc.leadIds && doc.leadIds.length > 0 && doc.assignedTo) {
        try {
            await Lead.updateMany(
                { _id: { $in: doc.leadIds } },
                {
                    $set: {
                        assignedTo: doc.assignedTo,
                        assignedToName: doc.assignedToName,
                        assignedToEmail: doc.assignedToEmail
                    }
                }
            );
            console.log(`Assigned ${doc.leadIds.length} leads to user ${doc.assignedToName} (${doc.assignedToEmail})`);
        } catch (error) {
            console.error('Error assigning leads to task performer:', error);
            // Don't throw error here as task creation was successful
            // The leads assignment is a secondary operation
        }
    }

    return doc;
};

export const queryTasks = async (filter, options) => {
    const { page = 1, limit = 10, sortBy = 'createdAt:desc' } = options || {};
    const [field, order] = sortBy.split(':');
    const sort = { [field]: order === 'asc' ? 1 : -1 };
    const query = {};
    if (filter?.assignedTo) query.assignedTo = filter.assignedTo;
    if (filter?.status) query.status = filter.status;
    if (filter?.search) query.title = { $regex: filter.search, $options: 'i' };
    const skip = (Number(page) - 1) * Number(limit);
    const [results, total] = await Promise.all([
        Task.find(query).sort(sort).skip(skip).limit(Number(limit)),
        Task.countDocuments(query),
    ]);
    return { results, page: Number(page), limit: Number(limit), totalResults: total, totalPages: Math.ceil(total / Number(limit) || 1) };
};

export const getTaskById = async (id) => Task.findById(id);

export const updateTaskById = async (id, updateBody) => {
    const doc = await getTaskById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'Task not found');

    // Store old leadIds for cleanup
    const oldLeadIds = doc.leadIds || [];
    const oldAssignedTo = doc.assignedTo;

    Object.assign(doc, updateBody);
    await doc.save();

    // Handle lead reassignment if assignedTo or leadIds changed
    const newLeadIds = doc.leadIds || [];
    const newAssignedTo = doc.assignedTo;

    if (newAssignedTo && (newLeadIds.length > 0 || oldLeadIds.length > 0)) {
        try {
            // Remove assignment from old leads that are no longer in the task
            if (oldLeadIds.length > 0) {
                const leadsToUnassign = oldLeadIds.filter(leadId => !newLeadIds.includes(leadId));
                if (leadsToUnassign.length > 0) {
                    await Lead.updateMany(
                        { _id: { $in: leadsToUnassign } },
                        {
                            $unset: {
                                assignedTo: 1,
                                assignedToName: 1,
                                assignedToEmail: 1
                            }
                        }
                    );
                    console.log(`Unassigned ${leadsToUnassign.length} leads from previous task assignment`);
                }
            }

            // Assign new leads to the task performer
            if (newLeadIds.length > 0) {
                await Lead.updateMany(
                    { _id: { $in: newLeadIds } },
                    {
                        $set: {
                            assignedTo: doc.assignedTo,
                            assignedToName: doc.assignedToName,
                            assignedToEmail: doc.assignedToEmail
                        }
                    }
                );
                console.log(`Assigned ${newLeadIds.length} leads to user ${doc.assignedToName} (${doc.assignedToEmail})`);
            }
        } catch (error) {
            console.error('Error updating lead assignments:', error);
            // Don't throw error here as task update was successful
        }
    }

    return doc;
};

export const deleteTaskById = async (id) => {
    const doc = await getTaskById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'Task not found');

    // Unassign leads when task is deleted
    if (doc.leadIds && doc.leadIds.length > 0) {
        try {
            await Lead.updateMany(
                { _id: { $in: doc.leadIds } },
                {
                    $unset: {
                        assignedTo: 1,
                        assignedToName: 1,
                        assignedToEmail: 1
                    }
                }
            );
            console.log(`Unassigned ${doc.leadIds.length} leads from deleted task`);
        } catch (error) {
            console.error('Error unassigning leads from deleted task:', error);
            // Don't throw error here as task deletion should proceed
        }
    }

    await doc.deleteOne();
    return true;
};

export const setTaskStatus = async (id, status) => {
    const doc = await getTaskById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'Task not found');
    doc.status = status;
    await doc.save();
    return doc;
};

export const incrementProgress = async (id, by = 1) => {
    const doc = await getTaskById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'Task not found');
    doc.completedCount = Math.max(0, (doc.completedCount || 0) + by);
    if (doc.totalCount && doc.completedCount >= doc.totalCount) {
        doc.status = 'COMPLETED';
    } else if (doc.completedCount > 0) {
        doc.status = 'IN_PROGRESS';
    }
    await doc.save();
    return doc;
};

export const getTasksAssignedToUser = async (userId) => {
    const tasks = await Task.find({ assignedTo: userId })
        .sort({ createdAt: -1 })
        .populate('leadIds', 'firstName lastName phoneNumber status callStatus')
        .lean();

    return tasks.map(task => ({
        id: task._id,
        title: task.title,
        description: task.description,
        status: task.status.toLowerCase(),
        priority: task.priority || 0,
        leadId: task.leadIds && task.leadIds.length > 0 ? task.leadIds[0]._id : null,
        dueAt: task.dueAt,
        createdAt: task.createdAt,
        updatedAt: task.updatedAt,
        completedCount: task.completedCount,
        totalCount: task.totalCount,
        leadIds: task.leadIds
    }));
};

export const recalculateTaskCompletion = async (taskId) => {
    const task = await getTaskById(taskId);
    if (!task) throw new ApiError(httpStatus.NOT_FOUND, 'Task not found');

    // Get all leads for this task
    const leads = await Lead.find({ _id: { $in: task.leadIds } });

    // Helper function to normalize status for comparison
    // Handles variations like "un-assigned", "un_assigned", "un assigned", etc.
    const normalizeStatus = (status) => {
        if (!status) return '';
        return status.toLowerCase().trim().replace(/[-_\s]/g, '');
    };

    // Count completed leads based on unified criteria
    // A lead is considered completed if status is NOT "assigned", "assign", "new", "unassigned", "unassigne", or "unassign"
    // Handles variations: "un-assigned", "un_assigned", "un assigned", "UnAssigned", "un-assigne", "un-assign", etc.
    const completedLeads = leads.filter(lead => {
        const normalizedStatus = normalizeStatus(lead.status);
        return normalizedStatus !== 'assigned' &&
            normalizedStatus !== 'assign' &&
            normalizedStatus !== 'new' &&
            normalizedStatus !== 'unassigned' &&
            normalizedStatus !== 'unassigne' &&
            normalizedStatus !== 'unassign';
    });

    const newCompletedCount = completedLeads.length;
    const totalCount = leads.length;

    // Update task completion count and status
    task.completedCount = newCompletedCount;
    task.totalCount = totalCount;

    // Update task status based on completion
    if (newCompletedCount >= totalCount && totalCount > 0) {
        task.status = 'COMPLETED';
    } else if (newCompletedCount > 0) {
        task.status = 'IN_PROGRESS';
    } else {
        task.status = 'PENDING';
    }

    await task.save();

    console.log(`Recalculated task ${taskId}: ${newCompletedCount}/${totalCount} completed (${task.status})`);

    return {
        taskId: task._id,
        completedCount: newCompletedCount,
        totalCount: totalCount,
        status: task.status
    };
};

export const removeLeadsFromTask = async (taskId, leadIds) => {
    if (!taskId || !Array.isArray(leadIds) || leadIds.length === 0) return null;
    const task = await getTaskById(taskId);
    if (!task) throw new ApiError(httpStatus.NOT_FOUND, 'Task not found');

    // Pull the leads from the task
    await Task.updateOne({ _id: taskId }, { $pull: { leadIds: { $in: leadIds } } });
    return await getTaskById(taskId);
};

export const syncTaskProgress = async (leadsData, userId) => {
    console.log(`[TaskService] Starting sync for ${leadsData.length} leads from user ${userId}`);

    const updatedTasks = [];
    const updatedLeads = [];

    try {
        // Update each lead with the synced data
        for (const leadData of leadsData) {
            const { leadId, status, callStatus, remark, lastContactedAt } = leadData;

            console.log(`[TaskService] Updating lead ${leadId}: status=${status}, callStatus=${callStatus}`);

            // Update the lead
            const lead = await Lead.findById(leadId);
            if (lead) {
                lead.status = status;
                lead.callStatus = callStatus;
                if (remark !== null && remark !== undefined) {
                    lead.remark = remark;
                }
                if (lastContactedAt) {
                    lead.lastContactedAt = new Date(lastContactedAt);
                }
                lead.updatedAt = new Date();

                await lead.save();
                updatedLeads.push(lead);

                console.log(`[TaskService] Updated lead ${leadId}: ${lead.firstName} ${lead.lastName}`);
            } else {
                console.log(`[TaskService] Lead ${leadId} not found, skipping`);
            }
        }

        // Find all tasks that contain any of the updated leads
        const leadIds = leadsData.map(l => l.leadId);
        const tasks = await Task.find({
            leadIds: { $in: leadIds },
            assignedTo: userId
        });

        console.log(`[TaskService] Found ${tasks.length} tasks to recalculate`);

        // Recalculate completion for each task
        for (const task of tasks) {
            const result = await recalculateTaskCompletion(task._id);
            updatedTasks.push({
                taskId: result.taskId,
                completedCount: result.completedCount,
                totalCount: result.totalCount,
                status: result.status
            });

            console.log(`[TaskService] Updated task ${task._id}: ${result.completedCount}/${result.totalCount} (${result.status})`);
        }

        console.log(`[TaskService] Sync completed: ${updatedLeads.length} leads, ${updatedTasks.length} tasks updated`);

        return {
            success: true,
            updatedLeads: updatedLeads.length,
            updatedTasks: updatedTasks,
            message: `Synced ${updatedLeads.length} leads and updated ${updatedTasks.length} tasks`
        };

    } catch (error) {
        console.error(`[TaskService] Error syncing task progress:`, error);
        throw new ApiError(httpStatus.INTERNAL_SERVER_ERROR, 'Failed to sync task progress');
    }
};

export default {
    createTask,
    queryTasks,
    getTaskById,
    updateTaskById,
    deleteTaskById,
    setTaskStatus,
    incrementProgress,
    getTasksAssignedToUser,
    recalculateTaskCompletion,
    removeLeadsFromTask,
    syncTaskProgress,
    incrementTaskCounter,
};


