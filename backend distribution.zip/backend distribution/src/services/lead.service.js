import httpStatus from 'http-status';
import { Lead, Task } from '../models/index.js';
import ApiError from '../utils/ApiError.js';
import taskService from './task.service.js';

// Utility function to sanitize phone number to last 10 digits
const sanitizePhoneNumber = (phoneNumber) => {
    if (!phoneNumber) return '';
    // Remove all non-digit characters
    const digitsOnly = phoneNumber.replace(/\D/g, '');
    // Return last 10 digits
    return digitsOnly.slice(-10);
};

// Escape user-provided search strings for safe use in Mongo $regex
const escapeRegex = (value = '') => {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
};

export const createLead = async (body) => {
    // Sanitize phone number to last 10 digits
    if (body.phoneNumber) {
        body.phoneNumber = sanitizePhoneNumber(body.phoneNumber);
    }

    // Duplicate validation: prevent creating multiple leads for the same sanitized phone number
    if (body.phoneNumber) {
        const existing = await Lead.findOne({ phoneNumber: body.phoneNumber });
        if (existing) {
            throw new ApiError(
                httpStatus.CONFLICT,
                'Lead already exists for this phone number'
            );
        }
    }

    const doc = await Lead.create(body);
    return doc;
};

export const queryLeads = async (filter, options) => {
    const { page = 1, limit = 10, sortBy = 'updatedAt:desc' } = options || {};
    const [sortField, sortOrder] = sortBy.split(':');
    const sort = { [sortField]: sortOrder === 'asc' ? 1 : -1 };
    const query = {};
    // Build search conditions
    const searchConditions = [];
    if (filter?.search) {
        const raw = String(filter.search || '').trim();
        const escaped = escapeRegex(raw);
        // Also build a cleaned phone variant to try exact match
        const cleanedPhone = raw.replace(/[\s\-()]/g, '');
        const phoneVariants = [raw, cleanedPhone, cleanedPhone.startsWith('+') ? cleanedPhone.slice(1) : `+${cleanedPhone}`];

        // Split search query into words for better matching across firstName and lastName
        const searchWords = raw.trim().split(/\s+/).filter(w => w.length > 0);
        const searchOrConditions = [
            { firstName: { $regex: escaped, $options: 'i' } },
            { lastName: { $regex: escaped, $options: 'i' } },
            { email: { $regex: escaped, $options: 'i' } },
            // Prefer exact matches for phoneNumber to avoid regex pitfalls with '+'
            { phoneNumber: { $in: phoneVariants.filter(Boolean) } },
            { phoneNumber: { $regex: escaped, $options: 'i' } },
        ];

        // If search has multiple words, also check if they match firstName and lastName combination
        if (searchWords.length > 1) {
            // Check if search matches concatenated firstName + lastName
            // e.g., "jane s" should match "Jane Smith"
            searchOrConditions.push({
                $expr: {
                    $regexMatch: {
                        input: { $concat: ['$firstName', ' ', '$lastName'] },
                        regex: escaped,
                        options: 'i'
                    }
                }
            });

            // Also check if first word matches firstName and remaining words match lastName
            const firstWordEscaped = escapeRegex(searchWords[0]);
            const remainingWordsEscaped = escapeRegex(searchWords.slice(1).join(' '));
            searchOrConditions.push({
                $and: [
                    { firstName: { $regex: firstWordEscaped, $options: 'i' } },
                    { lastName: { $regex: remainingWordsEscaped, $options: 'i' } }
                ]
            });
        } else if (searchWords.length === 1) {
            // Single word search - check if it matches the beginning of firstName or lastName
            // e.g., "jane" should match "Jane" in firstName or "Jane" at start of lastName
            const singleWordEscaped = escapeRegex(searchWords[0]);
            searchOrConditions.push({
                $expr: {
                    $regexMatch: {
                        input: { $concat: ['$firstName', ' ', '$lastName'] },
                        regex: singleWordEscaped,
                        options: 'i'
                    }
                }
            });
        }

        searchConditions.push({
            $or: searchOrConditions,
        });
    }

    // Build unassigned conditions
    const unassignedConditions = [];
    if (filter?.unassigned === 'true' || filter?.unassigned === true) {
        unassignedConditions.push({
            $or: [
                { assignedTo: { $exists: false } },
                { assignedTo: null },
                { assignedTo: '' }
            ]
        });
    }

    // Combine all conditions with $and
    const allConditions = [];
    if (searchConditions.length > 0) allConditions.push(...searchConditions);
    if (unassignedConditions.length > 0) allConditions.push(...unassignedConditions);

    if (allConditions.length > 0) {
        query.$and = allConditions;
    }

    if (filter?.status) query.status = filter.status;
    if (filter?.callStatus) query.callStatus = filter.callStatus;
    if (filter?.assignedTo) query.assignedTo = filter.assignedTo;
    if (filter?.source) query.source = filter.source;

    // Add city filter
    if (filter?.city) {
        const cityEscaped = escapeRegex(filter.city);
        query.city = { $regex: cityEscaped, $options: 'i' };
    }

    // Add campus filter
    if (filter?.campus) {
        const campusEscaped = escapeRegex(filter.campus);
        query.campus = { $regex: campusEscaped, $options: 'i' };
    }

    // Add class filter
    if (filter?.class) {
        const classEscaped = escapeRegex(filter.class);
        query.class = { $regex: classEscaped, $options: 'i' };
    }

    // Add date range filter for createdAt
    // Frontend sends ISO strings in UTC, so we can use them directly
    if (filter?.createdAtFrom || filter?.createdAtTo) {
        query.createdAt = {};
        if (filter.createdAtFrom) {
            // createdAtFrom is already in UTC format from frontend (start of day)
            const fromDate = new Date(filter.createdAtFrom);
            // Ensure it's a valid date
            if (!isNaN(fromDate.getTime())) {
                query.createdAt.$gte = fromDate;
            }
        }
        if (filter.createdAtTo) {
            // createdAtTo is already in UTC format from frontend (end of day)
            const toDate = new Date(filter.createdAtTo);
            // Ensure it's a valid date
            if (!isNaN(toDate.getTime())) {
                query.createdAt.$lte = toDate;
            }
        }
    }

    // Add assigned filter (true = has assignedTo, false = no assignedTo)
    if (filter?.assigned !== undefined) {
        // Ensure $and array exists
        if (!Array.isArray(query.$and)) {
            query.$and = [];
        }

        if (filter.assigned === 'true' || filter.assigned === true) {
            // Assigned: assignedTo exists and is not null/empty
            query.$and.push({
                $and: [
                    { assignedTo: { $exists: true } },
                    { assignedTo: { $ne: null } },
                    { assignedTo: { $ne: '' } }
                ]
            });
        } else if (filter.assigned === 'false' || filter.assigned === false) {
            // Unassigned: assignedTo is null, empty, or doesn't exist
            query.$and.push({
                $or: [
                    { assignedTo: { $exists: false } },
                    { assignedTo: null },
                    { assignedTo: '' }
                ]
            });
        }
    }

    // Add completed filter - filter leads based on completion status
    // Handles variations: "un-assigned", "un_assigned", "un assigned", "UnAssigned", etc.
    if (filter?.completed !== undefined) {
        // Create regex patterns for incomplete statuses that handle variations
        // Matches: assigned, assign, new, unassigned, un-assigned, un_assigned, un assigned, unassigne, un-assigne, unassign, un-assign, etc.
        const incompleteStatusPatterns = [
            /^assigned$/i,
            /^assign$/i,
            /^new$/i,
            /^un[-_\s]*assigned$/i,
            /^un[-_\s]*assigne$/i,
            /^un[-_\s]*assign$/i
        ];

        if (filter.completed === 'true' || filter.completed === true) {
            // Show only completed leads (status NOT matching incomplete status patterns)
            // Use $nor to exclude leads matching any incomplete status pattern
            query.$nor = incompleteStatusPatterns.map(pattern => ({ status: { $regex: pattern } }));
        } else if (filter.completed === 'false' || filter.completed === false) {
            // Show only incomplete leads (status matching any incomplete status pattern)
            query.$or = incompleteStatusPatterns.map(pattern => ({ status: { $regex: pattern } }));
        }
    }

    // Add taskId filtering - find leads that belong to the specified task
    if (filter?.taskId) {
        const task = await Task.findById(filter.taskId);
        if (task && task.leadIds && task.leadIds.length > 0) {
            query._id = { $in: task.leadIds };
        } else {
            // If task has no leads or doesn't exist, return empty result
            query._id = { $in: [] };
        }
    }

    // Add ids filtering - find leads by array of IDs
    if (filter?.ids) {
        const ids = Array.isArray(filter.ids) ? filter.ids : (typeof filter.ids === 'string' ? filter.ids.split(',').filter(Boolean) : []);
        if (ids.length > 0) {
            // If taskId was also set, combine with AND
            if (query._id && query._id.$in) {
                // Intersect both arrays
                const existingIds = query._id.$in.map(id => id.toString());
                const newIds = ids.map(id => id.toString());
                query._id.$in = existingIds.filter(id => newIds.includes(id));
            } else {
                query._id = { $in: ids };
            }
        } else {
            // If ids is empty, return empty result
            query._id = { $in: [] };
        }
    }

    const skip = (Number(page) - 1) * Number(limit);
    const [results, total] = await Promise.all([
        Lead.find(query).sort(sort).skip(skip).limit(Number(limit)),
        Lead.countDocuments(query),
    ]);
    return { results, page: Number(page), limit: Number(limit), totalResults: total, totalPages: Math.ceil(total / Number(limit) || 1) };
};

export const getLeadById = async (id) => {
    return Lead.findById(id);
};

export const updateLeadById = async (id, updateBody) => {
    const doc = await getLeadById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'Lead not found');

    // Sanitize phone number to last 10 digits if provided
    if (updateBody.phoneNumber) {
        updateBody.phoneNumber = sanitizePhoneNumber(updateBody.phoneNumber);
    }

    Object.assign(doc, updateBody);
    if (updateBody.callStatus === 'Called') {
        doc.lastContactedAt = new Date();
    }
    await doc.save();

    // Recalculate task completion for all tasks that include this lead
    try {
        const tasks = await Task.find({ leadIds: id });
        for (const task of tasks) {
            await taskService.recalculateTaskCompletion(task._id);
        }
        console.log(`Recalculated completion for ${tasks.length} tasks after updating lead ${id}`);
    } catch (error) {
        console.error('Error recalculating task completion:', error);
        // Don't throw error here as lead update was successful
    }

    return doc;
};

export const deleteLeadById = async (id) => {
    const doc = await getLeadById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'Lead not found');
    await doc.deleteOne();
    return true;
};

export const updateStatus = async (id, status, remark) => {
    const doc = await getLeadById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'Lead not found');
    doc.status = status;
    if (remark) doc.remark = remark;
    await doc.save();

    // Recalculate task completion for all tasks that include this lead
    try {
        const tasks = await Task.find({ leadIds: id });
        for (const task of tasks) {
            await taskService.recalculateTaskCompletion(task._id);
        }
        console.log(`Recalculated completion for ${tasks.length} tasks after updating lead status ${id}`);
    } catch (error) {
        console.error('Error recalculating task completion:', error);
        // Don't throw error here as lead update was successful
    }

    return doc;
};

export const updateCallStatus = async (id, callStatus) => {
    const doc = await getLeadById(id);
    if (!doc) throw new ApiError(httpStatus.NOT_FOUND, 'Lead not found');
    doc.callStatus = callStatus;
    if (callStatus === 'Called') {
        doc.lastContactedAt = new Date();
    }
    await doc.save();

    // Recalculate task completion for all tasks that include this lead
    try {
        const tasks = await Task.find({ leadIds: id });
        for (const task of tasks) {
            await taskService.recalculateTaskCompletion(task._id);
        }
        console.log(`Recalculated completion for ${tasks.length} tasks after updating lead call status ${id}`);
    } catch (error) {
        console.error('Error recalculating task completion:', error);
        // Don't throw error here as lead update was successful
    }

    return doc;
};

export const syncUpload = async (items = []) => {
    // Upsert by client-provided id stored in metadata.clientId
    const results = [];
    for (const item of items) {
        const filter = { phoneNumber: item.phoneNumber, firstName: item.firstName, lastName: item.lastName };
        const update = {
            firstName: item.firstName,
            lastName: item.lastName,
            phoneNumber: item.phoneNumber,
            email: item.email ?? null,
            campus: item.campus ?? null,
            class: item.class ?? null,
            city: item.city ?? null,
            status: item.status,
            remark: item.remark ?? null,
            callStatus: item.callStatus,
            createdAt: new Date(item.createdAt),
            updatedAt: new Date(item.updatedAt),
            lastContactedAt: item.lastContactedAt ? new Date(item.lastContactedAt) : null,
            metadata: item.metadata ?? null,
            isSynced: true,
            syncedAt: new Date(),
        };
        const doc = await Lead.findOneAndUpdate(filter, update, { new: true, upsert: true, setDefaultsOnInsert: true });
        results.push(doc);
    }
    return { success: true, imported: results.length };
};

export const syncPull = async (since, limit = 100) => {
    const sinceDate = new Date(since);
    const results = await Lead.find({ updatedAt: { $gt: sinceDate } }).sort({ updatedAt: 1 }).limit(Number(limit));
    return { results };
};

export default {
    createLead,
    queryLeads,
    getLeadById,
    updateLeadById,
    deleteLeadById,
    updateStatus,
    updateCallStatus,
    syncUpload,
    syncPull,
};


