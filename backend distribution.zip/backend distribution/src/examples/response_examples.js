/**
 * Example usage of standardized API responses
 * This file demonstrates how to use the new response utilities
 */

import {
    sendSuccess,
    sendError,
    sendCreated,
    sendNoContent,
    sendPaginated,
    sendAuthSuccess,
    sendAuthError,
    sendNotFound,
    sendValidationError,
    createPaginationMeta
} from '../utils/response.utils.js';

/**
 * Example controller methods showing different response types
 */
export class ExampleController {

    /**
     * Example: Get single resource
     */
    static async getUser(req, res) {
        try {
            const user = await User.findById(req.params.id);
            if (!user) {
                return sendNotFound(res, 'User not found');
            }
            sendSuccess(res, user, 'User retrieved successfully');
        } catch (error) {
            sendError(res, 'Failed to retrieve user', 500);
        }
    }

    /**
     * Example: Create new resource
     */
    static async createUser(req, res) {
        try {
            const user = await User.create(req.body);
            sendCreated(res, user, 'User created successfully');
        } catch (error) {
            if (error.name === 'ValidationError') {
                const validationErrors = {};
                Object.keys(error.errors).forEach(key => {
                    validationErrors[key] = [error.errors[key].message];
                });
                return sendValidationError(res, validationErrors, 'Validation failed');
            }
            sendError(res, 'Failed to create user', 500);
        }
    }

    /**
     * Example: Get paginated resources
     */
    static async getUsers(req, res) {
        try {
            const { page = 1, limit = 10 } = req.query;
            const result = await User.find()
                .skip((page - 1) * limit)
                .limit(limit);
            const total = await User.countDocuments();

            const paginationMeta = createPaginationMeta(page, limit, total);
            sendPaginated(res, result, paginationMeta, 'Users retrieved successfully');
        } catch (error) {
            sendError(res, 'Failed to retrieve users', 500);
        }
    }

    /**
     * Example: Authentication
     */
    static async login(req, res) {
        try {
            const { email, password } = req.body;
            const user = await User.findOne({ email });

            if (!user || !await user.comparePassword(password)) {
                return sendAuthError(res, 'Invalid credentials', 401);
            }

            const tokens = await generateTokens(user);
            sendAuthSuccess(res, user, tokens, 'Login successful');
        } catch (error) {
            sendError(res, 'Login failed', 500);
        }
    }

    /**
     * Example: Delete resource
     */
    static async deleteUser(req, res) {
        try {
            const user = await User.findByIdAndDelete(req.params.id);
            if (!user) {
                return sendNotFound(res, 'User not found');
            }
            sendNoContent(res, 'User deleted successfully');
        } catch (error) {
            sendError(res, 'Failed to delete user', 500);
        }
    }

    /**
     * Example: Update resource
     */
    static async updateUser(req, res) {
        try {
            const user = await User.findByIdAndUpdate(
                req.params.id,
                req.body,
                { new: true, runValidators: true }
            );

            if (!user) {
                return sendNotFound(res, 'User not found');
            }

            sendSuccess(res, user, 'User updated successfully');
        } catch (error) {
            if (error.name === 'ValidationError') {
                const validationErrors = {};
                Object.keys(error.errors).forEach(key => {
                    validationErrors[key] = [error.errors[key].message];
                });
                return sendValidationError(res, validationErrors, 'Validation failed');
            }
            sendError(res, 'Failed to update user', 500);
        }
    }
}

/**
 * Example response formats:
 * 
 * Success Response:
 * {
 *   "success": true,
 *   "status": 1,
 *   "data": { "id": 1, "name": "John Doe" },
 *   "message": "User retrieved successfully"
 * }
 * 
 * Error Response:
 * {
 *   "success": false,
 *   "status": 0,
 *   "data": null,
 *   "message": "User not found",
 *   "code": 404
 * }
 * 
 * Paginated Response:
 * {
 *   "success": true,
 *   "status": 1,
 *   "data": [{ "id": 1, "name": "John" }, { "id": 2, "name": "Jane" }],
 *   "meta": {
 *     "current_page": 1,
 *     "total_pages": 5,
 *     "total_items": 50,
 *     "per_page": 10
 *   },
 *   "message": "Users retrieved successfully"
 * }
 * 
 * Validation Error Response:
 * {
 *   "success": false,
 *   "status": 0,
 *   "data": null,
 *   "message": "Validation failed",
 *   "errors": {
 *     "email": ["Email is required"],
 *     "password": ["Password must be at least 8 characters"]
 *   }
 * }
 */
