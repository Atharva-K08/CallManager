import mongoose from 'mongoose';

// LeadStatus stores allowed values for lead status and call status
// type: 'status' | 'callStatus'
const leadStatusSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true,
            minlength: 1,
            maxlength: 100,
        },
        type: {
            type: String,
            required: true,
            enum: ['leadStatus', 'callStatus'],
            index: true,
        },
        color: {
            type: String,
            trim: true,
            default: null,
        },
        order: {
            type: Number,
            default: 0,
        },
        description: {
            type: String,
            trim: true,
            maxlength: 500,
            default: null,
        },
        isActive: {
            type: Boolean,
            default: true,
            index: true,
        },
        isDefaultForImport: {
            type: Boolean,
            default: false,
            index: true,
        },
        createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    },

    { timestamps: true }
);

// Unique per type
leadStatusSchema.index({ type: 1, name: 1 }, { unique: true });

// Ensure only one default import status per type (only for leadStatus type)
leadStatusSchema.index(
    { type: 1, isDefaultForImport: 1 },
    { unique: true, partialFilterExpression: { type: 'leadStatus', isDefaultForImport: true } }
);

const LeadStatus = mongoose.model('LeadStatus', leadStatusSchema);

export default LeadStatus;


