import mongoose from 'mongoose';

const followUpSchema = new mongoose.Schema(
    {
        leadId: { type: mongoose.Types.ObjectId, ref: 'Lead', required: true, index: true },
        dueAt: { type: Date, required: true, index: true },
        note: { type: String, trim: true },
        status: { type: String, enum: ['PENDING', 'DONE', 'CANCELLED'], default: 'PENDING', index: true },
        createdBy: { type: mongoose.Types.ObjectId, ref: 'User' },
        completedAt: { type: Date },
        cancelledAt: { type: Date },
        metadata: { type: Object },
    },
    {
        timestamps: true,
        toJSON: { virtuals: true },
        toObject: { virtuals: true }
    }
);

// Virtual field for lead name
followUpSchema.virtual('leadName', {
    ref: 'Lead',
    localField: 'leadId',
    foreignField: '_id',
    justOne: true,
    options: { select: 'firstName lastName' }
});

// Virtual field for user name (createdBy)
followUpSchema.virtual('userName', {
    ref: 'User',
    localField: 'createdBy',
    foreignField: '_id',
    justOne: true,
    options: { select: 'name' }
});

const FollowUp = mongoose.model('FollowUp', followUpSchema);
export default FollowUp;


