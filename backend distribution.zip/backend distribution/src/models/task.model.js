import mongoose from 'mongoose';

const taskSchema = new mongoose.Schema({
    title: { type: String, required: true, trim: true },
    description: { type: String, trim: true },

    // task number for tracking
    taskNumber: { type: Number, unique: true, sparse: true },

    // assignment
    assignedTo: { type: mongoose.Types.ObjectId, ref: 'User', required: true, index: true },
    assignedToName: { type: String, trim: true },
    assignedToEmail: { type: String, trim: true },
    createdBy: { type: mongoose.Types.ObjectId, ref: 'User' },

    // what to call
    leadIds: [{ type: mongoose.Types.ObjectId, ref: 'Lead' }],
    targetCount: { type: Number },

    // progress tracking
    status: { type: String, enum: ['PENDING', 'IN_PROGRESS', 'COMPLETED'], default: 'PENDING', index: true },
    completedCount: { type: Number, default: 0 },
    totalCount: { type: Number },

    dueAt: { type: Date },
}, { timestamps: true });

// pre-save totalCount if not set
taskSchema.pre('save', function (next) {
    if (!this.totalCount) {
        if (Array.isArray(this.leadIds) && this.leadIds.length > 0) {
            this.totalCount = this.leadIds.length;
        } else if (this.targetCount) {
            this.totalCount = this.targetCount;
        }
    }
    next();
});

const Task = mongoose.model('Task', taskSchema);
export default Task;


