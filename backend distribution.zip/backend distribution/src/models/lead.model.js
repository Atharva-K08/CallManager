import mongoose from 'mongoose';

const leadSchema = new mongoose.Schema(
    {
        firstName: { type: String, required: true, trim: true },
        lastName: { type: String, required: true, trim: true },
        phoneNumber: { type: String, required: true, trim: true, index: true },
        email: { type: String, trim: true, default: null },
        campus: { type: String, trim: true, default: null },
        class: { type: String, trim: true, default: null },
        city: { type: String, trim: true, default: null },
        status: { type: String, required: true, trim: true },
        remark: { type: String, trim: true, default: null },
        callStatus: { type: String, trim: true, default: 'Not Called' },
        lastContactedAt: { type: Date, default: null },
        isSynced: { type: Boolean, default: true, index: true },
        syncedAt: { type: Date, default: null },
        syncAttempts: { type: Number, default: 0 },
        syncError: { type: String, default: null },
        metadata: { type: mongoose.Schema.Types.Mixed, default: null },
        assignedTo: { type: String, default: null },
        assignedToName: { type: String, trim: true, default: null },
        assignedToEmail: { type: String, trim: true, default: null },
        source: { type: String, default: null },
        priority: { type: Number, default: 0 },
        createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    },
    { timestamps: true }
);

leadSchema.index({ status: 1, callStatus: 1 });
leadSchema.index({ updatedAt: -1 });

const Lead = mongoose.model('Lead', leadSchema);

export default Lead;


