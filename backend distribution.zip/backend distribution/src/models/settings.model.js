import mongoose from 'mongoose';

/**
 * Settings Model
 * Stores user preferences and system defaults for features
 * 
 * Structure:
 * - User-level settings: { userId, scope: 'user', category, key, value }
 * - System-level settings: { scope: 'system', category, key, value }
 * - Feature defaults: { scope: 'default', category, key, value }
 */
const settingsSchema = new mongoose.Schema(
    {
        // For user-specific settings
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            default: null,
            index: true,
        },

        // Scope: 'user' (user-specific), 'system' (system-wide), 'default' (feature defaults)
        scope: {
            type: String,
            enum: ['user', 'system', 'default'],
            required: true,
            default: 'user',
            index: true,
        },

        // Category: groups related settings (e.g., 'notifications', 'ui', 'features', 'integrations')
        category: {
            type: String,
            required: true,
            trim: true,
            index: true,
        },

        // Setting key (e.g., 'emailNotifications', 'theme', 'autoSync')
        key: {
            type: String,
            required: true,
            trim: true,
            index: true,
        },

        // Setting value (can be any type: string, number, boolean, object, array)
        value: {
            type: mongoose.Schema.Types.Mixed,
            required: true,
        },

        // Optional: data type for validation
        dataType: {
            type: String,
            enum: ['string', 'number', 'boolean', 'object', 'array'],
            default: 'string',
        },

        // Optional: description for UI
        description: {
            type: String,
            trim: true,
        },

        // Optional: whether this setting is editable by user
        isEditable: {
            type: Boolean,
            default: true,
        },

        // Optional: version for migration/updates
        version: {
            type: String,
            default: '1.0.0',
        },

        createdBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
        },
    },
    {
        timestamps: true,
    }
);

// Compound indexes for efficient queries
settingsSchema.index({ userId: 1, category: 1, key: 1 }, { unique: true });
settingsSchema.index({ scope: 1, category: 1, key: 1 }, { unique: true, partialFilterExpression: { userId: null } });
settingsSchema.index({ category: 1, key: 1 });

// Static method to get setting value with fallback
settingsSchema.statics.getSetting = async function (userId, category, key, defaultValue = null) {
    // Try user-specific setting first
    if (userId) {
        const userSetting = await this.findOne({ userId, category, key, scope: 'user' });
        if (userSetting) return userSetting.value;
    }

    // Try system-wide setting
    const systemSetting = await this.findOne({ scope: 'system', category, key });
    if (systemSetting) return systemSetting.value;

    // Try default setting
    const defaultSetting = await this.findOne({ scope: 'default', category, key });
    if (defaultSetting) return defaultSetting.value;

    // Return provided default
    return defaultValue;
};

// Static method to get all settings for a category
settingsSchema.statics.getCategorySettings = async function (userId, category) {
    const settings = {};

    // Get user-specific settings
    if (userId) {
        const userSettings = await this.find({ userId, category, scope: 'user' });
        userSettings.forEach(setting => {
            settings[setting.key] = setting.value;
        });
    }

    // Get system-wide settings (override user settings if they exist)
    const systemSettings = await this.find({ scope: 'system', category });
    systemSettings.forEach(setting => {
        settings[setting.key] = setting.value;
    });

    // Get defaults for any missing keys
    const defaultSettings = await this.find({ scope: 'default', category });
    defaultSettings.forEach(setting => {
        if (!(setting.key in settings)) {
            settings[setting.key] = setting.value;
        }
    });

    return settings;
};

// Static method to set or update a setting
settingsSchema.statics.setSetting = async function (userId, category, key, value, options = {}) {
    const {
        scope = 'user',
        dataType = 'string',
        description = null,
        isEditable = true,
        createdBy = null,
    } = options;

    const updateData = {
        value,
        dataType,
        description,
        isEditable,
        ...(createdBy && { createdBy }),
    };

    if (scope === 'user' && userId) {
        updateData.userId = userId;
    }

    return await this.findOneAndUpdate(
        {
            ...(scope === 'user' && userId ? { userId } : {}),
            scope,
            category,
            key,
        },
        {
            $set: updateData,
            $setOnInsert: {
                category,
                key,
                scope,
                ...(scope === 'user' && userId ? { userId } : {}),
            },
        },
        {
            upsert: true,
            new: true,
        }
    );
};

// Static method to initialize default settings for a feature
settingsSchema.statics.initializeDefaults = async function (category, defaults, version = '1.0.0') {
    const operations = Object.entries(defaults).map(([key, config]) => ({
        updateOne: {
            filter: { scope: 'default', category, key },
            update: {
                $setOnInsert: {
                    scope: 'default',
                    category,
                    key,
                    value: config.value,
                    dataType: config.dataType || 'string',
                    description: config.description || null,
                    isEditable: config.isEditable !== false,
                    version,
                },
            },
            upsert: true,
        },
    }));

    if (operations.length > 0) {
        await this.bulkWrite(operations);
    }
};

const Settings = mongoose.model('Settings', settingsSchema);

export default Settings;

