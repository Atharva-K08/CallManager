import mongoose from 'mongoose';

const activityLogSchema = new mongoose.Schema({
    // User who performed the action
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
    },
    userName: String,
    userEmail: String,

    // Target of the action
    targetModel: {
        type: String,
        required: true,
    },
    targetId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
    },
    targetName: String,

    // Action performed
    action: {
        type: String,
        required: true,
        enum: ['create', 'update', 'delete', 'view', 'login', 'logout', 'other'],
    },

    // Description of what happened
    description: {
        type: String,
        required: true,
    },

    // Optional: track changes for updates
    changes: {
        type: mongoose.Schema.Types.Mixed,
    },

    // Optional: additional metadata
    metadata: {
        type: mongoose.Schema.Types.Mixed,
    },

    // Request info
    ipAddress: String,
    userAgent: String,
}, {
    timestamps: true, // Automatically adds createdAt and updatedAt
});

// Indexes for common queries
activityLogSchema.index({ user: 1, createdAt: -1 });
activityLogSchema.index({ targetModel: 1, targetId: 1, createdAt: -1 });
activityLogSchema.index({ action: 1, createdAt: -1 });
activityLogSchema.index({ createdAt: -1 });

const ActivityLog = mongoose.model('ActivityLog', activityLogSchema);

export default ActivityLog;
