import mongoose from 'mongoose';

const callRecordSchema = new mongoose.Schema(
    {
        phoneNumber: { type: String, required: true, trim: true, index: true },
        contactName: { type: String, trim: true, default: null },
        initiatedAt: { type: Date, required: true, index: true },
        connectedAt: { type: Date, default: null, index: true },
        endedAt: { type: Date, default: null, index: true },
        durationSeconds: { type: Number, default: null },
        status: {
            type: String,
            required: true,
            trim: true,
            index: true,
            enum: [
                'CALL_DIALING',
                'CALL_CONNECTING',
                'CALL_RINGING',
                'CALL_CONNECTED',
                'CALL_ACTIVE',
                'CALL_ENDED_CONNECTED',
                'CALL_ENDED_BY_CALLER',
                'CALL_ENDED_BY_CALLEE',
                'CALL_ENDED_NO_ANSWER',
                'CALL_DECLINED_BY_LEAD',
                'CALL_DECLINED_BY_CALLEE',
                'CALL_DECLINED_BY_CALLER',
                'CALL_CANCELLED_BY_CALLER',
                'CALL_BUSY',
                'CALL_NO_ANSWER',
                'CALL_MISSED',
                'CALL_WAITING_INCOMING',
                'CALL_SWITCHED'
            ]
        },
        source: {
            type: String,
            required: true,
            enum: ['app', 'system', 'unknown'],
            default: 'unknown'
        },
        isOutgoing: { type: Boolean, required: true, index: true },
        deviceInfo: { type: String, trim: true, default: null },
        metadata: { type: mongoose.Schema.Types.Mixed, default: null },
        outcomeLabel: { type: String, trim: true, default: null },
        isSynced: { type: Boolean, default: true, index: true },
        syncedAt: { type: Date, default: null },
        syncAttempts: { type: Number, default: 0 },
        syncError: { type: String, default: null },
        createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        leadId: { type: mongoose.Schema.Types.ObjectId, ref: 'Lead', default: null, index: true },
    },
    { timestamps: true }
);

// Compound indexes for efficient querying
callRecordSchema.index({ phoneNumber: 1, initiatedAt: -1 });
callRecordSchema.index({ status: 1, initiatedAt: -1 });
callRecordSchema.index({ isOutgoing: 1, initiatedAt: -1 });
callRecordSchema.index({ leadId: 1, initiatedAt: -1 });
callRecordSchema.index({ createdBy: 1, initiatedAt: -1 });
callRecordSchema.index({ isSynced: 1, syncAttempts: 1 });

// Virtual for formatted duration
callRecordSchema.virtual('formattedDuration').get(function () {
    if (!this.durationSeconds) return '00:00';
    const minutes = Math.floor(this.durationSeconds / 60);
    const seconds = this.durationSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
});

// Virtual for call success status
callRecordSchema.virtual('isSuccessful').get(function () {
    return (
        (this.status === 'CALL_ENDED_CONNECTED' ||
            this.status === 'CALL_ENDED_BY_CALLER' ||
            this.status === 'CALL_ENDED_BY_CALLEE') &&
        this.durationSeconds != null &&
        this.durationSeconds > 0
    );
});

// Virtual for human-readable status
callRecordSchema.virtual('statusText').get(function () {
    const statusMap = {
        'CALL_DIALING': 'Connecting',
        'CALL_CONNECTING': 'Connecting',
        'CALL_RINGING': 'Ringing',
        'CALL_CONNECTED': 'Connected',
        'CALL_ACTIVE': 'Connected',
        'CALL_ENDED_CONNECTED': 'Call Ended',
        'CALL_ENDED_BY_CALLER': 'Ended by Caller',
        'CALL_ENDED_BY_CALLEE': 'Ended by Callee',
        'CALL_DECLINED_BY_CALLEE': 'Declined by Callee',
        'CALL_DECLINED_BY_CALLER': 'Declined by Caller',
        'CALL_CANCELLED_BY_CALLER': 'Cancelled by Caller',
        'CALL_BUSY': 'Busy',
        'CALL_NO_ANSWER': 'No Answer',
        'CALL_ENDED_NO_ANSWER': 'No Answer',
        'CALL_MISSED': 'Missed',
        'CALL_WAITING_INCOMING': 'Call Waiting',
        'CALL_SWITCHED': 'Call Switched'
    };
    return statusMap[this.status] || this.status.replace(/CALL_/g, '').replace(/_/g, ' ');
});

// Method to calculate duration if not set
callRecordSchema.methods.calculateDuration = function () {
    if (this.connectedAt && this.endedAt && !this.durationSeconds) {
        this.durationSeconds = Math.floor((this.endedAt - this.connectedAt) / 1000);
    }
    return this;
};

// Method to update status and handle state transitions
callRecordSchema.methods.updateStatus = function (newStatus, timestamp = null) {
    const now = timestamp || new Date();
    this.status = newStatus;

    // Determine if this is a final state that should set endedAt
    const isFinalState = this.isFinalState(newStatus);
    if (isFinalState) {
        this.endedAt = this.endedAt || now;
        this.calculateDuration();
    } else if (newStatus === 'CALL_CONNECTED' || newStatus === 'CALL_ACTIVE') {
        this.connectedAt = this.connectedAt || now;
    }

    // Mark as not synced when updated
    this.isSynced = false;
    this.syncError = null;
    return this;
};

// Helper method to check if status represents a final call state
callRecordSchema.methods.isFinalState = function (status) {
    const finalStates = [
        'CALL_ENDED_CONNECTED',
        'CALL_ENDED_BY_CALLER',
        'CALL_ENDED_BY_CALLEE',
        'CALL_DECLINED_BY_CALLEE',
        'CALL_DECLINED_BY_CALLER',
        'CALL_CANCELLED_BY_CALLER',
        'CALL_BUSY',
        'CALL_NO_ANSWER',
        'CALL_MISSED',
        'CALL_ENDED_NO_ANSWER'
    ];
    return finalStates.includes(status);
};

// Static method to get call statistics
callRecordSchema.statics.getCallStatistics = async function (filter = {}) {
    const pipeline = [
        { $match: filter },
        {
            $group: {
                _id: null,
                totalCalls: { $sum: 1 },
                outgoingCalls: {
                    $sum: { $cond: [{ $eq: ['$isOutgoing', true] }, 1, 0] }
                },
                incomingCalls: {
                    $sum: { $cond: [{ $eq: ['$isOutgoing', false] }, 1, 0] }
                },
                connectedCalls: {
                    $sum: {
                        $cond: [
                            {
                                $in: [
                                    '$status',
                                    [
                                        'CALL_CONNECTED',
                                        'CALL_ACTIVE',
                                        'CALL_ENDED_CONNECTED',
                                        'CALL_ENDED_BY_CALLER',
                                        'CALL_ENDED_BY_CALLEE'
                                    ]
                                ]
                            },
                            1,
                            0
                        ]
                    }
                },
                missedCalls: {
                    $sum: {
                        $cond: [
                            {
                                $in: [
                                    '$status',
                                    [
                                        'CALL_NO_ANSWER',
                                        'CALL_ENDED_NO_ANSWER',
                                        'CALL_DECLINED_BY_LEAD',
                                        'CALL_DECLINED_BY_CALLEE',
                                        'CALL_DECLINED_BY_CALLER'
                                    ]
                                ]
                            },
                            1,
                            0
                        ]
                    }
                },
                totalDuration: { $sum: '$durationSeconds' },
                avgDuration: { $avg: '$durationSeconds' }
            }
        }
    ];

    const result = await this.aggregate(pipeline);
    return result[0] || {
        totalCalls: 0,
        outgoingCalls: 0,
        incomingCalls: 0,
        connectedCalls: 0,
        missedCalls: 0,
        totalDuration: 0,
        avgDuration: 0
    };
};

const CallRecord = mongoose.model('CallRecord', callRecordSchema);
export default CallRecord;

