import { Lead, FollowUp } from '../models/index.js';
import { sendFCMNotification } from '../services/fcm.service.js';
import websocketService from '../services/websocket.service.js';

const __showFollowUpLogs = process.env.SHOWFOLLOWUPLOGS === 'true' || process.env.SHOW_FOLLOW_UP_LOGS === 'true';
const debug = (...args) => { if (__showFollowUpLogs) console.log('[FOLLOWUP-DEBUG][Processor]', ...args); };

/**
 * Process follow-up reminder jobs
 */
export const processReminderJob = async (job) => {
    const { followUpId, leadId, leadName, followUpDate, message, userId, userEmail } = job.data;

    try {
        console.log(`🔄 Processing reminder for lead: ${leadName} (${leadId})`);
        debug('Job data:', job.data);

        // Fetch FollowUp and Lead
        const followUp = await FollowUp.findById(followUpId);
        const lead = await Lead.findById(leadId);
        if (!followUp || !lead) {
            console.log(`⚠️ Lead ${leadId} not found, skipping reminder`);
            return;
        }
        debug('FollowUp status:', followUp?.status, 'Lead assignedTo:', lead?.assignedTo?.toString?.());

        // Check if reminder is still valid (not cancelled or completed)
        if (followUp.status !== 'PENDING') {
            console.log(`⚠️ FollowUp ${followUpId} not pending, skipping`);
            return;
        }

        // Check if follow-up date has passed
        const now = new Date();
        if (new Date(followUp.dueAt) > now) {
            console.log(`⚠️ Follow-up date not reached for followUp ${followUpId}, rescheduling`);
            // Reschedule for later
            const delay = new Date(followUp.dueAt) - now;
            await job.moveToDelayed(delay);
            return;
        }

        // Prepare notification data
        // Use message from job data, fallback to FollowUp note, or default message
        // Handle undefined, null, empty string, or string "undefined"
        const messageFromJob = (message && typeof message === 'string' && message.trim() !== '' && message !== 'undefined')
            ? message
            : null;
        const messageFromFollowUp = (followUp.note && typeof followUp.note === 'string' && followUp.note.trim() !== '' && followUp.note !== 'undefined')
            ? followUp.note
            : null;
        const notificationBody = messageFromJob || messageFromFollowUp || `Follow up with ${leadName}`;

        const notificationData = {
            title: 'Follow-up Reminder',
            body: notificationBody,
            data: {
                type: 'follow_up_reminder',
                leadId: leadId,
                leadName: leadName,
                followUpDate: followUpDate,
                userId: userId,
            },
        };
        debug('Notification payload:', notificationData);

        // Send FCM notification
        const fcmResult = await sendFCMNotification(userId, notificationData);
        debug('FCM result:', fcmResult);

        // Emit WebSocket event for real-time updates
        const wsMessage = messageFromJob || messageFromFollowUp || null;
        websocketService.sendToUser(userId, 'call_reminder', {
            followUpId: followUpId,
            leadId: leadId,
            leadName: leadName,
            studentName: leadName, // For compatibility with existing frontend
            followUpDate: followUpDate,
            message: wsMessage,
            userId: userId,
        });
        debug('WebSocket event emitted to user:', userId);

        // Mark follow up as completed (sent)
        followUp.status = 'DONE';
        followUp.completedAt = new Date();
        await followUp.save();
        debug('FollowUp marked DONE with completedAt:', followUp.completedAt);

        console.log(`✅ Reminder sent successfully for lead: ${leadName}`);

        return {
            success: true,
            followUpId: followUpId,
            leadId: leadId,
            leadName: leadName,
            sentAt: new Date(),
        };

    } catch (error) {
        console.error(`❌ Error processing reminder for lead ${leadId}:`, error);
        debug('Processor error details:', error?.message);
        throw error;
    }
};

/**
 * Process bulk reminder jobs
 */
export const processBulkReminderJob = async (job) => {
    const { reminders } = job.data;

    try {
        console.log(`🔄 Processing ${reminders.length} bulk reminders`);
        debug('Bulk reminders payload length:', reminders.length);

        const results = [];

        for (const reminder of reminders) {
            try {
                const result = await processReminderJob({ data: reminder });
                results.push({ ...result, leadId: reminder.leadId });
            } catch (error) {
                console.error(`❌ Error processing reminder for lead ${reminder.leadId}:`, error);
                debug('Bulk item error:', reminder.leadId, error?.message);
                results.push({
                    success: false,
                    leadId: reminder.leadId,
                    error: error.message,
                });
            }
        }

        const successCount = results.filter(r => r.success).length;
        const failureCount = results.filter(r => !r.success).length;

        console.log(`✅ Bulk reminder processing completed: ${successCount} success, ${failureCount} failures`);

        return {
            success: true,
            total: reminders.length,
            successCount,
            failureCount,
            results,
        };

    } catch (error) {
        console.error(`❌ Error processing bulk reminders:`, error);
        debug('Bulk processor error:', error?.message);
        throw error;
    }
};

/**
 * Process overdue reminder check
 */
export const processOverdueReminderCheck = async (job) => {
    try {
        console.log(`🔄 Checking for overdue reminders`);
        debug('Overdue job id:', job?.id);

        const now = new Date();
        const overdueLeads = await Lead.find({
            reminderScheduled: true,
            followUpDate: { $lt: now },
        }).populate('assignedTo', 'email fcmToken');

        console.log(`📋 Found ${overdueLeads.length} overdue reminders`);
        debug('Overdue leads IDs:', overdueLeads.map(l => l._id.toString()));

        if (overdueLeads.length === 0) {
            return { success: true, overdueCount: 0 };
        }

        // Process overdue reminders
        const results = [];
        for (const lead of overdueLeads) {
            try {
                const leadFullName = `${lead.firstName || ''} ${lead.lastName || ''}`.trim() || 'Lead';
                const notificationData = {
                    title: 'Overdue Follow-up',
                    body: `Follow up with ${leadFullName} is overdue`,
                    data: {
                        type: 'overdue_reminder',
                        leadId: lead._id.toString(),
                        leadName: leadFullName,
                        followUpDate: lead.followUpDate,
                        userId: lead.assignedTo?._id?.toString(),
                    },
                };

                if (lead.assignedTo?.fcmToken) {
                    await sendFCMNotification(lead.assignedTo._id.toString(), notificationData);
                }

                // Emit WebSocket event
                websocketService.sendToUser(lead.assignedTo?._id?.toString(), 'call_reminder', {
                    leadId: lead._id.toString(),
                    leadName: leadFullName,
                    studentName: leadFullName,
                    followUpDate: lead.followUpDate,
                    message: 'Overdue follow-up reminder',
                    userId: lead.assignedTo?._id?.toString(),
                });

                results.push({
                    success: true,
                    leadId: lead._id.toString(),
                    leadName: leadFullName,
                });

            } catch (error) {
                console.error(`❌ Error processing overdue reminder for lead ${lead._id}:`, error);
                debug('Overdue item error:', lead._id.toString(), error?.message);
                results.push({
                    success: false,
                    leadId: lead._id.toString(),
                    error: error.message,
                });
            }
        }

        const successCount = results.filter(r => r.success).length;
        console.log(`✅ Overdue reminder check completed: ${successCount} processed`);

        return {
            success: true,
            overdueCount: overdueLeads.length,
            successCount,
            results,
        };

    } catch (error) {
        console.error(`❌ Error checking overdue reminders:`, error);
        debug('Overdue check error:', error?.message);
        throw error;
    }
};
