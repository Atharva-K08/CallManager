import cron from 'node-cron';
import { reminderQueue } from '../config/queue.js';
import { processOverdueReminders } from '../services/reminder.service.js';

const __showFollowUpLogs = process.env.SHOWFOLLOWUPLOGS === 'true' || process.env.SHOW_FOLLOW_UP_LOGS === 'true';
const debug = (...args) => { if (__showFollowUpLogs) console.log('[FOLLOWUP-DEBUG][Scheduler]', ...args); };

/**
 * Initialize cron jobs for reminder system
 */
export const initializeScheduler = () => {
    console.log('🔄 Initializing reminder scheduler...');
    debug('Cron setup starting');

    // Check for overdue reminders every 30 minutes
    cron.schedule('*/30 * * * *', async () => {
        console.log('🔄 Running overdue reminder check...');
        debug('Cron tick: overdue reminder check');
        try {
            await processOverdueReminders();
        } catch (error) {
            console.error('❌ Error in overdue reminder check:', error);
            debug('Overdue cron error:', error?.message);
        }
    });

    // Daily cleanup of completed jobs at 2 AM
    cron.schedule('0 2 * * *', async () => {
        console.log('🔄 Running daily job cleanup...');
        debug('Cron tick: daily cleanup');
        try {
            await reminderQueue.clean(24 * 60 * 60 * 1000, 'completed'); // Clean completed jobs older than 24 hours
            await reminderQueue.clean(7 * 24 * 60 * 60 * 1000, 'failed'); // Clean failed jobs older than 7 days
            console.log('✅ Daily cleanup completed');
        } catch (error) {
            console.error('❌ Error in daily cleanup:', error);
            debug('Cleanup cron error:', error?.message);
        }
    });

    // Weekly reminder statistics at 9 AM on Mondays
    cron.schedule('0 9 * * 1', async () => {
        console.log('🔄 Running weekly reminder statistics...');
        debug('Cron tick: weekly stats');
        try {
            const stats = await reminderQueue.getJobCounts();
            console.log('📊 Weekly reminder statistics:', stats);
            debug('Job counts:', stats);
        } catch (error) {
            console.error('❌ Error in weekly statistics:', error);
            debug('Weekly stats error:', error?.message);
        }
    });

    // Health check every hour
    cron.schedule('0 * * * *', async () => {
        try {
            const counts = await reminderQueue.getJobCounts();
            const isHealthy = counts.waiting + counts.active + counts.delayed < 1000; // Threshold for healthy queue

            if (!isHealthy) {
                console.warn('⚠️ Reminder queue may be overloaded:', counts);
                debug('Health check not healthy:', counts);
            }
        } catch (error) {
            console.error('❌ Error in health check:', error);
            debug('Health check error:', error?.message);
        }
    });

    console.log('✅ Reminder scheduler initialized');
    debug('Cron setup complete');
};

/**
 * Get scheduler status
 */
export const getSchedulerStatus = async () => {
    try {
        const counts = await reminderQueue.getJobCounts();
        const isPaused = await reminderQueue.isPaused();

        return {
            isRunning: !isPaused,
            jobCounts: counts,
            isHealthy: counts.waiting + counts.active + counts.delayed < 1000,
        };
    } catch (error) {
        console.error('❌ Error getting scheduler status:', error);
        return {
            isRunning: false,
            error: error.message,
        };
    }
};

/**
 * Pause scheduler
 */
export const pauseScheduler = async () => {
    try {
        await reminderQueue.pause();
        console.log('⏸️ Reminder scheduler paused');
        return { success: true };
    } catch (error) {
        console.error('❌ Error pausing scheduler:', error);
        return { success: false, error: error.message };
    }
};

/**
 * Resume scheduler
 */
export const resumeScheduler = async () => {
    try {
        await reminderQueue.resume();
        console.log('▶️ Reminder scheduler resumed');
        return { success: true };
    } catch (error) {
        console.error('❌ Error resuming scheduler:', error);
        return { success: false, error: error.message };
    }
};

/**
 * Clear all jobs
 */
export const clearAllJobs = async () => {
    try {
        await reminderQueue.empty();
        console.log('🗑️ All reminder jobs cleared');
        return { success: true };
    } catch (error) {
        console.error('❌ Error clearing jobs:', error);
        return { success: false, error: error.message };
    }
};
