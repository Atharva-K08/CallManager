# API Response Standards

This document outlines the standardized response format used across all API endpoints in the call tracker backend.

## Response Format

All API responses follow a consistent structure to ensure frontend-backend compatibility and maintainability.

### Success Response Format

```javascript
{
  "success": true,
  "status": 1,
  "data": any,
  "message": "Success message"
}
```

### Error Response Format

```javascript
{
  "success": false,
  "status": 0,
  "data": null,
  "message": "Error message",
  "code": 400,
  "errors": {
    "field": ["validation error message"]
  }
}
```

### Paginated Response Format

```javascript
{
  "success": true,
  "status": 1,
  "data": [...],
  "meta": {
    "current_page": 1,
    "total_pages": 10,
    "total_items": 100,
    "per_page": 10
  },
  "message": "Data retrieved successfully"
}
```

## Response Types

### 1. ApiResponse
Standard response for most endpoints.

**Usage:**
```javascript
import { sendSuccess, sendError } from '../utils/response.utils.js';

// Success response
sendSuccess(res, data, 'Operation successful');

// Error response
sendError(res, 'Error message', 400);
```

### 2. PaginatedResponse
For endpoints that return paginated data.

**Usage:**
```javascript
import { sendPaginated } from '../utils/response.utils.js';

const paginationMeta = createPaginationMeta(page, limit, total);
sendPaginated(res, data, paginationMeta, 'Data retrieved successfully');
```

### 3. AuthResponse
For authentication-related endpoints.

**Usage:**
```javascript
import { sendAuthSuccess, sendAuthError } from '../utils/response.utils.js';

// Login success
sendAuthSuccess(res, user, tokens, 'Login successful');

// Auth error
sendAuthError(res, 'Invalid credentials', 401);
```

### 4. ValidationResponse
For validation error responses.

**Usage:**
```javascript
import { sendValidationError } from '../utils/response.utils.js';

sendValidationError(res, validationErrors, 'Validation failed');
```

## Response Utility Functions

### Success Responses
- `sendSuccess(res, data, message, statusCode)` - Standard success response
- `sendCreated(res, data, message)` - Created resource response (201)
- `sendNoContent(res, message)` - No content response (204)
- `sendAuthSuccess(res, user, tokens, message)` - Authentication success

### Error Responses
- `sendError(res, message, statusCode, errors)` - Standard error response
- `sendValidationError(res, errors, message)` - Validation error response
- `sendAuthError(res, message, statusCode)` - Authentication error
- `sendNotFound(res, message)` - Not found error (404)
- `sendUnauthorized(res, message)` - Unauthorized error (401)
- `sendForbidden(res, message)` - Forbidden error (403)
- `sendInternalError(res, message)` - Internal server error (500)

### Pagination
- `sendPaginated(res, data, pagination, message)` - Paginated response
- `createPaginationMeta(page, limit, total)` - Create pagination metadata

## Implementation Examples

### Controller Implementation

```javascript
import { sendSuccess, sendError, sendPaginated } from '../utils/response.utils.js';

// Get all users
const getUsers = catchAsync(async (req, res) => {
  const users = await userService.getUsers();
  sendSuccess(res, users, 'Users retrieved successfully');
});

// Get paginated users
const getUsersPaginated = catchAsync(async (req, res) => {
  const { page = 1, limit = 10 } = req.query;
  const result = await userService.getUsersPaginated(page, limit);
  const paginationMeta = createPaginationMeta(page, limit, result.total);
  sendPaginated(res, result.users, paginationMeta, 'Users retrieved successfully');
});

// Create user
const createUser = catchAsync(async (req, res) => {
  const user = await userService.createUser(req.body);
  sendCreated(res, user, 'User created successfully');
});

// Error handling
const getUserById = catchAsync(async (req, res) => {
  const user = await userService.getUserById(req.params.id);
  if (!user) {
    return sendNotFound(res, 'User not found');
  }
  sendSuccess(res, user, 'User retrieved successfully');
});
```

### Error Middleware Integration

The error middleware automatically converts all errors to the standardized format:

```javascript
// Automatic error conversion
app.use(errorConverter);
app.use(errorHandler);
```

## Frontend Integration

The frontend can now expect consistent response formats:

```typescript
// TypeScript interfaces for frontend
interface ApiResponse<T = any> {
  success: boolean;
  status: number;
  data: T;
  message?: string;
  errors?: Record<string, string[]>;
}

interface PaginatedResponse<T> {
  success: boolean;
  status: number;
  data: T[];
  meta: {
    current_page: number;
    total_pages: number;
    total_items: number;
    per_page: number;
  };
  message?: string;
}
```

## Benefits

1. **Consistency**: All endpoints return responses in the same format
2. **Frontend Compatibility**: Easy to handle responses in frontend applications
3. **Error Handling**: Standardized error responses with proper HTTP status codes
4. **Pagination**: Built-in support for paginated responses
5. **Type Safety**: TypeScript interfaces available for frontend integration
6. **Maintainability**: Centralized response logic makes updates easier

## Migration Guide

### Before (Old Format)
```javascript
res.status(200).json({
  status: 1,
  data: result,
  message: 'Success'
});
```

### After (New Format)
```javascript
import { sendSuccess } from '../utils/response.utils.js';

sendSuccess(res, result, 'Success');
```

This standardized approach ensures consistency across all API endpoints and makes the codebase more maintainable and frontend-friendly.
