/**
 * Common API Response Types
 * These types define the standardized response format for all API endpoints
 */

/**
 * Standard API Response interface
 * @template T - The type of data being returned
 */
export class ApiResponse {
    /**
     * Creates a successful API response
     * @param {any} data - The response data
     * @param {string} message - Optional success message
     * @returns {Object} Standardized success response
     */
    static success(data, message = 'Success') {
        return {
            success: true,
            status: 1,
            data,
            message
        };
    }

    /**
     * Creates a failed API response
     * @param {string} message - Error message
     * @param {Object} errors - Optional validation errors
     * @returns {Object} Standardized error response
     */
    static error(message, errors = null) {
        return {
            success: false,
            status: 0,
            data: null,
            message,
            ...(errors && { errors })
        };
    }
}

/**
 * Paginated Response interface
 * @template T - The type of items in the paginated data
 */
export class PaginatedResponse {
    /**
     * Creates a paginated API response
     * @param {Array} data - Array of items
     * @param {Object} meta - Pagination metadata
     * @param {number} meta.current_page - Current page number
     * @param {number} meta.total_pages - Total number of pages
     * @param {number} meta.total_items - Total number of items
     * @param {number} meta.per_page - Items per page
     * @param {string} message - Optional success message
     * @returns {Object} Standardized paginated response
     */
    static success(data, meta, message = 'Success') {
        return {
            success: true,
            status: 1,
            data,
            meta,
            message
        };
    }
}

/**
 * API Error class for consistent error handling
 */
export class ApiErrorResponse {
    /**
     * Creates an API error response
     * @param {string} message - Error message
     * @param {number} status - HTTP status code
     * @param {Object} errors - Optional validation errors
     * @returns {Object} Standardized error response
     */
    static create(message, status = 400, errors = null) {
        return {
            success: false,
            status: 0,
            data: null,
            message,
            code: status,
            ...(errors && { errors })
        };
    }
}

/**
 * Auth-specific response types
 */
export class AuthResponse {
    /**
     * Creates a successful authentication response
     * @param {Object} user - User data
     * @param {Object} tokens - Authentication tokens
     * @param {string} message - Optional success message
     * @returns {Object} Standardized auth response
     */
    static success(user, tokens, message = 'Authentication successful') {
        return {
            success: true,
            status: 1,
            data: {
                user,
                tokens
            },
            message
        };
    }

    /**
     * Creates an authentication error response
     * @param {string} message - Error message
     * @param {number} status - HTTP status code
     * @returns {Object} Standardized auth error response
     */
    static error(message, status = 401) {
        return {
            success: false,
            status: 0,
            data: null,
            message,
            code: status
        };
    }
}

/**
 * Validation error response
 */
export class ValidationResponse {
    /**
     * Creates a validation error response
     * @param {Object} errors - Validation errors object
     * @param {string} message - Error message
     * @returns {Object} Standardized validation error response
     */
    static error(errors, message = 'Validation failed') {
        return {
            success: false,
            status: 0,
            data: null,
            message,
            errors
        };
    }
}
