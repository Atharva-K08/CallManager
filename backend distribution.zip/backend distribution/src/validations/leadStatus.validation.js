import Joi from 'joi';

const objectId = (value, helpers) => {
    // simple 24-hex check
    if (!/^[a-fA-F0-9]{24}$/.test(value)) {
        return helpers.message('"{#label}" must be a valid id');
    }
    return value;
};

export const createLeadStatus = {
    body: Joi.object().keys({
        name: Joi.string().trim().min(1).max(100).required(),
        type: Joi.string().valid('leadStatus', 'callStatus').required(),
        color: Joi.string().trim().allow(null, ''),
        order: Joi.number().integer().min(0).default(0),
        isActive: Joi.boolean().default(true),
        description: Joi.string().trim().max(500).allow(null, ''),
    }),
};

export const getLeadStatuses = {
    query: Joi.object().keys({
        type: Joi.string().valid('leadStatus', 'callStatus'),
        isActive: Joi.alternatives(Joi.boolean(), Joi.string().valid('true', 'false')),
        search: Joi.string().trim().allow('', null),
        sortBy: Joi.string().trim(),
        page: Joi.number().integer().min(1),
        limit: Joi.number().integer().min(1).max(100),
    }),
};

export const getLeadStatus = {
    params: Joi.object().keys({
        leadStatusId: Joi.string().custom(objectId),
    }),
};

export const updateLeadStatus = {
    params: Joi.object().keys({
        leadStatusId: Joi.string().custom(objectId),
    }),
    body: Joi.object()
        .keys({
            name: Joi.string().trim().min(1).max(100),
            type: Joi.string().valid('leadStatus', 'callStatus'),
            color: Joi.string().trim().allow(null, ''),
            order: Joi.number().integer().min(0),
            isActive: Joi.boolean(),
            description: Joi.string().trim().max(500).allow(null, ''),
        })
        .min(1),
};

export const deleteLeadStatus = {
    params: Joi.object().keys({
        leadStatusId: Joi.string().custom(objectId),
    }),
};

export const setActive = {
    params: Joi.object().keys({
        leadStatusId: Joi.string().custom(objectId),
    }),
};

export default {
    createLeadStatus,
    getLeadStatuses,
    getLeadStatus,
    updateLeadStatus,
    deleteLeadStatus,
    setActive,
};


