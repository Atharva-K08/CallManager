import Joi from 'joi';

const lookupCaller = {
    body: Joi.object().keys({
        phone_number: Joi.string()
            .required()
            .min(10)
            .max(15)
            .pattern(/^[\+]?[0-9\s\-\(\)]+$/)
            .messages({
                'string.pattern.base': 'Phone number must contain only digits, spaces, dashes, parentheses, and optional + prefix',
                'string.min': 'Phone number must be at least 10 characters',
                'string.max': 'Phone number must be at most 15 characters',
                'string.empty': 'Phone number is required'
            })
    })
};

export { lookupCaller };
