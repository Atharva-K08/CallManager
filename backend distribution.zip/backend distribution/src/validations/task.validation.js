import Joi from 'joi';

const objectId = (value, helpers) => {
    if (!/^[a-fA-F0-9]{24}$/.test(value)) {
        return helpers.message('"{#label}" must be a valid id');
    }
    return value;
};

export const createTask = {
    body: Joi.object().keys({
        title: Joi.string().trim().allow('', null),
        description: Joi.string().trim().allow('', null),
        assignedTo: Joi.string().custom(objectId).required(),
        assignedToName: Joi.string().trim().allow('', null),
        assignedToEmail: Joi.string().email().allow('', null),
        leadIds: Joi.array().items(Joi.string().custom(objectId)).default([]),
        targetCount: Joi.number().integer().min(0),
        status: Joi.string().valid('PENDING', 'IN_PROGRESS', 'COMPLETED').default('PENDING'),
        completedCount: Joi.number().integer().min(0).default(0),
        totalCount: Joi.number().integer().min(0),
        dueAt: Joi.date().allow(null),
    }),
};

export const handoverTask = {
    body: Joi.object().keys({
        title: Joi.string().trim().allow('', null),
        description: Joi.string().trim().allow('', null),
        assignedTo: Joi.string().custom(objectId).required(),
        assignedToName: Joi.string().trim().allow('', null),
        assignedToEmail: Joi.string().email().allow('', null),
        leadIds: Joi.array().items(Joi.string().custom(objectId)).min(1).required(),
        dueAt: Joi.date().allow(null),
        sourceTaskId: Joi.string().custom(objectId).allow(null),
    })
};

export const getTasks = {
    query: Joi.object().keys({
        assignedTo: Joi.string().custom(objectId),
        status: Joi.string().valid('PENDING', 'IN_PROGRESS', 'COMPLETED'),
        search: Joi.string().trim().allow('', null),
        sortBy: Joi.string().trim().allow('', null),
        page: Joi.number().integer().min(1),
        limit: Joi.number().integer().min(1).max(100),
    }),
};

export const getTask = {
    params: Joi.object().keys({ taskId: Joi.string().custom(objectId) }),
};

export const updateTask = {
    params: Joi.object().keys({ taskId: Joi.string().custom(objectId) }),
    body: Joi.object().keys({
        title: Joi.string().trim(),
        description: Joi.string().trim().allow('', null),
        assignedTo: Joi.string().custom(objectId),
        assignedToName: Joi.string().trim().allow('', null),
        assignedToEmail: Joi.string().email().allow('', null),
        leadIds: Joi.array().items(Joi.string().custom(objectId)),
        targetCount: Joi.number().integer().min(0),
        status: Joi.string().valid('PENDING', 'IN_PROGRESS', 'COMPLETED'),
        completedCount: Joi.number().integer().min(0),
        totalCount: Joi.number().integer().min(0),
        dueAt: Joi.date().allow(null),
    }).min(1),
};

export const deleteTask = {
    params: Joi.object().keys({ taskId: Joi.string().custom(objectId) }),
};

export const setTaskStatus = {
    params: Joi.object().keys({ taskId: Joi.string().custom(objectId) }),
    body: Joi.object().keys({ status: Joi.string().valid('PENDING', 'IN_PROGRESS', 'COMPLETED').required() }),
};

export const incrementTaskProgress = {
    params: Joi.object().keys({ taskId: Joi.string().custom(objectId) }),
    body: Joi.object().keys({ by: Joi.number().integer().min(1).default(1) }),
};

export const syncTaskProgress = {
    body: Joi.object().keys({
        leads: Joi.array().items(
            Joi.object().keys({
                leadId: Joi.string().custom(objectId).required(),
                status: Joi.string().trim().required(),
                callStatus: Joi.string().trim().required(),
                remark: Joi.string().trim().allow('', null),
                lastContactedAt: Joi.date().allow(null),
            })
        ).min(1).required(),
    }),
};

export default {
    createTask,
    handoverTask,
    getTasks,
    getTask,
    updateTask,
    deleteTask,
    setTaskStatus,
    incrementTaskProgress,
    syncTaskProgress,
};


