import Joi from 'joi';
import { password, objectId } from './custom.validation.js';

const createUser = {
    body: Joi.object().keys({
        name: Joi.string().required().trim().min(2).max(50).messages({
            'string.empty': 'Name cannot be empty',
            'string.min': 'Name must be at least 2 characters long',
            'string.max': 'Name cannot exceed 50 characters',
        }),
        email: Joi.string().required().email().trim().lowercase().messages({
            'string.empty': 'Email cannot be empty',
            'string.email': 'Please provide a valid email address',
        }),
        password: Joi.string().required().custom(password).messages({
            'string.empty': 'Password cannot be empty',
        }),
        role: Joi.string().allow('', null),
        phoneNumber: Joi.string().optional().pattern(/^[0-9+\-\s()]+$/).messages({
            'string.pattern.base': 'Please provide a valid phone number',
        }),
        profilePicture: Joi.string().optional().uri().messages({
            'string.uri': 'Profile picture must be a valid URL',
        }),
        isActive: Joi.boolean().default(true),
    }),
};

const getUsers = {
    query: Joi.object().keys({
        name: Joi.string().optional(),
        email: Joi.string().optional(),
        role: Joi.string().allow('', null).optional(),
        isActive: Joi.boolean().optional(),
        sortBy: Joi.string().optional(),
        limit: Joi.number().integer().min(1).max(100).default(10),
        page: Joi.number().integer().min(1).default(1),
    }),
};

const getUser = {
    params: Joi.object().keys({
        userId: Joi.string().required().custom(objectId),
    }),
};

const updateUser = {
    params: Joi.object().keys({
        userId: Joi.string().required().custom(objectId),
    }),
    body: Joi.object()
        .keys({
            name: Joi.string().optional().trim().min(2).max(50),
            email: Joi.string().optional().email().trim().lowercase(),
            phoneNumber: Joi.string().optional().pattern(/^[0-9+\-\s()]+$/),
            profilePicture: Joi.string().optional().uri(),
            role: Joi.string().allow('', null).optional(),
            isActive: Joi.boolean().optional(),
        })
        .min(1)
        .messages({
            'object.min': 'At least one field must be provided for update',
        }),
};

const updateUserPassword = {
    params: Joi.object().keys({
        userId: Joi.string().required().custom(objectId),
    }),
    body: Joi.object().keys({
        currentPassword: Joi.string().required().messages({
            'string.empty': 'Current password is required',
        }),
        newPassword: Joi.string().required().custom(password).messages({
            'string.empty': 'New password is required',
        }),
        confirmPassword: Joi.string().required().valid(Joi.ref('newPassword')).messages({
            'any.only': 'Confirm password must match new password',
            'string.empty': 'Confirm password is required',
        }),
    }),
};

const updateUserPasswordByAdmin = {
    params: Joi.object().keys({
        userId: Joi.string().required().custom(objectId),
    }),
    body: Joi.object().keys({
        newPassword: Joi.string().required().custom(password).messages({
            'string.empty': 'New password is required',
        }),
        confirmPassword: Joi.string().required().valid(Joi.ref('newPassword')).messages({
            'any.only': 'Confirm password must match new password',
            'string.empty': 'Confirm password is required',
        }),
    }),
};

const deleteUser = {
    params: Joi.object().keys({
        userId: Joi.string().required().custom(objectId),
    }),
};

const activateUser = {
    params: Joi.object().keys({
        userId: Joi.string().required().custom(objectId),
    }),
};

const deactivateUser = {
    params: Joi.object().keys({
        userId: Joi.string().required().custom(objectId),
    }),
};

const getUserProfile = {
    params: Joi.object().keys({
        userId: Joi.string().required().custom(objectId),
    }),
};

const updateUserProfile = {
    params: Joi.object().keys({
        userId: Joi.string().required().custom(objectId),
    }),
    body: Joi.object()
        .keys({
            name: Joi.string().optional().trim().min(2).max(50),
            phoneNumber: Joi.string().optional().pattern(/^[0-9+\-\s()]+$/),
            profilePicture: Joi.string().optional().uri(),
        })
        .min(1)
        .messages({
            'object.min': 'At least one field must be provided for update',
        }),
};

const searchUsers = {
    query: Joi.object().keys({
        q: Joi.string().required().min(1).max(100).messages({
            'string.empty': 'Search query cannot be empty',
            'string.min': 'Search query must be at least 1 character',
            'string.max': 'Search query cannot exceed 100 characters',
        }),
        role: Joi.string().allow('', null).optional(),
        isActive: Joi.boolean().optional(),
        limit: Joi.number().integer().min(1).max(50).default(10),
        page: Joi.number().integer().min(1).default(1),
    }),
};

const getUserStats = {
    query: Joi.object().keys({
        startDate: Joi.date().optional(),
        endDate: Joi.date().optional(),
    }),
};

export {
    createUser,
    getUsers,
    getUser,
    updateUser,
    updateUserPassword,
    updateUserPasswordByAdmin,
    deleteUser,
    activateUser,
    deactivateUser,
    getUserProfile,
    updateUserProfile,
    searchUsers,
    getUserStats,
};
