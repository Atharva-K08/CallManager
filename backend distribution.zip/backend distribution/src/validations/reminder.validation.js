import Joi from 'joi';

const scheduleReminder = {
    body: Joi.object().keys({
        leadId: Joi.string().required().messages({
            'string.empty': 'Lead ID is required',
            'any.required': 'Lead ID is required',
        }),
        leadName: Joi.string().required().messages({
            'string.empty': 'Lead name is required',
            'any.required': 'Lead name is required',
        }),
        followUpDate: Joi.date().iso().greater('now').required().messages({
            'date.greater': 'Follow-up date must be in the future',
            'any.required': 'Follow-up date is required',
        }),
        message: Joi.string().max(500).optional().messages({
            'string.max': 'Message cannot exceed 500 characters',
        }),
        reminderIntervalDays: Joi.number().integer().min(1).max(365).default(7).messages({
            'number.min': 'Reminder interval must be at least 1 day',
            'number.max': 'Reminder interval cannot exceed 365 days',
        }),
    }),
};

const updateReminder = {
    body: Joi.object().keys({
        leadName: Joi.string().optional().messages({
            'string.empty': 'Lead name cannot be empty',
        }),
        followUpDate: Joi.date().iso().greater('now').optional().messages({
            'date.greater': 'Follow-up date must be in the future',
        }),
        message: Joi.string().max(500).optional().messages({
            'string.max': 'Message cannot exceed 500 characters',
        }),
        reminderIntervalDays: Joi.number().integer().min(1).max(365).optional().messages({
            'number.min': 'Reminder interval must be at least 1 day',
            'number.max': 'Reminder interval cannot exceed 365 days',
        }),
    }),
};

const scheduleBulkReminders = {
    body: Joi.object().keys({
        reminders: Joi.array()
            .items(
                Joi.object().keys({
                    leadId: Joi.string().required().messages({
                        'string.empty': 'Lead ID is required',
                        'any.required': 'Lead ID is required',
                    }),
                    leadName: Joi.string().required().messages({
                        'string.empty': 'Lead name is required',
                        'any.required': 'Lead name is required',
                    }),
                    followUpDate: Joi.date().iso().greater('now').required().messages({
                        'date.greater': 'Follow-up date must be in the future',
                        'any.required': 'Follow-up date is required',
                    }),
                    message: Joi.string().max(500).optional().messages({
                        'string.max': 'Message cannot exceed 500 characters',
                    }),
                    reminderIntervalDays: Joi.number().integer().min(1).max(365).default(7).messages({
                        'number.min': 'Reminder interval must be at least 1 day',
                        'number.max': 'Reminder interval cannot exceed 365 days',
                    }),
                })
            )
            .min(1)
            .max(100)
            .required()
            .messages({
                'array.min': 'At least one reminder is required',
                'array.max': 'Cannot schedule more than 100 reminders at once',
                'any.required': 'Reminders array is required',
            }),
    }),
};

export const reminderValidation = {
    scheduleReminder,
    updateReminder,
    scheduleBulkReminders,
};
