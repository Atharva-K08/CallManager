import Joi from 'joi';

const checkUserConnection = {
    params: Joi.object().keys({
        userId: Joi.string().required(),
    }),
};

const broadcastMessage = {
    body: Joi.object().keys({
        event: Joi.string().required(),
        data: Joi.object().optional(),
        target: Joi.string().valid('all', 'admin', 'mobile').optional(),
    }),
};

const sendToUser = {
    params: Joi.object().keys({
        userId: Joi.string().required(),
    }),
    body: Joi.object().keys({
        event: Joi.string().required(),
        data: Joi.object().optional(),
    }),
};

export {
    checkUserConnection,
    broadcastMessage,
    sendToUser,
};
