import Joi from 'joi';

const objectId = (value, helpers) => {
    if (!/^[a-fA-F0-9]{24}$/.test(value)) {
        return helpers.message('"{#label}" must be a valid id');
    }
    return value;
};

const callStatusEnum = [
    'CALL_DIALING',
    'CALL_CONNECTING',
    'CALL_RINGING',
    'CALL_CONNECTED',
    'CALL_ACTIVE',
    'CALL_ENDED_CONNECTED',
    'CALL_ENDED_BY_CALLER',
    'CALL_ENDED_BY_CALLEE',
    'CALL_ENDED_NO_ANSWER',
    'CALL_DECLINED_BY_LEAD',
    'CALL_DECLINED_BY_CALLEE',
    'CALL_DECLINED_BY_CALLER',
    'CALL_CANCELLED_BY_CALLER',
    'CALL_BUSY',
    'CALL_NO_ANSWER',
    'CALL_MISSED',
    'CALL_WAITING_INCOMING',
    'CALL_SWITCHED'
];

const callSourceEnum = ['app', 'system', 'unknown'];

export const createCallRecord = {
    body: Joi.object().keys({
        phoneNumber: Joi.string().trim().required(),
        contactName: Joi.string().trim().allow(null, ''),
        initiatedAt: Joi.date().required(),
        connectedAt: Joi.date().allow(null),
        endedAt: Joi.date().allow(null),
        durationSeconds: Joi.number().integer().min(0).allow(null),
        status: Joi.string().valid(...callStatusEnum).required(),
        source: Joi.string().valid(...callSourceEnum).required(),
        isOutgoing: Joi.boolean().required(),
        deviceInfo: Joi.string().trim().allow(null, ''),
        metadata: Joi.object().unknown(true).allow(null),
        outcomeLabel: Joi.string().trim().allow(null, ''),
        leadId: Joi.string().custom(objectId).allow(null, ''),
    }),
};

export const getCallRecords = {
    query: Joi.object().keys({
        search: Joi.string().trim().allow('', null),
        status: Joi.string().valid(...callStatusEnum).allow('', null),
        source: Joi.string().valid(...callSourceEnum).allow('', null),
        isOutgoing: Joi.boolean().allow('true', 'false', true, false),
        createdBy: Joi.string().custom(objectId).allow('', null),
        leadId: Joi.string().custom(objectId).allow('', null),
        from: Joi.date().allow('', null),
        to: Joi.date().allow('', null),
        sortBy: Joi.string().trim().allow('', null),
        page: Joi.number().integer().min(1),
        limit: Joi.number().integer().min(1).max(100),
    })
};

export const getCallRecord = {
    params: Joi.object().keys({ callRecordId: Joi.string().custom(objectId) }),
};

export const updateCallRecord = {
    params: Joi.object().keys({ callRecordId: Joi.string().custom(objectId) }),
    body: Joi.object().keys({
        phoneNumber: Joi.string().trim(),
        contactName: Joi.string().trim().allow(null, ''),
        initiatedAt: Joi.date(),
        connectedAt: Joi.date().allow(null),
        endedAt: Joi.date().allow(null),
        durationSeconds: Joi.number().integer().min(0).allow(null),
        status: Joi.string().valid(...callStatusEnum),
        source: Joi.string().valid(...callSourceEnum),
        isOutgoing: Joi.boolean(),
        deviceInfo: Joi.string().trim().allow(null, ''),
        metadata: Joi.object().unknown(true).allow(null),
        outcomeLabel: Joi.string().trim().allow(null, ''),
        leadId: Joi.string().custom(objectId).allow(null, ''),
    }).min(1),
};

export const deleteCallRecord = {
    params: Joi.object().keys({ callRecordId: Joi.string().custom(objectId) }),
};

export const updateStatus = {
    params: Joi.object().keys({ callRecordId: Joi.string().custom(objectId) }),
    body: Joi.object().keys({ status: Joi.string().valid(...callStatusEnum).required() })
};

export const getStatistics = {
    query: Joi.object().keys({
        createdBy: Joi.string().custom(objectId).allow('', null),
        leadId: Joi.string().custom(objectId).allow('', null),
        from: Joi.date().allow('', null),
        to: Joi.date().allow('', null),
    })
};

export const getByPhoneNumber = {
    params: Joi.object().keys({ phoneNumber: Joi.string().trim().required() }),
};

export const getByLeadId = {
    params: Joi.object().keys({ leadId: Joi.string().custom(objectId) }),
};

export const syncUpload = {
    body: Joi.object().keys({
        callRecords: Joi.array().items(Joi.object().keys({
            id: Joi.string().required(),
            phoneNumber: Joi.string().required(),
            contactName: Joi.string().allow(null, ''),
            initiatedAt: Joi.string().required(),
            connectedAt: Joi.string().allow(null, ''),
            endedAt: Joi.string().allow(null, ''),
            durationSeconds: Joi.number().integer().min(0).allow(null),
            status: Joi.string().valid(...callStatusEnum).required(),
            source: Joi.string().valid(...callSourceEnum).required(),
            isOutgoing: Joi.boolean().required(),
            deviceInfo: Joi.string().allow(null, ''),
            metadata: Joi.object().unknown(true).allow(null),
            outcomeLabel: Joi.string().allow(null, ''),
            leadId: Joi.string().allow(null, ''),
            createdBy: Joi.string().required(),
            createdAt: Joi.string().required(),
            updatedAt: Joi.string().required(),
        })).required()
    })
};

export const syncPull = {
    query: Joi.object().keys({ since: Joi.string().required(), limit: Joi.number().integer().min(1).max(100).default(100) })
};

export default {
    createCallRecord,
    getCallRecords,
    getCallRecord,
    updateCallRecord,
    deleteCallRecord,
    updateStatus,
    getStatistics,
    getByPhoneNumber,
    getByLeadId,
    syncUpload,
    syncPull,
};

