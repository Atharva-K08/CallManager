import Joi from 'joi';

const objectId = (value, helpers) => {
    if (!/^[a-fA-F0-9]{24}$/.test(value)) {
        return helpers.message('"{#label}" must be a valid id');
    }
    return value;
};

export const createLead = {
    body: Joi.object().keys({
        firstName: Joi.string().trim().required(),
        lastName: Joi.string().trim().required(),
        phoneNumber: Joi.string().trim().required().custom((value, helpers) => {
            // Remove all non-digit characters
            const digitsOnly = value.replace(/\D/g, '');
            // Check if it has at least 10 digits
            if (digitsOnly.length < 10) {
                return helpers.message('Phone number must have at least 10 digits');
            }
            return value;
        }),
        email: Joi.string().email().allow(null, ''),
        campus: Joi.string().trim().allow(null, ''),
        class: Joi.string().trim().allow(null, ''),
        city: Joi.string().trim().allow(null, ''),
        status: Joi.string().trim().required(),
        remark: Joi.string().trim().allow(null, ''),
        callStatus: Joi.string().trim().default('Not Called'),
        lastContactedAt: Joi.date().allow(null),
        metadata: Joi.object().unknown(true).allow(null),
        assignedTo: Joi.string().trim().allow(null, ''),
        assignedToName: Joi.string().trim().allow(null, ''),
        assignedToEmail: Joi.string().email().allow(null, ''),
        source: Joi.string().trim().allow(null, ''),
        priority: Joi.number().integer().min(0).max(3).default(0),
    }),
};

export const getLeads = {
    query: Joi.object().keys({
        search: Joi.string().trim().allow('', null),
        status: Joi.string().trim().allow('', null),
        callStatus: Joi.string().trim().allow('', null),
        assignedTo: Joi.string().trim().allow('', null),
        source: Joi.string().trim().allow('', null),
        taskId: Joi.string().custom(objectId).allow('', null),
        ids: Joi.alternatives().try(
            Joi.string().trim().allow('', null), // Comma-separated string
            Joi.array().items(Joi.string().custom(objectId)) // Array of IDs
        ).allow('', null),
        completed: Joi.boolean().allow('true', 'false', true, false),
        unassigned: Joi.boolean().allow('true', 'false', true, false),
        city: Joi.string().trim().allow('', null),
        campus: Joi.string().trim().allow('', null),
        class: Joi.string().trim().allow('', null),
        createdAtFrom: Joi.date().iso().allow('', null),
        createdAtTo: Joi.date().iso().allow('', null),
        assigned: Joi.boolean().allow('true', 'false', true, false),
        sortBy: Joi.string().trim().allow('', null),
        page: Joi.number().integer().min(1),
        limit: Joi.number().integer().min(1).max(100),
    })
};

export const getLead = {
    params: Joi.object().keys({ leadId: Joi.string().custom(objectId) }),
};

export const updateLead = {
    params: Joi.object().keys({ leadId: Joi.string().custom(objectId) }),
    body: Joi.object().keys({
        firstName: Joi.string().trim(),
        lastName: Joi.string().trim(),
        phoneNumber: Joi.string().trim().custom((value, helpers) => {
            if (!value) return value; // Allow empty for updates
            // Remove all non-digit characters
            const digitsOnly = value.replace(/\D/g, '');
            // Check if it has at least 10 digits
            if (digitsOnly.length < 10) {
                return helpers.message('Phone number must have at least 10 digits');
            }
            return value;
        }),
        email: Joi.string().email().allow(null, ''),
        campus: Joi.string().trim().allow(null, ''),
        class: Joi.string().trim().allow(null, ''),
        city: Joi.string().trim().allow(null, ''),
        status: Joi.string().trim(),
        remark: Joi.string().trim().allow(null, ''),
        callStatus: Joi.string().trim(),
        lastContactedAt: Joi.date().allow(null),
        metadata: Joi.object().unknown(true).allow(null),
        assignedTo: Joi.string().trim().allow(null, ''),
        assignedToName: Joi.string().trim().allow(null, ''),
        assignedToEmail: Joi.string().email().allow(null, ''),
        source: Joi.string().trim().allow(null, ''),
        priority: Joi.number().integer().min(0).max(3),
    }).min(1),
};

export const deleteLead = {
    params: Joi.object().keys({ leadId: Joi.string().custom(objectId) }),
};

export const updateStatus = {
    params: Joi.object().keys({ leadId: Joi.string().custom(objectId) }),
    body: Joi.object().keys({ status: Joi.string().trim().required(), remark: Joi.string().trim().allow('', null) })
};

export const updateCallStatus = {
    params: Joi.object().keys({ leadId: Joi.string().custom(objectId) }),
    body: Joi.object().keys({ callStatus: Joi.string().trim().required() })
};

export const syncUpload = {
    body: Joi.object().keys({
        leads: Joi.array().items(Joi.object().keys({
            id: Joi.string().required(),
            firstName: Joi.string().required(),
            lastName: Joi.string().required(),
            phoneNumber: Joi.string().required(),
            email: Joi.string().allow(null, ''),
            campus: Joi.string().allow(null, ''),
            class: Joi.string().allow(null, ''),
            city: Joi.string().allow(null, ''),
            status: Joi.string().required(),
            remark: Joi.string().allow(null, ''),
            callStatus: Joi.string().default('Not Called'),
            createdAt: Joi.string().required(),
            updatedAt: Joi.string().required(),
            lastContactedAt: Joi.string().allow(null, ''),
            metadata: Joi.object().unknown(true).allow(null),
            assignedTo: Joi.string().allow(null, ''),
            assignedToName: Joi.string().allow(null, ''),
            assignedToEmail: Joi.string().email().allow(null, ''),
            source: Joi.string().allow(null, ''),
            priority: Joi.number().integer().min(0).max(3).allow(null)
        })).required()
    })
};

export const syncPull = {
    query: Joi.object().keys({ since: Joi.string().required(), limit: Joi.number().integer().min(1).max(100).default(100) })
};

export default {
    createLead,
    getLeads,
    getLead,
    updateLead,
    deleteLead,
    updateStatus,
    updateCallStatus,
    syncUpload,
    syncPull,
};


