import express from 'express';
import auth from '../../middlewares/auth.js';
import * as followUpController from '../../controllers/followUp.controller.js';

const router = express.Router();
router.use(auth());

router
    .route('/')
    .post(followUpController.create)
    .get(followUpController.list);

router
    .route('/:followUpId')
    .get(followUpController.get)
    .put(followUpController.update)
    .delete(followUpController.remove);

router
    .route('/:followUpId/resolve')
    .post(followUpController.resolveFollowUp);

router
    .route('/:followUpId/unresolve')
    .post(followUpController.unresolveFollowUp);

router
    .route('/resolved')
    .get(followUpController.getResolvedFollowUps);

export default router;


