import express from 'express';
import docsRoute from './docs.route.js';
import config from '../../config/config.js';

import fileRoute from './file.route.js';
import userRoute from './user.route.js';
import authRoute from './auth.route.js';
import activityLogRoute from './activityLog.route.js';
import leadStatusRoute from './leadStatus.route.js';
import leadRoute from './lead.route.js';
import taskRoute from './task.route.js';
import websocketRoute from './websocket.route.js';
import healthRoute from './health.route.js';
import reminderRoute from './reminder.route.js';
import followUpRoute from './followUp.route.js';
import callRecordRoute from './callRecord.route.js';
import callerInfoRoute from './callerInfo.route.js';
import settingsRoute from './settings.route.js';

const router = express.Router();

const defaultRoutes = [
  {
    path: '/auth',
    route: authRoute,
  },
  {
    path: '/files',
    route: fileRoute,
  },
  {
    path: '/users',
    route: userRoute,
  },
  {
    path: '/activity-logs',
    route: activityLogRoute,
  },
  {
    path: '/lead-status',
    route: leadStatusRoute,
  },
  {
    path: '/leads',
    route: leadRoute,
  },
  {
    path: '/tasks',
    route: taskRoute,
  },
  {
    path: '/websocket',
    route: websocketRoute,
  },
  {
    path: '/health',
    route: healthRoute,
  },
  {
    path: '/reminders',
    route: reminderRoute,
  },
  {
    path: '/followups',
    route: followUpRoute,
  },
  {
    path: '/call-records',
    route: callRecordRoute,
  },
  {
    path: '/caller-info',
    route: callerInfoRoute,
  },
  {
    path: '/settings',
    route: settingsRoute,
  },
];

const devRoutes = [
  // routes available only in development mode
  {
    path: '/docs',
    route: docsRoute,
  },
];

defaultRoutes.forEach((route) => {
  router.use(route.path, route.route);
});

/* istanbul ignore next */
if (config.env === 'development') {
  devRoutes.forEach((route) => {
    router.use(route.path, route.route);
  });
}

export default router;
