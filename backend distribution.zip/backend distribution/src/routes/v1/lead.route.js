import express from 'express';
import multer from 'multer';
import auth from '../../middlewares/auth.js';
import validate from '../../middlewares/validate.js';
import * as leadValidation from '../../validations/lead.validation.js';
import * as leadController from '../../controllers/lead.controller.js';
import * as leadImportController from '../../controllers/leadImport.controller.js';

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

router
    .route('/')
    .post(auth('createLeads'), validate(leadValidation.createLead), leadController.create)
    .get(auth('viewLeads'), validate(leadValidation.getLeads), leadController.list);

router
    .route('/:leadId')
    .get(auth('viewLeads'), validate(leadValidation.getLead), leadController.get)
    .patch(auth('updateLeads'), validate(leadValidation.updateLead), leadController.update)
    .delete(auth('deleteLeads'), validate(leadValidation.deleteLead), leadController.remove);

router.patch('/:leadId/status', auth('updateLeads'), validate(leadValidation.updateStatus), leadController.setStatus);
router.patch('/:leadId/call-status', auth('updateLeads'), validate(leadValidation.updateCallStatus), leadController.setCallStatus);

router.post('/sync/upload', auth('updateLeads'), validate(leadValidation.syncUpload), leadController.syncUpload);
router.get('/sync/pull', auth('viewLeads'), validate(leadValidation.syncPull), leadController.syncPull);

// Import: sample, preview, confirm
router.get('/import/sample', auth('createLeads'), leadImportController.downloadSample);
router.post('/import/preview', auth('createLeads'), upload.single('file'), leadImportController.preview);
router.post('/import/confirm', auth('createLeads'), leadImportController.confirm);

export default router;


