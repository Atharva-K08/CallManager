import express from 'express';
import auth from '../../middlewares/auth.js';
import validate from '../../middlewares/validate.js';
import * as taskValidation from '../../validations/task.validation.js';
import * as taskController from '../../controllers/task.controller.js';

const router = express.Router();

// Get tasks assigned to current user (for callers) - MUST be before /:taskId route
router.get('/my', auth('viewTasks'), taskController.getMyTasks);

router
    .route('/')
    .post(auth('manageUsers'), validate(taskValidation.createTask), taskController.create)
    .get(auth('getUsers'), validate(taskValidation.getTasks), taskController.list);

router.post('/handover', auth('manageUsers'), validate(taskValidation.handoverTask), taskController.handover);

router
    .route('/:taskId')
    .get(auth('getUsers'), validate(taskValidation.getTask), taskController.get)
    .patch(auth('manageUsers'), validate(taskValidation.updateTask), taskController.update)
    .delete(auth('manageUsers'), validate(taskValidation.deleteTask), taskController.remove);

router.patch('/:taskId/status', auth('manageUsers'), validate(taskValidation.setTaskStatus), taskController.setStatus);
router.patch('/:taskId/progress', auth('manageUsers'), validate(taskValidation.incrementTaskProgress), taskController.incrementProgress);

// Sync task progress from mobile app
router.post('/sync-progress', auth(), validate(taskValidation.syncTaskProgress), taskController.syncProgress);

export default router;


