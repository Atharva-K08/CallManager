import express from 'express';
import auth from '../../middlewares/auth.js';
import { requireAdmin } from '../../middlewares/roleAuth.js';
import * as reminderController from '../../controllers/reminder.controller.js';
import validate from '../../middlewares/validate.js';
import { reminderValidation } from '../../validations/reminder.validation.js';

const router = express.Router();

// All routes require authentication
router.use(auth());

/**
 * @swagger
 * /api/v1/reminders:
 *   post:
 *     summary: Schedule a follow-up reminder
 *     tags: [Reminders]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - leadId
 *               - followUpDate
 *             properties:
 *               leadId:
 *                 type: string
 *                 description: ID of the lead
 *               leadName:
 *                 type: string
 *                 description: Name of the lead
 *               followUpDate:
 *                 type: string
 *                 format: date-time
 *                 description: Date and time for the reminder
 *               message:
 *                 type: string
 *                 description: Custom reminder message
 *               reminderIntervalDays:
 *                 type: number
 *                 default: 7
 *                 description: Days between reminders
 *     responses:
 *       201:
 *         description: Reminder scheduled successfully
 *       400:
 *         description: Bad request
 *       401:
 *         description: Unauthorized
 */
router.post(
    '/',
    validate(reminderValidation.scheduleReminder),
    reminderController.scheduleReminder
);

/**
 * @swagger
 * /api/v1/reminders/bulk:
 *   post:
 *     summary: Schedule multiple reminders
 *     tags: [Reminders]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               reminders:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     leadId:
 *                       type: string
 *                     leadName:
 *                       type: string
 *                     followUpDate:
 *                       type: string
 *                       format: date-time
 *                     message:
 *                       type: string
 *     responses:
 *       201:
 *         description: Bulk reminders scheduled successfully
 */
router.post(
    '/bulk',
    validate(reminderValidation.scheduleBulkReminders),
    reminderController.scheduleBulkReminders
);

/**
 * @swagger
 * /api/v1/reminders/scheduled:
 *   get:
 *     summary: Get scheduled reminders for current user
 *     tags: [Reminders]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Scheduled reminders fetched successfully
 */
router.get('/scheduled', reminderController.getScheduledReminders);

/**
 * @swagger
 * /api/v1/reminders/overdue:
 *   get:
 *     summary: Get overdue reminders for current user
 *     tags: [Reminders]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Overdue reminders fetched successfully
 */
router.get('/overdue', reminderController.getOverdueReminders);

/**
 * @swagger
 * /api/v1/reminders/statistics:
 *   get:
 *     summary: Get reminder statistics for current user
 *     tags: [Reminders]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Reminder statistics fetched successfully
 */
router.get('/statistics', reminderController.getReminderStatistics);

/**
 * @swagger
 * /api/v1/reminders/{leadId}:
 *   delete:
 *     summary: Cancel a follow-up reminder
 *     tags: [Reminders]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: leadId
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the lead
 *     responses:
 *       200:
 *         description: Reminder cancelled successfully
 */
router.delete('/:leadId', reminderController.cancelReminder);

/**
 * @swagger
 * /api/v1/reminders/{leadId}:
 *   put:
 *     summary: Update a follow-up reminder
 *     tags: [Reminders]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: leadId
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the lead
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               leadName:
 *                 type: string
 *               followUpDate:
 *                 type: string
 *                 format: date-time
 *               message:
 *                 type: string
 *               reminderIntervalDays:
 *                 type: number
 *     responses:
 *       200:
 *         description: Reminder updated successfully
 */
router.put(
    '/:leadId',
    validate(reminderValidation.updateReminder),
    reminderController.updateReminder
);

/**
 * @swagger
 * /api/v1/reminders/process-overdue:
 *   post:
 *     summary: Process overdue reminders (Admin only)
 *     tags: [Reminders]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Overdue reminders processed successfully
 */
router.post(
    '/process-overdue',
    requireAdmin,
    reminderController.processOverdueReminders
);

export default router;
