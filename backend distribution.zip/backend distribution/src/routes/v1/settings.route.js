import express from 'express';
import auth from '../../middlewares/auth.js';
import validate from '../../middlewares/validate.js';
import * as settingsController from '../../controllers/settings.controller.js';

const router = express.Router();

// All routes require authentication
router.use(auth());

// User settings routes
router.get('/', settingsController.getUserSettings);
router.get('/:category', settingsController.getCategorySettings);
router.get('/:category/:key', settingsController.getSetting);
router.put('/:category/:key', settingsController.setSetting);
router.put('/:category', settingsController.setCategorySettings);
router.delete('/:category/:key', settingsController.deleteSetting);

// System settings routes (admin only)
router.get('/system/:category?', auth('admin'), settingsController.getSystemSettings);
router.put('/system/:category/:key', auth('admin'), settingsController.setSystemSetting);

export default router;

