import express from 'express';
import auth from '../../middlewares/auth.js';
import validate from '../../middlewares/validate.js';
import * as leadStatusValidation from '../../validations/leadStatus.validation.js';
import * as leadStatusController from '../../controllers/leadStatus.controller.js';

const router = express.Router();

router
    .route('/')
    .post(auth('manageUsers'), validate(leadStatusValidation.createLeadStatus), leadStatusController.create)
    .get(auth('getUsers'), validate(leadStatusValidation.getLeadStatuses), leadStatusController.list);

router
    .route('/:leadStatusId')
    .get(auth('getUsers'), validate(leadStatusValidation.getLeadStatus), leadStatusController.get)
    .patch(auth('manageUsers'), validate(leadStatusValidation.updateLeadStatus), leadStatusController.update)
    .delete(auth('manageUsers'), validate(leadStatusValidation.deleteLeadStatus), leadStatusController.remove);

router.get('/default-import', auth('getUsers'), leadStatusController.getDefaultImport);
router.patch('/:leadStatusId/default-import', auth('manageUsers'), validate(leadStatusValidation.setActive), leadStatusController.setDefaultImport);

router.patch('/:leadStatusId/activate', auth('manageUsers'), validate(leadStatusValidation.setActive), leadStatusController.activate);
router.patch('/:leadStatusId/deactivate', auth('manageUsers'), validate(leadStatusValidation.setActive), leadStatusController.deactivate);

export default router;


