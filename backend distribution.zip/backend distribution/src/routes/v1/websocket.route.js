import express from 'express';
import auth from '../../middlewares/auth.js';
import validate from '../../middlewares/validate.js';
import * as websocketValidation from '../../validations/websocket.validation.js';
import * as websocketController from '../../controllers/websocket.controller.js';

const router = express.Router();

// Get WebSocket connection statistics
router.get('/stats', auth('getUsers'), websocketController.getConnectionStats);

// Get connected users
router.get('/users', auth('getUsers'), websocketController.getConnectedUsers);

// Check specific user connection
router.get('/users/:userId', auth('getUsers'), validate(websocketValidation.checkUserConnection), websocketController.checkUserConnection);

// Broadcast message to all clients
router.post('/broadcast', auth('manageUsers'), validate(websocketValidation.broadcastMessage), websocketController.broadcastMessage);

// Send message to specific user
router.post('/users/:userId/send', auth('manageUsers'), validate(websocketValidation.sendToUser), websocketController.sendToUser);

export default router;
