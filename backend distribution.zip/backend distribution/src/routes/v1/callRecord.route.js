import express from 'express';
import auth from '../../middlewares/auth.js';
import validate from '../../middlewares/validate.js';
import * as callRecordValidation from '../../validations/callRecord.validation.js';
import * as callRecordController from '../../controllers/callRecord.controller.js';

const router = express.Router();

router
    .route('/')
    .post(auth('createCallRecords'), validate(callRecordValidation.createCallRecord), callRecordController.create)
    .get(auth('viewCallRecords'), validate(callRecordValidation.getCallRecords), callRecordController.list);

router
    .route('/statistics')
    .get(auth('viewCallRecords'), validate(callRecordValidation.getStatistics), callRecordController.getStatistics);

router
    .route('/phone/:phoneNumber')
    .get(auth('viewCallRecords'), validate(callRecordValidation.getByPhoneNumber), callRecordController.getByPhoneNumber);

router
    .route('/lead/:leadId')
    .get(auth('viewCallRecords'), validate(callRecordValidation.getByLeadId), callRecordController.getByLeadId);

router
    .route('/:callRecordId')
    .get(auth('viewCallRecords'), validate(callRecordValidation.getCallRecord), callRecordController.get)
    .patch(auth('updateCallRecords'), validate(callRecordValidation.updateCallRecord), callRecordController.update)
    .delete(auth('deleteCallRecords'), validate(callRecordValidation.deleteCallRecord), callRecordController.remove);

router.patch('/:callRecordId/status', auth('updateCallRecords'), validate(callRecordValidation.updateStatus), callRecordController.setStatus);

router.post('/sync/upload', auth('updateCallRecords'), validate(callRecordValidation.syncUpload), callRecordController.syncUpload);
router.get('/sync/pull', auth('viewCallRecords'), validate(callRecordValidation.syncPull), callRecordController.syncPull);

export default router;

