import express from 'express';
import validate from '../../middlewares/validate.js';
import { lookupCallerController } from '../../controllers/callerInfo.controller.js';
import { lookupCaller } from '../../validations/callerInfo.validation.js';

const router = express.Router();

/**
 * @swagger
 * components:
 *   schemas:
 *     CallerInfo:
 *       type: object
 *       properties:
 *         name:
 *           type: string
 *           description: Caller's name
 *           example: "John Smith"
 *         company:
 *           type: string
 *           description: Caller's campus
 *           example: "Tech Corp"
 *         status:
 *           type: string
 *           description: Caller's lead status from database
 *           example: "assigned"
 *         remark:
 *           type: string
 *           description: Additional notes about the caller
 *           example: "Regular customer, prefers morning calls"
 *         phone_number:
 *           type: string
 *           description: The phone number that was looked up
 *           example: "+1234567890"
 *         found:
 *           type: boolean
 *           description: Whether caller information was found
 *           example: true
 *     CallerLookupRequest:
 *       type: object
 *       required:
 *         - phone_number
 *       properties:
 *         phone_number:
 *           type: string
 *           description: Phone number to lookup
 *           example: "+1234567890"
 */

/**
 * @swagger
 * /caller-info/lookup:
 *   post:
 *     summary: Lookup caller information by phone number from Lead database
 *     tags: [Caller Info]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CallerLookupRequest'
 *     responses:
 *       200:
 *         description: Caller information retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 status:
 *                   type: number
 *                   example: 1
 *                 data:
 *                   $ref: '#/components/schemas/CallerInfo'
 *                 message:
 *                   type: string
 *                   example: "Caller information retrieved successfully"
 *       400:
 *         description: Bad request - Invalid phone number format
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 status:
 *                   type: number
 *                   example: 0
 *                 message:
 *                   type: string
 *                   example: "Valid phone number is required"
 *       500:
 *         description: Internal server error
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 status:
 *                   type: number
 *                   example: 0
 *                 message:
 *                   type: string
 *                   example: "Internal server error"
 */
router.route('/lookup').post(validate(lookupCaller), lookupCallerController);

export default router;
