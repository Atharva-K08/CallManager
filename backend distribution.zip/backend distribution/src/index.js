import mongoose from 'mongoose';
import https from 'https';
import fs from 'fs';
import app from './app.js';
import config from './config/config.js';
import logger from './config/logger.js';
import websocketService from './services/websocket.service.js';
import { initializeScheduler } from './jobs/scheduler.js';
import { reminderQueue } from './config/queue.js';
import { processReminderJob, processBulkReminderJob, processOverdueReminderCheck } from './jobs/reminderProcessor.js';
import Settings from './models/settings.model.js';
import { initializeDefaultSettings } from './config/defaultSettings.js';

let server;

const startServer = () => {
  if (process.env.NODE_ENV === 'production') {
    logger.info('Starting server in HTTPS mode...');

    const sslOptions = {
      key: fs.readFileSync('/usr/local/hestia/data/users/suyog/ssl/flyvendo.com.key'),
      cert: fs.readFileSync('/usr/local/hestia/data/users/suyog/ssl/flyvendo.com.crt'),
    };

    server = https.createServer(sslOptions, app).listen(config.port, () => {
      logger.info(`HTTPS server running on port ${config.port}`);
      // Initialize WebSocket service
      websocketService.initialize(server);
    });
  } else {
    logger.info('Starting server in HTTP mode...');
    server = app.listen(config.port, () => {
      logger.info(`HTTP server running on port ${config.port}`);
      // Initialize WebSocket service
      websocketService.initialize(server);
    });
  }
};

mongoose.connect(config.mongoose.url, config.mongoose.options)
  .then(async () => {
    logger.info('Connected to MongoDB');

    // Initialize default settings
    await initializeSettings();

    // Initialize reminder system
    initializeReminderSystem();

    startServer();
  })
  .catch((err) => {
    logger.error('MongoDB connection error:', err);
    process.exit(1);
  });

const initializeSettings = async () => {
  try {
    await initializeDefaultSettings(Settings);
    logger.info('✅ Default settings initialized successfully');
  } catch (error) {
    logger.error('❌ Error initializing default settings:', error);
  }
};

const initializeReminderSystem = () => {
  try {
    // Initialize scheduler
    initializeScheduler();

    // Setup queue processors
    reminderQueue.process('follow-up-reminder', processReminderJob);
    reminderQueue.process('bulk-reminders', processBulkReminderJob);
    reminderQueue.process('overdue-check', processOverdueReminderCheck);

    logger.info('✅ Reminder system initialized successfully');
  } catch (error) {
    logger.error('❌ Error initializing reminder system:', error);
  }
};

const exitHandler = () => {
  if (server) {
    server.close(() => {
      logger.info('Server closed');
      process.exit(1);
    });
  } else {
    process.exit(1);
  }
};

const unexpectedErrorHandler = (error) => {
  logger.error(error);
  exitHandler();
};

process.on('uncaughtException', unexpectedErrorHandler);
process.on('unhandledRejection', unexpectedErrorHandler);

process.on('SIGTERM', () => {
  logger.info('SIGTERM received');
  if (server) {
    server.close();
  }
});
