import catchAsync from '../utils/catchAsync.js';
import { sendSuccess } from '../utils/response.utils.js';

export const getHealth = catchAsync(async (req, res) => {
    const maintenance = process.env.MAINTENANCE_MODE === 'true';
    sendSuccess(res, { maintenance }, maintenance ? 'Maintenance' : 'OK');
});

export default { getHealth };



