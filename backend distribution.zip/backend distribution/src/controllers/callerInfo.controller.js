import httpStatus from 'http-status';
import catchAsync from '../utils/catchAsync.js';
import { lookupCaller } from '../services/callerInfo.service.js';
import { sendSuccess, sendError } from '../utils/response.utils.js';

/**
 * Lookup caller information by phone number
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
export const lookupCallerController = catchAsync(async (req, res) => {
    const { phone_number } = req.body;

    const callerInfo = await lookupCaller(phone_number);

    sendSuccess(res, callerInfo, 'Caller information retrieved successfully');
});
