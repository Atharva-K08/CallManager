import httpStatus from 'http-status';
import catchAsync from '../utils/catchAsync.js';
import { authService, userService, tokenService, emailService } from '../services/index.js';
import { sendAuthSuccess, sendCreated, sendNoContent, sendSuccess, sendError } from '../utils/response.utils.js';

const register = catchAsync(async (req, res) => {
  // route disabled for now
  return sendError(res, 'Route disabled for now', httpStatus.FORBIDDEN);
  const user = await userService.createUser(req.body);

  const tokens = await tokenService.generateAuthTokens(user);
  sendAuthSuccess(res, user, tokens, 'User registered successfully');
});

const login = catchAsync(async (req, res) => {
  const { email, password } = req.body;
  const { user, tokens } = await authService.loginUserWithEmailAndPassword(email, password);
  sendAuthSuccess(res, user, tokens, 'Login successful');
});

const logout = catchAsync(async (req, res) => {
  await authService.logout(req.body.refreshToken);
  sendNoContent(res, 'Logout successful');
});

const refreshTokens = catchAsync(async (req, res) => {
  const tokens = await authService.refreshAuth(req.body.refreshToken);
  sendAuthSuccess(res, null, tokens, 'Tokens refreshed successfully');
});

const getMe = catchAsync(async (req, res) => {
  const user = await userService.getUserById(req.user.id);
  sendSuccess(res, user, 'User retrieved successfully');
});

const createFirstAdmin = catchAsync(async (req, res) => {
  const user = await userService.createFirstAdmin(req.body);
  const tokens = await tokenService.generateAuthTokens(user);
  sendAuthSuccess(res, user, tokens, 'First admin created successfully');
});

export { register, login, logout, refreshTokens, getMe, createFirstAdmin }; 