import httpStatus from 'http-status';
import catchAsync from '../utils/catchAsync.js';
import { sendSuccess } from '../utils/response.utils.js';
import websocketService from '../services/websocket.service.js';

const getConnectionStats = catchAsync(async (req, res) => {
    const stats = websocketService.getConnectionStats();
    sendSuccess(res, stats, 'WebSocket connection statistics retrieved successfully');
});

const getConnectedUsers = catchAsync(async (req, res) => {
    const stats = websocketService.getConnectionStats();
    const connectedUsers = stats.connectedClients.map(client => ({
        userId: client.userId,
        connectedAt: client.connectedAt,
        lastPing: client.lastPing,
        isAlive: client.isAlive,
        userRole: client.userRole
    }));

    sendSuccess(res, {
        totalConnections: stats.totalConnections,
        connectedUsers,
        serverTime: stats.serverTime,
        uptime: stats.uptime
    }, 'Connected users retrieved successfully');
});

const checkUserConnection = catchAsync(async (req, res) => {
    const { userId } = req.params;

    const isConnected = websocketService.isUserConnected(userId);
    const userInfo = websocketService.getConnectedUser(userId);

    sendSuccess(res, {
        userId,
        isConnected,
        userInfo: userInfo || null,
        serverTime: new Date().toISOString()
    }, `User ${userId} connection status retrieved successfully`);
});

const broadcastMessage = catchAsync(async (req, res) => {
    const { event, data, target } = req.body;

    if (!event) {
        return res.status(httpStatus.BAD_REQUEST).json({
            status: 0,
            message: 'Event is required'
        });
    }

    switch (target) {
        case 'all':
            websocketService.broadcast(event, data);
            break;
        case 'admin':
            websocketService.sendToAdmins(event, data);
            break;
        case 'mobile':
            websocketService.sendToMobile(event, data);
            break;
        default:
            websocketService.broadcast(event, data);
    }

    sendSuccess(res, {
        event,
        target: target || 'all',
        timestamp: new Date().toISOString()
    }, `Message broadcasted successfully to ${target || 'all'} clients`);
});

const sendToUser = catchAsync(async (req, res) => {
    const { userId } = req.params;
    const { event, data } = req.body;

    if (!event) {
        return res.status(httpStatus.BAD_REQUEST).json({
            status: 0,
            message: 'Event is required'
        });
    }

    websocketService.sendToUser(userId, event, data);

    sendSuccess(res, {
        userId,
        event,
        timestamp: new Date().toISOString()
    }, `Message sent successfully to user ${userId}`);
});

export {
    getConnectionStats,
    getConnectedUsers,
    checkUserConnection,
    broadcastMessage,
    sendToUser
};
