import catchAsync from '../utils/catchAsync.js';
import { sendCreated, sendSuccess, sendNoContent } from '../utils/response.utils.js';
import * as reminderService from '../services/reminder.service.js';
import { logActivity } from '../middlewares/activityLog.middleware.js';
import { FollowUp } from '../models/index.js';

/**
 * Schedule a follow-up reminder
 */
export const scheduleReminder = catchAsync(async (req, res) => {
    const { leadId, followUpDate, message, reminderIntervalDays } = req.body;
    const userId = req.user._id;

    // Ensure message is a valid string or null (not undefined)
    const validMessage = (message && typeof message === 'string' && message.trim() !== '')
        ? message.trim()
        : null;

    const reminderData = {
        leadId,
        leadName: req.body.leadName,
        followUpDate: new Date(followUpDate),
        message: validMessage,
        userId,
        userEmail: req.user.email,
        reminderIntervalDays: reminderIntervalDays || 7,
    };

    const result = await reminderService.scheduleFollowUpReminder(reminderData);

    await logActivity(req, {
        action: 'create',
        targetModel: 'Reminder',
        targetId: leadId,
        targetName: req.body.leadName,
        description: `Scheduled follow-up reminder for ${req.body.leadName}`,
    });

    sendCreated(res, result, 'Reminder scheduled successfully');
});

/**
 * Cancel a follow-up reminder
 */
export const cancelReminder = catchAsync(async (req, res) => {
    const { leadId } = req.params;

    const result = await reminderService.cancelFollowUpReminder(leadId);

    await logActivity(req, {
        action: 'delete',
        targetModel: 'Reminder',
        targetId: leadId,
        description: 'Cancelled follow-up reminder',
    });

    sendSuccess(res, result, 'Reminder cancelled successfully');
});

/**
 * Update a follow-up reminder
 */
export const updateReminder = catchAsync(async (req, res) => {
    const { leadId } = req.params;
    const { followUpDate, message, reminderIntervalDays } = req.body;

    // Ensure message is a valid string or null (not undefined)
    const validMessage = (message && typeof message === 'string' && message.trim() !== '')
        ? message.trim()
        : null;

    const newReminderData = {
        leadId,
        leadName: req.body.leadName,
        followUpDate: new Date(followUpDate),
        message: validMessage,
        reminderIntervalDays: reminderIntervalDays || 7,
    };

    const result = await reminderService.updateFollowUpReminder(leadId, newReminderData);

    await logActivity(req, {
        action: 'update',
        targetModel: 'Reminder',
        targetId: leadId,
        targetName: req.body.leadName,
        description: `Updated follow-up reminder for ${req.body.leadName}`,
    });

    sendSuccess(res, result, 'Reminder updated successfully');
});

/**
 * Get scheduled reminders for current user
 */
export const getScheduledReminders = catchAsync(async (req, res) => {
    const userId = req.user._id;
    const reminders = await reminderService.getScheduledReminders(userId);

    sendSuccess(res, reminders, 'Scheduled reminders fetched successfully');
});

/**
 * Get overdue reminders for current user
 */
export const getOverdueReminders = catchAsync(async (req, res) => {
    const userId = req.user._id;
    const reminders = await reminderService.getOverdueReminders(userId);

    sendSuccess(res, reminders, 'Overdue reminders fetched successfully');
});

/**
 * Get reminder statistics
 */
export const getReminderStatistics = catchAsync(async (req, res) => {
    const userId = req.user._id;
    const statistics = await reminderService.getReminderStatistics(userId);

    sendSuccess(res, statistics, 'Reminder statistics fetched successfully');
});

/**
 * Schedule bulk reminders
 */
export const scheduleBulkReminders = catchAsync(async (req, res) => {
    const { reminders } = req.body;
    const userId = req.user._id;

    // Add userId to each reminder
    const remindersWithUser = reminders.map(reminder => ({
        ...reminder,
        userId,
        userEmail: req.user.email,
    }));

    const result = await reminderService.scheduleBulkReminders(remindersWithUser);

    await logActivity(req, {
        action: 'create',
        targetModel: 'Reminder',
        description: `Scheduled ${reminders.length} bulk reminders`,
    });

    sendCreated(res, result, 'Bulk reminders scheduled successfully');
});

/**
 * Process overdue reminders (admin only)
 */
export const processOverdueReminders = catchAsync(async (req, res) => {
    const result = await reminderService.processOverdueReminders();

    sendSuccess(res, result, 'Overdue reminders processed successfully');
});

export default {
    scheduleReminder,
    cancelReminder,
    updateReminder,
    getScheduledReminders,
    getOverdueReminders,
    getReminderStatistics,
    scheduleBulkReminders,
    processOverdueReminders,
};
