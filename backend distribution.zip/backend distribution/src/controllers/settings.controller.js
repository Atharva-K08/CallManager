import catchAsync from '../utils/catchAsync.js';
import { sendSuccess, sendError } from '../utils/response.utils.js';
import * as settingsService from '../services/settings.service.js';
import { logActivity } from '../middlewares/activityLog.middleware.js';

/**
 * Get a single setting
 * GET /v1/settings/:category/:key
 */
export const getSetting = catchAsync(async (req, res) => {
    const { category, key } = req.params;
    const userId = req.user?._id;
    const defaultValue = req.query.defaultValue || null;

    const value = await settingsService.getSetting(userId, category, key, defaultValue);

    sendSuccess(res, { category, key, value }, 'Setting retrieved successfully');
});

/**
 * Get all settings for a category
 * GET /v1/settings/:category
 */
export const getCategorySettings = catchAsync(async (req, res) => {
    const { category } = req.params;
    const userId = req.user?._id;

    const settings = await settingsService.getCategorySettings(userId, category);

    sendSuccess(res, { category, settings }, 'Settings retrieved successfully');
});

/**
 * Get all user settings
 * GET /v1/settings
 */
export const getUserSettings = catchAsync(async (req, res) => {
    const userId = req.user?._id;

    const settings = await settingsService.getUserSettings(userId);

    sendSuccess(res, { settings }, 'User settings retrieved successfully');
});

/**
 * Set a single setting
 * PUT /v1/settings/:category/:key
 */
export const setSetting = catchAsync(async (req, res) => {
    const { category, key } = req.params;
    const { value, dataType, description, isEditable } = req.body;
    const userId = req.user?._id;

    if (value === undefined) {
        return sendError(res, 'Value is required', 400);
    }

    const setting = await settingsService.setSetting(userId, category, key, value, {
        dataType,
        description,
        isEditable,
    });

    await logActivity(req, {
        action: 'update',
        targetModel: 'Settings',
        targetId: setting._id,
        targetName: `${category}.${key}`,
        description: `Updated setting: ${category}.${key}`,
    });

    sendSuccess(res, setting, 'Setting updated successfully');
});

/**
 * Set multiple settings for a category
 * PUT /v1/settings/:category
 */
export const setCategorySettings = catchAsync(async (req, res) => {
    const { category } = req.params;
    const { settings } = req.body;
    const userId = req.user?._id;

    if (!settings || typeof settings !== 'object') {
        return sendError(res, 'Settings object is required', 400);
    }

    await settingsService.setMultipleSettings(userId, category, settings);

    await logActivity(req, {
        action: 'update',
        targetModel: 'Settings',
        targetName: category,
        description: `Updated multiple settings in category: ${category}`,
    });

    sendSuccess(res, { category, settings }, 'Settings updated successfully');
});

/**
 * Delete a user setting (revert to default)
 * DELETE /v1/settings/:category/:key
 */
export const deleteSetting = catchAsync(async (req, res) => {
    const { category, key } = req.params;
    const userId = req.user?._id;

    await settingsService.deleteUserSetting(userId, category, key);

    await logActivity(req, {
        action: 'delete',
        targetModel: 'Settings',
        targetName: `${category}.${key}`,
        description: `Deleted user setting: ${category}.${key}`,
    });

    sendSuccess(res, null, 'Setting deleted successfully');
});

/**
 * Get system settings (admin only)
 * GET /v1/settings/system/:category?
 */
export const getSystemSettings = catchAsync(async (req, res) => {
    const { category } = req.params;

    const settings = await settingsService.getSystemSettings(category || null);

    sendSuccess(res, { settings }, 'System settings retrieved successfully');
});

/**
 * Set system setting (admin only)
 * PUT /v1/settings/system/:category/:key
 */
export const setSystemSetting = catchAsync(async (req, res) => {
    const { category, key } = req.params;
    const { value, dataType, description, isEditable } = req.body;

    if (value === undefined) {
        return sendError(res, 'Value is required', 400);
    }

    const setting = await settingsService.setSystemSetting(category, key, value, {
        dataType,
        description,
        isEditable,
    });

    await logActivity(req, {
        action: 'update',
        targetModel: 'Settings',
        targetId: setting._id,
        targetName: `system.${category}.${key}`,
        description: `Updated system setting: ${category}.${key}`,
    });

    sendSuccess(res, setting, 'System setting updated successfully');
});

