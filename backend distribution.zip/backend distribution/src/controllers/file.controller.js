import catchAsync from '../utils/catchAsync.js';
import { initiateUploadService } from '../services/file.service.js';
import { S3Storage } from '../adapter/storageS3.js';
import { sendSuccess, sendError } from '../utils/response.utils.js';

const s3Storage = new S3Storage();

export const initiateUploadController = catchAsync(async (req, res) => {
  const result = await initiateUploadService(req.body);
  sendSuccess(res, result, 'Upload initiated successfully');
});

export const getSignedUrlController = catchAsync(async (req, res) => {
  const { key } = req.params;

  if (!key) {
    return sendError(res, 'File key is required', 400);
  }

  try {
    const signedUrl = await s3Storage.getFileUrl(key);
    sendSuccess(res, { signedUrl }, 'Signed URL generated successfully');
  } catch (error) {
    sendError(res, 'Failed to generate signed URL', 500);
  }
}); 