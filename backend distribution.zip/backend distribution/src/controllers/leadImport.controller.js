import catchAsync from '../utils/catchAsync.js';
import { sendSuccess } from '../utils/response.utils.js';
import { generateSampleWorkbook, parseAndValidate, bulkInsert } from '../services/leadImport.service.js';

export const downloadSample = catchAsync(async (req, res) => {
    const buffer = generateSampleWorkbook();
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="leads_sample.xlsx"');
    res.send(buffer);
});

export const preview = catchAsync(async (req, res) => {
    if (!req.file) {
        return sendSuccess(res, { totalRows: 0, validCount: 0, invalidCount: 1, validRows: [], invalidRows: [{ rowNumber: 0, data: {}, errors: ['No file uploaded'] }] }, 'Preview generated');
    }
    const report = await parseAndValidate(req.file.buffer);
    sendSuccess(res, report, 'Preview generated');
});

export const confirm = catchAsync(async (req, res) => {
    const { validRows } = req.body || {};
    const result = await bulkInsert(Array.isArray(validRows) ? validRows : [], req.user);
    sendSuccess(res, result, 'Import completed');
});

export default { downloadSample, preview, confirm };




