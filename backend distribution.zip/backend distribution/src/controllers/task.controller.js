import catchAsync from '../utils/catchAsync.js';
import { sendCreated, sendNoContent, sendSuccess } from '../utils/response.utils.js';
import * as taskService from '../services/task.service.js';
import { logActivity, logUpdate } from '../middlewares/activityLog.middleware.js';
import { sendFCMNotification } from '../services/fcm.service.js';

export const create = catchAsync(async (req, res) => {
    const payload = { ...req.body, createdBy: req.user?._id };
    const doc = await taskService.createTask(payload);
    await logActivity(req, { action: 'create', targetModel: 'Task', targetId: doc._id, targetName: doc.title, description: `Created task: ${doc.title}` });

    // Send FCM notification to assigned user
    if (doc.assignedTo) {
        try {
            await sendFCMNotification(doc.assignedTo, {
                title: 'New Task Assigned',
                body: `You have been assigned a new task: ${doc.title}`,
                data: {
                    type: 'TASK_ASSIGNED',
                    taskId: doc._id.toString(),
                    taskTitle: doc.title,
                    assignedBy: req.user?.name || 'Admin',
                    dueAt: doc.dueAt ? new Date(doc.dueAt).toISOString() : null,
                    leadCount: doc.leadIds?.length || 0,
                },
            });
            console.log(`✅ FCM notification sent to user ${doc.assignedToName} for task: ${doc.title}`);
        } catch (error) {
            console.error('❌ Failed to send FCM notification for task:', error.message);
            // Don't fail the task creation if FCM fails
        }
    }

    sendCreated(res, doc, 'Task created successfully');
});

export const handover = catchAsync(async (req, res) => {
    const payload = { ...req.body, createdBy: req.user?._id };
    const doc = await taskService.createTask(payload);
    await logActivity(req, { action: 'create', targetModel: 'Task', targetId: doc._id, targetName: doc.title, description: `Handover: created task ${doc.title}` });

    // If sourceTaskId provided, remove handed-over leads from the source task and recalc both tasks
    if (req.body.sourceTaskId && Array.isArray(req.body.leadIds) && req.body.leadIds.length > 0) {
        try {
            await taskService.removeLeadsFromTask(req.body.sourceTaskId, req.body.leadIds);
            // Recalculate completion for both tasks
            await Promise.all([
                taskService.recalculateTaskCompletion(req.body.sourceTaskId),
                taskService.recalculateTaskCompletion(doc._id),
            ]);
        } catch (e) {
            console.error('Failed to remove leads from source task during handover:', e?.message);
        }
    }

    if (doc.assignedTo) {
        try {
            await sendFCMNotification(doc.assignedTo, {
                title: 'New Task Assigned',
                body: `You have been assigned a new task: ${doc.title}`,
                data: {
                    type: 'TASK_ASSIGNED',
                    taskId: doc._id.toString(),
                    taskTitle: doc.title,
                    assignedBy: req.user?.name || 'Admin',
                    dueAt: doc.dueAt ? new Date(doc.dueAt).toISOString() : null,
                    leadCount: doc.leadIds?.length || 0,
                },
            });
            console.log(`✅ FCM notification sent to user ${doc.assignedToName} for handover task: ${doc.title}`);
        } catch (error) {
            console.error('❌ Failed to send FCM notification for handover:', error.message);
        }
    }

    sendCreated(res, doc, 'Task handed over successfully');
});

export const list = catchAsync(async (req, res) => {
    const data = await taskService.queryTasks(req.query, req.query);
    sendSuccess(res, data, 'Tasks fetched successfully');
});

export const get = catchAsync(async (req, res) => {
    const doc = await taskService.getTaskById(req.params.taskId);
    sendSuccess(res, doc, 'Task fetched successfully');
});

export const update = catchAsync(async (req, res) => {
    const before = await taskService.getTaskById(req.params.taskId);
    const doc = await taskService.updateTaskById(req.params.taskId, req.body);
    await logUpdate(req, 'Task', doc._id, before?.toObject?.() || before, doc.toObject?.() || doc, doc.title);

    // Send FCM notification if task was reassigned
    if (before?.assignedTo?.toString() !== doc.assignedTo?.toString() && doc.assignedTo) {
        try {
            await sendFCMNotification(doc.assignedTo, {
                title: 'Task Reassigned',
                body: `You have been assigned a task: ${doc.title}`,
                data: {
                    type: 'TASK_REASSIGNED',
                    taskId: doc._id.toString(),
                    taskTitle: doc.title,
                    assignedBy: req.user?.name || 'Admin',
                    dueAt: doc.dueAt ? new Date(doc.dueAt).toISOString() : null,
                    leadCount: doc.leadIds?.length || 0,
                },
            });
            console.log(`✅ FCM notification sent to user ${doc.assignedToName} for reassigned task: ${doc.title}`);
        } catch (error) {
            console.error('❌ Failed to send FCM notification for task reassignment:', error.message);
        }
    }

    sendSuccess(res, doc, 'Task updated successfully');
});

export const remove = catchAsync(async (req, res) => {
    const before = await taskService.getTaskById(req.params.taskId);
    await taskService.deleteTaskById(req.params.taskId);
    if (before) {
        await logActivity(req, { action: 'delete', targetModel: 'Task', targetId: before._id, targetName: before.title, description: `Deleted task: ${before.title}` });
    }
    sendNoContent(res);
});

export const setStatus = catchAsync(async (req, res) => {
    const before = await taskService.getTaskById(req.params.taskId);
    const doc = await taskService.setTaskStatus(req.params.taskId, req.body.status);
    await logActivity(req, { action: 'update', targetModel: 'Task', targetId: doc._id, targetName: doc.title, description: `Set task status: ${doc.status}` });

    // Send FCM notification for status changes (except when user updates their own task)
    if (before?.status !== doc.status && doc.assignedTo && req.user?._id?.toString() !== doc.assignedTo?.toString()) {
        try {
            await sendFCMNotification(doc.assignedTo, {
                title: 'Task Status Updated',
                body: `Task "${doc.title}" status changed to ${doc.status}`,
                data: {
                    type: 'TASK_STATUS_CHANGED',
                    taskId: doc._id.toString(),
                    taskTitle: doc.title,
                    oldStatus: before?.status || 'UNKNOWN',
                    newStatus: doc.status,
                    updatedBy: req.user?.name || 'Admin',
                },
            });
            console.log(`✅ FCM notification sent to user ${doc.assignedToName} for status change: ${doc.title}`);
        } catch (error) {
            console.error('❌ Failed to send FCM notification for task status change:', error.message);
        }
    }

    sendSuccess(res, doc, 'Task status updated');
});

export const incrementProgress = catchAsync(async (req, res) => {
    const doc = await taskService.incrementProgress(req.params.taskId, req.body.by);
    await logActivity(req, { action: 'update', targetModel: 'Task', targetId: doc._id, targetName: doc.title, description: `Incremented task progress by ${req.body.by || 1}` });
    sendSuccess(res, doc, 'Task progress updated');
});

export const getMyTasks = catchAsync(async (req, res) => {
    const data = await taskService.getTasksAssignedToUser(req.user._id);
    sendSuccess(res, data, 'My tasks fetched successfully');
});

export const syncProgress = catchAsync(async (req, res) => {
    const { leads } = req.body;
    const userId = req.user._id;

    console.log(`[TaskController] Syncing progress for ${leads.length} leads from user ${userId}`);

    const result = await taskService.syncTaskProgress(leads, userId);

    // Log activity with valid values - use first updated task ID or skip if none
    if (result.updatedTasks.length > 0) {
        await logActivity(req, {
            action: 'update',
            targetModel: 'Task',
            targetId: result.updatedTasks[0].taskId,
            targetName: 'Task Progress Sync',
            description: `Synced progress for ${leads.length} leads, updated ${result.updatedTasks.length} tasks`
        });
    } else {
        // If no tasks were updated, log a general activity
        await logActivity(req, {
            action: 'other',
            targetModel: 'Task',
            targetId: userId,
            targetName: 'Task Progress Sync',
            description: `Synced progress for ${leads.length} leads, no tasks updated`
        });
    }

    sendSuccess(res, result, 'Task progress synced successfully');
});

export default { create, handover, list, get, update, remove, setStatus, incrementProgress, getMyTasks, syncProgress };


