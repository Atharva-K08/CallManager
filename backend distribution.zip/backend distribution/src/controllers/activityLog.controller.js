import httpStatus from 'http-status';
import catchAsync from '../utils/catchAsync.js';
import ActivityLog from '../models/activityLog.model.js';
import {
    getActivityLogs,
    getTargetActivityLogs,
    getUserActivityLogs,
    getActivityStats,
    deleteActivityLog,
    cleanupOldLogs,
} from '../services/activityLog.service.js';
import { sendSuccess, sendPaginated, sendNotFound } from '../utils/response.utils.js';

/**
 * Get activity logs with filtering and pagination
 */
const getLogs = catchAsync(async (req, res) => {
    const filters = {
        user: req.query.user,
        targetModel: req.query.targetModel,
        targetId: req.query.targetId,
        action: req.query.action,
        startDate: req.query.startDate,
        endDate: req.query.endDate,
        page: parseInt(req.query.page) || 1,
        limit: parseInt(req.query.limit) || 20
    };

    const result = await getActivityLogs(filters);
    sendPaginated(res, result.logs, result.pagination, 'Activity logs fetched successfully');
});

/**
 * Get activity logs for a specific target
 */
const getTargetLogs = catchAsync(async (req, res) => {
    const { targetModel, targetId } = req.params;
    const limit = parseInt(req.query.limit) || 10;

    const logs = await getTargetActivityLogs(targetModel, targetId, limit);
    sendSuccess(res, logs, 'Target activity logs fetched successfully');
});

/**
 * Get activity logs for a specific user
 */
const getUserLogs = catchAsync(async (req, res) => {
    const { userId } = req.params;
    const limit = parseInt(req.query.limit) || 20;

    const logs = await getUserActivityLogs(userId, limit);
    sendSuccess(res, logs, 'User activity logs fetched successfully');
});

/**
 * Get activity statistics
 */
const getStats = catchAsync(async (req, res) => {
    const filters = {
        startDate: req.query.startDate,
        endDate: req.query.endDate
    };

    const stats = await getActivityStats(filters);
    sendSuccess(res, stats, 'Activity statistics fetched successfully');
});

/**
 * Delete activity log
 */
const deleteLog = catchAsync(async (req, res) => {
    const { logId } = req.params;
    const log = await deleteActivityLog(logId);
    sendSuccess(res, log, 'Activity log deleted successfully');
});

/**
 * Clean up old activity logs
 */
const cleanupLogs = catchAsync(async (req, res) => {
    const daysOld = parseInt(req.query.daysOld) || 365;
    const deletedCount = await cleanupOldLogs(daysOld);
    sendSuccess(res, { deletedCount }, `Cleaned up ${deletedCount} old activity logs`);
});

/**
 * Get activity log by ID
 */
const getLogById = catchAsync(async (req, res) => {
    const { logId } = req.params;

    const log = await ActivityLog.findById(logId)
        .populate('user', 'name email')
        .lean();

    if (!log) {
        return sendNotFound(res, 'Activity log not found');
    }

    sendSuccess(res, log, 'Activity log fetched successfully');
});

/**
 * Get recent activity (last 24 hours)
 */
const getRecentActivity = catchAsync(async (req, res) => {
    const limit = parseInt(req.query.limit) || 50;
    const targetModel = req.query.targetModel;
    const targetId = req.query.targetId;

    const oneDayAgo = new Date();
    oneDayAgo.setDate(oneDayAgo.getDate() - 1);

    const query = {
        createdAt: { $gte: oneDayAgo }
    };

    if (targetModel) query.targetModel = targetModel;
    if (targetId) query.targetId = targetId;

    const logs = await ActivityLog.find(query)
        .populate('user', 'name email')
        .sort({ createdAt: -1 })
        .limit(limit)
        .lean();

    sendSuccess(res, logs, 'Recent activity fetched successfully');
});

/**
 * Get activity summary for dashboard
 */
const getActivitySummary = catchAsync(async (req, res) => {
    const { days = 7 } = req.query;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(days));

    const [
        totalLogs,
        recentLogs,
        topActions,
        topTargets
    ] = await Promise.all([
        ActivityLog.countDocuments({
            createdAt: { $gte: startDate }
        }),
        ActivityLog.find({
            createdAt: { $gte: startDate }
        })
            .populate('user', 'name email')
            .sort({ createdAt: -1 })
            .limit(10)
            .lean(),
        ActivityLog.aggregate([
            { $match: { createdAt: { $gte: startDate } } },
            { $group: { _id: '$action', count: { $sum: 1 } } },
            { $sort: { count: -1 } },
            { $limit: 5 }
        ]),
        ActivityLog.aggregate([
            { $match: { createdAt: { $gte: startDate } } },
            { $group: { _id: '$targetModel', count: { $sum: 1 } } },
            { $sort: { count: -1 } },
            { $limit: 5 }
        ])
    ]);

    sendSuccess(res, {
        totalLogs,
        recentLogs,
        topActions,
        topTargets,
        period: `${days} days`
    }, 'Activity summary fetched successfully');
});

export {
    getLogs,
    getTargetLogs,
    getUserLogs,
    getStats,
    deleteLog,
    cleanupLogs,
    getLogById,
    getRecentActivity,
    getActivitySummary
};