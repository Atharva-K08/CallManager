import httpStatus from 'http-status';
import catchAsync from '../utils/catchAsync.js';
import {
    createUser,
    queryUsers,
    getUserById,
    updateUserById,
    deleteUserById,
    activateUserById,
    deactivateUserById,
    updateUserPassword,
    updateUserPasswordByAdmin,
    searchUsers,
    getUserStats,
    getUserProfile,
    updateUserProfile,
    getUsersByRole,
    bulkUpdateUsers,
    bulkDeleteUsers,
    getCallersWithStats,
} from '../services/user.service.js';
import { logActivity, logUpdate, logSimple } from '../middlewares/activityLog.middleware.js';
const __showFollowUpLogs = process.env.SHOWFOLLOWUPLOGS === 'true' || process.env.SHOW_FOLLOW_UP_LOGS === 'true';
const debug = (...args) => { if (__showFollowUpLogs) console.log('[FOLLOWUP-DEBUG][UserController]', ...args); };
import {
    sendSuccess,
    sendCreated,
    sendNotFound,
    sendError,
    sendPaginated
} from '../utils/response.utils.js';

const createUserController = catchAsync(async (req, res) => {
    const user = await createUser(req.body);

    // Log activity
    await logSimple(req, 'create', 'User', user._id, user.name);

    sendCreated(res, user, 'User created successfully');
});

const getUsers = catchAsync(async (req, res) => {
    const filter = {};
    const options = {};

    // Build filter from query parameters
    if (req.query.name) filter.name = { $regex: req.query.name, $options: 'i' };
    if (req.query.email) filter.email = { $regex: req.query.email, $options: 'i' };
    if (req.query.role) filter.role = req.query.role;
    if (req.query.isActive !== undefined) {
        // Support both string and boolean (Joi may coerce to boolean already)
        const isActiveQuery = typeof req.query.isActive === 'string'
            ? req.query.isActive === 'true'
            : !!req.query.isActive;
        filter.isActive = isActiveQuery;
    }

    // Build options
    if (req.query.sortBy) {
        options.sortBy = req.query.sortBy; // Pass the string directly to service
    }
    options.limit = parseInt(req.query.limit) || 10;
    options.page = parseInt(req.query.page) || 1;

    const result = await queryUsers(filter, options);

    // Log activity
    await logActivity(req, {
        action: 'view',
        targetModel: 'User',
        targetId: 'multiple',
        targetName: 'User List',
        description: 'Viewed user list'
    });

    sendPaginated(res, result.results, {
        current_page: result.page,
        per_page: result.limit,
        total_items: result.totalResults,
        total_pages: result.totalPages
    }, 'Users retrieved successfully');
});

const getUser = catchAsync(async (req, res) => {
    const user = await getUserById(req.params.userId);

    // Log activity
    await logSimple(req, 'view', 'User', user._id, user.name);

    sendSuccess(res, user, 'User retrieved successfully');
});

const updateUser = catchAsync(async (req, res) => {
    const oldUser = await getUserById(req.params.userId);
    const user = await updateUserById(req.params.userId, req.body);

    // Log activity with changes
    await logUpdate(req, 'User', user._id, oldUser, user, user.name);

    sendSuccess(res, user, 'User updated successfully');
});

const deleteUser = catchAsync(async (req, res) => {
    const user = await deleteUserById(req.params.userId);

    // Log activity
    await logSimple(req, 'delete', 'User', user._id, user.name);

    sendSuccess(res, user, 'User deleted successfully');
});

const activateUser = catchAsync(async (req, res) => {
    const user = await activateUserById(req.params.userId);

    // Log activity
    await logSimple(req, 'activate', 'User', user._id, user.name);

    sendSuccess(res, user, 'User activated successfully');
});

const deactivateUser = catchAsync(async (req, res) => {
    const user = await deactivateUserById(req.params.userId);

    // Log activity
    await logSimple(req, 'deactivate', 'User', user._id, user.name);

    sendSuccess(res, user, 'User deactivated successfully');
});

const updateUserPasswordController = catchAsync(async (req, res) => {
    const { currentPassword, newPassword } = req.body;
    const user = await updateUserPassword(req.params.userId, currentPassword, newPassword);

    // Log activity
    await logActivity(req, {
        action: 'update',
        targetModel: 'User',
        targetId: user._id,
        targetName: user.name,
        description: 'Updated password'
    });

    sendSuccess(res, { id: user._id }, 'Password updated successfully');
});

const updateUserPasswordByAdminController = catchAsync(async (req, res) => {
    const { newPassword } = req.body;
    const user = await updateUserPasswordByAdmin(req.params.userId, newPassword);

    // Log activity
    await logActivity(req, {
        action: 'update',
        targetModel: 'User',
        targetId: user._id,
        targetName: user.name,
        description: 'Updated password by admin'
    });

    sendSuccess(res, { id: user._id }, 'Password updated successfully by admin');
});

const searchUsersController = catchAsync(async (req, res) => {
    const { q, role, isActive, limit = 10, page = 1 } = req.query;

    const options = {
        limit: parseInt(limit),
        page: parseInt(page),
        role,
        isActive: isActive !== undefined ? isActive === 'true' : undefined,
    };

    const result = await searchUsers(q, options);

    // Log activity
    await logActivity(req, {
        action: 'view',
        targetModel: 'User',
        targetId: 'search',
        targetName: `Search: ${q}`,
        description: `Searched users with query: ${q}`
    });

    sendPaginated(res, result.results, {
        current_page: result.page,
        per_page: result.limit,
        total_items: result.totalResults,
        total_pages: result.totalPages
    }, 'Search results retrieved successfully');
});

const getUserStatsController = catchAsync(async (req, res) => {
    const filters = {
        startDate: req.query.startDate,
        endDate: req.query.endDate,
    };

    const stats = await getUserStats(filters);

    // Log activity
    await logActivity(req, {
        action: 'view',
        targetModel: 'User',
        targetId: 'stats',
        targetName: 'User Statistics',
        description: 'Viewed user statistics'
    });

    sendSuccess(res, stats, 'User statistics retrieved successfully');
});

const getUserProfileController = catchAsync(async (req, res) => {
    const profile = await getUserProfile(req.params.userId);

    // Log activity
    await logSimple(req, 'view', 'User', req.params.userId, profile.name);

    sendSuccess(res, profile, 'User profile retrieved successfully');
});

const updateUserProfileController = catchAsync(async (req, res) => {
    const oldUser = await getUserById(req.params.userId);
    const user = await updateUserProfile(req.params.userId, req.body);

    // Log activity with changes
    await logUpdate(req, 'User', user._id, oldUser, user, user.name);

    sendSuccess(res, user, 'User profile updated successfully');
});

const getUsersByRoleController = catchAsync(async (req, res) => {
    const { role } = req.params;
    const options = {
        limit: parseInt(req.query.limit) || 10,
        page: parseInt(req.query.page) || 1,
    };

    const result = await getUsersByRole(role, options);

    // Log activity
    await logActivity(req, {
        action: 'view',
        targetModel: 'User',
        targetId: 'role',
        targetName: `Users by role: ${role}`,
        description: `Viewed users with role: ${role}`
    });

    sendPaginated(res, result.results, {
        current_page: result.page,
        per_page: result.limit,
        total_items: result.totalResults,
        total_pages: result.totalPages
    }, `${role} users retrieved successfully`);
});

const bulkUpdateUsersController = catchAsync(async (req, res) => {
    const { userIds, updateData } = req.body;

    if (!userIds || !Array.isArray(userIds) || userIds.length === 0) {
        return sendError(res, 'User IDs array is required', 400);
    }

    if (!updateData || Object.keys(updateData).length === 0) {
        return sendError(res, 'Update data is required', 400);
    }

    const result = await bulkUpdateUsers(userIds, updateData);

    // Log activity
    await logActivity(req, {
        action: 'update',
        targetModel: 'User',
        targetId: 'bulk',
        targetName: 'Multiple Users',
        description: `Bulk updated ${userIds.length} users`
    });

    sendSuccess(res, {
        modifiedCount: result.modifiedCount,
        matchedCount: result.matchedCount
    }, `${result.modifiedCount} users updated successfully`);
});

const bulkDeleteUsersController = catchAsync(async (req, res) => {
    const { userIds } = req.body;

    if (!userIds || !Array.isArray(userIds) || userIds.length === 0) {
        return sendError(res, 'User IDs array is required', 400);
    }

    const result = await bulkDeleteUsers(userIds);

    // Log activity
    await logActivity(req, {
        action: 'delete',
        targetModel: 'User',
        targetId: 'bulk',
        targetName: 'Multiple Users',
        description: `Bulk deleted ${userIds.length} users`
    });

    sendSuccess(res, {
        deletedCount: result.deletedCount
    }, `${result.deletedCount} users deleted successfully`);
});

// Get callers with call statistics
const getCallersWithStatsController = catchAsync(async (req, res) => {
    const options = {
        page: req.query.page,
        limit: req.query.limit,
        from: req.query.from,
        to: req.query.to,
        sortBy: req.query.sortBy,
    };

    const result = await getCallersWithStats(options);

    // Log activity
    await logActivity(req, {
        action: 'view',
        targetModel: 'User',
        targetId: 'callers',
        targetName: 'Callers List',
        description: 'Viewed callers with call statistics'
    });

    sendPaginated(res, result.results, {
        current_page: result.page,
        per_page: result.limit,
        total_items: result.totalResults,
        total_pages: result.totalPages
    }, 'Callers with statistics retrieved successfully');
});

export {
    createUserController,
    getUsers,
    getUser,
    updateUser,
    deleteUser,
    activateUser,
    deactivateUser,
    updateUserPasswordController,
    updateUserPasswordByAdminController,
    searchUsersController,
    getUserStatsController,
    getUserProfileController,
    updateUserProfileController,
    getUsersByRoleController,
    bulkUpdateUsersController,
    bulkDeleteUsersController,
    getCallersWithStatsController,
};

// Save FCM token for current user
export const saveFcmToken = catchAsync(async (req, res) => {
    const { fcmToken } = req.body || {};
    if (!fcmToken) {
        return sendError(res, 'fcmToken is required', 400);
    }
    const user = await updateUserById(req.user._id, { fcmToken });
    debug('Saved FCM token for user:', req.user._id.toString(), fcmToken?.slice?.(0, 10) + '...');
    sendSuccess(res, { ok: true }, 'FCM token saved');
});
