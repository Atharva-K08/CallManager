import catchAsync from '../utils/catchAsync.js';
import { sendCreated, sendSuccess, sendNoContent } from '../utils/response.utils.js';
import * as followUpService from '../services/followUp.service.js';
import { scheduleFollowUpReminder } from '../services/reminder.service.js';
import { logActivity } from '../middlewares/activityLog.middleware.js';

const __showFollowUpLogs = process.env.SHOWFOLLOWUPLOGS === 'true' || process.env.SHOW_FOLLOW_UP_LOGS === 'true';
const debug = (...args) => { if (__showFollowUpLogs) console.log('[FOLLOWUP-DEBUG][FollowUpController]', ...args); };

export const create = catchAsync(async (req, res) => {
    // Validate future dueAt
    const dueAt = req.body?.dueAt || req.body?.followUpDate;
    if (!dueAt || isNaN(new Date(dueAt))) {
        return sendSuccess(res, null, 'Invalid or missing dueAt');
    }

    // Add 5:30 hours buffer for IST timezone validation
    // This accounts for the fact that frontend sends UTC time but user thinks in IST
    const dueAtDate = new Date(dueAt);
    const currentTime = new Date();
    const bufferTime = new Date(currentTime.getTime() - (5.5 * 60 * 60 * 1000)); // Subtract 5:30 hours

    if (dueAtDate <= bufferTime) {
        return sendSuccess(res, null, 'followUp dueAt must be in the future');
    }

    const doc = await followUpService.create(req.body, req.user?._id);
    await logActivity(req, { action: 'create', targetModel: 'FollowUp', targetId: doc._id, targetName: doc._id.toString(), description: `Created follow-up` });

    // Auto-schedule reminder job for this follow-up
    try {
        // Ensure message is a valid string or null (not undefined)
        const message = (req.body.note && typeof req.body.note === 'string' && req.body.note.trim() !== '')
            ? req.body.note.trim()
            : null;
        
        const reminderPayload = {
            followUpId: doc._id.toString(), // Pass the existing follow-up ID
            leadId: doc.leadId?.toString?.() || req.body.leadId,
            leadName: req.body.leadName, // optional; schedule service will validate lead
            followUpDate: doc.dueAt,
            message: message,
            userId: req.user?._id?.toString?.(),
            userEmail: req.user?.email,
            reminderIntervalDays: req.body?.metadata?.reminderIntervalDays || 7,
        };
        debug('Auto-scheduling reminder from FollowUp create:', {
            followUpId: reminderPayload.followUpId,
            leadId: reminderPayload.leadId,
            followUpDate: reminderPayload.followUpDate,
            userId: reminderPayload.userId,
        });
        await scheduleFollowUpReminder(reminderPayload);
    } catch (e) {
        debug('Failed to auto-schedule reminder:', e?.message);
    }

    sendCreated(res, doc, 'Follow-up created successfully');
});

export const list = catchAsync(async (req, res) => {
    const data = await followUpService.list(req.query, req.query);
    sendSuccess(res, data, 'Follow-ups fetched successfully');
});

export const get = catchAsync(async (req, res) => {
    const doc = await followUpService.getById(req.params.followUpId);
    sendSuccess(res, doc, 'Follow-up fetched successfully');
});

export const update = catchAsync(async (req, res) => {
    // Validate future dueAt if provided
    if (req.body?.dueAt || req.body?.followUpDate) {
        const dueAt = req.body?.dueAt || req.body?.followUpDate;
        if (!dueAt || isNaN(new Date(dueAt))) {
            return sendSuccess(res, null, 'Invalid or missing dueAt');
        }

        // Add 5:30 hours buffer for IST timezone validation
        // This accounts for the fact that frontend sends UTC time but user thinks in IST
        const dueAtDate = new Date(dueAt);
        const currentTime = new Date();
        const bufferTime = new Date(currentTime.getTime() - (5.5 * 60 * 60 * 1000)); // Subtract 5:30 hours

        if (dueAtDate <= bufferTime) {
            return sendSuccess(res, null, 'followUp dueAt must be in the future');
        }
    }

    const doc = await followUpService.updateById(req.params.followUpId, req.body);
    await logActivity(req, { action: 'update', targetModel: 'FollowUp', targetId: doc._id, targetName: doc._id.toString(), description: `Updated follow-up` });
    sendSuccess(res, doc, 'Follow-up updated successfully');
});

export const remove = catchAsync(async (req, res) => {
    await followUpService.removeById(req.params.followUpId);
    await logActivity(req, { action: 'delete', targetModel: 'FollowUp', targetId: req.params.followUpId, targetName: req.params.followUpId, description: `Deleted follow-up` });
    sendNoContent(res);
});

export const resolveFollowUp = catchAsync(async (req, res) => {
    const { followUpId } = req.params;
    const { resolutionReason, resolutionType = 'RESOLVED' } = req.body;
    const userId = req.user._id;

    const doc = await followUpService.resolveFollowUp(followUpId, {
        resolutionStatus: resolutionType,
        resolvedBy: userId,
        resolvedAt: new Date(),
        resolutionReason: resolutionReason,
    });

    await logActivity(req, {
        action: 'update',
        targetModel: 'FollowUp',
        targetId: doc._id,
        targetName: 'Follow-up Resolution',
        description: `Resolved follow-up: ${resolutionReason || 'No reason provided'}`
    });

    sendSuccess(res, doc, 'Follow-up resolved successfully');
});

export const unresolveFollowUp = catchAsync(async (req, res) => {
    const { followUpId } = req.params;
    const userId = req.user._id;

    const doc = await followUpService.unresolveFollowUp(followUpId, userId);

    await logActivity(req, {
        action: 'update',
        targetModel: 'FollowUp',
        targetId: doc._id,
        targetName: 'Follow-up Unresolution',
        description: 'Follow-up marked as unresolved'
    });

    sendSuccess(res, doc, 'Follow-up unresolved successfully');
});

export const getResolvedFollowUps = catchAsync(async (req, res) => {
    const data = await followUpService.getResolvedFollowUps(req.query, req.query);
    sendSuccess(res, data, 'Resolved follow-ups fetched successfully');
});

export default { create, list, get, update, remove, resolveFollowUp, unresolveFollowUp, getResolvedFollowUps };


