import httpStatus from 'http-status';
import catchAsync from '../utils/catchAsync.js';
import { sendCreated, sendNoContent, sendSuccess } from '../utils/response.utils.js';
import * as leadStatusService from '../services/leadStatus.service.js';
import { logActivity, logUpdate } from '../middlewares/activityLog.middleware.js';

export const create = catchAsync(async (req, res) => {
    const payload = {
        ...req.body,
        createdBy: req.user?.id || req.user?._id,
    };
    const doc = await leadStatusService.createLeadStatus(payload);
    await logActivity(req, {
        action: 'create',
        targetModel: 'LeadStatus',
        targetId: doc._id,
        targetName: doc.name,
        description: `Created LeadStatus: ${doc.name} (${doc.type})`,
    });
    sendCreated(res, doc, 'Lead status created successfully');
});

export const list = catchAsync(async (req, res) => {
    const data = await leadStatusService.queryLeadStatuses(req.query, req.query);
    sendSuccess(res, data, 'Lead statuses fetched successfully');
});

export const get = catchAsync(async (req, res) => {
    const doc = await leadStatusService.getLeadStatusById(req.params.leadStatusId);
    if (doc) {
        await logActivity(req, {
            action: 'view',
            targetModel: 'LeadStatus',
            targetId: doc._id,
            targetName: doc.name,
            description: `Viewed LeadStatus: ${doc.name}`,
        });
    }
    sendSuccess(res, doc, 'Lead status fetched successfully');
});

export const update = catchAsync(async (req, res) => {
    const before = await leadStatusService.getLeadStatusById(req.params.leadStatusId);
    const doc = await leadStatusService.updateLeadStatusById(req.params.leadStatusId, req.body);
    await logUpdate(req, 'LeadStatus', doc._id, before?.toObject?.() || before, doc.toObject?.() || doc, doc.name);
    sendSuccess(res, doc, 'Lead status updated successfully');
});

export const remove = catchAsync(async (req, res) => {
    const before = await leadStatusService.getLeadStatusById(req.params.leadStatusId);
    await leadStatusService.deleteLeadStatusById(req.params.leadStatusId);
    if (before) {
        await logActivity(req, {
            action: 'delete',
            targetModel: 'LeadStatus',
            targetId: before._id,
            targetName: before.name,
            description: `Deleted LeadStatus: ${before.name}`,
        });
    }
    sendNoContent(res);
});

export const activate = catchAsync(async (req, res) => {
    const doc = await leadStatusService.setActiveState(req.params.leadStatusId, true);
    await logActivity(req, {
        action: 'activate',
        targetModel: 'LeadStatus',
        targetId: doc._id,
        targetName: doc.name,
        description: `Activated LeadStatus: ${doc.name}`,
    });
    sendSuccess(res, doc, 'Lead status activated');
});

export const deactivate = catchAsync(async (req, res) => {
    const doc = await leadStatusService.setActiveState(req.params.leadStatusId, false);
    await logActivity(req, {
        action: 'deactivate',
        targetModel: 'LeadStatus',
        targetId: doc._id,
        targetName: doc.name,
        description: `Deactivated LeadStatus: ${doc.name}`,
    });
    sendSuccess(res, doc, 'Lead status deactivated');
});

export const getDefaultImport = catchAsync(async (req, res) => {
    const doc = await leadStatusService.getDefaultImportLeadStatus();
    sendSuccess(res, { default: doc }, 'Default import lead status fetched successfully');
});

export const setDefaultImport = catchAsync(async (req, res) => {
    const doc = await leadStatusService.setDefaultImportLeadStatus(req.params.leadStatusId);
    await logActivity(req, {
        action: 'update',
        targetModel: 'LeadStatus',
        targetId: doc._id,
        targetName: doc.name,
        description: `Set ${doc.name} as default import lead status`,
    });
    sendSuccess(res, { updated: doc }, 'Default import lead status updated successfully');
});

export default { create, list, get, update, remove, activate, deactivate, getDefaultImport, setDefaultImport };


