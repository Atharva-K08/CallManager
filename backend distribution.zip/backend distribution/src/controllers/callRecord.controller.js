import catchAsync from '../utils/catchAsync.js';
import { sendCreated, sendNoContent, sendSuccess } from '../utils/response.utils.js';
import * as callRecordService from '../services/callRecord.service.js';
import { logActivity, logUpdate } from '../middlewares/activityLog.middleware.js';

export const create = catchAsync(async (req, res) => {
    const payload = { ...req.body, createdBy: req.user?._id };
    const doc = await callRecordService.createCallRecord(payload);
    await logActivity(req, { action: 'create', targetModel: 'CallRecord', targetId: doc._id, targetName: doc.phoneNumber, description: `Created call record for ${doc.phoneNumber}` });
    sendCreated(res, doc, 'Call record created successfully');
});

export const list = catchAsync(async (req, res) => {
    const data = await callRecordService.queryCallRecords(req.query, req.query);
    sendSuccess(res, data, 'Call records fetched successfully');
});

export const get = catchAsync(async (req, res) => {
    const doc = await callRecordService.getCallRecordById(req.params.callRecordId);
    sendSuccess(res, doc, 'Call record fetched successfully');
});

export const update = catchAsync(async (req, res) => {
    const before = await callRecordService.getCallRecordById(req.params.callRecordId);
    const doc = await callRecordService.updateCallRecordById(req.params.callRecordId, req.body);
    await logUpdate(req, 'CallRecord', doc._id, before?.toObject?.() || before, doc.toObject?.() || doc, doc.phoneNumber);
    sendSuccess(res, doc, 'Call record updated successfully');
});

export const remove = catchAsync(async (req, res) => {
    const before = await callRecordService.getCallRecordById(req.params.callRecordId);
    await callRecordService.deleteCallRecordById(req.params.callRecordId);
    if (before) {
        await logActivity(req, { action: 'delete', targetModel: 'CallRecord', targetId: before._id, targetName: before.phoneNumber, description: `Deleted call record for ${before.phoneNumber}` });
    }
    sendNoContent(res);
});

export const setStatus = catchAsync(async (req, res) => {
    const doc = await callRecordService.updateStatus(req.params.callRecordId, req.body.status);
    await logActivity(req, { action: 'update', targetModel: 'CallRecord', targetId: doc._id, targetName: doc.phoneNumber, description: `Updated call record status to ${doc.status}` });
    sendSuccess(res, doc, 'Call record status updated');
});

export const getStatistics = catchAsync(async (req, res) => {
    const filter = {};
    if (req.query.createdBy) filter.createdBy = req.query.createdBy;
    if (req.query.from) filter.from = req.query.from;
    if (req.query.to) filter.to = req.query.to;
    if (req.query.leadId) filter.leadId = req.query.leadId;

    const statistics = await callRecordService.getCallStatistics(filter);
    sendSuccess(res, statistics, 'Call statistics fetched successfully');
});

export const getByPhoneNumber = catchAsync(async (req, res) => {
    const phoneNumber = req.params.phoneNumber;
    const records = await callRecordService.getCallRecordsByPhoneNumber(phoneNumber);
    sendSuccess(res, records, `Call records for ${phoneNumber} fetched successfully`);
});

export const getByLeadId = catchAsync(async (req, res) => {
    const leadId = req.params.leadId;
    const records = await callRecordService.getCallRecordsByLeadId(leadId);
    sendSuccess(res, records, `Call records for lead ${leadId} fetched successfully`);
});

export const syncUpload = catchAsync(async (req, res) => {
    const result = await callRecordService.syncUpload(req.body.callRecords || []);
    sendSuccess(res, result, 'Call records synced (upload)');
});

export const syncPull = catchAsync(async (req, res) => {
    const { since, limit } = req.query;
    const result = await callRecordService.syncPull(since, limit);
    sendSuccess(res, result, 'Call records synced (pull)');
});

export default { create, list, get, update, remove, setStatus, getStatistics, getByPhoneNumber, getByLeadId, syncUpload, syncPull };

