import catchAsync from '../utils/catchAsync.js';
import { sendCreated, sendNoContent, sendSuccess } from '../utils/response.utils.js';
import * as leadService from '../services/lead.service.js';
import { logActivity, logUpdate } from '../middlewares/activityLog.middleware.js';

export const create = catchAsync(async (req, res) => {
    const payload = { ...req.body, createdBy: req.user?._id };
    const doc = await leadService.createLead(payload);
    const fullName = `${doc.firstName} ${doc.lastName}`.trim();
    await logActivity(req, { action: 'create', targetModel: 'Lead', targetId: doc._id, targetName: fullName, description: `Created lead: ${fullName}` });
    sendCreated(res, doc, 'Lead created successfully');
});

export const list = catchAsync(async (req, res) => {
    const data = await leadService.queryLeads(req.query, req.query);
    sendSuccess(res, data, 'Leads fetched successfully');
});

export const get = catchAsync(async (req, res) => {
    const doc = await leadService.getLeadById(req.params.leadId);
    sendSuccess(res, doc, 'Lead fetched successfully');
});

export const update = catchAsync(async (req, res) => {
    const before = await leadService.getLeadById(req.params.leadId);
    const doc = await leadService.updateLeadById(req.params.leadId, req.body);
    const fullName = `${doc.firstName} ${doc.lastName}`.trim();
    await logUpdate(req, 'Lead', doc._id, before?.toObject?.() || before, doc.toObject?.() || doc, fullName);
    sendSuccess(res, doc, 'Lead updated successfully');
});

export const remove = catchAsync(async (req, res) => {
    const before = await leadService.getLeadById(req.params.leadId);
    await leadService.deleteLeadById(req.params.leadId);
    if (before) {
        const fullName = `${before.firstName} ${before.lastName}`.trim();
        await logActivity(req, { action: 'delete', targetModel: 'Lead', targetId: before._id, targetName: fullName, description: `Deleted lead: ${fullName}` });
    }
    sendNoContent(res);
});

export const setStatus = catchAsync(async (req, res) => {
    const doc = await leadService.updateStatus(req.params.leadId, req.body.status, req.body.remark);
    const fullName = `${doc.firstName} ${doc.lastName}`.trim();
    await logActivity(req, { action: 'update', targetModel: 'Lead', targetId: doc._id, targetName: fullName, description: `Updated lead status to ${doc.status}` });
    sendSuccess(res, doc, 'Lead status updated');
});

export const setCallStatus = catchAsync(async (req, res) => {
    const doc = await leadService.updateCallStatus(req.params.leadId, req.body.callStatus);
    const fullName = `${doc.firstName} ${doc.lastName}`.trim();
    await logActivity(req, { action: 'update', targetModel: 'Lead', targetId: doc._id, targetName: fullName, description: `Updated call status to ${doc.callStatus}` });
    sendSuccess(res, doc, 'Lead call status updated');
});

export const syncUpload = catchAsync(async (req, res) => {
    const result = await leadService.syncUpload(req.body.leads || []);
    sendSuccess(res, result, 'Leads synced (upload)');
});

export const syncPull = catchAsync(async (req, res) => {
    const { since, limit } = req.query;
    const result = await leadService.syncPull(since, limit);
    sendSuccess(res, result, 'Leads synced (pull)');
});

export default { create, list, get, update, remove, setStatus, setCallStatus, syncUpload, syncPull };


