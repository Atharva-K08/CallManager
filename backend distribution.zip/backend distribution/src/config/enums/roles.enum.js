const Roles = Object.freeze({
  ADMIN: 'admin',
  EMPLOYEE: 'employee',
});

export default Roles;
