import {
  ROLES,
  ROLE_PERMISSIONS,
  AVAILABLE_ROLES,
  getRolePermissions as getSharedRolePermissions,
  roleRights as sharedRoleRights
} from './shared-roles.js';

// Legacy role mapping for backward compatibility
const legacyRoleMapping = {
  'user': ROLES.USER,
  'admin': ROLES.ADMIN,
  'superadmin': ROLES.SUPERADMIN,
  'employee': ROLES.EMPLOYEE,
  'caller': ROLES.CALLER
};

// Function to get role permissions - handles custom roles and legacy mappings
const getRolePermissions = (role, subRole = null) => {
  // Handle legacy role names
  const mappedRole = legacyRoleMapping[role] || role;

  if (ROLE_PERMISSIONS[mappedRole]) {
    return ROLE_PERMISSIONS[mappedRole];
  }

  // Fallback to user permissions for unknown roles
  return ROLE_PERMISSIONS[ROLES.USER];
};

// Export roles array for backward compatibility
const roles = AVAILABLE_ROLES;

// Export roles array for backward compatibility
export { roles, getRolePermissions, ROLES };
export { sharedRoleRights as roleRights };
