/**
 * Default Settings Configuration
 * Define default values for all features here
 * 
 * Structure:
 * {
 *   category: {
 *     key: {
 *       value: defaultValue,
 *       dataType: 'string' | 'number' | 'boolean' | 'object' | 'array',
 *       description: 'Human-readable description',
 *       isEditable: true/false
 *     }
 *   }
 * }
 */

export const DEFAULT_SETTINGS = {
    // UI/Display Preferences
    ui: {
        theme: {
            value: 'light',
            dataType: 'string',
            description: 'Application theme (light, dark, auto)',
            isEditable: true,
        },
        language: {
            value: 'en',
            dataType: 'string',
            description: 'Interface language',
            isEditable: true,
        },
        itemsPerPage: {
            value: 10,
            dataType: 'number',
            description: 'Default number of items per page',
            isEditable: true,
        },
        showNotifications: {
            value: true,
            dataType: 'boolean',
            description: 'Show toast notifications',
            isEditable: true,
        },
    },

    // Notification Preferences
    notifications: {
        emailEnabled: {
            value: true,
            dataType: 'boolean',
            description: 'Enable email notifications',
            isEditable: true,
        },
        pushEnabled: {
            value: true,
            dataType: 'boolean',
            description: 'Enable push notifications',
            isEditable: true,
        },
        soundEnabled: {
            value: true,
            dataType: 'boolean',
            description: 'Enable sound notifications',
            isEditable: true,
        },
        desktopEnabled: {
            value: true,
            dataType: 'boolean',
            description: 'Enable desktop notifications',
            isEditable: true,
        },
        notifyOnNewTask: {
            value: true,
            dataType: 'boolean',
            description: 'Notify when assigned a new task',
            isEditable: true,
        },
        notifyOnNewLead: {
            value: false,
            dataType: 'boolean',
            description: 'Notify when a new lead is assigned',
            isEditable: true,
        },
        notifyOnFollowUp: {
            value: true,
            dataType: 'boolean',
            description: 'Notify on follow-up reminders',
            isEditable: true,
        },
    },

    // Feature Flags (for new features)
    features: {
        // Example: New feature flag
        enableAdvancedReports: {
            value: false,
            dataType: 'boolean',
            description: 'Enable advanced reporting features',
            isEditable: true,
        },
        enableBulkActions: {
            value: true,
            dataType: 'boolean',
            description: 'Enable bulk actions on lists',
            isEditable: true,
        },
        enableExport: {
            value: true,
            dataType: 'boolean',
            description: 'Enable data export functionality',
            isEditable: true,
        },
    },

    // Sync/Data Preferences
    sync: {
        autoSync: {
            value: true,
            dataType: 'boolean',
            description: 'Automatically sync data in background',
            isEditable: true,
        },
        syncInterval: {
            value: 300000, // 5 minutes in milliseconds
            dataType: 'number',
            description: 'Sync interval in milliseconds',
            isEditable: true,
        },
        syncOnAppStart: {
            value: true,
            dataType: 'boolean',
            description: 'Sync data when app starts',
            isEditable: true,
        },
    },

    // Integration Settings
    integrations: {
        enableWhatsApp: {
            value: false,
            dataType: 'boolean',
            description: 'Enable WhatsApp integration',
            isEditable: true,
        },
        enableSMS: {
            value: false,
            dataType: 'boolean',
            description: 'Enable SMS integration',
            isEditable: true,
        },
    },
};

/**
 * Initialize all default settings in database
 * Call this during app startup or migration
 */
export const initializeDefaultSettings = async (Settings) => {
    for (const [category, settings] of Object.entries(DEFAULT_SETTINGS)) {
        await Settings.initializeDefaults(category, settings);
    }
};

