const fileBaseUrl = 'https://vsm-backend-i6ad.onrender.com/v1/files/';
export default fileBaseUrl;
