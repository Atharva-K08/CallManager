/**
 * Shared Role Definitions
 * This file contains role definitions that are shared between backend and frontend
 * to ensure consistency across the application.
 */

// Role constants
export const ROLES = {
    USER: 'user',
    ADMIN: 'admin',
    SUPERADMIN: 'superadmin',
    EMPLOYEE: 'employee',
    CALLER: 'caller'
};

// Role hierarchy (higher number = more permissions)
export const ROLE_HIERARCHY = {
    [ROLES.USER]: 1,
    [ROLES.CALLER]: 2,
    [ROLES.EMPLOYEE]: 2,
    [ROLES.ADMIN]: 3,
    [ROLES.SUPERADMIN]: 4
};

// Role permissions mapping
export const ROLE_PERMISSIONS = {
    [ROLES.USER]: [
        'viewOwnProfile',
        'updateOwnProfile',
        'viewOwnCalls',
        'createCall',
        'updateOwnCall',
        // CallRecord API granular permissions (minimal for user)
        'createCallRecords',
        'viewCallRecords'
    ],
    [ROLES.EMPLOYEE]: [
        'viewOwnProfile',
        'updateOwnProfile',
        'viewOwnCalls',
        'createCall',
        'updateOwnCall',
        'viewAssignedStudents',
        'updateAssignedStudents',
        // CallRecord API granular permissions
        'createCallRecords',
        'viewCallRecords',
        'updateCallRecords'
    ],
    [ROLES.CALLER]: [
        'createLeads',
        'updateLeads',
        'deleteLeads',
        'viewLeads',
        'viewLeadStatuses',
        'viewTasks',
        'viewOwnProfile',
        'updateOwnProfile',
        'viewOwnCalls',
        'createCall',
        'updateOwnCall',
        'viewAssignedStudents',
        'updateAssignedStudents',
        'getUsers', // Allow callers to view leads and lead statuses
        'viewLeads',
        'viewLeadStatuses',
        // CallRecord API granular permissions
        'createCallRecords',
        'viewCallRecords',
        'updateCallRecords'
    ],
    [ROLES.ADMIN]: [
        'viewOwnProfile',
        'updateOwnProfile',
        'viewOwnCalls',
        'createCall',
        'updateOwnCall',
        'createLeads',
        'updateLeads',
        'deleteLeads',
        'viewLeads',
        'viewLeadStatuses',
        'viewAssignedStudents',
        'updateAssignedStudents',
        'getUsers',
        'manageUsers',
        'viewAllCalls',
        'viewAllStudents',
        'assignStudents',
        'viewReports',
        'manageSystemSettings',
        // CallRecord API granular permissions
        'createCallRecords',
        'viewCallRecords',
        'updateCallRecords',
        'deleteCallRecords'
    ],
    [ROLES.SUPERADMIN]: [
        'viewOwnProfile',
        'updateOwnProfile',
        'viewOwnCalls',
        'createCall',
        'updateOwnCall',
        'viewAssignedStudents',
        'updateAssignedStudents',
        'getUsers',
        'manageUsers',
        'viewAllCalls',
        'viewAllStudents',
        'assignStudents',
        'viewReports',
        'manageSystemSettings',
        'deleteUsers',
        'bulkManageUsers',
        'viewAllReports',
        'manageAllSettings',
        'systemAdministration',
        // CallRecord API granular permissions
        'createCallRecords',
        'viewCallRecords',
        'updateCallRecords',
        'deleteCallRecords'
    ]
};

// Role display names for UI
export const ROLE_DISPLAY_NAMES = {
    [ROLES.USER]: 'User',
    [ROLES.EMPLOYEE]: 'Employee',
    [ROLES.CALLER]: 'Caller',
    [ROLES.ADMIN]: 'Admin',
    [ROLES.SUPERADMIN]: 'Super Admin'
};

// Role descriptions
export const ROLE_DESCRIPTIONS = {
    [ROLES.USER]: 'Basic user with limited permissions',
    [ROLES.EMPLOYEE]: 'Employee with access to assigned students and calls',
    [ROLES.CALLER]: 'Caller with access to assigned leads and calls',
    [ROLES.ADMIN]: 'Administrator with user management and reporting capabilities',
    [ROLES.SUPERADMIN]: 'Super administrator with full system access'
};

// Available roles array (for validation)
export const AVAILABLE_ROLES = Object.values(ROLES);

// Helper functions
export const getRolePermissions = (role) => {
    return ROLE_PERMISSIONS[role] || [];
};

export const hasPermission = (userRole, permission) => {
    const permissions = getRolePermissions(userRole);
    return permissions.includes(permission);
};

export const canAccessRole = (userRole, targetRole) => {
    const userLevel = ROLE_HIERARCHY[userRole] || 0;
    const targetLevel = ROLE_HIERARCHY[targetRole] || 0;
    return userLevel >= targetLevel;
};

export const getRolesUserCanManage = (userRole) => {
    const userLevel = ROLE_HIERARCHY[userRole] || 0;
    return AVAILABLE_ROLES.filter(role =>
        ROLE_HIERARCHY[role] < userLevel
    );
};

// Role validation
export const isValidRole = (role) => {
    return AVAILABLE_ROLES.includes(role);
};

// Export role rights for backward compatibility
export const roleRights = new Map(Object.entries(ROLE_PERMISSIONS));
