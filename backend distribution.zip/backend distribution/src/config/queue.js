import Queue from 'bull';
import Redis from 'ioredis';
import config from './config.js';

const __showFollowUpLogs = process.env.SHOWFOLLOWUPLOGS === 'true' || process.env.SHOW_FOLLOW_UP_LOGS === 'true';
const debug = (...args) => { if (__showFollowUpLogs) console.log('[FOLLOWUP-DEBUG][Queue]', ...args); };

// Redis connection configuration
const redisConfig = {
    host: config.redis.host || 'localhost',
    port: config.redis.port || 6379,
    password: config.redis.password,
    db: config.redis.db || 0,
    retryDelayOnFailover: 100,
    maxRetriesPerRequest: 3,
};

// Create Redis connection
const redis = new Redis(redisConfig);
debug('Redis config:', { host: redisConfig.host, port: redisConfig.port, db: redisConfig.db });

// Queue configurations
export const reminderQueue = new Queue('follow-up reminders', {
    redis: redisConfig,
    defaultJobOptions: {
        removeOnComplete: 100,
        removeOnFail: 50,
        attempts: 3,
        backoff: {
            type: 'exponential',
            delay: 2000,
        },
    },
});
debug('Initialized reminderQueue');

export const notificationQueue = new Queue('notifications', {
    redis: redisConfig,
    defaultJobOptions: {
        removeOnComplete: 200,
        removeOnFail: 100,
        attempts: 3,
        backoff: {
            type: 'exponential',
            delay: 2000,
        },
    },
});
debug('Initialized notificationQueue');

// Queue event listeners
reminderQueue.on('completed', (job) => {
    console.log(`✅ Reminder job ${job.id} completed`);
    debug('Job completed payload:', job.data);
});

reminderQueue.on('failed', (job, err) => {
    console.error(`❌ Reminder job ${job.id} failed:`, err.message);
    debug('Job failed payload:', job.data, 'error:', err?.stack || err?.message);
});

reminderQueue.on('stalled', (job) => {
    console.warn(`⚠️ Reminder job ${job.id} stalled`);
    debug('Job stalled payload:', job.data);
});

notificationQueue.on('completed', (job) => {
    console.log(`✅ Notification job ${job.id} completed`);
    debug('Notification job completed payload:', job.data);
});

notificationQueue.on('failed', (job, err) => {
    console.error(`❌ Notification job ${job.id} failed:`, err.message);
    debug('Notification job failed payload:', job.data, 'error:', err?.stack || err?.message);
});

notificationQueue.on('stalled', (job) => {
    console.warn(`⚠️ Notification job ${job.id} stalled`);
    debug('Notification job stalled payload:', job.data);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
    console.log('🔄 Gracefully shutting down queues...');
    await reminderQueue.close();
    await notificationQueue.close();
    await redis.disconnect();
    process.exit(0);
});

process.on('SIGINT', async () => {
    console.log('🔄 Gracefully shutting down queues...');
    await reminderQueue.close();
    await notificationQueue.close();
    await redis.disconnect();
    process.exit(0);
});

export { redis };
