import { createActivityLog } from '../services/activityLog.service.js';

/**
 * Simple activity logging helper
 * @param {Object} req - Express request object
 * @param {Object} options - Logging options
 */
export const logActivity = async (req, options = {}) => {
    try {
        const {
            action,
            targetModel,
            targetId,
            targetName,
            description,
            changes = null,
            metadata = {}
        } = options;

        // Validate required fields
        if (!action || !targetModel || !targetId) {
            console.warn('Missing required fields for activity log');
            return;
        }

        const logData = {
            user: req.user?._id,
            userName: req.user?.name || 'Unknown',
            userEmail: req.user?.email || 'unknown@example.com',
            targetModel,
            targetId,
            targetName: targetName || 'Unknown',
            action,
            description: description || `${action} ${targetModel}`,
            changes,
            metadata: {
                ...metadata,
                method: req.method,
                url: req.originalUrl,
            },
            ipAddress: req.ip || req.connection?.remoteAddress,
            userAgent: req.get('User-Agent')
        };

        await createActivityLog(logData);
    } catch (error) {
        console.error('Error in activity logging:', error);
        // Don't throw - logging should not break the main flow
    }
};

/**
 * Log a simple action
 * Usage: await logSimple(req, 'create', 'User', userId, 'John Doe');
 */
export const logSimple = async (req, action, targetModel, targetId, targetName = null) => {
    await logActivity(req, {
        action,
        targetModel,
        targetId,
        targetName,
        description: `${action} ${targetModel}${targetName ? ': ' + targetName : ''}`
    });
};

/**
 * Log an update with changes
 * Usage: await logUpdate(req, 'User', userId, oldDoc, newDoc);
 */
export const logUpdate = async (req, targetModel, targetId, oldDoc, newDoc, targetName = null) => {
    const changes = {};

    // Simple change detection
    if (oldDoc && newDoc) {
        Object.keys(newDoc).forEach(key => {
            if (key !== '__v' && key !== 'updatedAt' && key !== 'password') {
                const oldValue = oldDoc[key];
                const newValue = newDoc[key];

                if (JSON.stringify(oldValue) !== JSON.stringify(newValue)) {
                    changes[key] = {
                        from: oldValue,
                        to: newValue
                    };
                }
            }
        });
    }

    await logActivity(req, {
        action: 'update',
        targetModel,
        targetId,
        targetName: targetName || newDoc?.name || newDoc?.title,
        description: `Updated ${targetModel}`,
        changes: Object.keys(changes).length > 0 ? changes : null
    });
};

/**
 * Middleware to automatically log requests (optional)
 * Use this on routes you want to automatically track
 */
export const autoLogMiddleware = (targetModel) => {
    return async (req, res, next) => {
        // Store original send function
        const originalSend = res.send;

        // Override send function
        res.send = function (data) {
            // Log activity on successful operations
            if (res.statusCode >= 200 && res.statusCode < 300) {
                const action = req.method === 'POST' ? 'create' :
                    req.method === 'PUT' || req.method === 'PATCH' ? 'update' :
                        req.method === 'DELETE' ? 'delete' : 'view';

                const targetId = req.params.id || req.body?._id || req.body?.id;

                if (targetId) {
                    logSimple(req, action, targetModel, targetId).catch(err =>
                        console.error('Auto-log error:', err)
                    );
                }
            }

            // Call original send
            return originalSend.call(this, data);
        };

        next();
    };
};