import { ROLES, ROLE_PERMISSIONS, hasPermission, canAccessRole } from '../config/shared-roles.js';

/**
 * Role-based authentication middleware
 */

// Check if user has specific permission
export const requirePermission = (permission) => {
    return (req, res, next) => {
        try {
            const userRole = req.user?.role;

            if (!userRole) {
                return res.status(401).json({
                    status: 0,
                    message: 'User role not found'
                });
            }

            if (!hasPermission(userRole, permission)) {
                return res.status(403).json({
                    status: 0,
                    message: `Insufficient permissions. Required: ${permission}`
                });
            }

            next();
        } catch (error) {
            return res.status(500).json({
                status: 0,
                message: 'Error checking permissions',
                error: error.message
            });
        }
    };
};

// Check if user can manage another user with target role
export const requireRoleAccess = (targetRoleParam = 'targetRole') => {
    return (req, res, next) => {
        try {
            const userRole = req.user?.role;
            const targetRole = req.params[targetRoleParam] || req.body.role;

            if (!userRole) {
                return res.status(401).json({
                    status: 0,
                    message: 'User role not found'
                });
            }

            if (!canAccessRole(userRole, targetRole)) {
                return res.status(403).json({
                    status: 0,
                    message: `Cannot manage users with role: ${targetRole}`
                });
            }

            next();
        } catch (error) {
            return res.status(500).json({
                status: 0,
                message: 'Error checking role access',
                error: error.message
            });
        }
    };
};

// Check if user is admin or higher
export const requireAdmin = (req, res, next) => {
    try {
        const userRole = req.user?.role;

        if (!userRole) {
            return res.status(401).json({
                status: 0,
                message: 'User role not found'
            });
        }

        if (![ROLES.ADMIN, ROLES.SUPERADMIN].includes(userRole)) {
            return res.status(403).json({
                status: 0,
                message: 'Admin access required'
            });
        }

        next();
    } catch (error) {
        return res.status(500).json({
            status: 0,
            message: 'Error checking admin access',
            error: error.message
        });
    }
};

// Check if user is super admin
export const requireSuperAdmin = (req, res, next) => {
    try {
        const userRole = req.user?.role;

        if (!userRole) {
            return res.status(401).json({
                status: 0,
                message: 'User role not found'
            });
        }

        if (userRole !== ROLES.SUPERADMIN) {
            return res.status(403).json({
                status: 0,
                message: 'Super admin access required'
            });
        }

        next();
    } catch (error) {
        return res.status(500).json({
            status: 0,
            message: 'Error checking super admin access',
            error: error.message
        });
    }
};

// Validate role in request body
export const validateRole = (req, res, next) => {
    try {
        const { role } = req.body;

        if (role && !Object.values(ROLES).includes(role)) {
            return res.status(400).json({
                status: 0,
                message: `Invalid role. Must be one of: ${Object.values(ROLES).join(', ')}`
            });
        }

        next();
    } catch (error) {
        return res.status(500).json({
            status: 0,
            message: 'Error validating role',
            error: error.message
        });
    }
};
