import React, { createContext, useCallback, useEffect, useMemo, useState } from 'react';
import { LoginRequest, User, ApiError } from '../types/api.types';
import { authService } from '../services';
import { useApi } from '../hooks/useApi';
import showToast from '../lib/toast';

interface AuthContextValue {
    user: User | null;
    isAuthenticated: boolean;
    loading: boolean;
    error: ApiError | null;
    login: (credentials: LoginRequest) => Promise<any>;
    logout: () => Promise<any>;
    getCurrentUser: () => Promise<any>;
}

export const AuthContext = createContext<AuthContextValue | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<User | null>(null);
    const [isAuthenticated, setIsAuthenticated] = useState<boolean>(authService.isAuthenticated());
    const [initialized, setInitialized] = useState<boolean>(false);

    const loginApi = useApi(authService.login, {
        onSuccess: (response) => {
            setUser(response.user);
            setIsAuthenticated(true);
            showToast.success('Login successful!');
        },
        onError: (error) => {
            showToast.error(error.message || 'Login failed');
        },
        showErrorAlert: false,
    });

    const logoutApi = useApi(authService.logout, {
        onSuccess: () => {
            setUser(null);
            setIsAuthenticated(false);
        },
    });

    const getCurrentUserApi = useApi(authService.getCurrentUser, {
        onSuccess: (userData) => {
            setUser(userData);
            setIsAuthenticated(true);
        },
        onError: () => {
            setIsAuthenticated(false);
        },
    });

    const login = useCallback(async (credentials: LoginRequest) => {
        return await loginApi.execute(credentials);
    }, [loginApi]);

    const logout = useCallback(async () => {
        return await logoutApi.execute();
    }, [logoutApi]);

    const getCurrentUser = useCallback(async () => {
        return await getCurrentUserApi.execute();
    }, [getCurrentUserApi]);

    useEffect(() => {
        const init = async () => {
            if (authService.isAuthenticated() && !user) {
                try {
                    await getCurrentUser();
                } catch (e) {
                    await logout();
                }
            }
            setInitialized(true);
        };
        init();
    }, [user, getCurrentUser, logout]);

    const value = useMemo<AuthContextValue>(() => ({
        user,
        isAuthenticated,
        loading: !initialized || loginApi.loading || logoutApi.loading || getCurrentUserApi.loading,
        error: loginApi.error || logoutApi.error || getCurrentUserApi.error,
        login,
        logout,
        getCurrentUser,
    }), [user, isAuthenticated, initialized, loginApi.loading, logoutApi.loading, getCurrentUserApi.loading, loginApi.error, logoutApi.error, getCurrentUserApi.error, login, logout, getCurrentUser]);

    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );
};

export default AuthProvider;



