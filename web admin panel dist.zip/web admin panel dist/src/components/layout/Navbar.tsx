import React, { useEffect, useState } from 'react';
import { BellIcon, SearchIcon, UserIcon, LogOutIcon, ChevronDownIcon, PhoneCallIcon, UserPlusIcon, CheckIcon, MessageSquareIcon, BellOffIcon } from 'lucide-react';
import NotificationCenter from '../ui/NotificationCenter';
import SearchInput from '../ui/SearchInput';
import { useAuth } from '../../hooks/useAuth';
interface NavbarProps {
  toggleSidebar: () => void;
}
const Navbar: React.FC<NavbarProps> = ({
  toggleSidebar
}) => {
  const { logout, user } = useAuth();
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [globalSearch, setGlobalSearch] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [showSearchResults, setShowSearchResults] = useState(false);
  // Initialize with some notifications
  useEffect(() => {
    const initialNotifications = [{
      id: '1',
      title: 'New call logged',
      message: 'Jane Smith called Alex Turner',
      time: '5 minutes ago',
      read: false,
      type: 'info',
      icon: <PhoneCallIcon size={16} className="text-blue-600" />
    }, {
      id: '2',
      title: 'Students assigned',
      message: '10 students assigned to Robert Johnson',
      time: '1 hour ago',
      read: false,
      type: 'success',
      icon: <UserPlusIcon size={16} className="text-green-600" />
    }, {
      id: '3',
      title: 'Call reminder',
      message: 'Follow-up call with William Scott is due',
      time: '2 hours ago',
      read: true,
      type: 'warning',
      icon: <BellIcon size={16} className="text-yellow-600" />
    }];
    setNotifications(initialNotifications);
    // Simulate receiving new notifications periodically
    const interval = setInterval(() => {
      addRandomNotification();
    }, 45000); // Every 45 seconds
    return () => clearInterval(interval);
  }, []);
  // Simulate search results
  useEffect(() => {
    if (globalSearch.length > 2) {
      // Mock search results
      const results = [{
        type: 'student',
        name: 'Alex Turner',
        id: 1,
        details: '123-456-7890'
      }, {
        type: 'student',
        name: 'Emma Watson',
        id: 2,
        details: '234-567-8901'
      }, {
        type: 'user',
        name: 'Jane Smith',
        id: 2,
        details: 'Manager'
      }, {
        type: 'call',
        name: 'Call with James Cameron',
        id: 3,
        details: 'Connected - 06/15/2023'
      }].filter(item => item.name.toLowerCase().includes(globalSearch.toLowerCase()) || item.details.toLowerCase().includes(globalSearch.toLowerCase()));
      setSearchResults(results);
      setShowSearchResults(results.length > 0);
    } else {
      setShowSearchResults(false);
    }
  }, [globalSearch]);
  const addRandomNotification = () => {
    const types = ['info', 'success', 'warning', 'error'];
    const type = types[Math.floor(Math.random() * types.length)] as 'info' | 'success' | 'warning' | 'error';
    const icons = {
      info: <MessageSquareIcon size={16} className="text-blue-600" />,
      success: <CheckIcon size={16} className="text-green-600" />,
      warning: <BellIcon size={16} className="text-yellow-600" />,
      error: <BellOffIcon size={16} className="text-red-600" />
    };
    const titles = {
      info: 'New message',
      success: 'Task completed',
      warning: 'Reminder',
      error: 'Missed call'
    };
    const messages = {
      info: 'New message from system admin',
      success: 'Student assignment completed',
      warning: 'Call reminder scheduled for today',
      error: 'Missed call with student'
    };
    const newNotification = {
      id: Date.now().toString(),
      title: titles[type],
      message: messages[type],
      time: 'Just now',
      read: false,
      type,
      icon: icons[type]
    };
    setNotifications(prev => [newNotification, ...prev]);
  };
  const handleMarkAsRead = (id: string) => {
    setNotifications(notifications.map(notification => notification.id === id ? {
      ...notification,
      read: true
    } : notification));
  };
  const handleMarkAllAsRead = () => {
    setNotifications(notifications.map(notification => ({
      ...notification,
      read: true
    })));
  };
  const handleClearNotification = (id: string) => {
    setNotifications(notifications.filter(notification => notification.id !== id));
  };
  const handleGlobalSearch = (query: string) => {
    setGlobalSearch(query);
  };
  const handleSearchResultClick = (result: any) => {
    // In a real app, this would navigate to the appropriate page
    console.log(`Navigate to ${result.type} details for ${result.name}`);
    setShowSearchResults(false);
  };
  const getSearchResultIcon = (type: string) => {
    switch (type) {
      case 'student':
        return <UserIcon size={16} className="text-blue-600" />;
      case 'user':
        return <UserIcon size={16} className="text-green-600" />;
      case 'call':
        return <PhoneCallIcon size={16} className="text-purple-600" />;
      default:
        return <SearchIcon size={16} className="text-gray-600" />;
    }
  };
  return <header className="bg-white shadow-sm z-10">
    <div className="flex items-center justify-end h-16 px-4 md:px-6">
      {/* Right: Notifications & Profile */}
      <div className="flex items-center space-x-4">
        {/* Notifications */}
        <NotificationCenter notifications={notifications} onMarkAsRead={handleMarkAsRead} onMarkAllAsRead={handleMarkAllAsRead} onClear={handleClearNotification} />
        {/* Profile */}
        <div className="relative">
          <button className="flex items-center space-x-2 focus:outline-none" onClick={() => setShowProfileMenu(!showProfileMenu)}>
            {/* <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white">
              <UserIcon size={18} />
            </div> */}
            <span className="hidden md:inline-block text-sm font-medium">
              {user?.name || 'Admin User'}
            </span>
            <ChevronDownIcon size={16} className="text-gray-500" />
          </button>
          {showProfileMenu && <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20 border border-gray-200">
            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center">
              <UserIcon size={16} className="mr-2 text-gray-400" />
              Your Profile
            </a>
            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center">
              <BellIcon size={16} className="mr-2 text-gray-400" />
              Notification Settings
            </a>
            <div className="border-t border-gray-200 my-1"></div>
            <button onClick={logout} className="flex items-center w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-50">
              <LogOutIcon size={16} className="mr-2" />
              Logout
            </button>
          </div>}
        </div>
      </div>
    </div>
  </header>;
};
export default Navbar;