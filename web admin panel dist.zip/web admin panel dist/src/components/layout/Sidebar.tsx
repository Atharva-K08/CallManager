import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { HomeIcon, UsersIcon, GraduationCapIcon, PhoneCallIcon, SettingsIcon, XIcon, MenuIcon, ClipboardListIcon, ClockIcon } from 'lucide-react';
interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}
const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  toggleSidebar
}) => {
  const location = useLocation();
  const navItems = [{
    path: '/dashboard',
    name: 'Dashboard',
    icon: <HomeIcon size={20} />
  }, {
    path: '/users',
    name: 'User Management',
    icon: <UsersIcon size={20} />
  }, {
    path: '/leads',
    name: 'Leads Management',
    icon: <GraduationCapIcon size={20} />
  }, {
    path: '/tasks',
    name: 'Tasks',
    icon: <ClipboardListIcon size={20} />
  }, {
    path: '/follow-ups',
    name: 'Follow-ups',
    icon: <ClockIcon size={20} />
  }, {
    path: '/calls',
    name: 'Call Tracking',
    icon: <PhoneCallIcon size={20} />
  },
  // {
  //   path: '/reports',
  //   name: 'Reports',
  //   icon: <BarChartIcon size={20} />
  // },
  {
    path: '/settings',
    name: 'Settings',
    icon: <SettingsIcon size={20} />
  }];

  // Helper function to check if a nav item is active
  const isActive = (itemPath: string) => {
    // Special handling for /calls to match both /calls and /calls/:userId
    if (itemPath === '/calls') {
      return location.pathname === '/calls' || location.pathname.startsWith('/calls/');
    }
    return location.pathname === itemPath || location.pathname.startsWith(`${itemPath}/`);
  };
  return <>
    {/* Mobile sidebar backdrop */}
    {isOpen && <div className="fixed inset-0 z-20 bg-black bg-opacity-50 lg:hidden" onClick={toggleSidebar} />}
    {/* Sidebar */}
    <aside className={`fixed inset-y-0 left-0 z-30 w-64 bg-blue-700 text-white transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-auto lg:z-auto ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex items-center justify-between h-16 px-6 bg-blue-800">
        <div className="flex items-center">
          <PhoneCallIcon className="h-8 w-8 mr-2" />
          <span className="text-xl font-semibold">CallManager</span>
        </div>
        <button onClick={toggleSidebar} className="lg:hidden text-white">
          <XIcon size={24} />
        </button>
      </div>
      <nav className="mt-6 px-4">
        <ul className="space-y-1">
          {navItems.map(item => <li key={item.path}>
            <Link to={item.path} className={`flex items-center px-4 py-3 rounded-md hover:bg-blue-600 transition-colors ${isActive(item.path) ? 'bg-blue-600' : ''}`}>
              <span className="mr-3">{item.icon}</span>
              <span>{item.name}</span>
            </Link>
          </li>)}
        </ul>
      </nav>
    </aside>
    {/* Mobile toggle button */}
    <button className="fixed bottom-4 right-4 z-10 p-3 rounded-full bg-blue-600 text-white shadow-lg lg:hidden" onClick={toggleSidebar}>
      <MenuIcon size={24} />
    </button>
  </>;
};
export default Sidebar;