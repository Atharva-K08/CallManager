import React, { useEffect, useMemo, useState } from 'react';
import Drawer from '../ui/Drawer';
import FormField from '../ui/FormField';
import FormInput from '../ui/FormInput';
import Button from '../ui/Button';
import { useUsers } from '../../hooks/useUsers';
import { SearchIcon, UserIcon } from 'lucide-react';

interface LeadLike { _id: string; firstName?: string; lastName?: string; phoneNumber?: string; }

interface HandoverDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  selectedLeads: LeadLike[];
  onSubmit: (payload: { title: string; assignedTo: string; dueAt?: string; description?: string; leadIds: string[]; assignedToName?: string; assignedToEmail?: string; }) => Promise<void> | void;
  excludeUserId?: string;
}

const HandoverDrawer: React.FC<HandoverDrawerProps> = ({ isOpen, onClose, selectedLeads, onSubmit, excludeUserId }) => {

  const [title, setTitle] = useState('');
  const [assignedTo, setAssignedTo] = useState('');
  const [assignedToName, setAssignedToName] = useState('');
  const [assignedToEmail, setAssignedToEmail] = useState('');
  const [dueAt, setDueAt] = useState<string>('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [isCallerDrawerOpen, setIsCallerDrawerOpen] = useState(false);

  const leadIds = useMemo(() => selectedLeads.map(l => l._id), [selectedLeads]);

  // Fetch users only when opening the Select Caller drawer (to avoid duplicate/infinite fetches)

  const handleAssignFromUser = (u: any) => {
    if (!u) return;
    const id = String(u.id ?? u._id);
    setAssignedTo(id);
    setAssignedToName((u as any).name || (u as any).full_name || '');
    setAssignedToEmail((u as any).email || '');
    setIsCallerDrawerOpen(false);
  };

  const canSubmit = title.trim().length > 0 && assignedTo && leadIds.length > 0 && !submitting;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    try {
      setSubmitting(true);
      await onSubmit({ title: title.trim(), assignedTo, dueAt: dueAt || undefined, description: description || undefined, leadIds, assignedToName, assignedToEmail });
      setSubmitting(false);
      onClose();
      // reset
      setTitle(''); setAssignedTo(''); setAssignedToName(''); setAssignedToEmail(''); setDueAt(''); setDescription('');
    } catch (err) {
      setSubmitting(false);
    }
  };

  return (
    <Drawer isOpen={isOpen} onClose={onClose} title="Handover Leads">
      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="space-y-4">
          <FormField label="Task Title" htmlFor="handover-title" required>
            <FormInput id="handover-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g., Follow up leads batch" className="h-11" />
          </FormField>
          <FormField label="Assign To" htmlFor="handover-assignee" required>
            <div
              role="button"
              tabIndex={0}
              onClick={() => setIsCallerDrawerOpen(true)}
              onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') setIsCallerDrawerOpen(true); }}
              className={`w-full flex items-center justify-between gap-3 rounded-lg border ${assignedTo ? 'border-gray-200' : 'border-dashed border-gray-300'} bg-white px-3 py-2 shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-primary/40`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className={`h-10 w-10 rounded-full ${assignedTo ? 'bg-blue-100 text-blue-700' : 'bg-gray-200 text-gray-500'} flex items-center justify-center text-sm font-semibold`}>
                  {assignedToName
                    ? String(assignedToName).split(' ').map((p) => p[0]).filter(Boolean).slice(0, 2).join('').toUpperCase()
                    : '?'}
                </div>
                <div className="flex-1 min-w-0">
                  {assignedToName ? (
                    <>
                      <div className="truncate text-sm font-medium text-gray-900" title={assignedToName}>{assignedToName}</div>
                      <div className="truncate text-xs text-gray-500" title={assignedToEmail || ''}>{assignedToEmail || '—'}</div>
                    </>
                  ) : (
                    <div className="text-sm text-gray-500">Select a caller</div>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {assignedTo && (
                  <Button
                    variant="outline"
                    size="sm"
                    type="button"
                    onClick={(e) => { e.stopPropagation(); setAssignedTo(''); setAssignedToName(''); setAssignedToEmail(''); }}
                  >
                    Clear
                  </Button>
                )}
                <Button variant='outline' size='sm' type='button' onClick={(e) => { e.stopPropagation(); setIsCallerDrawerOpen(true); }}>{assignedTo ? 'Change' : 'Select'}</Button>
              </div>
            </div>
          </FormField>
        </div>

        <div className="space-y-4">
          <FormField label="Due Date" htmlFor="handover-dueAt">
            <input id="handover-dueAt" type="datetime-local" value={dueAt} onChange={(e) => setDueAt(e.target.value)} className="w-full h-11 border border-gray-300 rounded-md px-3 text-sm" />
          </FormField>
          {/* <FormField label="Description" htmlFor="handover-desc">
            <FormInput id="handover-desc" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Optional description" />
          </FormField> */}
        </div>

        <div>
          <div className="text-sm font-medium text-gray-700 mb-2">Selected Leads ({leadIds.length})</div>
          <div className="max-h-40 overflow-auto border border-gray-200 rounded-md p-2 bg-white">
            {selectedLeads.length === 0 ? (
              <div className="text-sm text-gray-500">No leads selected.</div>
            ) : (
              <ul className="divide-y divide-gray-100">
                {selectedLeads.map(l => {
                  const fullName = l.firstName && l.lastName ? `${l.firstName} ${l.lastName}` : l.firstName || l.lastName || 'Unknown';
                  return (
                    <li key={l._id} className="py-2 text-sm text-gray-800 flex items-center justify-between">
                      <span className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center"><UserIcon size={12} /></span>
                        {fullName}{l.phoneNumber ? ` · ${l.phoneNumber}` : ''}
                      </span>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>

        <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
          <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="primary" disabled={!canSubmit || submitting}>{submitting ? 'Submitting...' : 'Handover'}</Button>
        </div>
      </form>
      {/* Caller selection drawer for consistency */}
      <SelectCallerDrawer
        isOpen={isCallerDrawerOpen}
        onClose={() => setIsCallerDrawerOpen(false)}
        onSelect={handleAssignFromUser}
        selectedId={assignedTo}
        excludeUserId={excludeUserId}
      />
    </Drawer>
  );
};

export default HandoverDrawer;



// Local component: Select Caller Drawer (mirrors TasksManagement)
const SelectCallerDrawer: React.FC<{ isOpen: boolean; onClose: () => void; onSelect: (u: any) => void; selectedId?: string; excludeUserId?: string }> = ({ isOpen, onClose, onSelect, selectedId, excludeUserId }) => {
  const { users, usersLoading, getUsers } = useUsers();
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (isOpen) {
      getUsers({ role: 'caller', isActive: true, sortBy: 'createdAt:desc' } as any);
    }
  }, [isOpen]);

  useEffect(() => {
    const h = setTimeout(() => {
      if (!isOpen) return;
      const q = search.trim();
      if (q.length === 0) return;
      getUsers({ role: 'caller', isActive: true, name: q } as any);
    }, 400);
    return () => clearTimeout(h);
  }, [search, isOpen]);

  return (
    <Drawer isOpen={isOpen} onClose={onClose} title="Select Caller">
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Search Callers</label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon size={18} className="text-gray-400" />
            </div>
            <input
              className="block w-full pl-10 pr-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400"
              placeholder="Search by name or email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
        <div className="border rounded-md divide-y">
          {usersLoading ? (
            Array.from({ length: 6 }).map((_, idx) => (
              <div key={idx} className="p-3 flex items-center justify-between">
                <div className="flex items-center gap-3 w-full">
                  <div className="h-9 w-9 rounded-full bg-gray-200 animate-pulse" />
                  <div className="flex-1">
                    <div className="h-3 w-40 bg-gray-200 rounded mb-2 animate-pulse" />
                    <div className="h-3 w-56 bg-gray-200 rounded animate-pulse" />
                  </div>
                </div>
                <div className="h-8 w-16 bg-gray-200 rounded-md animate-pulse ml-3" />
              </div>
            ))
          ) : (
            (users || []).filter((u: any) => String(u?._id ?? u?.id) !== String(excludeUserId || '')).map((u: any) => (
              <div
                key={u?._id}
                className={`p-3 flex items-center justify-between hover:bg-gray-50 cursor-pointer ${selectedId && u?._id === selectedId ? 'bg-blue-50' : ''}`}
                onClick={() => onSelect(u)}
              >
                <div className="flex items-center gap-3">
                  <div className="h-9 w-9 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-semibold">
                    {(u?.name || ' ')?.split(' ').map((p: string) => p[0]).filter(Boolean).slice(0, 2).join('').toUpperCase()}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-900">{u?.name || '—'}</div>
                    <div className="text-xs text-gray-500">{u?.email || '—'}</div>
                  </div>
                </div>
                {selectedId && u?._id === selectedId ? (
                  <span className="text-xs font-medium text-primary">Selected</span>
                ) : (
                  <Button variant="outline" size="sm" type="button" onClick={() => onSelect(u)}>Select</Button>
                )}
              </div>
            ))
          )}
          {!usersLoading && (!users || users.length === 0) && (
            <div className="p-4 text-sm text-gray-500">No callers found</div>
          )}
        </div>
      </div>
    </Drawer>
  );
};