import React, { useEffect } from 'react';
import { XIcon } from 'lucide-react';
interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  position?: 'right' | 'left';
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  footer?: React.ReactNode;
}
const Drawer: React.FC<DrawerProps> = ({
  isOpen,
  onClose,
  title,
  children,
  position = 'right',
  size = 'full',
  footer
}) => {
  // Close drawer on escape key press
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);
  // Prevent scrolling when drawer is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);
  if (!isOpen) return null;
  
  // Size classes - 'full' stops exactly at sidebar (w-64 = 16rem)
  // Sidebar is w-64 (16rem), so drawer should be calc(100% - 16rem) or calc(100vw - 16rem)
  // On mobile (below lg), drawer takes full width since sidebar is hidden
  const sizeClasses = {
    sm: 'w-80',
    md: 'w-96',
    lg: 'w-[32rem]',
    xl: 'w-[48rem]',
    full: 'w-full lg:w-[calc(100vw-16rem)]' // Full width on mobile, stops at sidebar on desktop
  } as const;
  
  const positionClasses = {
    right: 'right-0',
    left: 'left-0'
  };
  const transformClasses = {
    right: isOpen ? 'translate-x-0' : 'translate-x-full',
    left: isOpen ? 'translate-x-0' : '-translate-x-full'
  };
  
  return <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop - covers full screen on mobile, starts after sidebar on desktop */}
      <div 
        className={`fixed inset-0 lg:left-64 bg-gray-500 bg-opacity-75 transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0'} backdrop-blur-sm`} 
        onClick={onClose}
      ></div>
      {/* Drawer panel */}
      <div className={`fixed inset-y-0 ${positionClasses[position]} flex max-w-full`}>
        <div className={`${sizeClasses[size]} transform transition ease-in-out duration-300 ${transformClasses[position]} h-full`}>
          <div className="flex flex-col h-full bg-gray-50 shadow-xl">
            {/* Header */}
            <div className="px-6 py-6 flex items-center justify-between">
              <h1 className="text-2xl font-semibold text-gray-900">
                {title}
              </h1>
              <button className="p-1 text-gray-400 rounded-full hover:bg-gray-100 hover:text-gray-500 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500" onClick={onClose}>
                <XIcon size={20} />
              </button>
            </div>
            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
              {children}
            </div>
            {/* Footer */}
            {footer && <div className="px-6 py-4">{footer}</div>}
          </div>
        </div>
      </div>
    </div>;
};
export default Drawer;