import React from 'react';
import { LucideIcon } from 'lucide-react';

interface FormInputProps {
    type?: 'text' | 'email' | 'password' | 'tel' | 'url' | 'number';
    id?: string;
    name?: string;
    value?: string | number;
    onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onBlur?: (e: React.FocusEvent<HTMLInputElement>) => void;
    placeholder?: string;
    disabled?: boolean;
    required?: boolean;
    error?: string;
    icon?: LucideIcon;
    className?: string;
    autoComplete?: string;
}

const FormInput: React.FC<FormInputProps> = ({
    type = 'text',
    id,
    name,
    value,
    onChange,
    onBlur,
    placeholder,
    disabled = false,
    required = false,
    error,
    icon: Icon,
    className = '',
    autoComplete,
}) => {
    const baseClasses = "block w-full px-3 py-2.5 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 disabled:bg-gray-50 disabled:text-gray-500 disabled:cursor-not-allowed";
    const errorClasses = error ? "border-red-300 focus:ring-red-500 focus:border-red-500" : "";
    const iconClasses = Icon ? "pl-10" : "";

    const inputClasses = `${baseClasses} ${errorClasses} ${iconClasses} ${className}`;

    return (
        <div className="relative">
            {Icon && (
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Icon size={16} className="text-gray-400" />
                </div>
            )}
            <input
                type={type}
                id={id}
                name={name}
                value={value}
                onChange={onChange}
                onBlur={onBlur}
                placeholder={placeholder}
                disabled={disabled}
                required={required}
                autoComplete={autoComplete}
                className={inputClasses}
            />
            {error && (
                <p className="mt-1 text-sm text-red-600">{error}</p>
            )}
        </div>
    );
};

export default FormInput;

