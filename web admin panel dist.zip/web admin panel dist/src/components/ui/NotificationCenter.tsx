import React, { useEffect, useState, createElement } from 'react';
import { BellIcon, CheckIcon, XIcon } from 'lucide-react';
import Badge from './Badge';
interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'info' | 'success' | 'warning' | 'error';
  icon?: React.ReactNode;
}
interface NotificationCenterProps {
  notifications: Notification[];
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
  onClear: (id: string) => void;
}
const NotificationCenter: React.FC<NotificationCenterProps> = ({
  notifications,
  onMarkAsRead,
  onMarkAllAsRead,
  onClear
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [animateNotification, setAnimateNotification] = useState(false);
  const [notificationCount, setNotificationCount] = useState(0);
  // Count unread notifications
  useEffect(() => {
    const unreadCount = notifications.filter(n => !n.read).length;
    setNotificationCount(unreadCount);
    // Animate bell when new notification arrives
    if (unreadCount > 0) {
      setAnimateNotification(true);
      const timer = setTimeout(() => setAnimateNotification(false), 1000);
      return () => clearTimeout(timer);
    }
  }, [notifications]);
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (isOpen && !target.closest('[data-notification-center]')) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);
  const toggleNotifications = () => {
    setIsOpen(!isOpen);
  };
  const handleMarkAsRead = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onMarkAsRead(id);
  };
  const handleClear = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onClear(id);
  };
  const getNotificationBgColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'bg-green-100';
      case 'warning':
        return 'bg-yellow-100';
      case 'error':
        return 'bg-red-100';
      default:
        return 'bg-blue-100';
    }
  };
  const getNotificationTextColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'text-green-600';
      case 'warning':
        return 'text-yellow-600';
      case 'error':
        return 'text-red-600';
      default:
        return 'text-blue-600';
    }
  };
  return <div className="relative" data-notification-center>
      <button className="p-2 rounded-full hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 relative" onClick={toggleNotifications}>
        <BellIcon size={20} className={`text-gray-600 ${animateNotification ? 'animate-wiggle' : ''}`} />
        {notificationCount > 0 && <span className="absolute top-0 right-0 flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-red-500 rounded-full">
            {notificationCount > 9 ? '9+' : notificationCount}
          </span>}
      </button>
      {isOpen && <div className="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg py-1 z-20 border border-gray-200">
          <div className="px-4 py-2 border-b border-gray-200 flex justify-between items-center">
            <h3 className="text-sm font-medium text-gray-700">Notifications</h3>
            {notificationCount > 0 && <button onClick={onMarkAllAsRead} className="text-xs text-blue-600 hover:text-blue-800">
                Mark all as read
              </button>}
          </div>
          <div className="max-h-60 overflow-y-auto">
            {notifications.length === 0 ? <div className="px-4 py-6 text-center text-gray-500">
                <p>No notifications</p>
              </div> : notifications.map(notification => <div key={notification.id} className={`px-4 py-3 hover:bg-gray-50 transition-colors ${!notification.read ? 'bg-blue-50' : ''}`}>
                  <div className="flex items-start">
                    <div className={`mr-3 ${getNotificationBgColor(notification.type)} rounded-full p-2`}>
                      {notification.icon || <BellIcon size={16} className={getNotificationTextColor(notification.type)} />}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <p className="text-sm font-medium text-gray-900">
                          {notification.title}
                        </p>
                        <div className="flex space-x-1">
                          {!notification.read && <button onClick={e => handleMarkAsRead(notification.id, e)} className="p-1 text-gray-400 hover:text-gray-600" title="Mark as read">
                              <CheckIcon size={12} />
                            </button>}
                          <button onClick={e => handleClear(notification.id, e)} className="p-1 text-gray-400 hover:text-gray-600" title="Remove">
                            <XIcon size={12} />
                          </button>
                        </div>
                      </div>
                      <p className="text-xs text-gray-500">
                        {notification.message}
                      </p>
                      <p className="text-xs text-gray-400 mt-1">
                        {notification.time}
                      </p>
                    </div>
                  </div>
                </div>)}
          </div>
          <div className="px-4 py-2 text-center border-t border-gray-200">
            <a href="#" className="text-xs text-blue-600 hover:underline">
              View all notifications
            </a>
          </div>
        </div>}
    </div>;
};
export default NotificationCenter;
// Add this to index.css
const style = document.createElement('style');
style.textContent = `
@keyframes wiggle {
  0% { transform: rotate(0deg); }
  25% { transform: rotate(10deg); }
  50% { transform: rotate(0deg); }
  75% { transform: rotate(-10deg); }
  100% { transform: rotate(0deg); }
}
.animate-wiggle {
  animation: wiggle 0.5s ease-in-out;
}
`;
document.head.appendChild(style);