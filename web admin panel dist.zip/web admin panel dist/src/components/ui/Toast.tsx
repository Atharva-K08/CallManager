import React from 'react';
import { X, CheckCircle, AlertCircle, AlertTriangle, Info } from 'lucide-react';

interface ToastProps {
    id: string;
    title: string;
    description?: string;
    type: 'success' | 'error' | 'warning' | 'info';
    duration?: number;
    onClose?: () => void;
}

const Toast: React.FC<ToastProps> = ({
    title,
    description,
    type,
    duration = 5000,
    onClose
}) => {
    const [isVisible, setIsVisible] = React.useState(true);

    React.useEffect(() => {
        const timer = setTimeout(() => {
            setIsVisible(false);
            setTimeout(() => onClose?.(), 300); // Allow fade out animation
        }, duration);

        return () => clearTimeout(timer);
    }, [duration, onClose]);

    const getIcon = () => {
        switch (type) {
            case 'success':
                return <CheckCircle className="h-5 w-5 text-green-500" />;
            case 'error':
                return <AlertCircle className="h-5 w-5 text-red-500" />;
            case 'warning':
                return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
            case 'info':
                return <Info className="h-5 w-5 text-blue-500" />;
            default:
                return <Info className="h-5 w-5 text-blue-500" />;
        }
    };

    const getBackgroundColor = () => {
        switch (type) {
            case 'success':
                return 'bg-green-50 border-green-200';
            case 'error':
                return 'bg-red-50 border-red-200';
            case 'warning':
                return 'bg-yellow-50 border-yellow-200';
            case 'info':
                return 'bg-blue-50 border-blue-200';
            default:
                return 'bg-blue-50 border-blue-200';
        }
    };

    const getTextColor = () => {
        switch (type) {
            case 'success':
                return 'text-green-900';
            case 'error':
                return 'text-red-900';
            case 'warning':
                return 'text-yellow-900';
            case 'info':
                return 'text-blue-900';
            default:
                return 'text-blue-900';
        }
    };

    if (!isVisible) return null;

    return (
        <div
            className={`
        fixed top-4 right-4 z-[100] 
        max-w-md w-full 
        rounded-lg border shadow-lg 
        transition-all duration-300 ease-in-out
        transform translate-x-0 opacity-100
        ${getBackgroundColor()}
        ${isVisible ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}
      `}
            style={{
                animation: 'slideInFromRight 0.3s ease-out',
            }}
        >
            <div className="p-4">
                <div className="flex items-start space-x-3">
                    {/* Icon */}
                    <div className="flex-shrink-0 mt-0.5">
                        {getIcon()}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                            <div className="flex-1">
                                <h4 className={`text-sm font-semibold ${getTextColor()}`}>
                                    {title}
                                </h4>
                                {description && (
                                    <p className={`mt-1 text-sm ${getTextColor()} opacity-90`}>
                                        {description}
                                    </p>
                                )}
                            </div>

                            {/* Close button */}
                            <button
                                onClick={() => {
                                    setIsVisible(false);
                                    setTimeout(() => onClose?.(), 300);
                                }}
                                className={`
                  flex-shrink-0 ml-2 p-1 rounded-md 
                  hover:bg-black hover:bg-opacity-10 
                  transition-colors duration-200
                  ${getTextColor()} opacity-70 hover:opacity-100
                `}
                            >
                                <X className="h-4 w-4" />
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Toast;
