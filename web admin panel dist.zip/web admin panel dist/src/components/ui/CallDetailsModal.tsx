import React, { useEffect, useState } from 'react';
import { 
  UserIcon, 
  ClockIcon, 
  CalendarIcon, 
  PhoneIcon, 
  FileTextIcon, 
  CheckCircleIcon, 
  XCircleIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  SmartphoneIcon,
  GlobeIcon,
  MailIcon,
  InfoIcon
} from 'lucide-react';
import Modal from './Modal';
import Badge from './Badge';
import Drawer from './Drawer';
import Button from './Button';

interface CallDetails {
  id: number | string;
  userName: string;
  userEmail?: string;
  studentName: string;
  phone: string;
  status: string;
  originalStatus?: string;
  duration: string;
  durationSeconds?: number;
  dateTime: string;
  initiatedAt?: string;
  connectedAt?: string;
  endedAt?: string;
  isOutgoing?: boolean;
  source?: string;
  deviceInfo?: string;
  notes?: string;
  recordingUrl?: string;
  leadId?: string;
  leadName?: string;
  leadPhone?: string;
}

interface CallDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  call: CallDetails | null;
  onAddNote: (id: number | string, note: string) => void;
}

const CallDetailsModal: React.FC<CallDetailsModalProps> = ({
  isOpen,
  onClose,
  call,
  onAddNote
}) => {
  const [note, setNote] = useState('');
  const [isDrawerView, setIsDrawerView] = useState(window.innerWidth >= 768);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (call) {
      setNote(call.notes || '');
    }
  }, [call]);

  useEffect(() => {
    const handleResize = () => {
      setIsDrawerView(window.innerWidth >= 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (call) {
      setIsSubmitting(true);
      setTimeout(() => {
        onAddNote(call.id, note);
        setIsSubmitting(false);
      }, 500);
    }
  };

  const getCallIcon = (isOutgoing: boolean | undefined, durationSeconds: number | undefined) => {
    const hasDuration = durationSeconds && durationSeconds > 0;
    const isOutgoingCall = isOutgoing !== undefined ? isOutgoing : true;
    
    if (hasDuration) {
      // Call was successful (has duration)
      if (isOutgoingCall) {
        return <ArrowUpIcon size={24} className="text-blue-600" />;
      } else {
        return <ArrowDownIcon size={24} className="text-green-600" />;
      }
    } else {
      // Call didn't connect (no duration)
      if (isOutgoingCall) {
        return <ArrowUpIcon size={24} className="text-gray-400" />;
      } else {
        return <ArrowDownIcon size={24} className="text-gray-400" />;
      }
    }
  };

  if (!call) return null;

  const content = (
    <div className="space-y-6 pb-6">
      {/* Header Section */}
      <div className="bg-gradient-to-br from-blue-50 via-blue-50 to-indigo-50 p-6 rounded-xl border border-blue-100">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start space-x-4 flex-1">
            <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-md border-2 border-blue-200">
              {getCallIcon(call.isOutgoing, call.durationSeconds)}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-xl font-semibold text-gray-900 mb-1 truncate">
                {call.studentName}
              </h3>
              <div className="flex items-center space-x-2 mt-2">
                <div className="flex items-center text-sm text-gray-600">
                  <PhoneIcon size={14} className="mr-1.5" />
                  <span className="font-mono">{call.phone}</span>
                </div>
              </div>
            </div>
          </div>
          <div className="ml-4 flex items-center">
            {call.isOutgoing !== undefined && (
              <Badge 
                variant={call.isOutgoing ? 'primary' : 'success'} 
                size="sm"
              >
                {call.isOutgoing ? (
                  <>
                    <ArrowUpIcon size={12} className="mr-1" />
                    Outgoing
                  </>
                ) : (
                  <>
                    <ArrowDownIcon size={12} className="mr-1" />
                    Incoming
                  </>
                )}
              </Badge>
            )}
          </div>
        </div>

        {/* Quick Info Grid */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          <div className="bg-white rounded-lg p-3 border border-blue-100">
            <div className="flex items-center text-xs text-gray-500 mb-1">
              <ClockIcon size={14} className="mr-1.5" />
              Duration
            </div>
            <div className="text-sm font-semibold text-gray-900">
              {call.duration}
            </div>
          </div>
          <div className="bg-white rounded-lg p-3 border border-blue-100">
            <div className="flex items-center text-xs text-gray-500 mb-1">
              <CalendarIcon size={14} className="mr-1.5" />
              Call Time
            </div>
            <div className="text-sm font-semibold text-gray-900">
              {call.initiatedAt || call.dateTime}
            </div>
          </div>
        </div>
      </div>

      {/* Caller Information */}
      <div className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm">
        <h4 className="text-sm font-semibold text-gray-900 mb-4 flex items-center">
          <UserIcon size={16} className="mr-2 text-blue-500" />
          Caller Information
        </h4>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Name</span>
            <span className="text-sm font-medium text-gray-900">{call.userName}</span>
          </div>
          {call.userEmail && (
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 flex items-center">
                <MailIcon size={14} className="mr-1.5" />
                Email
              </span>
              <span className="text-sm font-medium text-gray-900">{call.userEmail}</span>
            </div>
          )}
        </div>
      </div>

      {/* Contact Information */}
      {(call.leadName || call.leadPhone) && (
        <div className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm">
          <h4 className="text-sm font-semibold text-gray-900 mb-4 flex items-center">
            <UserIcon size={16} className="mr-2 text-green-500" />
            Contact Information
          </h4>
          <div className="space-y-3">
            {call.leadName && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Lead Name</span>
                <span className="text-sm font-medium text-gray-900">{call.leadName}</span>
              </div>
            )}
            {call.leadPhone && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 flex items-center">
                  <PhoneIcon size={14} className="mr-1.5" />
                  Phone
                </span>
                <span className="text-sm font-medium text-gray-900 font-mono">{call.leadPhone}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Call Timeline */}
      <div className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm">
        <h4 className="text-sm font-semibold text-gray-900 mb-4 flex items-center">
          <ClockIcon size={16} className="mr-2 text-purple-500" />
          Call Timeline
        </h4>
        <div className="space-y-3">
          <div className="flex items-center justify-between py-2 border-b border-gray-100">
            <span className="text-sm text-gray-600">Initiated</span>
            <span className="text-sm font-medium text-gray-900">{call.initiatedAt || call.dateTime}</span>
          </div>
          {call.connectedAt && call.connectedAt !== 'N/A' && (
            <div className="flex items-center justify-between py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600 flex items-center">
                <CheckCircleIcon size={14} className="mr-1.5 text-green-500" />
                Connected
              </span>
              <span className="text-sm font-medium text-gray-900">{call.connectedAt}</span>
            </div>
          )}
          {call.endedAt && call.endedAt !== 'N/A' && (
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-gray-600 flex items-center">
                <XCircleIcon size={14} className="mr-1.5 text-gray-500" />
                Ended
              </span>
              <span className="text-sm font-medium text-gray-900">{call.endedAt}</span>
            </div>
          )}
        </div>
      </div>

      {/* Technical Details */}
      {(call.source || call.deviceInfo) && (
        <div className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm">
          <h4 className="text-sm font-semibold text-gray-900 mb-4 flex items-center">
            <InfoIcon size={16} className="mr-2 text-gray-500" />
            Technical Details
          </h4>
          <div className="space-y-3">
            {call.source && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 flex items-center">
                  <GlobeIcon size={14} className="mr-1.5" />
                  Source
                </span>
                <Badge variant="gray" size="sm">{call.source}</Badge>
              </div>
            )}
            {call.deviceInfo && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 flex items-center">
                  <SmartphoneIcon size={14} className="mr-1.5" />
                  Device
                </span>
                <span className="text-sm font-medium text-gray-900">{call.deviceInfo}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Call Recording */}
      {call.recordingUrl && (
        <div className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm">
          <h4 className="text-sm font-semibold text-gray-900 mb-4 flex items-center">
            <FileTextIcon size={16} className="mr-2 text-blue-500" />
            Call Recording
          </h4>
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <audio controls className="w-full">
              <source src={call.recordingUrl} type="audio/mpeg" />
              Your browser does not support the audio element.
            </audio>
          </div>
        </div>
      )}

      {/* Call Notes */}
      {/* Hidden for now */}
      {/* <div className="bg-white border border-gray-200 rounded-lg p-5 shadow-sm">
        <h4 className="text-sm font-semibold text-gray-900 mb-4 flex items-center">
          <FileTextIcon size={16} className="mr-2 text-blue-500" />
          Call Notes
        </h4>
        <form onSubmit={handleSubmit}>
          <textarea
            className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors resize-none"
            rows={5}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Add notes about this call..."
          />
          <div className="mt-4 flex justify-end">
            <Button 
              type="submit" 
              variant="primary" 
              size="sm" 
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Saving...' : 'Save Notes'}
            </Button>
          </div>
        </form>
      </div> */}
    </div>
  );

  return isDrawerView ? (
    <Drawer isOpen={isOpen} onClose={onClose} title="Call Details">
      {content}
    </Drawer>
  ) : (
    <Modal isOpen={isOpen} onClose={onClose} title="Call Details" size="lg">
      {content}
    </Modal>
  );
};

export default CallDetailsModal;
