import React from 'react';
import { AlertTriangleIcon, InfoIcon, AlertCircleIcon, CheckCircleIcon } from 'lucide-react';
import Button from './Button';
interface ConfirmDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  type?: 'info' | 'warning' | 'danger' | 'success';
  isProcessing?: boolean;
}
const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  type = 'warning',
  isProcessing = false
}) => {
  if (!isOpen) return null;
  const iconMap = {
    info: <InfoIcon size={24} className="text-blue-500" />,
    warning: <AlertTriangleIcon size={24} className="text-yellow-500" />,
    danger: <AlertCircleIcon size={24} className="text-red-500" />,
    success: <CheckCircleIcon size={24} className="text-green-500" />
  };
  const buttonVariantMap = {
    info: 'primary',
    warning: 'primary',
    danger: 'danger',
    success: 'success'
  };
  return <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center">
        {/* Background overlay */}
        <div className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" onClick={onClose} aria-hidden="true"></div>
        {/* Dialog */}
        <div className="inline-block w-full max-w-md p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white rounded-lg shadow-xl">
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0 mt-0.5">{iconMap[type]}</div>
            <div className="flex-1">
              <h3 className="text-lg font-medium text-gray-900">{title}</h3>
              <p className="mt-2 text-sm text-gray-500">{message}</p>
            </div>
          </div>
          <div className="mt-6 flex justify-end space-x-3">
            <Button variant="outline" onClick={onClose} disabled={isProcessing}>
              {cancelText}
            </Button>
            <Button variant={buttonVariantMap[type] as any} onClick={onConfirm} disabled={isProcessing}>
              {isProcessing ? 'Processing...' : confirmText}
            </Button>
          </div>
        </div>
      </div>
    </div>;
};
export default ConfirmDialog;