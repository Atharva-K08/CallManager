import React, { useEffect } from 'react';
import { XIcon } from 'lucide-react';
import Button from './Button';
interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  closeOnOverlayClick?: boolean;
}
const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  children,
  footer,
  size = 'md',
  closeOnOverlayClick = true
}) => {
  // Close modal on escape key press
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);
  // Prevent scrolling when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);
  if (!isOpen) return null;
  const sizeClasses = {
    sm: 'max-w-md',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl'
  };
  const handleOverlayClick = (e: React.MouseEvent) => {
    if (closeOnOverlayClick && e.target === e.currentTarget) {
      onClose();
    }
  };
  return <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0" onClick={handleOverlayClick}>
        {/* Background overlay with animation */}
        <div className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75 backdrop-blur-sm" aria-hidden="true"></div>
        {/* Modal panel with animations */}
        <div className="inline-block w-full px-4 pt-5 pb-4 overflow-hidden text-left align-bottom transition-all transform bg-white rounded-lg shadow-xl sm:my-8 sm:align-middle sm:p-6 animate-modal-appear">
          <div className={`${sizeClasses[size]} mx-auto`}>
            {/* Header with subtle highlight */}
            <div className="flex items-center justify-between mb-5 pb-3 border-b border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <span className="w-1 h-6 bg-blue-500 rounded mr-3"></span>
                {title}
              </h3>
              <button type="button" className="text-gray-400 bg-white rounded-full p-1 hover:bg-gray-100 hover:text-gray-500 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500" onClick={onClose}>
                <XIcon size={20} aria-hidden="true" />
              </button>
            </div>
            {/* Content */}
            <div className="mt-2 max-h-[70vh] overflow-y-auto custom-scrollbar">
              {children}
            </div>
            {/* Footer */}
            {footer && <div className="mt-6 pt-4 border-t border-gray-100 flex justify-end space-x-3">
                {footer}
              </div>}
          </div>
        </div>
      </div>
    </div>;
};
export default Modal;