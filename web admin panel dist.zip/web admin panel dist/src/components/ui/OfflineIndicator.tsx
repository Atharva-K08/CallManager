import React from 'react';
import { WifiOffIcon } from 'lucide-react';
import { useOnlineStatus } from '../../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
    const { isOnline } = useOnlineStatus({ showToast: false });

    if (isOnline) return null;

    return (
        <div className="fixed bottom-4 left-4 z-50 bg-red-500 text-white px-4 py-3 rounded-lg shadow-lg flex items-center space-x-3 animate-fadeIn">
            <WifiOffIcon size={20} className="animate-pulse" />
            <div>
                <p className="font-medium text-sm">You are offline</p>
                <p className="text-xs opacity-90">Some features may not work</p>
            </div>
        </div>
    );
};

export default OfflineIndicator;
