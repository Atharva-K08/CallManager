import React, { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface PasswordInputProps {
    id?: string;
    name?: string;
    value?: string;
    onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onBlur?: (e: React.FocusEvent<HTMLInputElement>) => void;
    placeholder?: string;
    disabled?: boolean;
    required?: boolean;
    error?: string;
    className?: string;
    autoComplete?: string;
}

const PasswordInput: React.FC<PasswordInputProps> = ({
    id,
    name,
    value,
    onChange,
    onBlur,
    placeholder,
    disabled = false,
    required = false,
    error,
    className = '',
    autoComplete,
}) => {
    const [showPassword, setShowPassword] = useState(false);

    const baseClasses = "block w-full px-3 py-2.5 pr-10 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 disabled:bg-gray-50 disabled:text-gray-500 disabled:cursor-not-allowed";
    const errorClasses = error ? "border-red-300 focus:ring-red-500 focus:border-red-500" : "";

    const inputClasses = `${baseClasses} ${errorClasses} ${className}`;

    return (
        <div className="relative">
            <input
                type={showPassword ? 'text' : 'password'}
                id={id}
                name={name}
                value={value}
                onChange={onChange}
                onBlur={onBlur}
                placeholder={placeholder}
                disabled={disabled}
                required={required}
                autoComplete={autoComplete}
                className={inputClasses}
            />
            <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 focus:outline-none"
                tabIndex={-1}
                disabled={disabled}
            >
                {showPassword ? (
                    <EyeOff size={16} className="cursor-pointer" />
                ) : (
                    <Eye size={16} className="cursor-pointer" />
                )}
            </button>
            {error && (
                <p className="mt-1 text-sm text-red-600">{error}</p>
            )}
        </div>
    );
};

export default PasswordInput;

