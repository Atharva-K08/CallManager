import React from 'react';

interface BulkActionItem {
    key: string;
    label: string;
    icon?: React.ReactNode;
    onClick: () => void;
    disabled?: boolean;
}

interface BulkActionsBarProps {
    count: number;
    onClear: () => void;
    className?: string;
    actions?: BulkActionItem[];
}

const BulkActionsBar: React.FC<BulkActionsBarProps> = ({ count, onClear, className, actions = [] }) => {
    if (count <= 0) return null;
    return (
        <div className={`flex items-center justify-between p-3 bg-blue-50 border border-blue-200 rounded-lg ${className || ''}`}>
            <div className="text-sm text-blue-900">{count} selected</div>
            <div className="flex items-center gap-2">
                {actions.map((action) => (
                    <button
                        key={action.key}
                        type="button"
                        onClick={action.onClick}
                        disabled={action.disabled}
                        className={`px-3 py-1.5 text-sm rounded-md border ${action.disabled ? 'opacity-50 cursor-not-allowed border-blue-200 text-blue-300' : 'border-blue-300 text-blue-700 hover:bg-blue-100'}`}
                    >
                        <span className="inline-flex items-center gap-1">
                            {action.icon ? action.icon : null}
                            <span>{action.label}</span>
                        </span>
                    </button>
                ))}
                <button
                    type="button"
                    onClick={onClear}
                    className="px-3 py-1.5 text-sm border border-blue-300 text-blue-700 rounded-md hover:bg-blue-100"
                >
                    Clear
                </button>
            </div>
        </div>
    );
};

export default BulkActionsBar;


