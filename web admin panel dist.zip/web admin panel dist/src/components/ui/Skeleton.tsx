import React from 'react';

interface SkeletonProps {
    width?: string | number;
    height?: string | number;
    variant?: 'rectangular' | 'circular' | 'text';
    className?: string;
    animation?: 'pulse' | 'wave' | 'none';
}

const Skeleton: React.FC<SkeletonProps> = ({
    width,
    height,
    variant = 'rectangular',
    className = '',
    animation = 'pulse',
}) => {
    const baseClasses = 'bg-gray-200';

    const animationClasses = {
        pulse: 'animate-pulse',
        wave: 'animate-wave',
        none: '',
    };

    const variantClasses = {
        rectangular: 'rounded',
        circular: 'rounded-full',
        text: 'rounded',
    };

    const style = {
        width: typeof width === 'number' ? `${width}px` : width,
        height: typeof height === 'number' ? `${height}px` : height,
    };

    return (
        <div
            className={`${baseClasses} ${variantClasses[variant]} ${animationClasses[animation]} ${className}`}
            style={style}
        />
    );
};

// Table skeleton
export const TableSkeleton: React.FC<{
    rows?: number;
    columns?: number;
    className?: string;
}> = ({ rows = 5, columns = 4, className = '' }) => (
    <div className={`space-y-3 ${className}`}>
        {/* Header skeleton */}
        <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}>
            {Array.from({ length: columns }).map((_, index) => (
                <Skeleton key={index} height={20} className="h-5" />
            ))}
        </div>

        {/* Rows skeleton */}
        {Array.from({ length: rows }).map((_, rowIndex) => (
            <div key={rowIndex} className="grid gap-4" style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}>
                {Array.from({ length: columns }).map((_, colIndex) => (
                    <Skeleton key={colIndex} height={16} className="h-4" />
                ))}
            </div>
        ))}
    </div>
);

// Card skeleton
export const CardSkeleton: React.FC<{
    count?: number;
    className?: string;
}> = ({ count = 3, className = '' }) => (
    <div className={`grid gap-4 ${className}`}>
        {Array.from({ length: count }).map((_, index) => (
            <div key={index} className="bg-white p-6 rounded-lg border border-gray-200">
                <div className="space-y-3">
                    <Skeleton height={24} className="h-6 w-3/4" />
                    <Skeleton height={16} className="h-4 w-full" />
                    <Skeleton height={16} className="h-4 w-2/3" />
                </div>
            </div>
        ))}
    </div>
);

// Stats skeleton
export const StatsSkeleton: React.FC<{
    count?: number;
    className?: string;
}> = ({ count = 4, className = '' }) => (
    <div className={`grid gap-4 ${className}`}>
        {Array.from({ length: count }).map((_, index) => (
            <div key={index} className="bg-white p-6 rounded-lg border border-gray-200">
                <div className="flex items-center justify-between">
                    <div className="space-y-2">
                        <Skeleton height={16} className="h-4 w-24" />
                        <Skeleton height={32} className="h-8 w-16" />
                    </div>
                    <Skeleton width={48} height={48} variant="circular" />
                </div>
            </div>
        ))}
    </div>
);

// User card skeleton
export const UserCardSkeleton: React.FC<{
    count?: number;
    className?: string;
}> = ({ count = 3, className = '' }) => (
    <div className={`grid gap-4 ${className}`}>
        {Array.from({ length: count }).map((_, index) => (
            <div key={index} className="bg-white p-6 rounded-lg border border-gray-200">
                <div className="flex items-center space-x-4">
                    <Skeleton width={48} height={48} variant="circular" />
                    <div className="flex-1 space-y-2">
                        <Skeleton height={20} className="h-5 w-32" />
                        <Skeleton height={16} className="h-4 w-48" />
                        <Skeleton height={16} className="h-4 w-24" />
                    </div>
                </div>
            </div>
        ))}
    </div>
);

// Chart skeleton
export const ChartSkeleton: React.FC<{
    height?: number;
    className?: string;
}> = ({ height = 300, className = '' }) => (
    <div className={`bg-white p-6 rounded-lg border border-gray-200 ${className}`}>
        <div className="space-y-4">
            <Skeleton height={24} className="h-6 w-48" />
            <Skeleton height={height} className="w-full" />
        </div>
    </div>
);

// Form skeleton
export const FormSkeleton: React.FC<{
    fields?: number;
    className?: string;
}> = ({ fields = 6, className = '' }) => (
    <div className={`space-y-6 ${className}`}>
        {Array.from({ length: fields }).map((_, index) => (
            <div key={index} className="space-y-2">
                <Skeleton height={16} className="h-4 w-24" />
                <Skeleton height={40} className="h-10 w-full" />
            </div>
        ))}
    </div>
);

// List skeleton
export const ListSkeleton: React.FC<{
    items?: number;
    className?: string;
}> = ({ items = 5, className = '' }) => (
    <div className={`space-y-3 ${className}`}>
        {Array.from({ length: items }).map((_, index) => (
            <div key={index} className="flex items-center space-x-3 p-3 bg-white rounded-lg border border-gray-200">
                <Skeleton width={40} height={40} variant="circular" />
                <div className="flex-1 space-y-2">
                    <Skeleton height={16} className="h-4 w-32" />
                    <Skeleton height={14} className="h-3.5 w-48" />
                </div>
                <Skeleton height={32} className="h-8 w-20" />
            </div>
        ))}
    </div>
);

export default Skeleton;