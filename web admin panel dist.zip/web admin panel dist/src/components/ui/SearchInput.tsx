import React, { useEffect, useState } from 'react';
import { SearchIcon, XCircleIcon } from 'lucide-react';
interface SearchInputProps {
  placeholder?: string;
  onSearch: (query: string) => void;
  className?: string;
  initialValue?: string;
  debounceTime?: number;
}
const SearchInput: React.FC<SearchInputProps> = ({
  placeholder = 'Search...',
  onSearch,
  className = '',
  initialValue = '',
  debounceTime = 300
}) => {
  const [query, setQuery] = useState(initialValue);
  const [debouncedQuery, setDebouncedQuery] = useState(initialValue);
  // Handle debounced search
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedQuery(query);
    }, debounceTime);
    return () => {
      clearTimeout(handler);
    };
  }, [query, debounceTime]);
  // Trigger search callback
  useEffect(() => {
    onSearch(debouncedQuery);
  }, [debouncedQuery, onSearch]);
  const handleClear = () => {
    setQuery('');
  };
  return <div className={`relative flex-1 ${className}`}>
      <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
        <SearchIcon size={18} className="text-gray-400" />
      </div>
      <input type="text" className="w-full pl-10 pr-10 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder={placeholder} value={query} onChange={e => setQuery(e.target.value)} />
      {query && <button className="absolute inset-y-0 right-0 flex items-center pr-3" onClick={handleClear} aria-label="Clear search">
          <XCircleIcon size={18} className="text-gray-400 hover:text-gray-600" />
        </button>}
    </div>;
};
export default SearchInput;