import React, { useEffect, useState, createElement } from 'react';
import { PhoneCallIcon, UserPlusIcon, ClockIcon, CheckIcon, XIcon, PhoneIcon } from 'lucide-react';
interface Activity {
  id: string;
  type: 'call' | 'assignment' | 'status';
  title: string;
  description: string;
  time: string;
  status?: 'success' | 'failed' | 'pending';
  user?: string;
}
interface ActivityFeedProps {
  activities: Activity[];
  showLive?: boolean;
  maxItems?: number;
}
const ActivityFeed: React.FC<ActivityFeedProps> = ({
  activities: initialActivities,
  showLive = true,
  maxItems = 5
}) => {
  const [activities, setActivities] = useState<Activity[]>(initialActivities);
  const [newActivityIndicator, setNewActivityIndicator] = useState(false);
  // Simulate real-time updates
  useEffect(() => {
    if (!showLive) return;
    const interval = setInterval(() => {
      const randomActivity = generateRandomActivity();
      setActivities(prev => [randomActivity, ...prev.slice(0, maxItems - 1)]);
      setNewActivityIndicator(true);
      setTimeout(() => {
        setNewActivityIndicator(false);
      }, 3000);
    }, 20000); // Add new activity every 20 seconds
    return () => clearInterval(interval);
  }, [maxItems, showLive]);
  const generateRandomActivity = (): Activity => {
    const types = ['call', 'assignment', 'status'];
    const statuses = ['success', 'failed', 'pending'];
    const type = types[Math.floor(Math.random() * types.length)] as 'call' | 'assignment' | 'status';
    const status = statuses[Math.floor(Math.random() * statuses.length)] as 'success' | 'failed' | 'pending';
    const users = ['Jane Smith', 'Robert Johnson', 'Michael Wilson', 'Sarah Brown'];
    const students = ['Alex Turner', 'Emma Watson', 'James Cameron', 'Olivia Parker'];
    const user = users[Math.floor(Math.random() * users.length)];
    const student = students[Math.floor(Math.random() * students.length)];
    let title = '';
    let description = '';
    switch (type) {
      case 'call':
        title = `${user} called ${student}`;
        description = status === 'success' ? 'Connected for 3:45 minutes' : 'Call not answered';
        break;
      case 'assignment':
        title = `Students assigned to ${user}`;
        description = '5 new students assigned';
        break;
      case 'status':
        title = `${student} status updated`;
        description = 'Marked as contacted';
        break;
    }
    return {
      id: Math.random().toString(36).substr(2, 9),
      type,
      title,
      description,
      time: 'Just now',
      status,
      user
    };
  };
  const getActivityIcon = (activity: Activity) => {
    switch (activity.type) {
      case 'call':
        if (activity.status === 'success') {
          return <PhoneCallIcon size={20} className="text-blue-600" />;
        } else if (activity.status === 'failed') {
          return <PhoneIcon size={20} className="text-red-600" />;
        } else {
          return <ClockIcon size={20} className="text-orange-600" />;
        }
      case 'assignment':
        return <UserPlusIcon size={20} className="text-green-600" />;
      case 'status':
        if (activity.status === 'success') {
          return <CheckIcon size={20} className="text-green-600" />;
        } else {
          return <XIcon size={20} className="text-red-600" />;
        }
      default:
        return <ClockIcon size={20} className="text-blue-600" />;
    }
  };
  const getActivityBgColor = (activity: Activity) => {
    switch (activity.type) {
      case 'call':
        return activity.status === 'failed' ? 'bg-red-100' : 'bg-blue-100';
      case 'assignment':
        return 'bg-green-100';
      case 'status':
        return activity.status === 'success' ? 'bg-green-100' : 'bg-red-100';
      default:
        return 'bg-blue-100';
    }
  };
  return <div className="space-y-4">
      {showLive && <div className="flex items-center mb-2">
          <div className={`w-2 h-2 rounded-full ${newActivityIndicator ? 'bg-green-500 animate-pulse' : 'bg-gray-300'} mr-2`}></div>
          <span className="text-xs text-gray-500">
            {newActivityIndicator ? 'New activity' : 'Monitoring activity'}
          </span>
        </div>}
      {activities.map(activity => <div key={activity.id} className="flex items-start animate-fadeIn">
          <div className="flex-shrink-0 mr-3">
            <div className={`w-10 h-10 rounded-full ${getActivityBgColor(activity)} flex items-center justify-center`}>
              {getActivityIcon(activity)}
            </div>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900">
              {activity.title}
            </p>
            <p className="text-xs text-gray-500">{activity.description}</p>
            <p className="text-xs text-gray-400 mt-1">{activity.time}</p>
          </div>
        </div>)}
    </div>;
};
export default ActivityFeed;
// Add this to index.css
const activityStyle = document.createElement('style');
activityStyle.textContent = `
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-10px); }
  to { opacity: 1; transform: translateY(0); }
}
.animate-fadeIn {
  animation: fadeIn 0.3s ease-out forwards;
}
`;
document.head.appendChild(activityStyle);