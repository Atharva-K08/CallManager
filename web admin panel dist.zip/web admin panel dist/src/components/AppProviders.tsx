import React from 'react';
import { ToastProvider, useToast } from '../contexts/ToastContext';
import ToastContainer from './ui/ToastContainer';
import OfflineIndicator from './ui/OfflineIndicator';

interface AppProvidersProps {
    children: React.ReactNode;
}

/**
 * Toast Container Component
 */
const ToastContainerWrapper: React.FC = () => {
    const { toasts, removeToast } = useToast();
    return <ToastContainer toasts={toasts} onRemove={removeToast} />;
};

/**
 * Global providers and components for the app
 */
export const AppProviders: React.FC<AppProvidersProps> = ({ children }) => {
    return (
        <ToastProvider>
            {children}

            {/* Professional Toast Notifications */}
            <ToastContainerWrapper />

            {/* Offline Indicator */}
            <OfflineIndicator />
        </ToastProvider>
    );
};

export default AppProviders;
