import React from 'react';
import './index.css';
import { createRoot } from 'react-dom/client';
import { App } from './App';
import AppProviders from './components/AppProviders';
import { AuthProvider } from './contexts/AuthContext';

const container = document.getElementById('root');
if (!container) throw new Error('Failed to find the root element');

const root = createRoot(container);
root.render(
    <AuthProvider>
        <AppProviders>
            <App />
        </AppProviders>
    </AuthProvider>
);