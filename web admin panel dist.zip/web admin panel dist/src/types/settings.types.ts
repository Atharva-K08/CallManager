/**
 * Settings Types
 * Type definitions for settings and preferences
 */

export type SettingDataType = 'string' | 'number' | 'boolean' | 'object' | 'array';

export interface SettingValue {
    value: any;
    dataType?: SettingDataType;
    description?: string;
    isEditable?: boolean;
}

export interface Setting {
    _id?: string;
    userId?: string;
    scope: 'user' | 'system' | 'default';
    category: string;
    key: string;
    value: any;
    dataType: SettingDataType;
    description?: string;
    isEditable: boolean;
    version?: string;
    createdAt?: string;
    updatedAt?: string;
}

export interface CategorySettings {
    [key: string]: any;
}

export interface UserSettings {
    [category: string]: CategorySettings;
}

// Predefined setting categories
export type SettingCategory = 
    | 'ui'
    | 'notifications'
    | 'features'
    | 'sync'
    | 'integrations'
    | string; // Allow custom categories

// UI Settings
export interface UISettings {
    theme: 'light' | 'dark' | 'auto';
    language: string;
    itemsPerPage: number;
    showNotifications: boolean;
}

// Notification Settings
export interface NotificationSettings {
    emailEnabled: boolean;
    pushEnabled: boolean;
    soundEnabled: boolean;
    desktopEnabled: boolean;
    notifyOnNewTask: boolean;
    notifyOnNewLead: boolean;
    notifyOnFollowUp: boolean;
}

// Feature Settings
export interface FeatureSettings {
    enableAdvancedReports: boolean;
    enableBulkActions: boolean;
    enableExport: boolean;
    [key: string]: boolean; // Allow custom feature flags
}

// Sync Settings
export interface SyncSettings {
    autoSync: boolean;
    syncInterval: number;
    syncOnAppStart: boolean;
}

// Integration Settings
export interface IntegrationSettings {
    enableWhatsApp: boolean;
    enableSMS: boolean;
    [key: string]: boolean; // Allow custom integrations
}

// Combined settings type
export interface AppSettings {
    ui: UISettings;
    notifications: NotificationSettings;
    features: FeatureSettings;
    sync: SyncSettings;
    integrations: IntegrationSettings;
    [category: string]: any; // Allow custom categories
}

// API Request/Response types
export interface GetSettingRequest {
    category: string;
    key: string;
    defaultValue?: any;
}

export interface SetSettingRequest {
    value: any;
    dataType?: SettingDataType;
    description?: string;
    isEditable?: boolean;
}

export interface SetCategorySettingsRequest {
    settings: Record<string, SettingValue | any>;
}

