/**
 * Shared Role Definitions for Frontend
 * This file contains role definitions that match the backend shared-roles.js
 * to ensure consistency across the application.
 */

// Role constants
export const ROLES = {
    USER: 'user',
    ADMIN: 'admin',
    SUPERADMIN: 'superadmin',
    EMPLOYEE: 'employee',
    CALLER: 'caller'
} as const;

// Type for role values
export type Role = typeof ROLES[keyof typeof ROLES];

// Role hierarchy (higher number = more permissions)
export const ROLE_HIERARCHY = {
    [ROLES.USER]: 1,
    [ROLES.CALLER]: 2,
    [ROLES.EMPLOYEE]: 2,
    [ROLES.ADMIN]: 3,
    [ROLES.SUPERADMIN]: 4
} as const;

// Role permissions mapping
export const ROLE_PERMISSIONS = {
    [ROLES.USER]: [
        'viewOwnProfile',
        'updateOwnProfile',
        'viewOwnCalls',
        'createCall',
        'updateOwnCall'
    ],
    [ROLES.EMPLOYEE]: [
        'viewOwnProfile',
        'updateOwnProfile',
        'viewOwnCalls',
        'createCall',
        'updateOwnCall',
        'viewAssignedStudents',
        'updateAssignedStudents'
    ],
    [ROLES.CALLER]: [
        'viewOwnProfile',
        'updateOwnProfile',
        'viewOwnCalls',
        'createCall',
        'updateOwnCall',
        'viewAssignedStudents',
        'updateAssignedStudents'
    ],
    [ROLES.ADMIN]: [
        'viewOwnProfile',
        'updateOwnProfile',
        'viewOwnCalls',
        'createCall',
        'updateOwnCall',
        'viewAssignedStudents',
        'updateAssignedStudents',
        'getUsers',
        'manageUsers',
        'viewAllCalls',
        'viewAllStudents',
        'assignStudents',
        'viewReports',
        'manageSystemSettings'
    ],
    [ROLES.SUPERADMIN]: [
        'viewOwnProfile',
        'updateOwnProfile',
        'viewOwnCalls',
        'createCall',
        'updateOwnCall',
        'viewAssignedStudents',
        'updateAssignedStudents',
        'getUsers',
        'manageUsers',
        'viewAllCalls',
        'viewAllStudents',
        'assignStudents',
        'viewReports',
        'manageSystemSettings',
        'deleteUsers',
        'bulkManageUsers',
        'viewAllReports',
        'manageAllSettings',
        'systemAdministration'
    ]
};

// Role display names for UI
export const ROLE_DISPLAY_NAMES = {
    [ROLES.USER]: 'User',
    [ROLES.EMPLOYEE]: 'Employee',
    [ROLES.CALLER]: 'Caller',
    [ROLES.ADMIN]: 'Admin',
    [ROLES.SUPERADMIN]: 'Super Admin'
} as const;

// Role descriptions
export const ROLE_DESCRIPTIONS = {
    [ROLES.USER]: 'Basic user with limited permissions',
    [ROLES.EMPLOYEE]: 'Employee with access to assigned students and calls',
    [ROLES.CALLER]: 'Caller with access to assigned leads and calls',
    [ROLES.ADMIN]: 'Administrator with user management and reporting capabilities',
    [ROLES.SUPERADMIN]: 'Super administrator with full system access'
} as const;

// Available roles array (for validation)
export const AVAILABLE_ROLES = Object.values(ROLES);

// Permission type
export type Permission = typeof ROLE_PERMISSIONS[Role][number];

// Helper functions
export const getRolePermissions = (role: Role): Permission[] => {
    return ROLE_PERMISSIONS[role] || [];
};

export const hasPermission = (userRole: Role, permission: Permission): boolean => {
    const permissions = getRolePermissions(userRole);
    return permissions.includes(permission);
};

export const canAccessRole = (userRole: Role, targetRole: Role): boolean => {
    const userLevel = ROLE_HIERARCHY[userRole] || 0;
    const targetLevel = ROLE_HIERARCHY[targetRole] || 0;
    return userLevel >= targetLevel;
};

export const getRolesUserCanManage = (userRole: Role): Role[] => {
    const userLevel = ROLE_HIERARCHY[userRole] || 0;
    return AVAILABLE_ROLES.filter(role =>
        ROLE_HIERARCHY[role] < userLevel
    );
};

// Role validation
export const isValidRole = (role: string): role is Role => {
    return AVAILABLE_ROLES.includes(role as Role);
};

// Role options for select components
export const ROLE_OPTIONS = AVAILABLE_ROLES.map(role => ({
    value: role,
    label: ROLE_DISPLAY_NAMES[role],
    description: ROLE_DESCRIPTIONS[role]
}));

// Role filter options (includes 'all' option)
export const ROLE_FILTER_OPTIONS = [
    { value: 'all', label: 'All Roles' },
    ...ROLE_OPTIONS
];
