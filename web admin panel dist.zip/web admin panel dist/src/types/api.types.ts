import { Role } from './roles';

// Common API Response Types
export interface ApiResponse<T = any> {
    success: boolean;
    status: number;
    data: T;
    message?: string;
    errors?: Record<string, string[]>;
    meta?: {
        current_page: number;
        per_page: number;
        total_items: number;
        total_pages: number;
    };
}

export interface PaginatedResponse<T> {
    success: boolean;
    data: T[];
    meta: {
        current_page: number;
        total_pages: number;
        total_items: number;
        per_page: number;
    };
}

export interface ApiError {
    message: string;
    status: number;
    errors?: Record<string, string[]>;
}

// Auth Types
export interface LoginRequest {
    email: string;
    password: string;
}

export interface LoginResponse {
    user: User;
    tokens: {
        access: {
            token: string;
            expires: string;
        };
        refresh: {
            token: string;
            expires: string;
        };
    };
}

export interface User {
    _id: string;
    id?: number; // For backward compatibility
    name: string;
    email: string;
    role: Role;
    phoneNumber?: string;
    profilePicture?: string;
    isActive: boolean;
    isEmailVerified?: boolean;
    createdAt: string;
    updatedAt: string;
}

// User Management Types
export interface CreateUserRequest {
    name: string;
    email: string;
    password: string;
    role: Role;
    phoneNumber?: string;
    profilePicture?: string;
    isActive?: boolean;
}

export interface UpdateUserRequest {
    name?: string;
    email?: string;
    role?: Role;
    phoneNumber?: string;
    profilePicture?: string;
    isActive?: boolean;
}

export interface UserFilters {
    name?: string;
    email?: string;
    role?: Role | '';
    isActive?: boolean | string;
    sortBy?: string;
    limit?: number;
    page?: number;
    per_page?: number;
}

export interface UserStats {
    totalUsers: number;
    activeUsers: number;
    inactiveUsers: number;
    roleStats: { _id: string; count: number }[];
    recentUsers: User[];
    monthlyStats: { _id: { year: number; month: number }; count: number }[];
}

export interface CallerStats {
    totalCalls: number;
    outgoingCalls: number;
    incomingCalls: number;
    connectedCalls: number;
    missedCalls: number;
    totalDuration: number;
    avgDuration: number;
    lastCallAt: string;
}

export interface CallerWithStats extends User {
    stats: CallerStats;
}

// Student Management Types
export interface Student {
    id: number;
    name: string;
    phone: string;
    email?: string;
    assignedUser?: string;
    assigned_user_id?: number;
    status: 'Called' | 'Not Called';
    created_at?: string;
    updated_at?: string;
}

export interface CreateStudentRequest {
    name: string;
    phone: string;
    email?: string;
    assigned_user_id?: number;
}

export interface UpdateStudentRequest {
    name?: string;
    phone?: string;
    email?: string;
    assigned_user_id?: number;
    status?: 'Called' | 'Not Called';
}

export interface AssignStudentsRequest {
    student_ids: number[];
    user_id: number;
    note?: string;
}

export interface ImportStudentsRequest {
    file: File;
}

// Call Tracking Types
export interface Call {
    id: number;
    user_id: number;
    userName: string;
    student_id: number;
    studentName: string;
    phone: string;
    status: 'Connected' | 'Not Answered' | 'Busy';
    duration: string;
    dateTime: string;
    notes?: string;
    recording_url?: string;
    created_at?: string;
}

export interface CreateCallRequest {
    student_id: number;
    status: 'Connected' | 'Not Answered' | 'Busy';
    duration: string;
    notes?: string;
    recording_url?: string;
}

export interface UpdateCallRequest {
    status?: 'Connected' | 'Not Answered' | 'Busy';
    duration?: string;
    notes?: string;
}

export interface CallFilters {
    user_id?: number;
    student_id?: number;
    status?: string;
    start_date?: string;
    end_date?: string;
    search?: string;
}

// Report Types
export interface CallStats {
    totalUsers: number;
    totalStudents: number;
    assignedStudents: number;
    callsMadeToday: number;
    callsPerUser: { name: string; calls: number }[];
    callStatusDistribution: { name: string; value: number }[];
    dailyCallTrends: { date: string; calls: number }[];
}

export interface ReportFilters {
    start_date?: string;
    end_date?: string;
    user_id?: number;
    report_type?: 'overview' | 'users' | 'time';
}

// Settings Types
export interface UpdateProfileRequest {
    name?: string;
    email?: string;
    phone?: string;
    timezone?: string;
}

export interface ChangePasswordRequest {
    current_password: string;
    new_password: string;
    confirm_password: string;
}

export interface SystemSettingsRequest {
    system_name?: string;
    email_notifications?: boolean;
    call_notifications?: boolean;
    report_notifications?: boolean;
    default_call_duration?: number;
    data_retention_days?: number;
}
