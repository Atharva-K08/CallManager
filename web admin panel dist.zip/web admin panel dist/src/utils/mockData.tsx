import React from 'react';
// Mock data for the admin panel
export const users = [{
  id: 1,
  name: 'John Doe',
  email: 'john@example.com',
  role: 'Admin',
  status: 'Active'
}, {
  id: 2,
  name: 'Jane Smith',
  email: 'jane@example.com',
  role: 'Manager',
  status: 'Active'
}, {
  id: 3,
  name: 'Robert Johnson',
  email: 'robert@example.com',
  role: 'Caller',
  status: 'Active'
}, {
  id: 4,
  name: 'Emily Davis',
  email: 'emily@example.com',
  role: 'Caller',
  status: 'Inactive'
}, {
  id: 5,
  name: 'Michael Wilson',
  email: 'michael@example.com',
  role: 'Caller',
  status: 'Active'
}, {
  id: 6,
  name: 'Sarah Brown',
  email: 'sarah@example.com',
  role: 'Caller',
  status: 'Active'
}, {
  id: 7,
  name: 'David Miller',
  email: 'david@example.com',
  role: 'Manager',
  status: 'Active'
}, {
  id: 8,
  name: 'Lisa Anderson',
  email: 'lisa@example.com',
  role: 'Caller',
  status: 'Inactive'
}];
export const students = [{
  id: 1,
  name: 'Alex Turner',
  phone: '123-456-7890',
  assignedUser: 'Jane Smith',
  status: 'Called'
}, {
  id: 2,
  name: 'Emma Watson',
  phone: '234-567-8901',
  assignedUser: 'Robert Johnson',
  status: 'Not Called'
}, {
  id: 3,
  name: 'James Cameron',
  phone: '345-678-9012',
  assignedUser: 'Michael Wilson',
  status: 'Called'
}, {
  id: 4,
  name: 'Olivia Parker',
  phone: '456-789-0123',
  assignedUser: 'Sarah Brown',
  status: 'Not Called'
}, {
  id: 5,
  name: 'William Scott',
  phone: '567-890-1234',
  assignedUser: 'Robert Johnson',
  status: 'Called'
}, {
  id: 6,
  name: 'Sophia Martinez',
  phone: '678-901-2345',
  assignedUser: 'Jane Smith',
  status: 'Not Called'
}, {
  id: 7,
  name: 'Benjamin Lee',
  phone: '789-012-3456',
  assignedUser: 'Michael Wilson',
  status: 'Called'
}, {
  id: 8,
  name: 'Ava Rodriguez',
  phone: '890-123-4567',
  assignedUser: 'Sarah Brown',
  status: 'Not Called'
}, {
  id: 9,
  name: 'Daniel White',
  phone: '901-234-5678',
  assignedUser: 'Jane Smith',
  status: 'Called'
}, {
  id: 10,
  name: 'Mia Thompson',
  phone: '012-345-6789',
  assignedUser: 'Robert Johnson',
  status: 'Not Called'
}];
export const calls = [{
  id: 1,
  userName: 'Jane Smith',
  studentName: 'Alex Turner',
  phone: '123-456-7890',
  status: 'Connected',
  duration: '5:23',
  dateTime: '2023-06-15 10:30 AM'
}, {
  id: 2,
  userName: 'Robert Johnson',
  studentName: 'Emma Watson',
  phone: '234-567-8901',
  status: 'Not Answered',
  duration: '0:00',
  dateTime: '2023-06-15 11:15 AM'
}, {
  id: 3,
  userName: 'Michael Wilson',
  studentName: 'James Cameron',
  phone: '345-678-9012',
  status: 'Connected',
  duration: '3:45',
  dateTime: '2023-06-15 01:20 PM'
}, {
  id: 4,
  userName: 'Sarah Brown',
  studentName: 'Olivia Parker',
  phone: '456-789-0123',
  status: 'Busy',
  duration: '0:00',
  dateTime: '2023-06-15 02:05 PM'
}, {
  id: 5,
  userName: 'Robert Johnson',
  studentName: 'William Scott',
  phone: '567-890-1234',
  status: 'Connected',
  duration: '7:12',
  dateTime: '2023-06-15 03:30 PM'
}, {
  id: 6,
  userName: 'Jane Smith',
  studentName: 'Sophia Martinez',
  phone: '678-901-2345',
  status: 'Not Answered',
  duration: '0:00',
  dateTime: '2023-06-16 09:45 AM'
}, {
  id: 7,
  userName: 'Michael Wilson',
  studentName: 'Benjamin Lee',
  phone: '789-012-3456',
  status: 'Connected',
  duration: '4:18',
  dateTime: '2023-06-16 10:30 AM'
}, {
  id: 8,
  userName: 'Sarah Brown',
  studentName: 'Ava Rodriguez',
  phone: '890-123-4567',
  status: 'Busy',
  duration: '0:00',
  dateTime: '2023-06-16 11:20 AM'
}, {
  id: 9,
  userName: 'Jane Smith',
  studentName: 'Daniel White',
  phone: '901-234-5678',
  status: 'Connected',
  duration: '6:05',
  dateTime: '2023-06-16 01:15 PM'
}, {
  id: 10,
  userName: 'Robert Johnson',
  studentName: 'Mia Thompson',
  phone: '012-345-6789',
  status: 'Not Answered',
  duration: '0:00',
  dateTime: '2023-06-16 02:30 PM'
}];
export const callStats = {
  totalUsers: users.filter(user => user.status === 'Active').length,
  totalStudents: students.length,
  assignedStudents: students.filter(student => student.assignedUser).length,
  callsMadeToday: calls.filter(call => {
    const today = new Date().toISOString().split('T')[0];
    return call.dateTime.includes(today);
  }).length || 5,
  callsPerUser: [{
    name: 'Jane Smith',
    calls: 12
  }, {
    name: 'Robert Johnson',
    calls: 9
  }, {
    name: 'Michael Wilson',
    calls: 15
  }, {
    name: 'Sarah Brown',
    calls: 7
  }],
  callStatusDistribution: [{
    name: 'Connected',
    value: 18
  }, {
    name: 'Not Answered',
    value: 12
  }, {
    name: 'Busy',
    value: 5
  }],
  dailyCallTrends: [{
    date: '06/10',
    calls: 15
  }, {
    date: '06/11',
    calls: 20
  }, {
    date: '06/12',
    calls: 18
  }, {
    date: '06/13',
    calls: 25
  }, {
    date: '06/14',
    calls: 22
  }, {
    date: '06/15',
    calls: 30
  }, {
    date: '06/16',
    calls: 28
  }]
};