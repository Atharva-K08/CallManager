import {
    Role,
    Permission,
    ROLES,
    ROLE_HIERARCHY,
    ROLE_PERMISSIONS,
    AVAILABLE_ROLES,
    getRolePermissions,
    hasPermission,
    canAccessRole,
    getRolesUserCanManage,
    isValidRole,
    ROLE_OPTIONS,
    ROLE_FILTER_OPTIONS
} from '../types/roles';

/**
 * Role utility functions for frontend components
 */

// Check if user has specific permission
export const checkPermission = (userRole: Role, permission: Permission): boolean => {
    return hasPermission(userRole, permission);
};

// Check if user can access/modify another user with target role
export const canManageUser = (userRole: Role, targetRole: Role): boolean => {
    return canAccessRole(userRole, targetRole);
};

// Get available roles for a user to assign
export const getAssignableRoles = (userRole: Role): Role[] => {
    return getRolesUserCanManage(userRole);
};

// Check if role is valid
export const validateRole = (role: string): role is Role => {
    return isValidRole(role);
};

// Get role display name
export const getRoleDisplayName = (role: Role): string => {
    const roleOption = ROLE_OPTIONS.find(option => option.value === role);
    return roleOption?.label || role;
};

// Get role description
export const getRoleDescription = (role: Role): string => {
    const roleOption = ROLE_OPTIONS.find(option => option.value === role);
    return roleOption?.description || '';
};

// Check if user can perform admin actions
export const isAdmin = (userRole: Role): boolean => {
    return userRole === ROLES.ADMIN || userRole === ROLES.SUPERADMIN;
};

// Check if user is super admin
export const isSuperAdmin = (userRole: Role): boolean => {
    return userRole === ROLES.SUPERADMIN;
};

// Check if user can manage other users
export const canManageUsers = (userRole: Role): boolean => {
    return checkPermission(userRole, 'manageUsers');
};

// Check if user can view reports
export const canViewReports = (userRole: Role): boolean => {
    return checkPermission(userRole, 'viewReports');
};

// Check if user can manage system settings
export const canManageSettings = (userRole: Role): boolean => {
    return checkPermission(userRole, 'manageSystemSettings');
};

// Get role color for UI components
export const getRoleColor = (role: Role): string => {
    const colors = {
        [ROLES.USER]: 'bg-gray-100 text-gray-800',
        [ROLES.EMPLOYEE]: 'bg-blue-100 text-blue-800',
        [ROLES.ADMIN]: 'bg-purple-100 text-purple-800',
        [ROLES.SUPERADMIN]: 'bg-red-100 text-red-800'
    };
    return colors[role] || colors[ROLES.USER];
};

// Get role icon for UI components
export const getRoleIcon = (role: Role): string => {
    const icons = {
        [ROLES.USER]: '👤',
        [ROLES.EMPLOYEE]: '👷',
        [ROLES.ADMIN]: '🛡️',
        [ROLES.SUPERADMIN]: '👑'
    };
    return icons[role] || icons[ROLES.USER];
};

// Filter users by role access
export const filterUsersByRoleAccess = <T extends { role: Role }>(
    users: T[],
    currentUserRole: Role
): T[] => {
    return users.filter(user => canManageUser(currentUserRole, user.role));
};

// Get role statistics
export const getRoleStats = <T extends { role: Role }>(users: T[]) => {
    const stats = AVAILABLE_ROLES.reduce((acc, role) => {
        acc[role] = users.filter(user => user.role === role).length;
        return acc;
    }, {} as Record<Role, number>);

    return stats;
};

// Export role options for components
export { ROLE_OPTIONS, ROLE_FILTER_OPTIONS };
