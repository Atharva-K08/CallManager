import { ApiError } from '../types/api.types';

/**
 * Format API error for display
 */
export const formatApiError = (error: ApiError): string => {
    if (error.errors) {
        // Handle validation errors
        const errorMessages = Object.entries(error.errors)
            .map(([field, messages]) => `${field}: ${messages.join(', ')}`)
            .join('\n');
        return errorMessages;
    }
    return error.message || 'An unexpected error occurred';
};

/**
 * Get error message from error object
 */
export const getErrorMessage = (error: unknown): string => {
    if (typeof error === 'string') {
        return error;
    }

    if (error && typeof error === 'object') {
        const apiError = error as ApiError;
        return formatApiError(apiError);
    }

    return 'An unexpected error occurred';
};

/**
 * Check if error is a network error
 */
export const isNetworkError = (error: ApiError): boolean => {
    return error.status === 0 || error.message.includes('Network');
};

/**
 * Check if error is an authentication error
 */
export const isAuthError = (error: ApiError): boolean => {
    return error.status === 401 || error.status === 403;
};

/**
 * Check if error is a validation error
 */
export const isValidationError = (error: ApiError): boolean => {
    return error.status === 422 || !!error.errors;
};

/**
 * Display error notification
 */
export const showErrorNotification = (error: unknown, defaultMessage?: string): void => {
    const message = getErrorMessage(error) || defaultMessage || 'An error occurred';

    if (typeof window !== 'undefined') {
        console.error('API Error:', error);

        // Import toast dynamically to avoid circular dependencies
        import('../lib/toast').then(({ default: showToast }) => {
            showToast.error(message);
        });
    }
};

/**
 * Handle API error with custom logic
 */
export const handleApiError = (
    error: unknown,
    customHandlers?: {
        onNetworkError?: () => void;
        onAuthError?: () => void;
        onValidationError?: (errors: Record<string, string[]>) => void;
        onGenericError?: (message: string) => void;
    }
): void => {
    const apiError = error as ApiError;

    if (isNetworkError(apiError)) {
        customHandlers?.onNetworkError?.();
        return;
    }

    if (isAuthError(apiError)) {
        customHandlers?.onAuthError?.();
        return;
    }

    if (isValidationError(apiError) && apiError.errors) {
        customHandlers?.onValidationError?.(apiError.errors);
        return;
    }

    customHandlers?.onGenericError?.(getErrorMessage(error));
};
