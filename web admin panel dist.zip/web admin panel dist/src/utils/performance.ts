/**
 * Debounce function - delays execution until after wait time has elapsed
 * since the last time it was invoked
 */
export function debounce<T extends (...args: any[]) => any>(
    func: T,
    wait: number
): (...args: Parameters<T>) => void {
    let timeout: NodeJS.Timeout | null = null;

    return function executedFunction(...args: Parameters<T>) {
        const later = () => {
            timeout = null;
            func(...args);
        };

        if (timeout) {
            clearTimeout(timeout);
        }
        timeout = setTimeout(later, wait);
    };
}

/**
 * Throttle function - ensures function is called at most once in specified time period
 */
export function throttle<T extends (...args: any[]) => any>(
    func: T,
    limit: number
): (...args: Parameters<T>) => void {
    let inThrottle: boolean;

    return function executedFunction(...args: Parameters<T>) {
        if (!inThrottle) {
            func(...args);
            inThrottle = true;
            setTimeout(() => (inThrottle = false), limit);
        }
    };
}

/**
 * Create a debounced async function
 */
export function debounceAsync<T extends (...args: any[]) => Promise<any>>(
    func: T,
    wait: number
): (...args: Parameters<T>) => Promise<ReturnType<T>> {
    let timeout: NodeJS.Timeout | null = null;
    let resolveList: ((value: any) => void)[] = [];
    let rejectList: ((reason?: any) => void)[] = [];

    return function executedFunction(...args: Parameters<T>): Promise<ReturnType<T>> {
        return new Promise((resolve, reject) => {
            if (timeout) {
                clearTimeout(timeout);
            }

            resolveList.push(resolve);
            rejectList.push(reject);

            timeout = setTimeout(async () => {
                const currentResolveList = [...resolveList];
                const currentRejectList = [...rejectList];
                resolveList = [];
                rejectList = [];

                try {
                    const result = await func(...args);
                    currentResolveList.forEach((r) => r(result));
                } catch (error) {
                    currentRejectList.forEach((r) => r(error));
                }
            }, wait);
        });
    };
}

/**
 * Retry function with exponential backoff
 */
export async function retryWithBackoff<T>(
    fn: () => Promise<T>,
    options: {
        maxAttempts?: number;
        initialDelay?: number;
        maxDelay?: number;
        backoffMultiplier?: number;
    } = {}
): Promise<T> {
    const {
        maxAttempts = 3,
        initialDelay = 1000,
        maxDelay = 10000,
        backoffMultiplier = 2,
    } = options;

    let lastError: any;
    let delay = initialDelay;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
            return await fn();
        } catch (error) {
            lastError = error;

            if (attempt < maxAttempts) {
                await new Promise((resolve) => setTimeout(resolve, delay));
                delay = Math.min(delay * backoffMultiplier, maxDelay);
            }
        }
    }

    throw lastError;
}

/**
 * Create a memoized function
 */
export function memoize<T extends (...args: any[]) => any>(
    func: T,
    options: {
        maxAge?: number;
        maxSize?: number;
    } = {}
): T {
    const { maxAge = 60000, maxSize = 100 } = options;
    const cache = new Map<string, { value: any; timestamp: number }>();

    return ((...args: Parameters<T>): ReturnType<T> => {
        const key = JSON.stringify(args);
        const now = Date.now();

        // Check if cached value exists and is not expired
        if (cache.has(key)) {
            const cached = cache.get(key)!;
            if (now - cached.timestamp < maxAge) {
                return cached.value;
            }
            cache.delete(key);
        }

        // Compute new value
        const value = func(...args);

        // Store in cache
        cache.set(key, { value, timestamp: now });

        // Enforce max cache size (remove oldest)
        if (cache.size > maxSize) {
            const firstKey = cache.keys().next().value;
            cache.delete(firstKey);
        }

        return value;
    }) as T;
}

/**
 * Request idle callback polyfill
 */
export const requestIdleCallback =
    typeof window !== 'undefined' && 'requestIdleCallback' in window
        ? window.requestIdleCallback
        : (callback: IdleRequestCallback) => {
            const start = Date.now();
            return setTimeout(() => {
                callback({
                    didTimeout: false,
                    timeRemaining: () => Math.max(0, 50 - (Date.now() - start)),
                });
            }, 1);
        };

/**
 * Cancel idle callback polyfill
 */
export const cancelIdleCallback =
    typeof window !== 'undefined' && 'cancelIdleCallback' in window
        ? window.cancelIdleCallback
        : (id: number) => clearTimeout(id);

/**
 * Run task when browser is idle
 */
export function runWhenIdle(task: () => void, options?: IdleRequestOptions): number {
    return requestIdleCallback(task, options);
}

/**
 * Batch multiple function calls
 */
export function batch<T extends (...args: any[]) => void>(
    func: T,
    wait: number
): (...args: Parameters<T>) => void {
    let calls: Parameters<T>[] = [];
    let timeout: NodeJS.Timeout | null = null;

    return function executedFunction(...args: Parameters<T>) {
        calls.push(args);

        if (timeout) {
            clearTimeout(timeout);
        }

        timeout = setTimeout(() => {
            const allCalls = [...calls];
            calls = [];
            allCalls.forEach((callArgs) => func(...callArgs));
        }, wait);
    };
}
