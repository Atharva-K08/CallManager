import { useApi } from './useApi';
import { callService } from '../services';
import { CreateCallRequest, UpdateCallRequest, CallFilters } from '../types/api.types';

export function useCalls() {
    const getCallsApi = useApi(callService.getCalls);
    const getCallApi = useApi(callService.getCall);
    const createCallApi = useApi(callService.createCall);
    const updateCallApi = useApi(callService.updateCall);
    const deleteCallApi = useApi(callService.deleteCall);
    const getCallStatsApi = useApi(callService.getCallStats);
    const addCallNoteApi = useApi(callService.addCallNote);

    return {
        // Get all calls
        getCalls: getCallsApi.execute,
        calls: getCallsApi.data,
        callsLoading: getCallsApi.loading,
        callsError: getCallsApi.error,

        // Get single call
        getCall: getCallApi.execute,
        call: getCallApi.data,
        callLoading: getCallApi.loading,

        // Create call
        createCall: createCallApi.execute,
        createLoading: createCallApi.loading,
        createError: createCallApi.error,

        // Update call
        updateCall: updateCallApi.execute,
        updateLoading: updateCallApi.loading,

        // Delete call
        deleteCall: deleteCallApi.execute,
        deleteLoading: deleteCallApi.loading,

        // Get call stats
        getCallStats: getCallStatsApi.execute,
        stats: getCallStatsApi.data,
        statsLoading: getCallStatsApi.loading,

        // Add call note
        addCallNote: addCallNoteApi.execute,
        addNoteLoading: addCallNoteApi.loading,
    };
}
