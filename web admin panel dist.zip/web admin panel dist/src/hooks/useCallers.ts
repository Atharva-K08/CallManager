import { useState, useCallback } from 'react';
import { useApi } from './useApi';
import { userService } from '../services/user.service';
import { CallerWithStats } from '../types/api.types';
import { useToastNotifications } from '../lib/toast';

export interface CallerFilters {
    page?: number;
    limit?: number;
    from?: string;
    to?: string;
    sortBy?: string;
}

export const useCallers = () => {
    const { showSuccess, showErrorWithDetails } = useToastNotifications();

    // List state
    const [callers, setCallers] = useState<CallerWithStats[]>([]);
    const [pagination, setPagination] = useState({
        current_page: 1,
        per_page: 10,
        total_items: 0,
        total_pages: 0,
    });

    // Get callers
    const { execute: getCallers, loading: callersLoading, error: callersError } = useApi(
        async (filters?: CallerFilters) => {
            const response = await userService.getCallers(filters);
            setCallers(response.data);
            if (response.meta) {
                setPagination(response.meta);
            }
            return response;
        },
        {
            onError: (error) => {
                showErrorWithDetails('Failed to fetch callers', error.message);
                console.error('Get callers error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Helper function to refresh callers list
    const refreshCallers = useCallback(async (filters?: CallerFilters) => {
        await getCallers(filters);
    }, [getCallers]);

    return {
        // State
        callers,
        pagination,

        // Loading states
        callersLoading,

        // Error states
        callersError,

        // Actions
        getCallers,
        refreshCallers,
    };
};

