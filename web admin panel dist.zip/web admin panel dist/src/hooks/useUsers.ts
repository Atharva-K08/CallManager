import { useState, useCallback } from 'react';
import { useApi } from './useApi';
import { userService } from '../services/user.service';
import { User, CreateUserRequest, UpdateUserRequest, UserFilters } from '../types/api.types';
import { useToastNotifications } from '../lib/toast';

export const useUsers = () => {
    // Toast notifications
    const { showSuccess, showErrorWithDetails } = useToastNotifications();

    // List state
    const [users, setUsers] = useState<User[]>([]);
    const [pagination, setPagination] = useState({
        current_page: 1,
        per_page: 10,
        total_items: 0,
        total_pages: 0,
    });

    // Get users
    const { execute: getUsers, loading: usersLoading, error: usersError } = useApi(
        async (filters?: UserFilters) => {
            const response = await userService.getUsers(filters);
            setUsers(response.data);
            if (response.meta) {
                setPagination(response.meta);
            }
            return response;
        },
        {
            onError: (error) => {
                showErrorWithDetails('Failed to fetch users', error.message);
                console.error('Get users error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Get single user
    const { execute: getUser, loading: userLoading, error: userError } = useApi(
        async (id: string | number) => {
            const response = await userService.getUser(id);
            return response;
        },
        {
            onError: (error) => {
                showErrorWithDetails('Failed to fetch user', error.message);
                console.error('Get user error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Create user
    const { execute: createUser, loading: createLoading, error: createError } = useApi(
        async (data: CreateUserRequest) => {
            const response = await userService.createUser(data);
            // Refresh users list
            await getUsers();
            return response;
        },
        {
            onSuccess: () => {
                showSuccess('User created successfully');
            },
            onError: (error) => {
                if (error.errors) {
                    // Handle validation errors
                    Object.entries(error.errors).forEach(([field, messages]) => {
                        showErrorWithDetails(`${field}: ${messages.join(', ')}`);
                    });
                } else {
                    showErrorWithDetails('Failed to create user', error.message);
                }
                console.error('Create user error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Update user
    const { execute: updateUser, loading: updateLoading, error: updateError } = useApi(
        async ({ id, data }: { id: string | number; data: UpdateUserRequest }) => {
            const response = await userService.updateUser(id, data);
            // Refresh users list
            await getUsers();
            return response;
        },
        {
            onSuccess: () => {
                showSuccess('User updated successfully');
            },
            onError: (error) => {
                if (error.errors) {
                    // Handle validation errors
                    Object.entries(error.errors).forEach(([field, messages]) => {
                        showErrorWithDetails(`${field}: ${messages.join(', ')}`);
                    });
                } else {
                    showErrorWithDetails('Failed to update user', error.message);
                }
                console.error('Update user error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Delete user
    const { execute: deleteUser, loading: deleteLoading, error: deleteError } = useApi(
        async (id: string | number) => {
            const response = await userService.deleteUser(id);
            // Refresh users list
            await getUsers();
            return response;
        },
        {
            onSuccess: () => {
                showSuccess('User deleted successfully');
            },
            onError: (error) => {
                showErrorWithDetails('Failed to delete user', error.message);
                console.error('Delete user error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Activate user
    const { execute: activateUser, loading: activateLoading } = useApi(
        async (id: string | number) => {
            const response = await userService.activateUser(id);
            // Refresh users list
            await getUsers();
            return response;
        },
        {
            onSuccess: () => {
                showSuccess('User activated successfully');
            },
            onError: (error) => {
                showErrorWithDetails('Failed to activate user', error.message);
                console.error('Activate user error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Deactivate user
    const { execute: deactivateUser, loading: deactivateLoading } = useApi(
        async (id: string | number) => {
            const response = await userService.deactivateUser(id);
            // Refresh users list
            await getUsers();
            return response;
        },
        {
            onSuccess: () => {
                showSuccess('User deactivated successfully');
            },
            onError: (error) => {
                showErrorWithDetails('Failed to deactivate user', error.message);
                console.error('Deactivate user error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Update user password
    const { execute: updateUserPassword, loading: passwordLoading } = useApi(
        async ({ id, data }: { id: number; data: { currentPassword: string; newPassword: string; confirmPassword: string } }) => {
            const response = await userService.updateUserPassword(id, data);
            return response;
        },
        {
            onSuccess: () => {
                showSuccess('Password updated successfully');
            },
            onError: (error) => {
                if (error.errors) {
                    Object.entries(error.errors).forEach(([field, messages]) => {
                        showErrorWithDetails(`${field}: ${messages.join(', ')}`);
                    });
                } else {
                    showErrorWithDetails('Failed to update password', error.message);
                }
                console.error('Update password error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Search users
    const { execute: searchUsers, loading: searchLoading } = useApi(
        async ({ query, filters }: { query: string; filters?: any }) => {
            const response = await userService.searchUsers(query, filters);
            setUsers(response.data);
            if (response.meta) {
                setPagination(response.meta);
            }
            return response;
        },
        {
            onError: (error) => {
                showErrorWithDetails('Failed to search users', error.message);
                console.error('Search users error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Get users by role
    const { execute: getUsersByRole, loading: roleLoading } = useApi(
        async ({ role, filters }: { role: string; filters?: any }) => {
            const response = await userService.getUsersByRole(role, filters);
            setUsers(response.data);
            if (response.meta) {
                setPagination(response.meta);
            }
            return response;
        },
        {
            onError: (error) => {
                showErrorWithDetails('Failed to fetch users by role', error.message);
                console.error('Get users by role error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Get user stats
    const { execute: getUserStats, loading: statsLoading, error: statsError } = useApi(
        async (filters?: { startDate?: string; endDate?: string }) => {
            const response = await userService.getUserStats(filters);
            return response;
        },
        {
            onError: (error) => {
                showErrorWithDetails('Failed to fetch user statistics', error.message);
                console.error('Get user stats error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Bulk update users
    const { execute: bulkUpdateUsers, loading: bulkUpdateLoading } = useApi(
        async ({ userIds, updateData }: { userIds: number[]; updateData: Partial<UpdateUserRequest> }) => {
            const response = await userService.bulkUpdateUsers(userIds, updateData);
            // Refresh users list
            await getUsers();
            return response;
        },
        {
            onSuccess: (data) => {
                showSuccess(`${data.data.modifiedCount} users updated successfully`);
            },
            onError: (error) => {
                showErrorWithDetails('Failed to bulk update users', error.message);
                console.error('Bulk update users error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Bulk delete users
    const { execute: bulkDeleteUsers, loading: bulkDeleteLoading } = useApi(
        async (userIds: number[]) => {
            const response = await userService.bulkDeleteUsers(userIds);
            // Refresh users list
            await getUsers();
            return response;
        },
        {
            onSuccess: (data) => {
                showSuccess(`${data.data.deletedCount} users deleted successfully`);
            },
            onError: (error) => {
                showErrorWithDetails('Failed to bulk delete users', error.message);
                console.error('Bulk delete users error:', error);
            },
            showErrorAlert: false,
        }
    );

    // Helper function to refresh users list
    const refreshUsers = useCallback(async (filters?: UserFilters) => {
        await getUsers(filters);
    }, [getUsers]);

    return {
        // State
        users,
        pagination,

        // Loading states
        usersLoading,
        userLoading,
        createLoading,
        updateLoading,
        deleteLoading,
        activateLoading,
        deactivateLoading,
        passwordLoading,
        searchLoading,
        roleLoading,
        statsLoading,
        bulkUpdateLoading,
        bulkDeleteLoading,

        // Error states
        usersError,
        userError,
        createError,
        updateError,
        deleteError,
        statsError,

        // Actions
        getUsers,
        getUser,
        createUser,
        updateUser,
        deleteUser,
        activateUser,
        deactivateUser,
        updateUserPassword,
        searchUsers,
        getUsersByRole,
        getUserStats,
        bulkUpdateUsers,
        bulkDeleteUsers,
        refreshUsers,
    };
};