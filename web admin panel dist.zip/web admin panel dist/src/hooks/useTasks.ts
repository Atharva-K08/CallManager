import { useCallback, useMemo, useState } from 'react';
import taskService, { CreateTaskRequest, Task, TaskFilters, TaskListResponse, UpdateTaskRequest } from '../services/task.service';
import { useApi } from './useApi';
import { useToastNotifications } from '../lib/toast';

export function useTasks() {
    const { showSuccess, showErrorWithDetails } = useToastNotifications();

    const [listData, setListData] = useState<TaskListResponse | null>(null);
    const [filters, setFilters] = useState<TaskFilters>({ page: 1, limit: 10, sortBy: 'createdAt:desc' });

    const listApi = useApi(taskService.list, {
        onSuccess: (data) => setListData(data),
        onError: (err) => showErrorWithDetails('Failed to fetch tasks', err?.message),
    });

    const createApi = useApi(taskService.create, {
        onSuccess: () => { showSuccess('Task created'); refresh(); },
        onError: (err) => showErrorWithDetails('Failed to create task', err?.message),
    });

    const updateApi = useApi(taskService.update, {
        onSuccess: () => { showSuccess('Task updated'); refresh(); },
        onError: (err) => showErrorWithDetails('Failed to update task', err?.message),
    });

    const removeApi = useApi(taskService.remove, {
        onSuccess: () => { showSuccess('Task deleted'); refresh(); },
        onError: (err) => showErrorWithDetails('Failed to delete task', err?.message),
    });

    const setStatusApi = useApi(taskService.setStatus, {
        onSuccess: () => { showSuccess('Task status updated'); refresh(); },
        onError: (err) => showErrorWithDetails('Failed to update status', err?.message),
    });

    const incrementApi = useApi(taskService.incrementProgress, {
        onSuccess: () => { showSuccess('Task progress updated'); refresh(); },
        onError: (err) => showErrorWithDetails('Failed to update progress', err?.message),
    });

    const getByIdApi = useApi(taskService.getById, {
        onError: (err) => showErrorWithDetails('Failed to fetch task', err?.message),
    });

    const fetch = useCallback(async (custom?: Partial<TaskFilters>) => {
        const next = { ...filters, ...(custom || {}) };
        setFilters(next);
        await listApi.execute(next);
    }, [filters, listApi]);

    const refresh = useCallback(async () => { await listApi.execute(filters); }, [filters, listApi]);

    const create = useCallback(async (payload: CreateTaskRequest) => { await createApi.execute(payload); }, [createApi]);
    const update = useCallback(async (id: string, payload: UpdateTaskRequest) => { await updateApi.execute(id, payload); }, [updateApi]);
    const remove = useCallback(async (id: string) => { await removeApi.execute(id); }, [removeApi]);
    const setStatus = useCallback(async (id: string, status: Task['status']) => { await setStatusApi.execute(id, status); }, [setStatusApi]);
    const increment = useCallback(async (id: string, by = 1) => { await incrementApi.execute(id, by); }, [incrementApi]);
    const getTaskById = useCallback(async (id: string) => { return await getByIdApi.execute(id); }, [getByIdApi]);

    const loading = useMemo(() => listApi.loading || createApi.loading || updateApi.loading || removeApi.loading || setStatusApi.loading || incrementApi.loading || getByIdApi.loading, [listApi.loading, createApi.loading, updateApi.loading, removeApi.loading, setStatusApi.loading, incrementApi.loading, getByIdApi.loading]);

    return { data: listData, filters, fetch, refresh, create, update, remove, setStatus, increment, getTaskById, loading, error: listApi.error || createApi.error || updateApi.error || removeApi.error || setStatusApi.error || incrementApi.error || getByIdApi.error };
}

export default useTasks;


