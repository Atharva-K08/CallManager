import { useState, useCallback } from 'react';
import { useToast } from '../contexts/ToastContext';
import { callRecordService, CallRecord, CallRecordFilters, CallRecordListResponse, CallStatistics, CreateCallRecordRequest, UpdateCallRecordRequest } from '../services/callRecord.service';

export interface UseCallRecordsReturn {
    data: CallRecordListResponse | null;
    statistics: CallStatistics | null;
    loading: boolean;
    error: string | null;
    currentFilters: CallRecordFilters;
    fetch: (filters?: CallRecordFilters) => Promise<void>;
    fetchStatistics: (filters?: Partial<CallRecordFilters>) => Promise<void>;
    create: (data: CreateCallRecordRequest) => Promise<CallRecord>;
    update: (id: string, data: UpdateCallRecordRequest) => Promise<CallRecord>;
    delete: (id: string) => Promise<void>;
    updateStatus: (id: string, status: string) => Promise<CallRecord>;
    getByPhoneNumber: (phoneNumber: string) => Promise<CallRecord[]>;
    getByLeadId: (leadId: string) => Promise<CallRecord[]>;
    setFilters: (filters: CallRecordFilters) => void;
    clearFilters: () => void;
}

export const useCallRecords = (initialFilters?: CallRecordFilters): UseCallRecordsReturn => {
    const [data, setData] = useState<CallRecordListResponse | null>(null);
    const [statistics, setStatistics] = useState<CallStatistics | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [currentFilters, setCurrentFilters] = useState<CallRecordFilters>(initialFilters || {});

    const { addToast } = useToast();

    const fetch = useCallback(async (filters?: CallRecordFilters) => {
        try {
            setLoading(true);
            setError(null);
            const filtersToUse = filters || currentFilters;
            const response = await callRecordService.getCallRecords(filtersToUse);
            console.log('useCallRecords - response:', response); // Debug log
            setData(response);
            setCurrentFilters(filtersToUse);
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to fetch call records';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
        } finally {
            setLoading(false);
        }
    }, [currentFilters, addToast]);

    const fetchStatistics = useCallback(async (filters?: Partial<CallRecordFilters>) => {
        try {
            setError(null);
            const response = await callRecordService.getCallStatistics(filters);
            setStatistics(response);
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to fetch call statistics';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
        }
    }, [addToast]);

    const create = useCallback(async (data: CreateCallRecordRequest): Promise<CallRecord> => {
        try {
            setError(null);
            const response = await callRecordService.createCallRecord(data);
            addToast({ type: 'success', title: 'Success', description: 'Call record created successfully' });
            // Refresh the list
            await fetch();
            return response;
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to create call record';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
            throw err;
        }
    }, [fetch, addToast]);

    const update = useCallback(async (id: string, data: UpdateCallRecordRequest): Promise<CallRecord> => {
        try {
            setError(null);
            const response = await callRecordService.updateCallRecord(id, data);
            addToast({ type: 'success', title: 'Success', description: 'Call record updated successfully' });
            // Refresh the list
            await fetch();
            return response;
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to update call record';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
            throw err;
        }
    }, [fetch, addToast]);

    const deleteRecord = useCallback(async (id: string): Promise<void> => {
        try {
            setError(null);
            await callRecordService.deleteCallRecord(id);
            addToast({ type: 'success', title: 'Success', description: 'Call record deleted successfully' });
            // Refresh the list
            await fetch();
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to delete call record';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
            throw err;
        }
    }, [fetch, addToast]);

    const updateStatus = useCallback(async (id: string, status: string): Promise<CallRecord> => {
        try {
            setError(null);
            const response = await callRecordService.updateCallRecordStatus(id, status);
            addToast({ type: 'success', title: 'Success', description: 'Call record status updated successfully' });
            // Refresh the list
            await fetch();
            return response;
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to update call record status';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
            throw err;
        }
    }, [fetch, addToast]);

    const getByPhoneNumber = useCallback(async (phoneNumber: string): Promise<CallRecord[]> => {
        try {
            setError(null);
            const response = await callRecordService.getCallRecordsByPhoneNumber(phoneNumber);
            return response;
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to fetch call records by phone number';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
            throw err;
        }
    }, [addToast]);

    const getByLeadId = useCallback(async (leadId: string): Promise<CallRecord[]> => {
        try {
            setError(null);
            const response = await callRecordService.getCallRecordsByLeadId(leadId);
            return response;
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to fetch call records by lead ID';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
            throw err;
        }
    }, [addToast]);

    const setFilters = useCallback((filters: CallRecordFilters) => {
        setCurrentFilters(filters);
    }, []);

    const clearFilters = useCallback(() => {
        setCurrentFilters({});
    }, []);

    return {
        data,
        statistics,
        loading,
        error,
        currentFilters,
        fetch,
        fetchStatistics,
        create,
        update,
        delete: deleteRecord,
        updateStatus,
        getByPhoneNumber,
        getByLeadId,
        setFilters,
        clearFilters,
    };
};
