import { useState, useCallback } from 'react';
import { ApiError } from '../types/api.types';
import { getErrorMessage } from '../utils/error-handler';
import { showToast } from '../lib/toast';

interface UseApiOptions<T> {
    onSuccess?: (data: T) => void;
    onError?: (error: ApiError) => void;
    showErrorAlert?: boolean;
}

interface UseApiReturn<T, P extends any[]> {
    data: T | null;
    error: ApiError | null;
    loading: boolean;
    execute: (...args: P) => Promise<T | undefined>;
    reset: () => void;
}

/**
 * Generic hook for API calls
 */
export function useApi<T, P extends any[] = []>(
    apiFunction: (...args: P) => Promise<T>,
    options: UseApiOptions<T> = {}
): UseApiReturn<T, P> {
    const [data, setData] = useState<T | null>(null);
    const [error, setError] = useState<ApiError | null>(null);
    const [loading, setLoading] = useState(false);

    const execute = useCallback(
        async (...args: P): Promise<T | undefined> => {
            setLoading(true);
            setError(null);

            try {
                const result = await apiFunction(...args);
                setData(result);
                options.onSuccess?.(result);
                return result;
            } catch (err) {
                const apiError = err as ApiError;
                setError(apiError);
                options.onError?.(apiError);

                if (options.showErrorAlert !== false) {
                    showToast.error(getErrorMessage(apiError));
                }
                return undefined;
            } finally {
                setLoading(false);
            }
        },
        [apiFunction, options]
    );

    const reset = useCallback(() => {
        setData(null);
        setError(null);
        setLoading(false);
    }, []);

    return { data, error, loading, execute, reset };
}

/**
 * Hook for API calls that auto-execute on mount
 */
export function useApiOnMount<T, P extends any[] = []>(
    apiFunction: (...args: P) => Promise<T>,
    args: P,
    options: UseApiOptions<T> = {}
): UseApiReturn<T, P> {
    const api = useApi(apiFunction, options);

    // Auto-execute on mount
    useState(() => {
        api.execute(...args);
    });

    return api;
}
