import { useState, useEffect, useCallback } from 'react';
import { settingsService } from '../services/settings.service';
import { UserSettings, CategorySettings, Setting } from '../types/settings.types';
import { useToastNotifications } from '../lib/toast';

interface UseSettingsReturn {
    // State
    settings: UserSettings | null;
    loading: boolean;
    error: Error | null;

    // Actions
    refresh: () => Promise<void>;
    getSetting: <T = any>(category: string, key: string, defaultValue?: T) => Promise<T>;
    setSetting: (category: string, key: string, value: any, options?: any) => Promise<void>;
    setCategorySettings: (category: string, settings: Record<string, any>) => Promise<void>;
    deleteSetting: (category: string, key: string) => Promise<void>;
    getCategory: (category: string) => CategorySettings | null;
}

/**
 * Hook for managing user settings
 */
export const useSettings = (): UseSettingsReturn => {
    const [settings, setSettings] = useState<UserSettings | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<Error | null>(null);
    const { showSuccess, showError } = useToastNotifications();

    const loadSettings = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);
            const data = await settingsService.getUserSettings();
            setSettings(data);
        } catch (err: any) {
            setError(err);
            console.error('Failed to load settings:', err);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        loadSettings();
    }, [loadSettings]);

    const refresh = useCallback(async () => {
        await loadSettings();
    }, [loadSettings]);

    const getSetting = useCallback(
        async <T = any>(category: string, key: string, defaultValue?: T): Promise<T> => {
            try {
                // First check cached settings
                if (settings && settings[category] && settings[category][key] !== undefined) {
                    return settings[category][key] as T;
                }

                // Fetch from API
                const value = await settingsService.getSetting<T>(category, key, defaultValue);
                
                // Update cache
                setSettings((prev) => {
                    if (!prev) return prev;
                    return {
                        ...prev,
                        [category]: {
                            ...prev[category],
                            [key]: value,
                        },
                    };
                });

                return value;
            } catch (err: any) {
                console.error(`Failed to get setting ${category}.${key}:`, err);
                return defaultValue as T;
            }
        },
        [settings]
    );

    const setSetting = useCallback(
        async (category: string, key: string, value: any, options?: any) => {
            try {
                await settingsService.setSetting(category, key, value, options);
                
                // Update cache
                setSettings((prev) => {
                    if (!prev) {
                        return { [category]: { [key]: value } };
                    }
                    return {
                        ...prev,
                        [category]: {
                            ...prev[category],
                            [key]: value,
                        },
                    };
                });

                showSuccess('Setting updated successfully');
            } catch (err: any) {
                showError('Failed to update setting');
                throw err;
            }
        },
        [showSuccess, showError]
    );

    const setCategorySettings = useCallback(
        async (category: string, newSettings: Record<string, any>) => {
            try {
                await settingsService.setCategorySettings(category, newSettings);
                
                // Update cache
                setSettings((prev) => ({
                    ...prev,
                    [category]: {
                        ...prev?.[category],
                        ...newSettings,
                    },
                }));

                showSuccess('Settings updated successfully');
            } catch (err: any) {
                showError('Failed to update settings');
                throw err;
            }
        },
        [showSuccess, showError]
    );

    const deleteSetting = useCallback(
        async (category: string, key: string) => {
            try {
                await settingsService.deleteSetting(category, key);
                
                // Update cache - remove the key
                setSettings((prev) => {
                    if (!prev || !prev[category]) return prev;
                    const { [key]: removed, ...rest } = prev[category];
                    return {
                        ...prev,
                        [category]: rest,
                    };
                });

                showSuccess('Setting deleted successfully');
            } catch (err: any) {
                showError('Failed to delete setting');
                throw err;
            }
        },
        [showSuccess, showError]
    );

    const getCategory = useCallback(
        (category: string): CategorySettings | null => {
            return settings?.[category] || null;
        },
        [settings]
    );

    return {
        settings,
        loading,
        error,
        refresh,
        getSetting,
        setSetting,
        setCategorySettings,
        deleteSetting,
        getCategory,
    };
};

/**
 * Hook for a specific category of settings
 */
export const useCategorySettings = (category: string) => {
    const { getCategory, setCategorySettings, loading, error } = useSettings();
    const categorySettings = getCategory(category);

    const updateCategory = useCallback(
        async (newSettings: Record<string, any>) => {
            await setCategorySettings(category, newSettings);
        },
        [category, setCategorySettings]
    );

    return {
        settings: categorySettings,
        loading,
        error,
        updateCategory,
    };
};

/**
 * Hook for a single setting
 */
export const useSetting = <T = any>(
    category: string,
    key: string,
    defaultValue?: T
) => {
    const { getSetting, setSetting, loading } = useSettings();
    const [value, setValue] = useState<T | undefined>(defaultValue);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const loadValue = async () => {
            setIsLoading(true);
            const settingValue = await getSetting<T>(category, key, defaultValue);
            setValue(settingValue);
            setIsLoading(false);
        };
        loadValue();
    }, [category, key, defaultValue, getSetting]);

    const update = useCallback(
        async (newValue: T) => {
            await setSetting(category, key, newValue);
            setValue(newValue);
        },
        [category, key, setSetting]
    );

    return {
        value: value ?? defaultValue,
        isLoading: isLoading || loading,
        update,
    };
};

