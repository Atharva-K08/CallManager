import { useApi } from './useApi';
import { reportService } from '../services';
import { ReportFilters } from '../types/api.types';

export function useReports() {
    const getOverviewReportApi = useApi(reportService.getOverviewReport);
    const getReportByUserApi = useApi(reportService.getReportByUser);
    const getReportByTimeApi = useApi(reportService.getReportByTime);
    const exportPDFApi = useApi(reportService.exportPDF);
    const exportExcelApi = useApi(reportService.exportExcel);

    return {
        // Get overview report
        getOverviewReport: getOverviewReportApi.execute,
        overviewData: getOverviewReportApi.data,
        overviewLoading: getOverviewReportApi.loading,

        // Get report by user
        getReportByUser: getReportByUserApi.execute,
        userReportData: getReportByUserApi.data,
        userReportLoading: getReportByUserApi.loading,

        // Get report by time
        getReportByTime: getReportByTimeApi.execute,
        timeReportData: getReportByTimeApi.data,
        timeReportLoading: getReportByTimeApi.loading,

        // Export PDF
        exportPDF: exportPDFApi.execute,
        exportPDFLoading: exportPDFApi.loading,

        // Export Excel
        exportExcel: exportExcelApi.execute,
        exportExcelLoading: exportExcelApi.loading,

        // Combined loading state
        loading:
            getOverviewReportApi.loading ||
            getReportByUserApi.loading ||
            getReportByTimeApi.loading ||
            exportPDFApi.loading ||
            exportExcelApi.loading,
    };
}
