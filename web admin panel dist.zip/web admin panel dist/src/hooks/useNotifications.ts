import { useEffect } from 'react';
import { useNotificationStore } from '../stores/notification.store';
import notificationService from '../services/notification.service';

/**
 * Hook to manage notifications
 */
export function useNotifications() {
    const {
        notifications,
        unreadCount,
        soundEnabled,
        desktopEnabled,
        addNotification,
        markAsRead,
        markAllAsRead,
        removeNotification,
        clearAll,
        toggleSound,
        toggleDesktop,
        getUnreadNotifications,
    } = useNotificationStore();

    return {
        notifications,
        unreadCount,
        soundEnabled,
        desktopEnabled,
        addNotification,
        markAsRead,
        markAllAsRead,
        removeNotification,
        clearAll,
        toggleSound,
        toggleDesktop,
        getUnreadNotifications,
        // WebSocket methods
        sendTestNotification: () => notificationService.sendTestNotification(),
        isConnected: () => notificationService.isConnected(),
    };
}

/**
 * Hook to initialize real-time notifications
 */
export function useRealTimeNotifications(token?: string) {
    useEffect(() => {
        if (token) {
            notificationService.initialize(token);

            return () => {
                notificationService.disconnect();
            };
        }
    }, [token]);

    return {
        isConnected: notificationService.isConnected(),
        emit: notificationService.emit.bind(notificationService),
        on: notificationService.on.bind(notificationService),
        off: notificationService.off.bind(notificationService),
    };
}
