import { useState, useEffect } from 'react';
import showToast from '../lib/toast';

interface OnlineStatusOptions {
    showToast?: boolean;
    onOnline?: () => void;
    onOffline?: () => void;
}

/**
 * Hook to detect online/offline status
 */
export function useOnlineStatus(options: OnlineStatusOptions = {}) {
    const { showToast: showToastNotification = true, onOnline, onOffline } = options;
    const [isOnline, setIsOnline] = useState(navigator.onLine);
    const [wasOffline, setWasOffline] = useState(false);

    useEffect(() => {
        const handleOnline = () => {
            setIsOnline(true);

            if (wasOffline && showToastNotification) {
                showToast.success('Back online! Connection restored.');
            }

            setWasOffline(false);
            onOnline?.();
        };

        const handleOffline = () => {
            setIsOnline(false);
            setWasOffline(true);

            if (showToastNotification) {
                showToast.error('You are offline. Some features may not work.', {
                    duration: 10000,
                });
            }

            onOffline?.();
        };

        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);

        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, [wasOffline, showToastNotification, onOnline, onOffline]);

    return { isOnline, wasOffline };
}

/**
 * Hook to retry failed requests when back online
 */
export function useRetryOnOnline(retryFn: () => void | Promise<void>) {
    const { isOnline, wasOffline } = useOnlineStatus({
        showToast: false,
    });

    useEffect(() => {
        if (isOnline && wasOffline) {
            // Retry after coming back online
            const timeoutId = setTimeout(() => {
                retryFn();
            }, 1000);

            return () => clearTimeout(timeoutId);
        }
    }, [isOnline, wasOffline, retryFn]);

    return { isOnline };
}
