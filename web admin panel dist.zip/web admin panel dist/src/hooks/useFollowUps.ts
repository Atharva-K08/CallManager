import { useState, useEffect } from 'react';
import { followUpService, FollowUp, FollowUpListResponse, CreateFollowUpRequest, UpdateFollowUpRequest, FollowUpFilters } from '../services/followUp.service';
import { useToast } from '../contexts/ToastContext';

interface UseFollowUpsReturn {
    data: FollowUpListResponse | null;
    loading: boolean;
    error: string | null;
    fetch: (filters?: FollowUpFilters) => Promise<void>;
    create: (data: CreateFollowUpRequest) => Promise<FollowUp>;
    update: (id: string, data: UpdateFollowUpRequest) => Promise<FollowUp>;
    delete: (id: string) => Promise<void>;
    markAsDone: (id: string) => Promise<FollowUp>;
    markAsCancelled: (id: string) => Promise<FollowUp>;
    refresh: () => Promise<void>;
}

export const useFollowUps = (initialFilters?: FollowUpFilters): UseFollowUpsReturn => {
    const [data, setData] = useState<FollowUpListResponse | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [currentFilters, setCurrentFilters] = useState<FollowUpFilters>(initialFilters || {});
    const { addToast } = useToast();

    const fetch = async (filters?: FollowUpFilters) => {
        try {
            setLoading(true);
            setError(null);
            const filtersToUse = { ...currentFilters, ...filters };
            setCurrentFilters(filtersToUse);

            const response = await followUpService.getFollowUps(filtersToUse);
            console.log('useFollowUps - response:', response);
            setData(response);
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to fetch follow-ups';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
        } finally {
            setLoading(false);
        }
    };

    const create = async (data: CreateFollowUpRequest): Promise<FollowUp> => {
        try {
            setLoading(true);
            setError(null);

            const newFollowUp = await followUpService.createFollowUp(data);

            // Refresh the list to include the new follow-up
            await fetch(currentFilters);

            addToast({ type: 'success', title: 'Success', description: 'Follow-up created successfully' });
            return newFollowUp;
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to create follow-up';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
            throw err;
        } finally {
            setLoading(false);
        }
    };

    const update = async (id: string, data: UpdateFollowUpRequest): Promise<FollowUp> => {
        try {
            setLoading(true);
            setError(null);

            const updatedFollowUp = await followUpService.updateFollowUp(id, data);

            // Refresh the list to show updated data
            await fetch(currentFilters);

            addToast({ type: 'success', title: 'Success', description: 'Follow-up updated successfully' });
            return updatedFollowUp;
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to update follow-up';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
            throw err;
        } finally {
            setLoading(false);
        }
    };

    const deleteFollowUp = async (id: string): Promise<void> => {
        try {
            setLoading(true);
            setError(null);

            await followUpService.deleteFollowUp(id);

            // Refresh the list to remove the deleted follow-up
            await fetch(currentFilters);

            addToast({ type: 'success', title: 'Success', description: 'Follow-up deleted successfully' });
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to delete follow-up';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
            throw err;
        } finally {
            setLoading(false);
        }
    };

    const markAsDone = async (id: string): Promise<FollowUp> => {
        try {
            setLoading(true);
            setError(null);

            const updatedFollowUp = await followUpService.markAsDone(id);

            // Refresh the list to show updated status
            await fetch(currentFilters);

            addToast({ type: 'success', title: 'Success', description: 'Follow-up marked as done' });
            return updatedFollowUp;
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to mark follow-up as done';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
            throw err;
        } finally {
            setLoading(false);
        }
    };

    const markAsCancelled = async (id: string): Promise<FollowUp> => {
        try {
            setLoading(true);
            setError(null);

            const updatedFollowUp = await followUpService.markAsCancelled(id);

            // Refresh the list to show updated status
            await fetch(currentFilters);

            addToast({ type: 'success', title: 'Success', description: 'Follow-up marked as cancelled' });
            return updatedFollowUp;
        } catch (err: any) {
            const errorMessage = err?.response?.data?.message || err?.message || 'Failed to mark follow-up as cancelled';
            setError(errorMessage);
            addToast({ type: 'error', title: 'Error', description: errorMessage });
            throw err;
        } finally {
            setLoading(false);
        }
    };

    const refresh = async (): Promise<void> => {
        await fetch(currentFilters);
    };

    // Initial fetch
    useEffect(() => {
        fetch(initialFilters);
    }, []);

    return {
        data,
        loading,
        error,
        fetch,
        create,
        update,
        delete: deleteFollowUp,
        markAsDone,
        markAsCancelled,
        refresh,
    };
};

export default useFollowUps;
