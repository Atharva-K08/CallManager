import { useCallback, useMemo, useState } from 'react';
import leadService, { CreateLeadRequest, Lead, LeadFilters, LeadListResponse, UpdateLeadRequest } from '../services/lead.service';
import { useApi } from './useApi';
import { useToastNotifications } from '../lib/toast';

export function useLeads() {
    const { showSuccess, showErrorWithDetails } = useToastNotifications();

    const [listData, setListData] = useState<LeadListResponse | null>(null);
    const [filters, setFilters] = useState<LeadFilters>({ page: 1, limit: 10, sortBy: 'updatedAt:desc' });

    const listApi = useApi(leadService.list, {
        onSuccess: (data) => setListData(data),
        onError: (err) => showErrorWithDetails('Failed to fetch leads', err?.message),
    });

    const createApi = useApi(leadService.create, {
        onSuccess: () => { showSuccess('Lead created'); refresh(); },
        onError: (err) => showErrorWithDetails('Failed to create lead', err?.message),
    });

    const updateApi = useApi(leadService.update, {
        onSuccess: () => { showSuccess('Lead updated'); refresh(); },
        onError: (err) => showErrorWithDetails('Failed to update lead', err?.message),
    });

    const removeApi = useApi(leadService.remove, {
        onSuccess: () => { showSuccess('Lead deleted'); refresh(); },
        onError: (err) => showErrorWithDetails('Failed to delete lead', err?.message),
    });

    const updateStatusApi = useApi(leadService.updateStatus, {
        onSuccess: () => { showSuccess('Status updated'); refresh(); },
        onError: (err) => showErrorWithDetails('Failed to update status', err?.message),
    });

    const updateCallStatusApi = useApi(leadService.updateCallStatus, {
        onSuccess: () => { showSuccess('Call status updated'); refresh(); },
        onError: (err) => showErrorWithDetails('Failed to update call status', err?.message),
    });

    const fetch = useCallback(async (custom?: Partial<LeadFilters>) => {
        const next = { ...filters, ...(custom || {}) };
        setFilters(next);
        await listApi.execute(next);
    }, [filters, listApi]);

    const refresh = useCallback(async () => {
        await listApi.execute(filters);
    }, [filters, listApi]);

    const create = useCallback(async (payload: CreateLeadRequest) => { await createApi.execute(payload); }, [createApi]);
    const update = useCallback(async (id: string, payload: UpdateLeadRequest) => { await updateApi.execute(id, payload); }, [updateApi]);
    const remove = useCallback(async (id: string) => { await removeApi.execute(id); }, [removeApi]);
    const updateStatus = useCallback(async (id: string, status: string, remark?: string) => { await updateStatusApi.execute(id, status, remark); }, [updateStatusApi]);
    const updateCallStatus = useCallback(async (id: string, callStatus: string) => { await updateCallStatusApi.execute(id, callStatus); }, [updateCallStatusApi]);

    const loading = useMemo(() => listApi.loading || createApi.loading || updateApi.loading || removeApi.loading || updateStatusApi.loading || updateCallStatusApi.loading, [listApi.loading, createApi.loading, updateApi.loading, removeApi.loading, updateStatusApi.loading, updateCallStatusApi.loading]);

    return { data: listData, filters, fetch, refresh, create, update, remove, updateStatus, updateCallStatus, loading, error: listApi.error || createApi.error || updateApi.error || removeApi.error || updateStatusApi.error || updateCallStatusApi.error };
}

export default useLeads;


