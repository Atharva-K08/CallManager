import { useCallback, useMemo, useState } from 'react';
import leadStatusService, { CreateLeadStatusRequest, LeadStatusFilters, LeadStatusListResponse, UpdateLeadStatusRequest } from '../services/leadStatus.service';
import { useApi } from './useApi';
import { useToastNotifications } from '../lib/toast';

export function useLeadStatus() {
    const { showSuccess, showErrorWithDetails } = useToastNotifications();

    const [listData, setListData] = useState<LeadStatusListResponse | null>(null);
    const [filters, setFilters] = useState<LeadStatusFilters>({ page: 1, limit: 10, sortBy: 'order:asc' });

    const listApi = useApi(leadStatusService.list, {
        onSuccess: (data) => setListData(data),
        onError: (err) => showErrorWithDetails('Failed to fetch lead statuses', err?.message),
    });

    const createApi = useApi(leadStatusService.create, {
        onSuccess: () => {
            showSuccess('Lead status created');
            refresh();
        },
        onError: (err) => showErrorWithDetails('Failed to create lead status', err?.message),
    });

    const updateApi = useApi(leadStatusService.update, {
        onSuccess: () => {
            showSuccess('Lead status updated');
            refresh();
        },
        onError: (err) => showErrorWithDetails('Failed to update lead status', err?.message),
    });

    const removeApi = useApi(leadStatusService.remove, {
        onSuccess: () => {
            showSuccess('Lead status deleted');
            refresh();
        },
        onError: (err) => showErrorWithDetails('Failed to delete lead status', err?.message),
    });

    const activateApi = useApi(leadStatusService.activate, {
        onSuccess: () => {
            showSuccess('Lead status activated');
            refresh();
        },
        onError: (err) => showErrorWithDetails('Failed to activate lead status', err?.message),
    });

    const deactivateApi = useApi(leadStatusService.deactivate, {
        onSuccess: () => {
            showSuccess('Lead status deactivated');
            refresh();
        },
        onError: (err) => showErrorWithDetails('Failed to deactivate lead status', err?.message),
    });

    const fetch = useCallback(async (custom?: Partial<LeadStatusFilters>) => {
        const next = { ...filters, ...(custom || {}) };
        setFilters(next);
        await listApi.execute(next);
    }, [filters, listApi]);

    const refresh = useCallback(async () => {
        await listApi.execute(filters);
    }, [filters, listApi]);

    const create = useCallback(async (payload: CreateLeadStatusRequest) => {
        await createApi.execute(payload);
    }, [createApi]);

    const update = useCallback(async (id: string, payload: UpdateLeadStatusRequest) => {
        await updateApi.execute(id, payload);
    }, [updateApi]);

    const remove = useCallback(async (id: string) => {
        await removeApi.execute(id);
    }, [removeApi]);

    const activate = useCallback(async (id: string) => {
        await activateApi.execute(id);
    }, [activateApi]);

    const deactivate = useCallback(async (id: string) => {
        await deactivateApi.execute(id);
    }, [deactivateApi]);

    const loading = useMemo(() => listApi.loading || createApi.loading || updateApi.loading || removeApi.loading || activateApi.loading || deactivateApi.loading, [listApi.loading, createApi.loading, updateApi.loading, removeApi.loading, activateApi.loading, deactivateApi.loading]);

    return {
        data: listData,
        filters,
        fetch,
        refresh,
        create,
        update,
        remove,
        activate,
        deactivate,
        loading,
        error: listApi.error || createApi.error || updateApi.error || removeApi.error || activateApi.error || deactivateApi.error,
    };
}

export default useLeadStatus;


