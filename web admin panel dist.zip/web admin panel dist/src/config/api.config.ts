export const API_CONFIG = {
    BASE_URL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/v1',
    TIMEOUT: parseInt(import.meta.env.VITE_API_TIMEOUT || '30000'),
    TOKEN_KEY: import.meta.env.VITE_TOKEN_KEY || 'call_tracker_token',
    REFRESH_TOKEN_KEY: import.meta.env.VITE_REFRESH_TOKEN_KEY || 'call_tracker_refresh_token',
};

export const API_ENDPOINTS = {
    // Auth
    AUTH: {
        LOGIN: '/auth/login',
        LOGOUT: '/auth/logout',
        REFRESH: '/auth/refresh',
        ME: '/auth/me',
    },
    // Users
    USERS: {
        LIST: '/users',
        CREATE: '/users',
        GET: (id: string | number) => `/users/${id}`,
        UPDATE: (id: string | number) => `/users/${id}`,
        DELETE: (id: string | number) => `/users/${id}`,
    },
    // Students
    LEADS: {
        LIST: '/leads',
        CREATE: '/leads',
        GET: (id: string) => `/leads/${id}`,
        UPDATE: (id: string) => `/leads/${id}`,
        DELETE: (id: string) => `/leads/${id}`,
        UPDATE_STATUS: (id: string) => `/leads/${id}/status`,
        UPDATE_CALL_STATUS: (id: string) => `/leads/${id}/call-status`,
        SYNC_UPLOAD: '/leads/sync/upload',
        SYNC_PULL: '/leads/sync/pull',
        IMPORT_SAMPLE: '/leads/import/sample',
        IMPORT_PREVIEW: '/leads/import/preview',
        IMPORT_CONFIRM: '/leads/import/confirm',
    },
    // Calls
    CALLS: {
        LIST: '/calls',
        CREATE: '/calls',
        GET: (id: number) => `/calls/${id}`,
        UPDATE: (id: number) => `/calls/${id}`,
        DELETE: (id: number) => `/calls/${id}`,
        STATS: '/calls/stats',
    },
    // Reports
    REPORTS: {
        OVERVIEW: '/reports/overview',
        BY_USER: '/reports/by-user',
        BY_TIME: '/reports/by-time',
        EXPORT_PDF: '/reports/export/pdf',
        EXPORT_EXCEL: '/reports/export/excel',
    },
    // Settings
    SETTINGS: {
        PROFILE: '/settings/profile',
        PASSWORD: '/settings/password',
        SYSTEM: '/settings/system',
    },
    // Lead Status
    LEAD_STATUS: {
        LIST: '/lead-status',
        CREATE: '/lead-status',
        GET: (id: string) => `/lead-status/${id}`,
        UPDATE: (id: string) => `/lead-status/${id}`,
        DELETE: (id: string) => `/lead-status/${id}`,
        GET_DEFAULT_IMPORT: '/lead-status/default-import',
        SET_DEFAULT_IMPORT: (id: string) => `/lead-status/${id}/default-import`,
    },
    // Tasks
    TASKS: {
        LIST: '/tasks',
        CREATE: '/tasks',
        HANDOVER: '/tasks/handover',
        GET: (id: string) => `/tasks/${id}`,
        UPDATE: (id: string) => `/tasks/${id}`,
        DELETE: (id: string) => `/tasks/${id}`,
        SET_STATUS: (id: string) => `/tasks/${id}/status`,
        INCREMENT_PROGRESS: (id: string) => `/tasks/${id}/progress`,
    },
};
