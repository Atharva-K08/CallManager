import { useToast } from '../contexts/ToastContext';

// Professional toast utilities
export const showToast = {
    success: (title: string, description?: string, duration?: number) => {
        // This will be used by the hook, not directly
        return { type: 'success', title, description, duration };
    },

    error: (title: string, description?: string, duration?: number) => {
        return { type: 'error', title, description, duration };
    },

    errorWithDetails: (genericMessage: string, apiMessage?: string, duration?: number) => {
        return {
            type: 'error' as const,
            title: genericMessage,
            description: apiMessage,
            duration: duration || 6000,
        };
    },

    warning: (title: string, description?: string, duration?: number) => {
        return { type: 'warning', title, description, duration };
    },

    info: (title: string, description?: string, duration?: number) => {
        return { type: 'info', title, description, duration };
    },

    loading: (title: string, description?: string, duration?: number) => {
        return { type: 'info', title, description, duration: duration || 0 }; // 0 means no auto-dismiss
    },

    promise: <T,>(
        promise: Promise<T>,
        _messages: {
            loading: string;
            success: string | ((data: T) => string);
            error: string | ((error: any) => string);
        },
        _options?: any
    ) => {
        // This will be handled by the hook
        return promise;
    },

    dismiss: (toastId?: string) => {
        // This will be handled by the hook
        console.log('Dismiss toast:', toastId);
    },

    custom: (component: React.ReactNode, options?: any) => {
        // This will be handled by the hook
        console.log('Custom toast:', component, options);
    },
};

// Hook for using toasts
export const useToastNotifications = () => {
    const { addToast, removeToast, clearAllToasts } = useToast();

    const showSuccess = (title: string, description?: string, duration?: number) => {
        addToast({ type: 'success', title, description, duration });
    };

    const showError = (title: string, description?: string, duration?: number) => {
        addToast({ type: 'error', title, description, duration });
    };

    const showErrorWithDetails = (genericMessage: string, apiMessage?: string, duration?: number) => {
        addToast({
            type: 'error',
            title: genericMessage,
            description: apiMessage,
            duration: duration || 6000,
        });
    };

    const showWarning = (title: string, description?: string, duration?: number) => {
        addToast({ type: 'warning', title, description, duration });
    };

    const showInfo = (title: string, description?: string, duration?: number) => {
        addToast({ type: 'info', title, description, duration });
    };

    const showLoading = (title: string, description?: string) => {
        addToast({ type: 'info', title, description, duration: 0 }); // No auto-dismiss
    };

    return {
        showSuccess,
        showError,
        showErrorWithDetails,
        showWarning,
        showInfo,
        showLoading,
        removeToast,
        clearAllToasts,
    };
};

export default showToast;
