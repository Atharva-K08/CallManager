import { io, Socket } from 'socket.io-client';

export interface WebSocketConfig {
    url: string;
    path: string;
    autoConnect: boolean;
}

export type WebSocketEventHandler = (data: any) => void;

class WebSocketClient {
    private socket: Socket | null = null;
    private reconnectAttempts = 0;
    private maxReconnectAttempts = 5;
    private reconnectDelay = 1000;
    private eventHandlers: Map<string, Set<WebSocketEventHandler>> = new Map();

    constructor(private config: WebSocketConfig) { }

    /**
     * Connect to WebSocket server
     */
    connect(token?: string): void {
        if (this.socket?.connected) {
            console.log('WebSocket already connected');
            return;
        }

        const socketOptions: any = {
            path: this.config.path,
            transports: ['websocket', 'polling'],
            autoConnect: this.config.autoConnect,
            reconnection: true,
            reconnectionDelay: this.reconnectDelay,
            reconnectionAttempts: this.maxReconnectAttempts,
        };

        // Add auth token if provided
        if (token) {
            socketOptions.auth = { token };
            socketOptions.extraHeaders = {
                Authorization: `Bearer ${token}`,
            };
        }

        this.socket = io(this.config.url, socketOptions);

        this.setupEventListeners();
    }

    /**
     * Disconnect from WebSocket server
     */
    disconnect(): void {
        if (this.socket) {
            this.socket.disconnect();
            this.socket = null;
            this.reconnectAttempts = 0;
        }
    }

    /**
     * Check if connected
     */
    isConnected(): boolean {
        return this.socket?.connected ?? false;
    }

    /**
     * Emit event to server
     */
    emit(event: string, data?: any): void {
        if (this.socket?.connected) {
            this.socket.emit(event, data);
        } else {
            console.warn('WebSocket not connected. Cannot emit event:', event);
        }
    }

    /**
     * Subscribe to event
     */
    on(event: string, handler: WebSocketEventHandler): void {
        // Store handler for potential reconnection
        if (!this.eventHandlers.has(event)) {
            this.eventHandlers.set(event, new Set());
        }
        this.eventHandlers.get(event)!.add(handler);

        // Register with socket if connected
        if (this.socket) {
            this.socket.on(event, handler);
        }
    }

    /**
     * Unsubscribe from event
     */
    off(event: string, handler?: WebSocketEventHandler): void {
        if (handler) {
            this.eventHandlers.get(event)?.delete(handler);
            if (this.socket) {
                this.socket.off(event, handler);
            }
        } else {
            this.eventHandlers.delete(event);
            if (this.socket) {
                this.socket.off(event);
            }
        }
    }

    /**
     * Subscribe to event once
     */
    once(event: string, handler: WebSocketEventHandler): void {
        if (this.socket) {
            this.socket.once(event, handler);
        }
    }

    /**
     * Setup default event listeners
     */
    private setupEventListeners(): void {
        if (!this.socket) return;

        this.socket.on('connect', () => {
            console.log('✅ WebSocket connected');
            this.reconnectAttempts = 0;
            this.resubscribeToEvents();
        });

        this.socket.on('disconnect', (reason: any) => {
            console.log('❌ WebSocket disconnected:', reason);
        });

        this.socket.on('connect_error', (error: any) => {
            console.error('WebSocket connection error:', error);
            this.reconnectAttempts++;

            if (this.reconnectAttempts >= this.maxReconnectAttempts) {
                console.error('Max reconnection attempts reached');
                this.disconnect();
            }
        });

        this.socket.on('error', (error: any) => {
            console.error('WebSocket error:', error);
        });

        this.socket.on('reconnect', (attemptNumber: any) => {
            console.log('WebSocket reconnected after', attemptNumber, 'attempts');
        });

        this.socket.on('reconnect_attempt', (attemptNumber: any) => {
            console.log('WebSocket reconnection attempt:', attemptNumber);
        });

        this.socket.on('reconnect_failed', () => {
            console.error('WebSocket reconnection failed');
        });
    }

    /**
     * Resubscribe to all events after reconnection
     */
    private resubscribeToEvents(): void {
        if (!this.socket) return;

        this.eventHandlers.forEach((handlers, event) => {
            handlers.forEach((handler) => {
                this.socket!.on(event, handler);
            });
        });
    }

    /**
     * Get socket instance (for advanced usage)
     */
    getSocket(): Socket | null {
        return this.socket;
    }
}

// Create singleton instance
const WS_URL = import.meta.env.VITE_WS_URL || 'http://localhost:8000/v1';
const WS_PATH = import.meta.env.VITE_WS_PATH || '/socket.io';

export const websocketClient = new WebSocketClient({
    url: WS_URL,
    path: WS_PATH,
    autoConnect: false, // Manual connection after authentication
});

export default websocketClient;
