import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import UserManagement from './pages/UserManagement';
import LeadsManagement from './pages/LeadsManagement';
import TasksManagement from './pages/TasksManagement';
import TaskDetails from './pages/TaskDetails';
import CallTracking from './pages/CallTracking';
import UserCallRecords from './pages/UserCallRecords';
import CallDetails from './pages/CallDetails';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import FollowUps from './pages/FollowUps';
import Layout from './components/layout/Layout';
import { useAuth } from './hooks/useAuth';
import Landing from './pages/Landing';
// New page imports
import TaskCreate from './pages/TaskCreate';
import TaskUpdate from './pages/TaskUpdate';
import TaskHandover from './pages/TaskHandover';
import SelectCaller from './pages/SelectCaller';
import SelectLeads from './pages/SelectLeads';
import LeadCreate from './pages/LeadCreate';
import LeadUpdate from './pages/LeadUpdate';
import LeadImport from './pages/LeadImport';
import FollowUpCreate from './pages/FollowUpCreate';
import FollowUpUpdate from './pages/FollowUpUpdate';
import UserCreate from './pages/UserCreate';
import UserUpdate from './pages/UserUpdate';
import UserPassword from './pages/UserPassword';
import LeadStatusCreate from './pages/LeadStatusCreate';
import LeadStatusUpdate from './pages/LeadStatusUpdate';

export function App() {
  const { isAuthenticated, loading } = useAuth();


  // Show loading spinner while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return <Router future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={isAuthenticated ? <Navigate to="/dashboard" /> : <Login />} />
      <Route path="/*" element={isAuthenticated ? <Layout>
        <Routes>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/users" element={<UserManagement />} />
          <Route path="/users/create" element={<UserCreate />} />
          <Route path="/users/:id/update" element={<UserUpdate />} />
          <Route path="/users/:id/password" element={<UserPassword />} />
          <Route path="/users/select/caller" element={<SelectCaller />} />
          <Route path="/leads" element={<LeadsManagement />} />
          <Route path="/leads/create" element={<LeadCreate />} />
          <Route path="/leads/:id/update" element={<LeadUpdate />} />
          <Route path="/leads/import" element={<LeadImport />} />
          <Route path="/leads/select" element={<SelectLeads />} />
          <Route path="/tasks" element={<TasksManagement />} />
          <Route path="/tasks/create" element={<TaskCreate />} />
          <Route path="/tasks/:id/update" element={<TaskUpdate />} />
          <Route path="/tasks/:taskId" element={<TaskDetails />} />
          <Route path="/tasks/:taskId/handover" element={<TaskHandover />} />
          <Route path="/follow-ups" element={<FollowUps />} />
          <Route path="/follow-ups/create" element={<FollowUpCreate />} />
          <Route path="/follow-ups/:id/update" element={<FollowUpUpdate />} />
          <Route path="/calls" element={<CallTracking />} />
          <Route path="/calls/:userId" element={<UserCallRecords />} />
          <Route path="/calls/:userId/:callId" element={<CallDetails />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/settings/lead-status/create" element={<LeadStatusCreate />} />
          <Route path="/settings/lead-status/:id/update" element={<LeadStatusUpdate />} />
        </Routes>
      </Layout> : <Navigate to="/" />} />
    </Routes>
  </Router>;
}