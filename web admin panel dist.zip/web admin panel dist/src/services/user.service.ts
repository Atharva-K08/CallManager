import apiClient from '../lib/api-client';
import { API_ENDPOINTS } from '../config/api.config';
import { User, CreateUserRequest, UpdateUserRequest, UserFilters, UserStats, CallerWithStats, ApiResponse } from '../types/api.types';

export const userService = {
    /**
     * Get users with filtering and pagination
     */
    async getUsers(filters?: UserFilters): Promise<ApiResponse<User[]>> {
        const response = await apiClient.get<User[]>(API_ENDPOINTS.USERS.LIST, { params: filters });
        return response;
    },

    /**
     * Get user by ID
     */
    async getUser(id: string | number) {
        const response = await apiClient.get<{
            success: boolean;
            status: number;
            data: User;
            message: string;
        }>(API_ENDPOINTS.USERS.GET(id));
        return response.data;
    },

    /**
     * Create new user
     */
    async createUser(data: CreateUserRequest) {
        const response = await apiClient.post<{
            success: boolean;
            status: number;
            data: User;
            message: string;
        }>(API_ENDPOINTS.USERS.CREATE, data);
        return response.data;
    },

    /**
     * Update user
     */
    async updateUser(id: string | number, data: UpdateUserRequest) {
        const response = await apiClient.patch<{
            success: boolean;
            status: number;
            data: User;
            message: string;
        }>(API_ENDPOINTS.USERS.UPDATE(id), data);
        return response.data;
    },

    /**
     * Delete user
     */
    async deleteUser(id: string | number) {
        const response = await apiClient.delete<{
            success: boolean;
            status: number;
            data: User;
            message: string;
        }>(API_ENDPOINTS.USERS.DELETE(id));
        return response.data;
    },

    /**
     * Activate user
     */
    async activateUser(id: string | number) {
        const response = await apiClient.patch<{
            success: boolean;
            status: number;
            data: User;
            message: string;
        }>(`${API_ENDPOINTS.USERS.GET(id)}/activate`);
        return response.data;
    },

    /**
     * Deactivate user
     */
    async deactivateUser(id: string | number) {
        const response = await apiClient.patch<{
            success: boolean;
            status: number;
            data: User;
            message: string;
        }>(`${API_ENDPOINTS.USERS.GET(id)}/deactivate`);
        return response.data;
    },

    /**
     * Update user password
     */
    async updateUserPassword(id: string, data: {
        currentPassword: string;
        newPassword: string;
        confirmPassword: string;
    }) {
        const response = await apiClient.patch<{
            success: boolean;
            status: number;
            data: { id: string };
            message: string;
        }>(`${API_ENDPOINTS.USERS.GET(id)}/password`, data);
        return response.data;
    },

    /**
     * Get user profile (public information)
     */
    async getUserProfile(id: number) {
        const response = await apiClient.get<{
            success: boolean;
            status: number;
            data: User;
            message: string;
        }>(`${API_ENDPOINTS.USERS.GET(id)}/profile`);
        return response.data;
    },

    /**
     * Update user profile (limited fields)
     */
    async updateUserPasswordByAdmin(id: string, data: {
        newPassword: string;
        confirmPassword: string;
    }) {
        const response = await apiClient.patch<{
            success: boolean;
            status: number;
            data: { id: string };
            message: string;
        }>(`${API_ENDPOINTS.USERS.GET(id)}/admin-password`, data);
        return response.data;
    },

    async updateUserProfile(id: string, data: {
        name?: string;
        phoneNumber?: string;
        profilePicture?: string;
    }) {
        const response = await apiClient.patch<{
            success: boolean;
            status: number;
            data: User;
            message: string;
        }>(`${API_ENDPOINTS.USERS.GET(id)}/profile`, data);
        return response.data;
    },

    /**
     * Search users
     */
    async searchUsers(query: string, filters?: {
        role?: string;
        isActive?: boolean;
        limit?: number;
        page?: number;
    }): Promise<ApiResponse<User[]>> {
        const response = await apiClient.get<User[]>(`${API_ENDPOINTS.USERS.LIST}/search`, {
            params: { q: query, ...filters }
        });
        return response;
    },

    /**
     * Get users by role
     */
    async getUsersByRole(role: string, filters?: {
        limit?: number;
        page?: number;
    }): Promise<ApiResponse<User[]>> {
        const response = await apiClient.get<User[]>(`${API_ENDPOINTS.USERS.LIST}/role/${role}`, { params: filters });
        return response;
    },

    /**
     * Get user statistics
     */
    async getUserStats(filters?: {
        startDate?: string;
        endDate?: string;
    }) {
        const response = await apiClient.get<{
            success: boolean;
            status: number;
            data: UserStats;
            message: string;
        }>(`${API_ENDPOINTS.USERS.LIST}/stats`, { params: filters });
        return response.data;
    },

    /**
     * Get callers (users with recent calls) with call statistics
     */
    async getCallers(filters?: {
        page?: number;
        limit?: number;
        from?: string;
        to?: string;
        sortBy?: string;
    }): Promise<ApiResponse<CallerWithStats[]>> {
        const response = await apiClient.get<CallerWithStats[]>(`${API_ENDPOINTS.USERS.LIST}/callers`, { params: filters });
        return response;
    },

    /**
     * Bulk update users
     */
    async bulkUpdateUsers(userIds: number[], updateData: Partial<UpdateUserRequest>) {
        const response = await apiClient.patch<{
            success: boolean;
            status: number;
            data: {
                modifiedCount: number;
                matchedCount: number;
            };
            message: string;
        }>(`${API_ENDPOINTS.USERS.LIST}/bulk-update`, {
            userIds,
            updateData
        });
        return response.data;
    },

    /**
     * Bulk delete users
     */
    async bulkDeleteUsers(userIds: number[]) {
        const response = await apiClient.delete<{
            success: boolean;
            status: number;
            data: {
                deletedCount: number;
            };
            message: string;
        }>(`${API_ENDPOINTS.USERS.LIST}/bulk-delete`, {
            data: { userIds }
        });
        return response.data;
    },
};