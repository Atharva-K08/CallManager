import { apiClient } from '../lib/api-client';

export interface CallRecord {
    _id: string;
    phoneNumber: string;
    contactName?: string;
    initiatedAt: string;
    connectedAt?: string;
    endedAt?: string;
    durationSeconds?: number;
    formattedDuration?: string;
    status: string;
    statusText?: string;
    source: 'app' | 'system' | 'unknown';
    isOutgoing: boolean;
    deviceInfo?: string;
    metadata?: any;
    outcomeLabel?: string;
    isSynced: boolean;
    syncedAt?: string;
    syncAttempts: number;
    syncError?: string;
    createdBy?: string | { _id: string; name: string; email: string };
    leadId?: string | { _id: string; firstName: string; lastName: string; phoneNumber: string };
    createdAt: string;
    updatedAt: string;
}

export interface CallRecordListResponse {
    results: CallRecord[];
    page: number;
    limit: number;
    totalResults: number;
    totalPages: number;
}

export interface CallRecordFilters {
    search?: string;
    status?: string;
    source?: string;
    isOutgoing?: boolean;
    createdBy?: string;
    leadId?: string;
    from?: string;
    to?: string;
    page?: number;
    limit?: number;
    sortBy?: string;
}

export interface CallStatistics {
    totalCalls: number;
    outgoingCalls: number;
    incomingCalls: number;
    connectedCalls: number;
    missedCalls: number;
    totalDuration: number;
    avgDuration: number;
}

export interface CreateCallRecordRequest {
    phoneNumber: string;
    contactName?: string;
    initiatedAt: string;
    connectedAt?: string;
    endedAt?: string;
    durationSeconds?: number;
    status: string;
    source: 'app' | 'system' | 'unknown';
    isOutgoing: boolean;
    deviceInfo?: string;
    metadata?: any;
    outcomeLabel?: string;
    leadId?: string;
}

export interface UpdateCallRecordRequest {
    phoneNumber?: string;
    contactName?: string;
    initiatedAt?: string;
    connectedAt?: string;
    endedAt?: string;
    durationSeconds?: number;
    status?: string;
    source?: 'app' | 'system' | 'unknown';
    isOutgoing?: boolean;
    deviceInfo?: string;
    metadata?: any;
    outcomeLabel?: string;
    leadId?: string;
}

class CallRecordService {
    private baseUrl = '/call-records';

    async getCallRecords(filters: CallRecordFilters = {}): Promise<CallRecordListResponse> {
        const params = new URLSearchParams();

        if (filters.search) params.append('search', filters.search);
        if (filters.status) params.append('status', filters.status);
        if (filters.source) params.append('source', filters.source);
        if (filters.isOutgoing !== undefined) params.append('isOutgoing', filters.isOutgoing.toString());
        if (filters.createdBy) params.append('createdBy', filters.createdBy);
        if (filters.leadId) params.append('leadId', filters.leadId);
        if (filters.from) params.append('from', filters.from);
        if (filters.to) params.append('to', filters.to);
        if (filters.page) params.append('page', filters.page.toString());
        if (filters.limit) params.append('limit', filters.limit.toString());
        if (filters.sortBy) params.append('sortBy', filters.sortBy);

        const response = await apiClient.get(`${this.baseUrl}?${params.toString()}`);
        console.log('CallRecord API Response:', response); // Debug log
        return response.data;
    }

    async getCallRecordById(id: string): Promise<CallRecord> {
        const response = await apiClient.get(`${this.baseUrl}/${id}`);
        return response.data;
    }

    async createCallRecord(data: CreateCallRecordRequest): Promise<CallRecord> {
        const response = await apiClient.post(this.baseUrl, data);
        return response.data;
    }

    async updateCallRecord(id: string, data: UpdateCallRecordRequest): Promise<CallRecord> {
        const response = await apiClient.patch(`${this.baseUrl}/${id}`, data);
        return response.data;
    }

    async deleteCallRecord(id: string): Promise<void> {
        await apiClient.delete(`${this.baseUrl}/${id}`);
    }

    async updateCallRecordStatus(id: string, status: string): Promise<CallRecord> {
        const response = await apiClient.patch(`${this.baseUrl}/${id}/status`, { status });
        return response.data;
    }

    async getCallStatistics(filters: Partial<CallRecordFilters> = {}): Promise<CallStatistics> {
        const params = new URLSearchParams();

        if (filters.createdBy) params.append('createdBy', filters.createdBy);
        if (filters.from) params.append('from', filters.from);
        if (filters.to) params.append('to', filters.to);
        if (filters.leadId) params.append('leadId', filters.leadId);

        const response = await apiClient.get(`${this.baseUrl}/statistics?${params.toString()}`);
        return response.data;
    }

    async getCallRecordsByPhoneNumber(phoneNumber: string): Promise<CallRecord[]> {
        const response = await apiClient.get(`${this.baseUrl}/phone/${encodeURIComponent(phoneNumber)}`);
        return response.data;
    }

    async getCallRecordsByLeadId(leadId: string): Promise<CallRecord[]> {
        const response = await apiClient.get(`${this.baseUrl}/lead/${leadId}`);
        return response.data;
    }
}

export const callRecordService = new CallRecordService();
export default callRecordService;
