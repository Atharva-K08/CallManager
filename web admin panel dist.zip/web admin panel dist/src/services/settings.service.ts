import apiClient from '../lib/api-client';
import {
    Setting,
    UserSettings,
    CategorySettings,
    GetSettingRequest,
    SetSettingRequest,
    SetCategorySettingsRequest,
} from '../types/settings.types';

class SettingsService {
    private readonly basePath = '/settings';

    /**
     * Get all user settings
     */
    async getUserSettings(): Promise<UserSettings> {
        const response = await apiClient.get<{ settings: UserSettings }>(this.basePath);
        return response.data.settings;
    }

    /**
     * Get all settings for a category
     */
    async getCategorySettings(category: string): Promise<CategorySettings> {
        const response = await apiClient.get<{ category: string; settings: CategorySettings }>(
            `${this.basePath}/${category}`
        );
        return response.data.settings;
    }

    /**
     * Get a single setting value
     */
    async getSetting<T = any>(category: string, key: string, defaultValue?: T): Promise<T> {
        const params = defaultValue !== undefined ? { defaultValue } : {};
        const response = await apiClient.get<{ category: string; key: string; value: T }>(
            `${this.basePath}/${category}/${key}`,
            { params }
        );
        return response.data.value;
    }

    /**
     * Set a single setting
     */
    async setSetting(
        category: string,
        key: string,
        value: any,
        options?: Omit<SetSettingRequest, 'value'>
    ): Promise<Setting> {
        const response = await apiClient.put<Setting>(
            `${this.basePath}/${category}/${key}`,
            { value, ...options }
        );
        return response.data;
    }

    /**
     * Set multiple settings for a category
     */
    async setCategorySettings(
        category: string,
        settings: Record<string, any>
    ): Promise<{ category: string; settings: CategorySettings }> {
        const response = await apiClient.put<{ category: string; settings: CategorySettings }>(
            `${this.basePath}/${category}`,
            { settings }
        );
        return response.data;
    }

    /**
     * Delete a user setting (revert to default)
     */
    async deleteSetting(category: string, key: string): Promise<void> {
        await apiClient.delete(`${this.basePath}/${category}/${key}`);
    }

    /**
     * Get system settings (admin only)
     */
    async getSystemSettings(category?: string): Promise<UserSettings> {
        const url = category
            ? `${this.basePath}/system/${category}`
            : `${this.basePath}/system`;
        const response = await apiClient.get<{ settings: UserSettings }>(url);
        return response.data.settings;
    }

    /**
     * Set system setting (admin only)
     */
    async setSystemSetting(
        category: string,
        key: string,
        value: any,
        options?: Omit<SetSettingRequest, 'value'>
    ): Promise<Setting> {
        const response = await apiClient.put<Setting>(
            `${this.basePath}/system/${category}/${key}`,
            { value, ...options }
        );
        return response.data;
    }
}

export const settingsService = new SettingsService();
export default settingsService;
