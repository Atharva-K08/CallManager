import websocketClient from '../lib/websocket';
import { useNotificationStore } from '../stores/notification.store';
import showToast from '../lib/toast';

export interface RealTimeNotification {
    title: string;
    message: string;
    type: 'info' | 'success' | 'warning' | 'error';
    showToast?: boolean;
    actionUrl?: string;
    metadata?: Record<string, any>;
}

class NotificationService {
    private isInitialized = false;

    /**
     * Initialize notification service with WebSocket
     */
    initialize(token?: string): void {
        if (this.isInitialized) {
            console.log('Notification service already initialized');
            return;
        }

        // Connect WebSocket
        websocketClient.connect(token);

        // Setup event listeners
        this.setupEventListeners();

        this.isInitialized = true;
        console.log('✅ Notification service initialized');
    }

    /**
     * Disconnect notification service
     */
    disconnect(): void {
        websocketClient.disconnect();
        this.isInitialized = false;
        console.log('Notification service disconnected');
    }

    /**
     * Setup WebSocket event listeners
     */
    private setupEventListeners(): void {
        // Listen for new call notifications
        websocketClient.on('new_call', (data: any) => {
            this.handleNotification({
                title: 'New Call Logged',
                message: `${data.userName} called ${data.studentName}`,
                type: 'info',
                showToast: true,
                metadata: data,
            });
        });

        // Listen for student assignment notifications
        websocketClient.on('students_assigned', (data: any) => {
            this.handleNotification({
                title: 'Students Assigned',
                message: `${data.count} students assigned to ${data.userName}`,
                type: 'success',
                showToast: true,
                metadata: data,
            });
        });

        // Listen for user status change
        websocketClient.on('user_status_changed', (data: any) => {
            this.handleNotification({
                title: 'User Status Changed',
                message: `${data.userName} is now ${data.status}`,
                type: 'info',
                showToast: false,
                metadata: data,
            });
        });

        // Listen for call reminder
        websocketClient.on('call_reminder', (data: any) => {
            this.handleNotification({
                title: 'Call Reminder',
                message: `Follow-up call with ${data.studentName} is due`,
                type: 'warning',
                showToast: true,
                metadata: data,
            });
        });

        // Listen for system alerts
        websocketClient.on('system_alert', (data: any) => {
            this.handleNotification({
                title: 'System Alert',
                message: data.message,
                type: data.type || 'info',
                showToast: true,
                metadata: data,
            });
        });

        // Listen for custom notifications
        websocketClient.on('notification', (data: RealTimeNotification) => {
            this.handleNotification(data);
        });

        // Connection status events
        websocketClient.on('connect', () => {
            console.log('📡 Connected to notification server');
        });

        websocketClient.on('disconnect', () => {
            console.log('📡 Disconnected from notification server');
        });
    }

    /**
     * Handle incoming notification
     */
    private handleNotification(notification: RealTimeNotification): void {
        const { addNotification } = useNotificationStore.getState();

        // Add to notification center
        addNotification({
            title: notification.title,
            message: notification.message,
            type: notification.type,
            actionUrl: notification.actionUrl,
            metadata: notification.metadata,
        });

        // Show toast if enabled
        if (notification.showToast !== false) {
            switch (notification.type) {
                case 'success':
                    showToast.success(notification.message);
                    break;
                case 'error':
                    showToast.error(notification.message);
                    break;
                case 'warning':
                    showToast.warning(notification.message);
                    break;
                default:
                    showToast.info(notification.message);
            }
        }
    }

    /**
     * Emit event to server
     */
    emit(event: string, data?: any): void {
        websocketClient.emit(event, data);
    }

    /**
     * Subscribe to custom event
     */
    on(event: string, handler: (data: any) => void): void {
        websocketClient.on(event, handler);
    }

    /**
     * Unsubscribe from event
     */
    off(event: string, handler?: (data: any) => void): void {
        websocketClient.off(event, handler);
    }

    /**
     * Check if connected
     */
    isConnected(): boolean {
        return websocketClient.isConnected();
    }

    /**
     * Send test notification
     */
    sendTestNotification(): void {
        this.handleNotification({
            title: 'Test Notification',
            message: 'This is a test notification from the system',
            type: 'info',
            showToast: true,
        });
    }
}

// Create singleton instance
export const notificationService = new NotificationService();
export default notificationService;
