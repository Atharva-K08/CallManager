import { apiClient } from '../lib/api-client';

export interface FollowUp {
    _id: string;
    leadId: string | { _id: string; firstName: string; lastName: string };
    leadName?: string;
    dueAt: string;
    note?: string;
    status: 'PENDING' | 'DONE' | 'CANCELLED';
    createdBy?: string | { _id: string; name: string };
    userName?: string;
    completedAt?: string;
    cancelledAt?: string;
    metadata?: any;
    createdAt: string;
    updatedAt: string;
}

export interface FollowUpListResponse {
    results: FollowUp[];
    page: number;
    limit: number;
    totalResults: number;
    totalPages: number;
}

export interface CreateFollowUpRequest {
    leadId: string;
    leadName?: string;
    dueAt: string;
    note?: string;
    status?: 'PENDING' | 'DONE' | 'CANCELLED';
    metadata?: any;
}

export interface UpdateFollowUpRequest {
    leadId?: string;
    leadName?: string;
    dueAt?: string;
    note?: string;
    status?: 'PENDING' | 'DONE' | 'CANCELLED';
    completedAt?: string;
    cancelledAt?: string;
    metadata?: any;
}

export interface FollowUpFilters {
    leadId?: string;
    status?: string;
    resolvedBy?: string;
    from?: string;
    to?: string;
    page?: number;
    limit?: number;
    sortBy?: string;
}

class FollowUpService {
    private baseUrl = '/followups';

    async getFollowUps(filters: FollowUpFilters = {}): Promise<FollowUpListResponse> {
        const params = new URLSearchParams();

        if (filters.leadId) params.append('leadId', filters.leadId);
        if (filters.status) params.append('status', filters.status);
        if (filters.from) params.append('from', filters.from);
        if (filters.to) params.append('to', filters.to);
        if (filters.page) params.append('page', filters.page.toString());
        if (filters.limit) params.append('limit', filters.limit.toString());
        if (filters.sortBy) params.append('sortBy', filters.sortBy);

        const response = await apiClient.get(`${this.baseUrl}?${params.toString()}`);
        console.log('FollowUp API Response:', response);

        // The API client already unwraps the response, so we access the data directly
        return response.data;
    }

    async getFollowUpById(id: string): Promise<FollowUp> {
        const response = await apiClient.get(`${this.baseUrl}/${id}`);
        return response.data;
    }

    async createFollowUp(data: CreateFollowUpRequest): Promise<FollowUp> {
        const response = await apiClient.post(this.baseUrl, data);
        return response.data;
    }

    async updateFollowUp(id: string, data: UpdateFollowUpRequest): Promise<FollowUp> {
        const response = await apiClient.put(`${this.baseUrl}/${id}`, data);
        return response.data;
    }

    async deleteFollowUp(id: string): Promise<void> {
        await apiClient.delete(`${this.baseUrl}/${id}`);
    }

    async markAsDone(id: string): Promise<FollowUp> {
        return this.updateFollowUp(id, {
            status: 'DONE',
            completedAt: new Date().toISOString()
        });
    }

    async markAsCancelled(id: string): Promise<FollowUp> {
        return this.updateFollowUp(id, {
            status: 'CANCELLED',
            cancelledAt: new Date().toISOString()
        });
    }

    async resolveFollowUp(followUpId: string, resolutionReason: string): Promise<FollowUp> {
        const response = await apiClient.post(`/v1/followups/${followUpId}/resolve`, {
            resolutionReason,
            resolutionType: 'RESOLVED'
        });
        return response.data;
    }

    async unresolveFollowUp(followUpId: string): Promise<FollowUp> {
        const response = await apiClient.post(`/v1/followups/${followUpId}/unresolve`);
        return response.data;
    }

    async getResolvedFollowUps(filters: FollowUpFilters = {}): Promise<FollowUpListResponse> {
        const params = new URLSearchParams();
        if (filters.resolvedBy) params.append('resolvedBy', filters.resolvedBy);
        if (filters.from) params.append('from', filters.from);
        if (filters.to) params.append('to', filters.to);
        if (filters.page) params.append('page', filters.page.toString());
        if (filters.limit) params.append('limit', filters.limit.toString());

        const response = await apiClient.get(`/v1/followups/resolved?${params}`);
        return response.data;
    }
}

export const followUpService = new FollowUpService();
export default followUpService;
