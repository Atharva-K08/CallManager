import apiClient from '../lib/api-client';
import { API_ENDPOINTS } from '../config/api.config';

export interface Task {
    _id: string;
    title: string;
    description?: string;
    assignedTo: string;
    assignedToName?: string;
    assignedToEmail?: string;
    createdBy?: string;
    leadIds?: string[];
    targetCount?: number;
    status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED';
    completedCount: number;
    totalCount?: number;
    dueAt?: string;
    createdAt: string;
    updatedAt: string;
}

export interface TaskListResponse {
    results: Task[];
    page: number;
    limit: number;
    totalResults: number;
    totalPages: number;
}

export interface TaskFilters {
    assignedTo?: string;
    status?: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED';
    search?: string;
    page?: number;
    limit?: number;
    sortBy?: string;
}

export interface CreateTaskRequest {
    title: string;
    description?: string;
    assignedTo: string;
    assignedToName?: string;
    assignedToEmail?: string;
    leadIds?: string[];
    targetCount?: number;
    status?: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED';
    dueAt?: string;
}

export interface UpdateTaskRequest extends Partial<CreateTaskRequest> {
    completedCount?: number;
    totalCount?: number;
}

export interface HandoverTaskRequest {
    title: string;
    description?: string;
    assignedTo: string;
    assignedToName?: string;
    assignedToEmail?: string;
    leadIds: string[];
    dueAt?: string;
    sourceTaskId?: string;
}

const taskService = {
    async list(params?: TaskFilters): Promise<TaskListResponse> {
        const response = await apiClient.get<TaskListResponse>(API_ENDPOINTS.TASKS.LIST, { params });
        return response.data;
    },
    async getById(id: string): Promise<Task> {
        const response = await apiClient.get<Task>(API_ENDPOINTS.TASKS.GET(id));
        return response.data;
    },
    async create(data: CreateTaskRequest): Promise<Task> {
        const response = await apiClient.post<Task>(API_ENDPOINTS.TASKS.CREATE, data);
        return response.data;
    },
    async update(id: string, data: UpdateTaskRequest): Promise<Task> {
        const response = await apiClient.patch<Task>(API_ENDPOINTS.TASKS.UPDATE(id), data);
        return response.data;
    },
    async remove(id: string): Promise<void> {
        await apiClient.delete<void>(API_ENDPOINTS.TASKS.DELETE(id));
    },
    async setStatus(id: string, status: Task['status']): Promise<Task> {
        const response = await apiClient.patch<Task>(API_ENDPOINTS.TASKS.SET_STATUS(id), { status });
        return response.data;
    },
    async incrementProgress(id: string, by = 1): Promise<Task> {
        const response = await apiClient.patch<Task>(API_ENDPOINTS.TASKS.INCREMENT_PROGRESS(id), { by });
        return response.data;
    },
    async handover(data: HandoverTaskRequest): Promise<Task> {
        const response = await apiClient.post<Task>(API_ENDPOINTS.TASKS.HANDOVER, data);
        return response.data;
    },
};

export default taskService;


