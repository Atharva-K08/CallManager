import apiClient from '../lib/api-client';
import { API_ENDPOINTS } from '../config/api.config';
import {
    Call,
    CreateCallRequest,
    UpdateCallRequest,
    CallFilters,
    CallStats,
    PaginatedResponse,
    ApiResponse,
} from '../types/api.types';

export const callService = {
    /**
     * Get all calls with optional pagination and filters
     */
    async getCalls(params?: CallFilters & {
        page?: number;
        per_page?: number;
    }): Promise<PaginatedResponse<Call> | ApiResponse<Call[]>> {
        const response = await apiClient.get<Call[] | PaginatedResponse<Call>>(
            API_ENDPOINTS.CALLS.LIST,
            { params }
        );
        return response as any;
    },

    /**
     * Get single call by ID
     */
    async getCall(id: number): Promise<Call> {
        const response = await apiClient.get<Call>(API_ENDPOINTS.CALLS.GET(id));
        return response.data;
    },

    /**
     * Create new call record
     */
    async createCall(data: CreateCallRequest): Promise<Call> {
        const response = await apiClient.post<Call>(API_ENDPOINTS.CALLS.CREATE, data);
        return response.data;
    },

    /**
     * Update existing call
     */
    async updateCall(id: number, data: UpdateCallRequest): Promise<Call> {
        const response = await apiClient.put<Call>(
            API_ENDPOINTS.CALLS.UPDATE(id),
            data
        );
        return response.data;
    },

    /**
     * Delete call
     */
    async deleteCall(id: number): Promise<void> {
        await apiClient.delete(API_ENDPOINTS.CALLS.DELETE(id));
    },

    /**
     * Get call statistics
     */
    async getCallStats(params?: {
        start_date?: string;
        end_date?: string;
        user_id?: number;
    }): Promise<CallStats> {
        const response = await apiClient.get<CallStats>(
            API_ENDPOINTS.CALLS.STATS,
            { params }
        );
        return response.data;
    },

    /**
     * Add note to call
     */
    async addCallNote(id: number, note: string): Promise<Call> {
        const response = await apiClient.patch<Call>(API_ENDPOINTS.CALLS.UPDATE(id), {
            notes: note,
        });
        return response.data;
    },
};
