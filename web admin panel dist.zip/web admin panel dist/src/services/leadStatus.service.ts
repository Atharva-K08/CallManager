import apiClient from '../lib/api-client';
import { API_ENDPOINTS } from '../config/api.config';

export interface LeadStatus {
    _id: string;
    name: string;
    type: 'leadStatus' | 'callStatus';
    color?: string | null;
    order: number;
    isActive: boolean;
    isDefaultForImport?: boolean;
    description?: string | null;
    createdAt: string;
    updatedAt: string;
}

export interface LeadStatusListResponse {
    results: LeadStatus[];
    page: number;
    limit: number;
    totalResults: number;
    totalPages: number;
}

export interface LeadStatusFilters {
    type?: 'leadStatus' | 'callStatus';
    isActive?: boolean | string;
    search?: string;
    page?: number;
    limit?: number;
    sortBy?: string; // e.g., 'order:asc'
}

export interface CreateLeadStatusRequest {
    name: string;
    type: 'leadStatus' | 'callStatus';
    color?: string | null;
    order?: number;
    isActive?: boolean;
    description?: string | null;
}

export interface UpdateLeadStatusRequest extends Partial<CreateLeadStatusRequest> { }

const leadStatusService = {
    async list(params?: LeadStatusFilters): Promise<LeadStatusListResponse> {
        const response = await apiClient.get<LeadStatusListResponse>(API_ENDPOINTS.LEAD_STATUS.LIST, { params });
        return response.data;
    },

    async create(data: CreateLeadStatusRequest): Promise<LeadStatus> {
        const response = await apiClient.post<LeadStatus>(API_ENDPOINTS.LEAD_STATUS.CREATE, data);
        return response.data;
    },

    async update(id: string, data: UpdateLeadStatusRequest): Promise<LeadStatus> {
        const response = await apiClient.patch<LeadStatus>(API_ENDPOINTS.LEAD_STATUS.UPDATE(id), data);
        return response.data;
    },

    async remove(id: string): Promise<void> {
        await apiClient.delete<void>(API_ENDPOINTS.LEAD_STATUS.DELETE(id));
    },

    async activate(id: string): Promise<LeadStatus> {
        const response = await apiClient.patch<LeadStatus>(`${API_ENDPOINTS.LEAD_STATUS.UPDATE(id)}/activate`, {});
        return response.data;
    },

    async deactivate(id: string): Promise<LeadStatus> {
        const response = await apiClient.patch<LeadStatus>(`${API_ENDPOINTS.LEAD_STATUS.UPDATE(id)}/deactivate`, {});
        return response.data;
    },

    async getDefaultImport(): Promise<{ default: LeadStatus | null }> {
        const response = await apiClient.get<{ default: LeadStatus | null }>(API_ENDPOINTS.LEAD_STATUS.GET_DEFAULT_IMPORT);
        return response.data;
    },

    async setDefaultImport(id: string): Promise<{ updated: LeadStatus }> {
        const response = await apiClient.patch<{ updated: LeadStatus }>(API_ENDPOINTS.LEAD_STATUS.SET_DEFAULT_IMPORT(id), {});
        return response.data;
    },
};

export default leadStatusService;


