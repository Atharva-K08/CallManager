import apiClient from '../lib/api-client';
import { API_ENDPOINTS } from '../config/api.config';
import { LoginRequest, LoginResponse, User } from '../types/api.types';

export const authService = {
    /**
     * Login user
     */
    async login(credentials: LoginRequest): Promise<LoginResponse> {
        // Set login attempt flag to prevent redirects
        apiClient.setLoginAttempt(true);

        try {
            const response = await apiClient.post<LoginResponse>(
                API_ENDPOINTS.AUTH.LOGIN,
                credentials
            );

            // Store tokens
            if (response.data.tokens?.access?.token) {
                apiClient.setToken(response.data.tokens.access.token);
                if (response.data.tokens?.refresh?.token) {
                    apiClient.setRefreshToken(response.data.tokens.refresh.token);
                }
            }

            return response.data;
        } finally {
            // Clear login attempt flag
            apiClient.setLoginAttempt(false);
        }
    },

    /**
     * Logout user
     */
    async logout(): Promise<void> {
        try {
            const refreshToken = apiClient.getRefreshToken();
            if (refreshToken) {
                await apiClient.post(API_ENDPOINTS.AUTH.LOGOUT, { refreshToken });
            }
        } finally {
            apiClient.clearTokens();
        }
    },

    /**
     * Get current user
     */
    async getCurrentUser(): Promise<User> {
        const response = await apiClient.get<User>(API_ENDPOINTS.AUTH.ME);
        return response.data;
    },

    /**
     * Refresh token
     */
    async refreshToken(refreshToken: string): Promise<LoginResponse> {
        const response = await apiClient.post<LoginResponse>(
            API_ENDPOINTS.AUTH.REFRESH,
            { refreshToken }
        );

        // Store new tokens
        if (response.data.tokens?.access?.token) {
            apiClient.setToken(response.data.tokens.access.token);
            if (response.data.tokens?.refresh?.token) {
                apiClient.setRefreshToken(response.data.tokens.refresh.token);
            }
        }

        return response.data;
    },

    /**
     * Check if user is authenticated
     */
    isAuthenticated(): boolean {
        return !!apiClient.getToken();
    },
};
