import apiClient from '../lib/api-client';
import { API_ENDPOINTS } from '../config/api.config';

export interface Lead {
    _id: string;
    firstName: string;
    lastName: string;
    phoneNumber: string;
    email?: string | null;
    campus?: string | null;
    class?: string | null;
    city?: string | null;
    status: string;
    remark?: string | null;
    callStatus?: string;
    lastContactedAt?: string | null;
    assignedTo?: string | null;
    source?: string | null;
    priority?: number;
    createdAt: string;
    updatedAt: string;
}

export interface LeadListResponse {
    results: Lead[];
    page: number;
    limit: number;
    totalResults: number;
    totalPages: number;
}

export interface LeadFilters {
    search?: string;
    status?: string;
    callStatus?: string;
    assignedTo?: string;
    source?: string;
    taskId?: string;
    completed?: boolean;
    unassigned?: boolean;
    city?: string;
    campus?: string;
    class?: string;
    createdAtFrom?: string;
    createdAtTo?: string;
    assigned?: boolean;
    ids?: string | string[]; // Array of lead IDs to fetch
    sortBy?: string;
    page?: number;
    limit?: number;
}

export interface CreateLeadRequest {
    firstName: string;
    lastName: string;
    phoneNumber: string;
    email?: string | null;
    campus?: string | null;
    class?: string | null;
    city?: string | null;
    status: string;
    remark?: string | null;
    callStatus?: string;
    assignedTo?: string | null;
    source?: string | null;
    priority?: number;
}

export interface UpdateLeadRequest extends Partial<CreateLeadRequest> { }

const leadService = {
    async list(params?: LeadFilters): Promise<LeadListResponse> {
        // Convert ids array to comma-separated string for query parameter
        const queryParams = { ...params };
        if (queryParams.ids && Array.isArray(queryParams.ids)) {
            queryParams.ids = queryParams.ids.join(',');
        }
        const response = await apiClient.get<LeadListResponse>(API_ENDPOINTS.LEADS.LIST, { params: queryParams });
        return response.data;
    },

    async getById(id: string): Promise<Lead> {
        const response = await apiClient.get<Lead>(API_ENDPOINTS.LEADS.GET(id));
        return response.data;
    },

    async create(data: CreateLeadRequest): Promise<Lead> {
        const response = await apiClient.post<Lead>(API_ENDPOINTS.LEADS.CREATE, data);
        return response.data;
    },

    async update(id: string, data: UpdateLeadRequest): Promise<Lead> {
        const response = await apiClient.patch<Lead>(API_ENDPOINTS.LEADS.UPDATE(id), data);
        return response.data;
    },

    async remove(id: string): Promise<void> {
        await apiClient.delete<void>(API_ENDPOINTS.LEADS.DELETE(id));
    },

    async updateStatus(id: string, status: string, remark?: string): Promise<Lead> {
        const response = await apiClient.patch<Lead>(API_ENDPOINTS.LEADS.UPDATE_STATUS(id), { status, remark });
        return response.data;
    },

    async updateCallStatus(id: string, callStatus: string): Promise<Lead> {
        const response = await apiClient.patch<Lead>(API_ENDPOINTS.LEADS.UPDATE_CALL_STATUS(id), { callStatus });
        return response.data;
    },

    async syncUpload(leads: any[]): Promise<{ success: boolean; imported: number }> {
        const response = await apiClient.post<{ success: boolean; imported: number }>(API_ENDPOINTS.LEADS.SYNC_UPLOAD, { leads });
        return response.data;
    },

    async syncPull(sinceISO: string, limit = 100): Promise<{ results: Lead[] }> {
        const response = await apiClient.get<{ results: Lead[] }>(API_ENDPOINTS.LEADS.SYNC_PULL, { params: { since: sinceISO, limit } });
        return response.data;
    },

    async downloadImportTemplate(): Promise<void> {
        await apiClient.download(API_ENDPOINTS.LEADS.IMPORT_SAMPLE, `leads_sample.xlsx`);
    },

    async previewImport(file: File): Promise<{ totalRows: number; validCount: number; invalidCount: number; validRows: any[]; invalidRows: any[] }> {
        const formData = new FormData();
        formData.append('file', file);
        const response = await apiClient.post(API_ENDPOINTS.LEADS.IMPORT_PREVIEW, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
        return response.data;
    },

    async confirmImport(validRows: any[]): Promise<{ imported: number; skipped: number }> {
        const response = await apiClient.post(API_ENDPOINTS.LEADS.IMPORT_CONFIRM, { validRows });
        return response.data;
    },
};

export default leadService;


