import apiClient from '../lib/api-client';
import { API_ENDPOINTS } from '../config/api.config';
import { ReportFilters, CallStats, ApiResponse } from '../types/api.types';

export const reportService = {
    /**
     * Get overview report
     */
    async getOverviewReport(params?: ReportFilters): Promise<CallStats> {
        const response = await apiClient.get<CallStats>(
            API_ENDPOINTS.REPORTS.OVERVIEW,
            { params }
        );
        return response.data;
    },

    /**
     * Get report by user
     */
    async getReportByUser(params?: ReportFilters): Promise<any> {
        const response = await apiClient.get(API_ENDPOINTS.REPORTS.BY_USER, {
            params,
        });
        return response.data;
    },

    /**
     * Get report by time
     */
    async getReportByTime(params?: ReportFilters): Promise<any> {
        const response = await apiClient.get(API_ENDPOINTS.REPORTS.BY_TIME, {
            params,
        });
        return response.data;
    },

    /**
     * Export report as PDF
     */
    async exportPDF(params?: ReportFilters): Promise<void> {
        const queryString = new URLSearchParams(params as any).toString();
        const url = `${API_ENDPOINTS.REPORTS.EXPORT_PDF}${queryString ? `?${queryString}` : ''}`;
        await apiClient.download(url, `report_${Date.now()}.pdf`);
    },

    /**
     * Export report as Excel
     */
    async exportExcel(params?: ReportFilters): Promise<void> {
        const queryString = new URLSearchParams(params as any).toString();
        const url = `${API_ENDPOINTS.REPORTS.EXPORT_EXCEL}${queryString ? `?${queryString}` : ''}`;
        await apiClient.download(url, `report_${Date.now()}.xlsx`);
    },
};
