import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { EyeIcon, UserIcon, SearchIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Table from '../components/ui/Table';
import Badge from '../components/ui/Badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { useCallers } from '../hooks/useCallers';
import { CallerWithStats } from '../types/api.types';
import { debounce } from '../utils/performance';

const CallTracking: React.FC = () => {
  const navigate = useNavigate();
  const [dateRange, setDateRange] = useState<{
    start: string;
    end: string;
  }>({
    start: '',
    end: ''
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('lastCall:desc');

  // Use the callers hook
  const {
    callers,
    pagination,
    callersLoading,
    getCallers
  } = useCallers();

  // Debounced search function
  const debouncedSearch = debounce((query: string) => {
    const filters: any = {
      page: 1,
      limit: 10,
      sortBy: sortBy,
    };

    if (query && query.trim()) {
      filters.search = query.trim();
    }

    if (dateRange.start && dateRange.start.trim()) filters.from = dateRange.start;
    if (dateRange.end && dateRange.end.trim()) filters.to = dateRange.end;

    getCallers(filters);
  }, 500);

  // Load data on component mount and when filters change
  useEffect(() => {
    const filters: any = {
      page: 1,
      limit: 10,
      sortBy: sortBy,
    };

    if (dateRange.start && dateRange.start.trim()) filters.from = dateRange.start;
    if (dateRange.end && dateRange.end.trim()) filters.to = dateRange.end;

    getCallers(filters);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sortBy, dateRange.start, dateRange.end]);

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    debouncedSearch(query);
  };

  // Handle date filter change
  const handleDateChange = (field: 'start' | 'end', value: string) => {
    const newDateRange = { ...dateRange, [field]: value };
    setDateRange(newDateRange);

    const filters: any = {
      page: 1,
      limit: 10,
      sortBy: sortBy,
    };

    if (newDateRange.start && newDateRange.start.trim()) filters.from = newDateRange.start;
    if (newDateRange.end && newDateRange.end.trim()) filters.to = newDateRange.end;

    getCallers(filters);
  };

  // Handle sort change
  const handleSortChange = (value: string) => {
    setSortBy(value);

    const filters: any = {
      page: 1,
      limit: 10,
      sortBy: value,
    };

    if (dateRange.start && dateRange.start.trim()) filters.from = dateRange.start;
    if (dateRange.end && dateRange.end.trim()) filters.to = dateRange.end;

    getCallers(filters);
  };

  // Format duration helper
  const formatDuration = (seconds: number) => {
    if (!seconds) return '0:00';
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  // Format date helper
  const formatDate = (dateString: string) => {
    if (!dateString) return 'Never';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB') + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Calculate success rate
  const getSuccessRate = (caller: CallerWithStats) => {
    if (!caller.stats.totalCalls) return 0;
    return Math.round((caller.stats.connectedCalls / caller.stats.totalCalls) * 100);
  };

  const columns = [
    {
      key: 'name',
      header: 'User Name',
      width: 'w-2/12',
      render: (_: string, item: CallerWithStats) => (
        <div className="flex items-center">
          <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
            {item.profilePicture ? (
              <img src={item.profilePicture} alt={item.name} className="h-10 w-10 rounded-full" />
            ) : (
              <UserIcon className="h-6 w-6 text-blue-600" />
            )}
          </div>
          <div className="ml-3">
            <span className="text-sm font-medium text-gray-900">{item.name}</span>
            <div className="text-sm text-gray-500">{item.email}</div>
          </div>
        </div>
      )
    },
    {
      key: 'role',
      header: 'Role',
      width: 'w-1/12',
      render: (_: string, item: CallerWithStats) => (
        <Badge variant="primary">
          {item.role}
        </Badge>
      )
    },
    {
      key: 'totalCalls',
      header: 'Total Calls',
      width: 'w-1/12',
      render: (_: string, item: CallerWithStats) => (
        <span className="text-sm font-medium text-gray-900">
          {item.stats.totalCalls}
        </span>
      )
    },
    {
      key: 'connectedCalls',
      header: 'Connected',
      width: 'w-1/12',
      render: (_: string, item: CallerWithStats) => (
        <div>
          <span className="text-sm font-medium text-green-600">
            {item.stats.connectedCalls}
          </span>
          <div className="text-xs text-gray-500">
            {getSuccessRate(item)}% success
          </div>
        </div>
      )
    },
    {
      key: 'avgDuration',
      header: 'Avg Duration',
      width: 'w-1/12',
      render: (_: string, item: CallerWithStats) => (
        <span className="text-sm text-gray-900">
          {formatDuration(Math.round(item.stats.avgDuration))}
        </span>
      )
    },
    {
      key: 'lastCallAt',
      header: 'Last Call',
      width: 'w-2/12',
      render: (_: string, item: CallerWithStats) => (
        <span className="text-sm text-gray-900">
          {formatDate(item.stats.lastCallAt)}
        </span>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      width: 'w-1/12',
      render: (_: any, item: CallerWithStats) => (
        <div className="flex space-x-1 justify-end">
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleViewCallerRecords(item._id);
            }}
            className="p-1.5 rounded-full text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition-colors"
            title="View Call Records"
          >
            <EyeIcon size={16} />
          </button>
        </div>
      )
    }
  ];

  const handleViewCallerRecords = (userId: string) => {
    navigate(`/calls/${userId}`);
  };

  // Calculate overall statistics
  const overallStats = callers.reduce((acc, caller) => ({
    totalCalls: acc.totalCalls + caller.stats.totalCalls,
    outgoingCalls: acc.outgoingCalls + caller.stats.outgoingCalls,
    incomingCalls: acc.incomingCalls + caller.stats.incomingCalls,
    connectedCalls: acc.connectedCalls + caller.stats.connectedCalls,
    totalDuration: acc.totalDuration + caller.stats.totalDuration,
  }), {
    totalCalls: 0,
    outgoingCalls: 0,
    incomingCalls: 0,
    connectedCalls: 0,
    totalDuration: 0,
  });

  const overallAvgDuration = callers.length > 0
    ? overallStats.totalDuration / overallStats.totalCalls
    : 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">
            Call Tracking
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            View callers and their call statistics
          </p>
        </div>
        <div className="flex space-x-2">
          {/* <Button variant="outline" icon={<DownloadIcon size={16} />}>
            Export Data
          </Button> */}
        </div>
      </div>

      {/* Search and filters */}
      <Card>
        <div className="p-3">
          <div className="space-y-2">
            {/* Search and Filters - single row on md+ */}
            <div className="flex flex-col md:flex-row md:items-end gap-3">
              {/* Search - flexible width */}
              <div className="md:flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Search Callers
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <SearchIcon size={18} className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search by name, email..."
                    value={searchQuery}
                    onChange={handleSearchChange}
                    className="block w-full pl-10 pr-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400"
                  />
                </div>
              </div>

              {/* Sort By Filter */}
              <div className="md:w-56">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Sort By
                </label>
                <Select value={sortBy} onValueChange={handleSortChange}>
                  <SelectTrigger className="w-full h-11">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lastCall:desc">Last Call (Newest)</SelectItem>
                    <SelectItem value="lastCall:asc">Last Call (Oldest)</SelectItem>
                    <SelectItem value="totalCalls:desc">Total Calls (High to Low)</SelectItem>
                    <SelectItem value="totalCalls:asc">Total Calls (Low to High)</SelectItem>
                    <SelectItem value="name:asc">Name (A-Z)</SelectItem>
                    <SelectItem value="name:desc">Name (Z-A)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Start Date Filter */}
              <div className="md:w-56" lang="en-GB">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Start Date
                </label>
                <input
                  type="date"
                  lang="en-GB"
                  className="block w-full px-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 cursor-pointer"
                  value={dateRange.start}
                  onClick={(e) => {
                    e.currentTarget.showPicker?.();
                  }}
                  onChange={(e) => handleDateChange('start', e.target.value)}
                />
              </div>

              {/* End Date Filter */}
              <div className="md:w-56" lang="en-GB">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  End Date
                </label>
                <input
                  type="date"
                  lang="en-GB"
                  className="block w-full px-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 cursor-pointer"
                  value={dateRange.end}
                  onClick={(e) => {
                    e.currentTarget.showPicker?.();
                  }}
                  onChange={(e) => handleDateChange('end', e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Callers Data */}
      <Card>
        <div className="mb-4 flex justify-between items-center">
          <h3 className="text-lg font-medium text-gray-800">Callers</h3>
          {pagination.total_items > 0 && (
            <span className="text-sm text-gray-500">
              Showing {callers.length} of {pagination.total_items} callers
            </span>
          )}
        </div>
        <Table
          columns={columns}
          data={callers}
          loading={callersLoading}
          onRowClick={(item) => handleViewCallerRecords(item._id)}
        />
      </Card>

      {/* Overall Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="hover:shadow-md transition-shadow duration-200">
          <div className="text-center">
            <p className="text-sm font-medium text-gray-500">Total Callers</p>
            <p className="mt-2 text-3xl font-semibold text-gray-900">
              {callers.length}
            </p>
            <div className="mt-2 inline-flex items-center text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full">
              <span>{overallStats.totalCalls} total calls</span>
            </div>
          </div>
        </Card>
        <Card className="hover:shadow-md transition-shadow duration-200">
          <div className="text-center">
            <p className="text-sm font-medium text-gray-500">Total Connected Calls</p>
            <p className="mt-2 text-3xl font-semibold text-green-600">
              {overallStats.connectedCalls}
            </p>
            <div className="mt-2 flex justify-center">
              <div className="bg-gray-200 h-2 w-36 rounded-full overflow-hidden">
                <div
                  className="bg-green-500 h-2"
                  style={{
                    width: `${overallStats.totalCalls ? (overallStats.connectedCalls / overallStats.totalCalls * 100) : 0}%`
                  }}
                />
              </div>
            </div>
            <p className="mt-1 text-xs text-gray-500">
              {overallStats.totalCalls ? Math.round(overallStats.connectedCalls / overallStats.totalCalls * 100) : 0}
              % success rate
            </p>
          </div>
        </Card>
        <Card className="hover:shadow-md transition-shadow duration-200">
          <div className="text-center">
            <p className="text-sm font-medium text-gray-500">Average Call Duration</p>
            <p className="mt-2 text-3xl font-semibold text-blue-600">
              {formatDuration(Math.round(overallAvgDuration))}
            </p>
            <div className="mt-2 inline-flex items-center text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full">
              <span>Total: {formatDuration(Math.round(overallStats.totalDuration))}</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default CallTracking;
