import React, { useEffect, useState } from 'react';
import { DownloadIcon, PrinterIcon, CalendarIcon, RefreshCwIcon, ArrowRightIcon, ZoomInIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { callStats } from '../utils/mockData';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Area, AreaChart, ComposedChart, Scatter } from 'recharts';
import { showToast } from '../lib/toast';
const Reports: React.FC = () => {
  const [dateRange, setDateRange] = useState<string>('week');
  const [isLoading, setIsLoading] = useState(false);
  const [activeChart, setActiveChart] = useState<string>('overview');
  const [chartType, setChartType] = useState<string>('bar');
  const [expandedChart, setExpandedChart] = useState<string | null>(null);
  const COLORS = ['#0088FE', '#FF8042', '#FF0000'];
  const handleExportPDF = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      showToast.success('PDF exported successfully');
    }, 1000);
  };
  const handleExportExcel = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      showToast.success('Excel file exported successfully');
    }, 1000);
  };
  const handleRefreshData = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 800);
  };
  const handleExpandChart = (chartId: string) => {
    setExpandedChart(chartId);
  };
  const handleCloseExpandedChart = () => {
    setExpandedChart(null);
  };
  // Enhanced data for charts
  const enhancedCallData = callStats.callsPerUser.map(user => ({
    ...user,
    connected: Math.floor(user.calls * 0.6),
    notAnswered: Math.floor(user.calls * 0.3),
    busy: user.calls - Math.floor(user.calls * 0.6) - Math.floor(user.calls * 0.3)
  }));
  // Weekly data for trends
  const weeklyData = [{
    week: 'Week 1',
    calls: 45,
    connected: 28,
    duration: 4.1
  }, {
    week: 'Week 2',
    calls: 52,
    connected: 35,
    duration: 4.3
  }, {
    week: 'Week 3',
    calls: 49,
    connected: 30,
    duration: 3.9
  }, {
    week: 'Week 4',
    calls: 60,
    connected: 42,
    duration: 4.5
  }];
  // Hourly distribution
  const hourlyDistribution = [{
    hour: '9 AM',
    calls: 12
  }, {
    hour: '10 AM',
    calls: 18
  }, {
    hour: '11 AM',
    calls: 15
  }, {
    hour: '12 PM',
    calls: 8
  }, {
    hour: '1 PM',
    calls: 10
  }, {
    hour: '2 PM',
    calls: 14
  }, {
    hour: '3 PM',
    calls: 16
  }, {
    hour: '4 PM',
    calls: 9
  }];
  return <div className="space-y-6">
    <div className="flex justify-between items-center">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Reports</h1>
        <p className="mt-1 text-sm text-gray-500">
          Call analytics and performance metrics
        </p>
      </div>
      <div className="flex space-x-3">
        <Button variant="outline" icon={<RefreshCwIcon size={16} className={isLoading ? 'animate-spin' : ''} />} onClick={handleRefreshData} disabled={isLoading}>
          {isLoading ? 'Refreshing...' : 'Refresh Data'}
        </Button>
        <Button variant="outline" icon={<PrinterIcon size={16} />} onClick={handleExportPDF} disabled={isLoading}>
          Export PDF
        </Button>
        <Button variant="outline" icon={<DownloadIcon size={16} />} onClick={handleExportExcel} disabled={isLoading}>
          Export Excel
        </Button>
      </div>
    </div>
    {/* Date Range & Chart Type Selectors */}
    <Card>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center">
          <CalendarIcon size={20} className="text-gray-400 mr-2" />
          <div className="text-sm font-medium text-gray-700 mr-4">
            Date Range:
          </div>
          <div className="flex space-x-2">
            {['week', 'month', 'quarter', 'year'].map(range => <button key={range} className={`px-3 py-1 text-sm rounded-md ${dateRange === range ? 'bg-blue-100 text-blue-700' : 'text-gray-700 hover:bg-gray-100'}`} onClick={() => setDateRange(range)}>
              {range.charAt(0).toUpperCase() + range.slice(1)}
            </button>)}
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <div className="flex border rounded-md overflow-hidden">
            <button className={`px-3 py-1 text-sm font-medium ${activeChart === 'overview' ? 'bg-blue-50 text-blue-600' : 'bg-white text-gray-600 hover:bg-gray-50'}`} onClick={() => setActiveChart('overview')}>
              Overview
            </button>
            <button className={`px-3 py-1 text-sm font-medium ${activeChart === 'users' ? 'bg-blue-50 text-blue-600' : 'bg-white text-gray-600 hover:bg-gray-50'}`} onClick={() => setActiveChart('users')}>
              By Users
            </button>
            <button className={`px-3 py-1 text-sm font-medium ${activeChart === 'time' ? 'bg-blue-50 text-blue-600' : 'bg-white text-gray-600 hover:bg-gray-50'}`} onClick={() => setActiveChart('time')}>
              By Time
            </button>
          </div>
          <div className="flex border rounded-md overflow-hidden">
            <button className={`px-3 py-1 text-sm font-medium ${chartType === 'bar' ? 'bg-blue-50 text-blue-600' : 'bg-white text-gray-600 hover:bg-gray-50'}`} onClick={() => setChartType('bar')}>
              Bar
            </button>
            <button className={`px-3 py-1 text-sm font-medium ${chartType === 'line' ? 'bg-blue-50 text-blue-600' : 'bg-white text-gray-600 hover:bg-gray-50'}`} onClick={() => setChartType('line')}>
              Line
            </button>
            <button className={`px-3 py-1 text-sm font-medium ${chartType === 'area' ? 'bg-blue-50 text-blue-600' : 'bg-white text-gray-600 hover:bg-gray-50'}`} onClick={() => setChartType('area')}>
              Area
            </button>
          </div>
        </div>
      </div>
    </Card>
    {/* Charts */}
    {activeChart === 'overview' && <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Bar Chart: Calls per User */}
      <Card title={<div className="flex justify-between items-center">
        <span>Calls per User</span>
        <button className="text-gray-400 hover:text-gray-600" onClick={() => handleExpandChart('userCalls')}>
          <ZoomInIcon size={18} />
        </button>
      </div>}>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'bar' ? <BarChart data={enhancedCallData} margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 5
            }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="calls" fill="#3B82F6" />
            </BarChart> : chartType === 'line' ? <LineChart data={enhancedCallData} margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 5
            }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="calls" stroke="#3B82F6" activeDot={{
                r: 8
              }} />
            </LineChart> : <AreaChart data={enhancedCallData} margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 5
            }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Area type="monotone" dataKey="calls" fill="#3B82F6" stroke="#3B82F6" />
            </AreaChart>}
          </ResponsiveContainer>
        </div>
      </Card>
      {/* Pie Chart: Call Status Distribution */}
      <Card title={<div className="flex justify-between items-center">
        <span>Call Status Distribution</span>
        <button className="text-gray-400 hover:text-gray-600" onClick={() => handleExpandChart('callStatus')}>
          <ZoomInIcon size={18} />
        </button>
      </div>}>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={callStats.callStatusDistribution} cx="50%" cy="50%" labelLine={false} outerRadius={80} fill="#8884d8" dataKey="value" label={({
                name,
                percent
              }) => `${name}: ${(percent * 100).toFixed(0)}%`} animationBegin={0} animationDuration={1000}>
                {callStats.callStatusDistribution.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </Card>
      {/* Line Chart: Daily Call Trends */}
      <Card title={<div className="flex justify-between items-center">
        <span>Daily Call Trends</span>
        <button className="text-gray-400 hover:text-gray-600" onClick={() => handleExpandChart('dailyTrends')}>
          <ZoomInIcon size={18} />
        </button>
      </div>} className="lg:col-span-2">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'bar' ? <BarChart data={callStats.dailyCallTrends} margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 5
            }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="calls" fill="#3B82F6" />
            </BarChart> : chartType === 'line' ? <LineChart data={callStats.dailyCallTrends} margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 5
            }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="calls" stroke="#3B82F6" activeDot={{
                r: 8
              }} strokeWidth={2} />
            </LineChart> : <AreaChart data={callStats.dailyCallTrends} margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 5
            }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Area type="monotone" dataKey="calls" fill="#3B82F6" stroke="#3B82F6" fillOpacity={0.6} />
            </AreaChart>}
          </ResponsiveContainer>
        </div>
      </Card>
    </div>}
    {activeChart === 'users' && <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card title="Call Status by User">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={enhancedCallData} margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 5
            }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="connected" stackId="a" fill="#10B981" />
              <Bar dataKey="notAnswered" stackId="a" fill="#F59E0B" />
              <Bar dataKey="busy" stackId="a" fill="#EF4444" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card title="Average Call Duration by User">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={enhancedCallData.map(user => ({
              ...user,
              avgDuration: (Math.random() * 2 + 3).toFixed(1)
            }))} margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 5
            }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Legend />
              <Bar yAxisId="left" dataKey="calls" fill="#3B82F6" />
              <Line yAxisId="right" type="monotone" dataKey="avgDuration" stroke="#10B981" strokeWidth={2} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card title="Weekly Performance Comparison" className="lg:col-span-2">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={weeklyData} margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 5
            }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="calls" fill="#3B82F6" />
              <Bar dataKey="connected" fill="#10B981" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 pt-4 border-t border-gray-100">
          <div className="text-center">
            <p className="text-sm text-gray-500">Total Calls</p>
            <p className="text-xl font-semibold text-gray-900">206</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-500">Connected</p>
            <p className="text-xl font-semibold text-green-600">135</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-500">Success Rate</p>
            <p className="text-xl font-semibold text-blue-600">65.5%</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-500">Avg Duration</p>
            <p className="text-xl font-semibold text-purple-600">4.2m</p>
          </div>
        </div>
      </Card>
    </div>}
    {activeChart === 'time' && <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card title="Hourly Call Distribution">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={hourlyDistribution} margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 5
            }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="hour" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="calls" fill="#3B82F6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card title="Day of Week Analysis">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={[{
              day: 'Monday',
              calls: 22,
              connected: 15
            }, {
              day: 'Tuesday',
              calls: 28,
              connected: 18
            }, {
              day: 'Wednesday',
              calls: 30,
              connected: 20
            }, {
              day: 'Thursday',
              calls: 25,
              connected: 16
            }, {
              day: 'Friday',
              calls: 20,
              connected: 12
            }]} margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 5
            }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="calls" fill="#3B82F6" />
              <Bar dataKey="connected" fill="#10B981" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card title="Monthly Trends" className="lg:col-span-2">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={[{
              month: 'Jan',
              calls: 120,
              connected: 75,
              duration: 4.1
            }, {
              month: 'Feb',
              calls: 135,
              connected: 82,
              duration: 4.0
            }, {
              month: 'Mar',
              calls: 150,
              connected: 95,
              duration: 4.2
            }, {
              month: 'Apr',
              calls: 145,
              connected: 90,
              duration: 4.3
            }, {
              month: 'May',
              calls: 160,
              connected: 105,
              duration: 4.4
            }, {
              month: 'Jun',
              calls: 175,
              connected: 115,
              duration: 4.5
            }]} margin={{
              top: 20,
              right: 30,
              left: 20,
              bottom: 5
            }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="calls" stroke="#3B82F6" strokeWidth={2} />
              <Line yAxisId="left" type="monotone" dataKey="connected" stroke="#10B981" strokeWidth={2} />
              <Line yAxisId="right" type="monotone" dataKey="duration" stroke="#F59E0B" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>}
    {/* Summary Stats */}
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card className="hover:shadow-md transition-shadow duration-200">
        <div className="text-center">
          <p className="text-sm font-medium text-gray-500">Total Calls</p>
          <p className="mt-2 text-3xl font-semibold text-gray-900">35</p>
          <div className="mt-2 flex justify-center">
            <button className="text-xs text-blue-600 hover:text-blue-800 flex items-center">
              View details <ArrowRightIcon size={12} className="ml-1" />
            </button>
          </div>
        </div>
      </Card>
      <Card className="hover:shadow-md transition-shadow duration-200">
        <div className="text-center">
          <p className="text-sm font-medium text-gray-500">Connected Rate</p>
          <p className="mt-2 text-3xl font-semibold text-green-600">51.4%</p>
          <div className="mt-2 flex justify-center">
            <div className="w-32 bg-gray-200 rounded-full h-2.5">
              <div className="bg-green-600 h-2.5 rounded-full" style={{
                width: '51.4%'
              }}></div>
            </div>
          </div>
        </div>
      </Card>
      <Card className="hover:shadow-md transition-shadow duration-200">
        <div className="text-center">
          <p className="text-sm font-medium text-gray-500">
            Avg. Call Duration
          </p>
          <p className="mt-2 text-3xl font-semibold text-blue-600">4:12</p>
          <div className="mt-2 flex justify-center">
            <button className="text-xs text-blue-600 hover:text-blue-800 flex items-center">
              View details <ArrowRightIcon size={12} className="ml-1" />
            </button>
          </div>
        </div>
      </Card>
      <Card className="hover:shadow-md transition-shadow duration-200">
        <div className="text-center">
          <p className="text-sm font-medium text-gray-500">Calls per User</p>
          <p className="mt-2 text-3xl font-semibold text-purple-600">8.75</p>
          <div className="mt-2 flex justify-center">
            <button className="text-xs text-blue-600 hover:text-blue-800 flex items-center">
              View details <ArrowRightIcon size={12} className="ml-1" />
            </button>
          </div>
        </div>
      </Card>
    </div>
    {/* Expanded Chart Modal */}
    {expandedChart && <div className="fixed inset-0 z-50 overflow-y-auto bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl">
        <div className="flex justify-between items-center p-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">
            {expandedChart === 'userCalls' && 'Calls per User'}
            {expandedChart === 'callStatus' && 'Call Status Distribution'}
            {expandedChart === 'dailyTrends' && 'Daily Call Trends'}
          </h3>
          <button onClick={handleCloseExpandedChart} className="text-gray-400 hover:text-gray-600">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="p-6">
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              {expandedChart === 'userCalls' && <BarChart data={enhancedCallData} margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 5
              }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="connected" name="Connected" stackId="a" fill="#10B981" />
                <Bar dataKey="notAnswered" name="Not Answered" stackId="a" fill="#F59E0B" />
                <Bar dataKey="busy" name="Busy" stackId="a" fill="#EF4444" />
              </BarChart>}
              {expandedChart === 'callStatus' && <PieChart>
                <Pie data={callStats.callStatusDistribution} cx="50%" cy="50%" labelLine={false} outerRadius={120} fill="#8884d8" dataKey="value" label={({
                  name,
                  percent
                }) => `${name}: ${(percent * 100).toFixed(0)}%`}>
                  {callStats.callStatusDistribution.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>}
              {expandedChart === 'dailyTrends' && <ComposedChart data={callStats.dailyCallTrends.map(item => ({
                ...item,
                connected: Math.floor(item.calls * 0.6),
                notAnswered: Math.floor(item.calls * 0.3),
                busy: item.calls - Math.floor(item.calls * 0.6) - Math.floor(item.calls * 0.3)
              }))} margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 5
              }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="calls" fill="#3B82F6" />
                <Line type="monotone" dataKey="connected" stroke="#10B981" strokeWidth={2} />
              </ComposedChart>}
            </ResponsiveContainer>
          </div>
        </div>
        <div className="flex justify-end p-4 border-t border-gray-200">
          <Button variant="outline" onClick={handleCloseExpandedChart}>
            Close
          </Button>
        </div>
      </div>
    </div>}
    {/* Detailed Stats Table */}
    <Card title="Performance by User">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                User
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Total Calls
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Connected
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Not Answered
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Busy
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Avg. Duration
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Trend
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            <tr className="hover:bg-gray-50 cursor-pointer">
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                Jane Smith
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                12
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                8 (67%)
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600">
                3 (25%)
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-orange-600">
                1 (8%)
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                5:42
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="w-16 h-6">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={[{
                      day: 1,
                      calls: 2
                    }, {
                      day: 2,
                      calls: 3
                    }, {
                      day: 3,
                      calls: 2
                    }, {
                      day: 4,
                      calls: 5
                    }]}>
                      <Line type="monotone" dataKey="calls" stroke="#3B82F6" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </td>
            </tr>
            <tr className="hover:bg-gray-50 cursor-pointer">
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                Robert Johnson
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                9
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                4 (44%)
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600">
                4 (44%)
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-orange-600">
                1 (11%)
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                3:58
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="w-16 h-6">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={[{
                      day: 1,
                      calls: 3
                    }, {
                      day: 2,
                      calls: 2
                    }, {
                      day: 3,
                      calls: 1
                    }, {
                      day: 4,
                      calls: 3
                    }]}>
                      <Line type="monotone" dataKey="calls" stroke="#3B82F6" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </td>
            </tr>
            <tr className="hover:bg-gray-50 cursor-pointer">
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                Michael Wilson
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                15
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                9 (60%)
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600">
                4 (27%)
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-orange-600">
                2 (13%)
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                4:22
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="w-16 h-6">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={[{
                      day: 1,
                      calls: 3
                    }, {
                      day: 2,
                      calls: 4
                    }, {
                      day: 3,
                      calls: 3
                    }, {
                      day: 4,
                      calls: 5
                    }]}>
                      <Line type="monotone" dataKey="calls" stroke="#3B82F6" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </td>
            </tr>
            <tr className="hover:bg-gray-50 cursor-pointer">
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                Sarah Brown
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                7
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                3 (43%)
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600">
                3 (43%)
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-orange-600">
                1 (14%)
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                3:47
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="w-16 h-6">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={[{
                      day: 1,
                      calls: 1
                    }, {
                      day: 2,
                      calls: 2
                    }, {
                      day: 3,
                      calls: 2
                    }, {
                      day: 4,
                      calls: 2
                    }]}>
                      <Line type="monotone" dataKey="calls" stroke="#3B82F6" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </Card>
  </div>;
};
export default Reports;