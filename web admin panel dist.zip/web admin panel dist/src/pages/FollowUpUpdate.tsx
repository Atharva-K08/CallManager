import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeftIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import FormInput from '../components/ui/FormInput';
import { useFollowUps } from '../hooks/useFollowUps';
import { UpdateFollowUpRequest } from '../services/followUp.service';
import followUpService from '../services/followUp.service';
import { TableSkeleton } from '../components/ui/Skeleton';

const FollowUpUpdate: React.FC = () => {
    const navigate = useNavigate();
    const { id } = useParams<{ id: string }>();
    const { update, loading } = useFollowUps();

    const [followUp, setFollowUp] = useState<any>(null);
    const [followUpLoading, setFollowUpLoading] = useState(true);
    const [formErrors, setFormErrors] = useState<{ [k: string]: string }>({});
    const [formData, setFormData] = useState<UpdateFollowUpRequest & { _id?: string }>({
        leadId: '',
        leadName: '',
        dueAt: '',
        note: '',
        status: 'PENDING',
    });

    useEffect(() => {
        const loadFollowUp = async () => {
            if (!id) return;
            try {
                setFollowUpLoading(true);
                const followUpData = await followUpService.getFollowUpById(id);
                setFollowUp(followUpData);

                // Handle both populated lead object and direct fields
                const leadId = typeof followUpData.leadId === 'object' ? followUpData.leadId._id : followUpData.leadId;
                const leadName = typeof followUpData.leadId === 'object'
                    ? `${followUpData.leadId.firstName || ''} ${followUpData.leadId.lastName || ''}`.trim()
                    : followUpData.leadName;

                setFormData({
                    _id: followUpData._id,
                    leadId: leadId || '',
                    leadName: leadName || '',
                    dueAt: followUpData.dueAt ? new Date(followUpData.dueAt).toISOString().slice(0, 16) : '',
                    note: followUpData.note || '',
                    status: followUpData.status || 'PENDING',
                });
            } catch (error: any) {
                console.error('Failed to load follow-up:', error);
            } finally {
                setFollowUpLoading(false);
            }
        };
        loadFollowUp();
    }, [id]);

    const validateForm = () => {
        const errors: { [k: string]: string } = {};
        if (!formData.dueAt?.trim()) errors.dueAt = 'Due date is required';
        if (formData.dueAt && new Date(formData.dueAt) <= new Date()) {
            errors.dueAt = 'Due date must be in the future';
        }
        return errors;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!id) return;

        const errors = validateForm();
        if (Object.keys(errors).length) {
            setFormErrors(errors);
            return;
        }

        try {
            const payload: UpdateFollowUpRequest = { ...formData };
            delete (payload as any)._id;
            await update(id, payload);
            navigate('/follow-ups');
        } catch (error: any) {
            // Error handling is done in the hook
        }
    };

    if (followUpLoading) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/follow-ups')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <div className="h-8 bg-gray-200 rounded w-64 animate-pulse"></div>
                </div>
                <Card>
                    <div className="p-6">
                        <TableSkeleton rows={5} columns={1} />
                    </div>
                </Card>
            </div>
        );
    }

    if (!followUp) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/follow-ups')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <h1 className="text-2xl font-semibold text-gray-900">Follow-up Not Found</h1>
                </div>
                <Card>
                    <div className="p-6 text-center">
                        <p className="text-gray-500">The requested follow-up could not be found.</p>
                    </div>
                </Card>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={() => navigate('/follow-ups')} icon={<ArrowLeftIcon size={16} />}>
                    Back
                </Button>
                <h1 className="text-2xl font-semibold text-gray-900">Edit Follow-up</h1>
            </div>

            <Card>
                <div className="p-6">
                    <form onSubmit={handleSubmit} className="space-y-5">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Lead Name" htmlFor="leadName">
                                <FormInput
                                    id="leadName"
                                    name="leadName"
                                    placeholder="e.g., John Doe"
                                    value={formData.leadName || ''}
                                    onChange={(e) => setFormData({ ...formData, leadName: e.target.value })}
                                    className="h-11"
                                    disabled={true}
                                />
                            </FormField>
                            <FormField label="Due Date & Time" htmlFor="dueAt" required error={formErrors.dueAt}>
                                <input
                                    id="dueAt"
                                    name="dueAt"
                                    type="datetime-local"
                                    lang="en-GB"
                                    value={formData.dueAt || ''}
                                    onClick={(e) => {
                                        e.currentTarget.showPicker?.();
                                    }}
                                    onChange={(e) => {
                                        setFormData({ ...formData, dueAt: e.target.value });
                                        if (formErrors.dueAt) {
                                            setFormErrors({ ...formErrors, dueAt: '' });
                                        }
                                    }}
                                    className={`block w-full px-3 py-2.5 h-11 border rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 cursor-pointer ${formErrors.dueAt ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : 'border-gray-300'
                                        }`}
                                />
                                {formErrors.dueAt && (
                                    <p className="mt-1 text-sm text-red-600">{formErrors.dueAt}</p>
                                )}
                            </FormField>
                        </div>

                        <FormField label="Note" htmlFor="note" error={formErrors.note}>
                            <textarea
                                id="note"
                                name="note"
                                className={`block w-full px-3 py-2.5 border rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 resize-none ${formErrors.note ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : 'border-gray-300'
                                    }`}
                                rows={5}
                                placeholder="Add any notes for this follow-up (optional)"
                                value={formData.note || ''}
                                onChange={(e) => {
                                    setFormData({ ...formData, note: e.target.value });
                                    if (formErrors.note) {
                                        setFormErrors({ ...formErrors, note: '' });
                                    }
                                }}
                            />
                            {formErrors.note && (
                                <p className="mt-1 text-sm text-red-600">{formErrors.note}</p>
                            )}
                        </FormField>

                        <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                            <Button type="button" variant="outline" onClick={() => navigate('/follow-ups')}>Cancel</Button>
                            <Button type="submit" variant="primary" disabled={loading}>
                                {loading ? 'Saving...' : 'Save Changes'}
                            </Button>
                        </div>
                    </form>
                </div>
            </Card>
        </div>
    );
};

export default FollowUpUpdate;

