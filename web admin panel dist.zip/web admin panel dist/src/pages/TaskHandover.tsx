import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useParams, useSearchParams, useLocation } from 'react-router-dom';
import { ArrowLeftIcon, UserIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import FormInput from '../components/ui/FormInput';
import { useTasks } from '../hooks/useTasks';
import { useLeads } from '../hooks/useLeads';
import taskService, { HandoverTaskRequest } from '../services/task.service';
import { useToastNotifications } from '../lib/toast';
import { TableSkeleton } from '../components/ui/Skeleton';
import { useSetting } from '../hooks/useSettings';

const TaskHandover: React.FC = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const { taskId } = useParams<{ taskId: string }>();
    const [searchParams] = useSearchParams();
    const { getTaskById } = useTasks();
    const { data: leadsData, fetch: fetchLeads } = useLeads();
    const { showSuccess, showErrorWithDetails } = useToastNotifications();

    // Get task counter from settings
    const { value: taskCounter } = useSetting<number>('tasks', 'counter', 0);

    // Get form state from location state (preserved across navigation)
    const savedFormData = location.state as {
        title?: string;
        description?: string;
        dueAt?: string;
        assignedTo?: string;
        assignedToName?: string;
        assignedToEmail?: string;
    } | null;

    const leadIdsParam = searchParams.get('leadIds') || '';
    const leadIds = leadIdsParam ? leadIdsParam.split(',').filter(Boolean) : [];

    const [task, setTask] = useState<any>(null);
    const [taskLoading, setTaskLoading] = useState(true);
    const [leadsLoading, setLeadsLoading] = useState(false);
    const [submitting, setSubmitting] = useState(false);

    // Initialize from saved state or empty
    const [title, setTitle] = useState(savedFormData?.title || '');
    const [assignedTo, setAssignedTo] = useState(savedFormData?.assignedTo || '');
    const [assignedToName, setAssignedToName] = useState(savedFormData?.assignedToName || '');
    const [assignedToEmail, setAssignedToEmail] = useState(savedFormData?.assignedToEmail || '');
    const [dueAt, setDueAt] = useState<string>(savedFormData?.dueAt || '');
    const [description, setDescription] = useState(savedFormData?.description || '');

    // Get updated values from query params (for navigation from SelectCaller)
    const assignedToFromParams = searchParams.get('assignedTo');
    const assignedToNameFromParams = searchParams.get('assignedToName');
    const assignedToEmailFromParams = searchParams.get('assignedToEmail');

    // Load task
    useEffect(() => {
        const loadTask = async () => {
            if (!taskId) return;
            try {
                setTaskLoading(true);
                const taskData = await getTaskById(taskId);
                setTask(taskData);
            } catch (error: any) {
                showErrorWithDetails('Failed to load task', error?.message);
            } finally {
                setTaskLoading(false);
            }
        };
        loadTask();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [taskId]);

    // Load selected leads
    useEffect(() => {
        if (leadIds.length > 0) {
            const loadLeads = async () => {
                try {
                    setLeadsLoading(true);
                    await fetchLeads({
                        page: 1,
                        limit: 1000,
                        sortBy: 'updatedAt:desc'
                    });
                } catch (error) {
                    console.error('Error loading leads:', error);
                } finally {
                    setLeadsLoading(false);
                }
            };
            loadLeads();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [JSON.stringify(leadIds)]);

    // Update form data when params change (after returning from SelectCaller)
    useEffect(() => {
        if (assignedToFromParams) {
            setAssignedTo(assignedToFromParams);
            setAssignedToName(assignedToNameFromParams || '');
            setAssignedToEmail(assignedToEmailFromParams || '');
        }
    }, [assignedToFromParams, assignedToNameFromParams, assignedToEmailFromParams]);

    // Auto-generate title immediately on page open and update when leads change
    useEffect(() => {
        // Always generate title if it's empty or was previously auto-generated
        if (!title || title.startsWith('Task #') || title.startsWith('Task -')) {
            const nextTaskNumber = (taskCounter || 0) + 1;
            const leadCount = leadIds.length;
            
            if (leadCount > 0) {
                const generatedTitle = `Task #${nextTaskNumber} - ${leadCount} lead${leadCount === 1 ? '' : 's'}`;
                setTitle(generatedTitle);
            } else {
                // Generate basic title even without leads
                const generatedTitle = `Task #${nextTaskNumber}`;
                setTitle(generatedTitle);
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [leadIds.length, taskCounter]);

    const allLeads = leadsData?.results || [];
    const selectedLeads = useMemo(() => {
        return allLeads.filter((l: any) => leadIds.includes(l._id));
    }, [allLeads, leadIds]);

    const formatDateTimeLocal = (iso?: string) => {
        if (!iso) return '';
        const d = new Date(iso);
        const pad = (n: number) => String(n).padStart(2, '0');
        const yyyy = d.getFullYear();
        const MM = pad(d.getMonth() + 1);
        const dd = pad(d.getDate());
        const hh = pad(d.getHours());
        const mm = pad(d.getMinutes());
        return `${yyyy}-${MM}-${dd}T${hh}:${mm}`;
    };

    const canSubmit = title.trim().length > 0 && assignedTo && leadIds.length > 0 && !submitting;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!canSubmit || !taskId) return;

        try {
            setSubmitting(true);
            const payload: HandoverTaskRequest = {
                title: title.trim(),
                assignedTo,
                dueAt: dueAt || undefined,
                description: description || undefined,
                leadIds,
                assignedToName,
                assignedToEmail,
                sourceTaskId: taskId,
            };
            await taskService.handover(payload);
            showSuccess('Task handed over successfully');
            navigate(`/tasks/${taskId}`);
        } catch (error: any) {
            showErrorWithDetails('Failed to handover task', error?.message);
        } finally {
            setSubmitting(false);
        }
    };

    const handleSelectCaller = () => {
        const params = new URLSearchParams();
        params.set('returnTo', `/tasks/${taskId}/handover`);
        params.set('leadIds', leadIds.join(','));
        if (task?.assignedTo) {
            params.set('excludeUserId', task.assignedTo);
        }
        if (assignedTo) {
            params.set('selectedId', assignedTo);
        }
        navigate(`/users/select/caller?${params.toString()}`, {
            state: {
                title,
                description,
                dueAt,
                assignedTo,
                assignedToName,
                assignedToEmail,
            },
        });
    };

    if (taskLoading) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate(`/tasks/${taskId}`)} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <div className="h-8 bg-gray-200 rounded w-64 animate-pulse"></div>
                </div>
                <Card>
                    <div className="p-6">
                        <TableSkeleton rows={5} columns={1} />
                    </div>
                </Card>
            </div>
        );
    }

    if (!task) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/tasks')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <h1 className="text-2xl font-semibold text-gray-900">Task Not Found</h1>
                </div>
                <Card>
                    <div className="p-6 text-center">
                        <p className="text-gray-500">The requested task could not be found.</p>
                    </div>
                </Card>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={() => navigate(`/tasks/${taskId}`)} icon={<ArrowLeftIcon size={16} />}>
                    Back
                </Button>
                <h1 className="text-2xl font-semibold text-gray-900">Handover Leads</h1>
            </div>

            <Card>
                <div className="p-6">
                    <form onSubmit={handleSubmit} className="space-y-5">
                        <div className="space-y-4">
                            <FormField label="Task Title" htmlFor="handover-title">
                                <FormInput
                                    id="handover-title"
                                    value={title}
                                    onChange={(e) => setTitle(e.target.value)}
                                    placeholder="e.g., Follow up leads batch"
                                    className="h-11"
                                />
                            </FormField>
                            <FormField label="Assign To" htmlFor="handover-assignee" required>
                                <div
                                    role="button"
                                    tabIndex={0}
                                    onClick={handleSelectCaller}
                                    onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleSelectCaller(); }}
                                    className={`w-full flex items-center justify-between gap-3 rounded-lg border ${assignedTo ? 'border-gray-200' : 'border-dashed border-gray-300'} bg-white px-3 py-2 shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-primary/40`}
                                >
                                    <div className="flex items-center gap-3 min-w-0">
                                        <div className={`h-10 w-10 rounded-full ${assignedTo ? 'bg-blue-100 text-blue-700' : 'bg-gray-200 text-gray-500'} flex items-center justify-center text-sm font-semibold`}>
                                            {assignedToName
                                                ? String(assignedToName).split(' ').map((p) => p[0]).filter(Boolean).slice(0, 2).join('').toUpperCase()
                                                : '?'}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            {assignedToName ? (
                                                <>
                                                    <div className="truncate text-sm font-medium text-gray-900" title={assignedToName}>{assignedToName}</div>
                                                    <div className="truncate text-xs text-gray-500" title={assignedToEmail || ''}>{assignedToEmail || '—'}</div>
                                                </>
                                            ) : (
                                                <div className="text-sm text-gray-500">Select a caller</div>
                                            )}
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2 shrink-0">
                                        {assignedTo && (
                                            <Button
                                                variant="outline"
                                                size="sm"
                                                type="button"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    setAssignedTo('');
                                                    setAssignedToName('');
                                                    setAssignedToEmail('');
                                                }}
                                            >
                                                Clear
                                            </Button>
                                        )}
                                        <Button variant='outline' size='sm' type='button' onClick={(e) => { e.stopPropagation(); handleSelectCaller(); }}>{assignedTo ? 'Change' : 'Select'}</Button>
                                    </div>
                                </div>
                            </FormField>
                        </div>

                        <div className="space-y-4">
                            <FormField label="Due Date" htmlFor="handover-dueAt">
                                <input
                                    id="handover-dueAt"
                                    type="datetime-local"
                                    lang="en-GB"
                                    value={dueAt}
                                    onClick={(e) => {
                                        e.currentTarget.showPicker?.();
                                    }}
                                    onChange={(e) => setDueAt(e.target.value)}
                                    className="w-full h-11 border border-gray-300 rounded-md px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 cursor-pointer"
                                />
                            </FormField>
                        </div>

                        <div>
                            <div className="text-sm font-medium text-gray-700 mb-2">Selected Leads ({leadIds.length})</div>
                            {leadsLoading ? (
                                <div className="max-h-40 overflow-auto border border-gray-200 rounded-md p-2 bg-white">
                                    <TableSkeleton rows={3} columns={1} />
                                </div>
                            ) : (
                                <div className="max-h-40 overflow-auto border border-gray-200 rounded-md p-2 bg-white">
                                    {selectedLeads.length === 0 ? (
                                        <div className="text-sm text-gray-500">No leads selected.</div>
                                    ) : (
                                        <ul className="divide-y divide-gray-100">
                                            {selectedLeads.map((l: any) => {
                                                const fullName = l.firstName && l.lastName ? `${l.firstName} ${l.lastName}` : l.firstName || l.lastName || 'Unknown';
                                                return (
                                                    <li key={l._id} className="py-2 text-sm text-gray-800 flex items-center justify-between">
                                                        <span className="flex items-center gap-2">
                                                            <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center">
                                                                <UserIcon size={12} />
                                                            </span>
                                                            {fullName}{l.phoneNumber ? ` · ${l.phoneNumber}` : ''}
                                                        </span>
                                                    </li>
                                                );
                                            })}
                                        </ul>
                                    )}
                                </div>
                            )}
                        </div>

                        <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                            <Button type="button" variant="outline" onClick={() => navigate(`/tasks/${taskId}`)}>Cancel</Button>
                            <Button type="submit" variant="primary" disabled={!canSubmit || submitting}>
                                {submitting ? 'Submitting...' : 'Handover'}
                            </Button>
                        </div>
                    </form>
                </div>
            </Card>
        </div>
    );
};

export default TaskHandover;

