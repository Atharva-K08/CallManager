import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusIcon, SearchIcon, CalendarIcon, CheckCircleIcon, UndoIcon, EditIcon, TrashIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Table from '../components/ui/Table';
import Button from '../components/ui/Button';
import Pagination from '../components/ui/Pagination';
import { TableSkeleton } from '../components/ui/Skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { debounce } from '../utils/performance';
import { useFollowUps } from '../hooks/useFollowUps';
import { followUpService } from '../services/followUp.service';
import { useToast } from '../contexts/ToastContext';

const FollowUps: React.FC = () => {
    const navigate = useNavigate();
    const { addToast } = useToast();
    const {
        data,
        fetch,
        // delete: deleteFollowUp, // Not used in current implementation
        // markAsDone, // Not used in current implementation
        // markAsCancelled, // Not used in current implementation
        loading,
    } = useFollowUps();

    const followUps = data?.results || [];
    const pagination = useMemo(() => ({
        current_page: data?.page || 1,
        total_pages: data?.totalPages || 1,
        total_items: data?.totalResults || 0,
        per_page: data?.limit || 10,
    }), [data]);

    // Debug logging
    console.log('FollowUps Page - data:', data);
    console.log('FollowUps Page - followUps:', followUps);
    console.log('FollowUps Page - loading:', loading);

    const [searchQuery, setSearchQuery] = useState('');
    const [filters, setFilters] = useState({
        status: 'all',
        sortBy: 'dueAt:asc',
    });

    // const statusColorMap = {
    //     'PENDING': '#f59e0b', // amber
    //     'DONE': '#10b981', // emerald
    //     'CANCELLED': '#ef4444', // red
    // };

    // const hexToRgba = (hex: string, alpha = 1): string => {
    //     const sanitized = hex.replace('#', '');
    //     const bigint = parseInt(sanitized.length === 3 ? sanitized.split('').map((c) => c + c).join('') : sanitized, 16);
    //     const r = (bigint >> 16) & 255;
    //     const g = (bigint >> 8) & 255;
    //     const b = bigint & 255;
    //     return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    // };

    const columns = [
        {
            key: 'leadName',
            header: 'Lead Name',
            width: 'w-3/12',
            render: (_: any, item: any) => {
                // Handle both populated lead object and direct leadName field
                if (typeof item.leadId === 'object' && item.leadId?.firstName) {
                    const fullName = `${item.leadId.firstName || ''} ${item.leadId.lastName || ''}`.trim();
                    return <span className="text-sm text-gray-900">{fullName || 'Unknown Lead'}</span>;
                }
                return <span className="text-sm text-gray-900">{item.leadName || 'Unknown Lead'}</span>;
            }
        },
        // { 
        //     key: 'leadId', 
        //     header: 'Lead ID', 
        //     width: 'w-2/12',
        //     render: (_: any, item: any) => {
        //         // Handle both populated lead object and direct leadId field
        //         if (typeof item.leadId === 'object' && item.leadId?._id) {
        //             return <span className="text-sm text-gray-600 font-mono">{item.leadId._id}</span>;
        //         }
        //         return <span className="text-sm text-gray-600 font-mono">{item.leadId}</span>;
        //     }
        // },
        {
            key: 'dueAt', header: 'Due Date & Time', width: 'w-2/12', render: (value: string) => {
                const date = new Date(value);
                const isOverdue = date < new Date() && new Date().toDateString() !== date.toDateString();
                return (
                    <div className="flex items-center">
                        <div className="flex flex-col">
                            <span className={`text-sm ${isOverdue ? 'text-red-600 font-medium' : 'text-gray-900'}`}>
                                {date.toLocaleDateString('en-GB')}
                            </span>
                            <span className={`text-xs ${isOverdue ? 'text-red-500' : 'text-gray-500'}`}>
                                {date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                        </div>
                        {isOverdue && <span className="ml-1 text-xs text-red-500">(Overdue)</span>}
                    </div>
                );
            }
        },
        {
            key: 'dynamicStatus',
            header: 'Status',
            width: 'w-2/12',
            render: (_: any, item: any) => {
                const status = item.dynamicStatus || 'upcoming';
                const statusConfig = {
                    overdue: { label: 'Overdue', bgColor: 'bg-red-100', textColor: 'text-red-700' },
                    upcoming: { label: 'Upcoming', bgColor: 'bg-blue-100', textColor: 'text-blue-700' },
                };
                const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.upcoming;
                return (
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${config.bgColor} ${config.textColor}`}>
                        {config.label}
                    </span>
                );
            }
        },
        // {
        //     key: 'status', header: 'Status', width: 'w-2/12', render: (value: string) => {
        //         const base = statusColorMap[value as keyof typeof statusColorMap] || '#9ca3af';
        //         const bg = hexToRgba(base, 0.15);
        //         return (
        //             <span
        //                 className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium"
        //                 style={{ backgroundColor: bg, color: base }}
        //             >
        //                 {value}
        //             </span>
        //         );
        //     }
        //         },
        // {
        //     key: 'resolutionStatus',
        //     header: 'Resolution Status',
        //     width: 'w-2/12',
        //     render: (_: any, item: any) => {
        //         const isResolved = item.metadata?.resolutionStatus === 'RESOLVED';
        //         return (
        //             <div className="flex items-center space-x-2">
        //                 <div className={`w-2 h-2 rounded-full ${isResolved ? 'bg-green-500' : 'bg-orange-500'}`}></div>
        //                 <span className={`text-sm ${isResolved ? 'text-green-600' : 'text-orange-600'}`}>
        //                     {isResolved ? 'Resolved' : 'Pending'}
        //                 </span>
        //             </div>
        //         );
        //     }
        // },
        {
            key: 'userName',
            header: 'Created By',
            width: 'w-2/12',
            render: (_: any, item: any) => {
                // Handle both populated user object and direct userName field
                if (typeof item.createdBy === 'object' && item.createdBy?.name) {
                    return <span className="text-sm text-gray-900">{item.createdBy.name}</span>;
                }
                return <span className="text-sm text-gray-900">{item.userName || 'Unknown User'}</span>;
            }
        },
        {
            key: 'note', header: 'Note', width: 'w-2/12', render: (value: string) => (
                <span className="text-sm text-gray-600 truncate block max-w-xs" title={value}>
                    {value || 'No note'}
                </span>
            )
        },
        {
            key: 'actions',
            header: 'Actions',
            width: 'w-24',
            render: (_: any, item: any) => {
                const isResolved = item.metadata?.resolutionStatus === 'RESOLVED';
                return (
                    <div className="flex space-x-1 justify-start">
                        <button
                            onClick={(e) => { e.stopPropagation(); handleEditFollowUp(item); }}
                            className="p-1.5 rounded-full text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition-colors"
                            title="Edit Follow-up"
                        >
                            <EditIcon size={16} />
                        </button>
                        <button
                            onClick={(e) => { e.stopPropagation(); handleDeleteFollowUp(item); }}
                            className="p-1.5 rounded-full text-red-600 hover:text-red-800 hover:bg-red-50 transition-colors"
                            title="Delete Follow-up"
                        >
                            <TrashIcon size={16} />
                        </button>
                    </div>
                );
            }
        },
        // {
        //     key: 'actions', header: 'Actions', width: 'w-2/12', render: (_: any, item: any) => (
        //         <div className="flex space-x-1 justify-end">
        //             {item.status === 'PENDING' && (
        //                 <>
        //                     <button
        //                         onClick={(e) => { e.stopPropagation(); handleMarkAsDone(item._id); }}
        //                         className="p-1.5 rounded-full text-green-600 hover:text-green-800 hover:bg-green-50 transition-colors"
        //                         title="Mark as Done"
        //                     >
        //                         <CheckIcon size={16} />
        //                     </button>
        //                     <button
        //                         onClick={(e) => { e.stopPropagation(); handleMarkAsCancelled(item._id); }}
        //                         className="p-1.5 rounded-full text-red-600 hover:text-red-800 hover:bg-red-50 transition-colors"
        //                         title="Mark as Cancelled"
        //                     >
        //                         <XIcon size={16} />
        //                     </button>
        //                 </>
        //             )}
        //             <button
        //                 onClick={(e) => { e.stopPropagation(); handleEditFollowUp(item); }}
        //                 className="p-1.5 rounded-full text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition-colors"
        //                 title="Edit Follow-up"
        //             >
        //                 <EditIcon size={16} />
        //             </button>
        //         </div>
        //     )
        // }
    ];

    useEffect(() => { fetch({ page: 1, limit: 10, sortBy: filters.sortBy }); }, []);

    const convertFiltersToApi = (local: typeof filters) => {
        const api: any = {
            sortBy: local.sortBy,
        };

        // Only add status if it's not 'all'
        if (local.status && local.status !== 'all') {
            api.status = local.status;
        }

        return api;
    };

    const debouncedSearch = debounce((_query: string) => {
        const api = convertFiltersToApi(filters);
        fetch({ ...api, page: 1 });
    }, 500);

    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const q = e.target.value;
        setSearchQuery(q);
        debouncedSearch(q);
    };

    const handleFilterChange = (key: keyof typeof filters, value: string) => {
        const nf = { ...filters, [key]: value };
        setFilters(nf);
        const api = convertFiltersToApi(nf);
        fetch({ ...api, page: 1 });
    };

    const handlePageChange = (page: number) => {
        const api = convertFiltersToApi(filters);
        fetch({ ...api, page });
    };

    const handlePerPageChange = (perPage: number) => {
        const api = convertFiltersToApi(filters);
        fetch({ ...api, limit: perPage, page: 1 });
    };

    const handleAddFollowUp = () => {
        navigate('/follow-ups/create');
    };

    // const handleEditFollowUp = (followUp: any) => {
    //     setCurrentFollowUpId(followUp._id);

    //     // Handle both populated lead object and direct fields
    //     const leadId = typeof followUp.leadId === 'object' ? followUp.leadId._id : followUp.leadId;
    //     const leadName = typeof followUp.leadId === 'object' ? followUp.leadId.name : followUp.leadName;

    //     setFormData({
    //         _id: followUp._id,
    //         leadId: leadId || '',
    //         leadName: leadName || '',
    //         dueAt: followUp.dueAt ? new Date(followUp.dueAt).toISOString().slice(0, 16) : '',
    //         note: followUp.note || '',
    //         status: followUp.status || 'PENDING',
    //     });
    //     setFormErrors({});
    //     setIsDrawerOpen(true);
    // };

    // const handleMarkAsDone = async (id: string) => {
    //     try {
    //         await markAsDone(id);
    //     } catch (err) {
    //         // Error handling is done in the hook
    //     }
    // };

    // const handleMarkAsCancelled = async (id: string) => {
    //     try {
    //         await markAsCancelled(id);
    //     } catch (err) {
    //         // Error handling is done in the hook
    //     }
    // };

    const handleResolveFollowUp = async (followUp: any) => {
        const reason = prompt('Enter resolution reason:');
        if (reason && reason.trim()) {
            try {
                await followUpService.resolveFollowUp(followUp._id, reason.trim());
                addToast({
                    type: 'success',
                    title: 'Success',
                    description: 'Follow-up resolved successfully'
                });
                fetch();
            } catch (error) {
                addToast({
                    type: 'error',
                    title: 'Error',
                    description: 'Failed to resolve follow-up'
                });
            }
        }
    };

    const handleUnresolveFollowUp = async (followUp: any) => {
        if (confirm('Are you sure you want to unresolve this follow-up?')) {
            try {
                await followUpService.unresolveFollowUp(followUp._id);
                addToast({
                    type: 'success',
                    title: 'Success',
                    description: 'Follow-up unresolved successfully'
                });
                fetch();
            } catch (error) {
                addToast({
                    type: 'error',
                    title: 'Error',
                    description: 'Failed to unresolve follow-up'
                });
            }
        }
    };

    const handleEditFollowUp = (followUp: any) => {
        navigate(`/follow-ups/${followUp._id}/update`);
    };

    const handleDeleteFollowUp = async (followUp: any) => {
        if (confirm('Are you sure you want to delete this follow-up?')) {
            try {
                await followUpService.deleteFollowUp(followUp._id);
                addToast({
                    type: 'success',
                    title: 'Success',
                    description: 'Follow-up deleted successfully'
                });
                fetch();
            } catch (error) {
                addToast({
                    type: 'error',
                    title: 'Error',
                    description: 'Failed to delete follow-up'
                });
            }
        }
    };


    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-semibold text-gray-900">Follow-ups</h1>
                </div>
                {/* <Button variant="primary" onClick={handleAddFollowUp} icon={<PlusIcon size={16} />}>
                    Add New Follow-up
                </Button> */}
            </div>

            <Card>
                <div className="p-3 space-y-2">
                    <div className="flex flex-col md:flex-row md:items-end gap-3">
                        {/* <div className="md:flex-1">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Search Follow-ups</label>
                            <div className="relative">
                                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <SearchIcon size={18} className="text-gray-400" />
                                </div>
                                <input
                                    type="text"
                                    placeholder="Search by lead name or ID..."
                                    value={searchQuery}
                                    onChange={handleSearchChange}
                                    className="block w-full pl-10 pr-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400"
                                />
                            </div>
                        </div> */}
                        {/* <div className="lg:col-span-3">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                            <Select value={filters.status} onValueChange={(v: string) => handleFilterChange('status', v)}>
                                <SelectTrigger className="w-full"><SelectValue placeholder="All" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All</SelectItem>
                                    <SelectItem value="PENDING">Pending</SelectItem>
                                    <SelectItem value="DONE">Done</SelectItem>
                                    <SelectItem value="CANCELLED">Cancelled</SelectItem>
                                </SelectContent>
                            </Select>
                        </div> */}
                        <div className="md:w-56">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Sort By</label>
                            <Select value={filters.sortBy} onValueChange={(v: string) => handleFilterChange('sortBy', v)}>
                                <SelectTrigger className="w-full h-11"><SelectValue placeholder="Sort by" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="dueAt:asc">Due Date (Earliest)</SelectItem>
                                    <SelectItem value="dueAt:desc">Due Date (Latest)</SelectItem>
                                    <SelectItem value="createdAt:desc">Created (Newest)</SelectItem>
                                    <SelectItem value="createdAt:asc">Created (Oldest)</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                </div>
            </Card>

            <Card>
                {loading ? (
                    <div className="p-6"><TableSkeleton rows={5} columns={6} /></div>
                ) : (
                    <>
                        <Table columns={columns} data={followUps} />
                        {pagination.total_pages > 1 && (
                            <div className="p-6 border-t border-gray-200">
                                <Pagination
                                    currentPage={pagination.current_page}
                                    totalPages={pagination.total_pages}
                                    totalItems={pagination.total_items}
                                    perPage={pagination.per_page}
                                    onPageChange={handlePageChange}
                                    onPerPageChange={handlePerPageChange}
                                />
                            </div>
                        )}
                    </>
                )}
            </Card>
        </div>
    );
};

export default FollowUps;


