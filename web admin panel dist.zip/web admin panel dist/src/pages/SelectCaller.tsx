import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useNavigate, useSearchParams, useLocation } from 'react-router-dom';
import { ArrowLeftIcon, SearchIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import { useUsers } from '../hooks/useUsers';
import { debounce } from '../utils/performance';
import { TableSkeleton } from '../components/ui/Skeleton';

const SelectCaller: React.FC = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [searchParams] = useSearchParams();
    const { users, usersLoading, getUsers } = useUsers();

    const returnTo = searchParams.get('returnTo') || '/tasks';
    const selectedId = searchParams.get('selectedId') || '';
    const excludeUserId = searchParams.get('excludeUserId') || '';

    const [search, setSearch] = useState('');
    const isInitialMount = useRef(true);

    // Load users on mount
    useEffect(() => {
        const filters: any = { role: 'caller', isActive: true, sortBy: 'createdAt:desc' };
        if (excludeUserId) {
            // Note: API may need to support excludeUserId filter
        }
        getUsers(filters);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [excludeUserId]);

    // Debounced search
    const debouncedSearch = useMemo(
        () => debounce((query: string) => {
            const q = query.trim();
            if (q.length === 0) {
                getUsers({ role: 'caller', isActive: true, sortBy: 'createdAt:desc' } as any);
            } else {
                getUsers({ role: 'caller', isActive: true, name: q } as any);
            }
        }, 400),
        // eslint-disable-next-line react-hooks/exhaustive-deps
        []
    );

    useEffect(() => {
        // Skip debounced search on initial mount (already loaded in first useEffect)
        if (isInitialMount.current) {
            isInitialMount.current = false;
            return;
        }
        debouncedSearch(search);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [search]);

    const handleBack = () => {
        const params = new URLSearchParams();
        // Preserve any existing params from returnTo URL
        const returnToParts = returnTo.split('?');
        const currentReturnTo = returnToParts[0];
        
        if (returnToParts.length > 1) {
            // Parse existing params from returnTo
            const existingParams = new URLSearchParams(returnToParts[1]);
            existingParams.forEach((value, key) => {
                params.set(key, value);
            });
        }
        
        // Preserve location state if it exists
        const preservedState = location.state;
        
        navigate(`${currentReturnTo}${params.toString() ? '?' + params.toString() : ''}`, {
            state: preservedState,
        });
    };

    const handleSelect = (user: any) => {
        const params = new URLSearchParams();
        params.set('assignedTo', user._id);
        params.set('assignedToName', user.name || '');
        params.set('assignedToEmail', user.email || '');
        
        // Preserve any existing params from returnTo URL
        const returnToParts = returnTo.split('?');
        if (returnToParts.length > 1) {
            const existingParams = new URLSearchParams(returnToParts[1]);
            existingParams.forEach((value, key) => {
                if (!params.has(key)) {
                    params.set(key, value);
                }
            });
        }
        
        // Preserve location state
        navigate(`${returnToParts[0]}?${params.toString()}`, {
            state: location.state,
        });
    };

    const filteredUsers = excludeUserId
        ? users.filter((u: any) => u._id !== excludeUserId)
        : users;

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={handleBack} icon={<ArrowLeftIcon size={16} />}>
                    Back
                </Button>
                <h1 className="text-2xl font-semibold text-gray-900">Select Caller</h1>
            </div>

            {/* Search */}
            <Card>
                <div className="p-6">
                    <FormField label="Search Callers" htmlFor="search">
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <SearchIcon size={18} className="text-gray-400" />
                            </div>
                            <input
                                type="text"
                                placeholder="Search by name or email..."
                                value={search}
                                onChange={(e) => setSearch(e.target.value)}
                                className="block w-full pl-10 pr-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400"
                            />
                        </div>
                    </FormField>
                </div>
            </Card>

            {/* Users List */}
            <Card>
                <div className="p-6">
                    {usersLoading ? (
                        <TableSkeleton rows={6} columns={1} />
                    ) : (
                        <div className="border rounded-md divide-y">
                            {filteredUsers.length === 0 ? (
                                <div className="p-4 text-sm text-gray-500 text-center">No callers found</div>
                            ) : (
                                filteredUsers.map((u: any) => (
                                    <div
                                        key={u._id}
                                        className={`p-3 flex items-center justify-between hover:bg-gray-50 cursor-pointer transition-colors ${selectedId && u._id === selectedId ? 'bg-blue-50' : ''}`}
                                        onClick={() => handleSelect(u)}
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className="h-9 w-9 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-semibold">
                                                {(u?.name || ' ')
                                                    .split(' ')
                                                    .map((p: string) => p[0])
                                                    .filter(Boolean)
                                                    .slice(0, 2)
                                                    .join('')
                                                    .toUpperCase()}
                                            </div>
                                            <div>
                                                <div className="text-sm font-medium text-gray-900">{u?.name || '—'}</div>
                                                <div className="text-xs text-gray-500">{u?.email || '—'}</div>
                                            </div>
                                        </div>
                                        {selectedId && u._id === selectedId ? (
                                            <span className="text-xs font-medium text-blue-600">Selected</span>
                                        ) : (
                                            <Button variant="outline" size="sm" type="button" onClick={(e) => { e.stopPropagation(); handleSelect(u); }}>
                                                Select
                                            </Button>
                                        )}
                                    </div>
                                ))
                            )}
                        </div>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default SelectCaller;

