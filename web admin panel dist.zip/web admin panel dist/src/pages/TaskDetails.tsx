import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
    ArrowLeftIcon,
    UserIcon,
    CheckCircleIcon,
    ClockIcon,
    MailIcon,
    SearchIcon
} from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Table from '../components/ui/Table';
import BulkActionsBar from '../components/ui/BulkActionsBar';
import HandoverDrawer from '../components/tasks/HandoverDrawer';
import taskService, { HandoverTaskRequest } from '../services/task.service';
import { useToastNotifications } from '../lib/toast';
import Pagination from '../components/ui/Pagination';
import { TableSkeleton } from '../components/ui/Skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { useTasks } from '../hooks/useTasks';
import { useLeads } from '../hooks/useLeads';
import { useLeadStatus } from '../hooks/useLeadStatus';
import { debounce } from '../utils/performance';

interface TaskDetailsProps { }

const TaskDetails: React.FC<TaskDetailsProps> = () => {
    const { taskId } = useParams<{ taskId: string }>();
    const navigate = useNavigate();

    const { getTaskById } = useTasks();
    const { data: leadsData, fetch: fetchLeads } = useLeads();
    const { data: leadStatusData, fetch: fetchLeadStatuses } = useLeadStatus();

    const [task, setTask] = useState<any>(null);
    const [taskLoading, setTaskLoading] = useState(true);
    const [leadsLoading, setLeadsLoading] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [statusFilter, setStatusFilter] = useState('all');
    const [completedFilter, setCompletedFilter] = useState('all');
    const [assignedFilter, setAssignedFilter] = useState<boolean | undefined>(undefined);
    const [currentPage, setCurrentPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const [selectedIds, setSelectedIds] = useState<string[]>([]);
    const [isHandoverOpen, setIsHandoverOpen] = useState(false);
    const { showSuccess, showErrorWithDetails } = useToastNotifications();

    const leads = leadsData?.results || [];
    const pagination = {
        current_page: leadsData?.page || 1,
        total_pages: leadsData?.totalPages || 1,
        total_items: leadsData?.totalResults || 0,
        per_page: leadsData?.limit || 10,
    };

    // No need for frontend filtering since backend will filter by taskId
    const taskLeads = leads;

    // Load lead statuses from DB for status display
    const leadStatusOptions = useMemo(
        () => (leadStatusData?.results || []).filter((s: any) => s.type === 'leadStatus' && s.isActive),
        [leadStatusData]
    );

    const statusColorMap = useMemo(() => {
        const map: Record<string, string> = {};
        (leadStatusOptions || []).forEach((s: any) => {
            if (s?.name) map[s.name] = s.color || '#e5e7eb';
        });
        return map;
    }, [leadStatusOptions]);

    const hexToRgba = (hex: string, alpha = 1): string => {
        const sanitized = hex.replace('#', '');
        const bigint = parseInt(sanitized.length === 3 ? sanitized.split('').map((c) => c + c).join('') : sanitized, 16);
        const r = (bigint >> 16) & 255;
        const g = (bigint >> 8) & 255;
        const b = bigint & 255;
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    };

    // Load lead statuses
    useEffect(() => {
        fetchLeadStatuses({ page: 1, limit: 100, sortBy: 'order:asc' });
    }, []);

    // Load task details
    useEffect(() => {
        const loadTask = async () => {
            if (!taskId) return;

            try {
                setTaskLoading(true);
                const taskData = await getTaskById(taskId);
                setTask(taskData);
            } catch (error) {
                console.error('Error loading task:', error);
            } finally {
                setTaskLoading(false);
            }
        };

        loadTask();
    }, [taskId]); // Remove getTaskById from dependencies to prevent infinite loop

    // Load leads for this task
    useEffect(() => {
        if (task?.leadIds && task.leadIds.length > 0) {
            loadLeads(1, '', 'all', 'all', undefined);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [task?.leadIds]); // Only depend on leadIds, not the entire task object

    const loadLeads = async (page = 1, search = '', status = 'all', completed = 'all', assigned: boolean | undefined = undefined) => {
        try {
            setLeadsLoading(true);
            // Use taskId parameter to fetch only leads assigned to this task
            await fetchLeads({
                page,
                limit: pageSize,
                search: search.trim() || undefined,
                status: status === 'all' ? undefined : status,
                completed: completed === 'all' ? undefined : completed === 'completed',
                assigned: assigned,
                taskId: taskId, // Add taskId parameter
                sortBy: 'updatedAt:desc'
            });
        } catch (error) {
            console.error('Error loading leads:', error);
        } finally {
            setLeadsLoading(false);
            // Clear selection after data refresh to prevent stale selections
            setSelectedIds([]);
        }
    };

    // Debounced search
    const debouncedSearch = debounce((query: string) => {
        setSearchQuery(query);
        setCurrentPage(1);
        loadLeads(1, query, statusFilter, completedFilter, assignedFilter);
    }, 500);

    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        debouncedSearch(e.target.value);
    };

    const handleStatusFilterChange = (value: string) => {
        setStatusFilter(value);
        setCurrentPage(1);
        loadLeads(1, searchQuery, value, completedFilter, assignedFilter);
    };

    const handleCompletedFilterChange = (value: string) => {
        setCompletedFilter(value);
        setCurrentPage(1);
        loadLeads(1, searchQuery, statusFilter, value, assignedFilter);
    };


    const handlePageChange = (page: number) => {
        setCurrentPage(page);
        loadLeads(page, searchQuery, statusFilter, completedFilter, assignedFilter);
    };

    const handlePerPageChange = (perPage: number) => {
        setPageSize(perPage);
        setCurrentPage(1);
        loadLeads(1, searchQuery, statusFilter, completedFilter, assignedFilter);
    };


    // Selection handlers
    const getRowId = (item: any) => item?._id as string;
    const handleToggleRow = (id: string, checked: boolean) => {
        setSelectedIds((prev) => checked ? Array.from(new Set([...prev, id])) : prev.filter(x => x !== id));
    };
    const handleToggleAll = (checked: boolean) => {
        if (checked) {
            const allIds = (taskLeads || []).map((l: any) => l._id).filter(Boolean);
            setSelectedIds(allIds);
        } else {
            setSelectedIds([]);
        }
    };
    const handleClearSelection = () => setSelectedIds([]);

    // Helper function to normalize status for comparison
    // Handles variations like "un-assigned", "un_assigned", "un assigned", etc.
    const normalizeStatus = (status: string | undefined | null): string => {
        if (!status) return '';
        return status.toLowerCase().trim().replace(/[-_\s]/g, '');
    };

    // Lead completion criteria (same as mobile app)
    // Handles variations: "un-assigned", "un_assigned", "un assigned", "UnAssigned", "un-assigne", "un-assign", etc.
    const isLeadComplete = (lead: any) => {
        const normalizedStatus = normalizeStatus(lead.status);
        return normalizedStatus !== 'assigned' &&
            normalizedStatus !== 'assign' &&
            normalizedStatus !== 'new' &&
            normalizedStatus !== 'unassigned' &&
            normalizedStatus !== 'unassigne' &&
            normalizedStatus !== 'unassign';
    };

    const formatDate = (dateString: string) => {
        if (!dateString) return '-';
        return new Date(dateString).toLocaleDateString('en-GB', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const columns = [
        {
            key: 'firstName',
            header: 'Name',
            width: 'w-2/12',
            render: (_: string, item: any) => {
                const fullName = `${item.firstName || ''} ${item.lastName || ''}`.trim() || 'Unknown';
                return (
                    <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isLeadComplete(item) ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
                            }`}>
                            <UserIcon size={16} />
                        </div>
                        <div>
                            <div className="font-medium text-gray-900">{fullName}</div>
                            <div className="text-sm text-gray-500">{item.phoneNumber || 'No phone'}</div>
                        </div>
                    </div>
                );
            }
        },
        {
            key: 'email',
            header: 'Email',
            width: 'w-2/12',
            render: (value: string) => (
                <div className="text-sm text-gray-600">
                    {value ? (
                        <div className="flex items-center space-x-1">
                            <MailIcon size={14} className="text-gray-400" />
                            <span className="truncate">{value}</span>
                        </div>
                    ) : '-'}
                </div>
            )
        },
        {
            key: 'status',
            header: 'Status',
            width: 'w-2/12',
            render: (value: string) => {
                const base = statusColorMap[value] || '#9ca3af';
                const bg = hexToRgba(base, 0.15);
                return (
                    <span
                        className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium"
                        style={{ backgroundColor: bg, color: base }}
                    >
                        {value}
                    </span>
                );
            }
        },
        {
            key: 'remark',
            header: 'Remark',
            width: 'w-3/12',
            render: (value: string) => (
                <div className="text-sm text-gray-600 max-w-xs">
                    {value ? (
                        <div className="break-words whitespace-pre-wrap leading-relaxed" title={value}>
                            {value.length > 100 ? (
                                <div>
                                    <span className="block">{value.substring(0, 100)}...</span>
                                    <button
                                        className="text-blue-600 hover:text-blue-800 text-xs mt-1 font-medium"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            // Toggle between truncated and full view
                                            const target = e.target as HTMLElement;
                                            const parent = target.parentElement;
                                            if (parent) {
                                                const span = parent.querySelector('span');
                                                if (span) {
                                                    if (span.textContent?.includes('...')) {
                                                        span.textContent = value;
                                                        target.textContent = 'Show less';
                                                    } else {
                                                        span.textContent = value.substring(0, 100) + '...';
                                                        target.textContent = 'Show more';
                                                    }
                                                }
                                            }
                                        }}
                                    >
                                        Show more
                                    </button>
                                </div>
                            ) : (
                                <span>{value}</span>
                            )}
                        </div>
                    ) : (
                        <span className="text-gray-400 italic">No remark</span>
                    )}
                </div>
            )
        },
        {
            key: 'isComplete',
            header: 'Complete',
            width: 'w-1/12',
            render: (_: any, item: any) => (
                <div className="flex items-center space-x-2">
                    {isLeadComplete(item) ? (
                        <div className="flex items-center space-x-1 text-green-600">
                            <CheckCircleIcon size={16} />
                            <span className="text-sm font-medium">Yes</span>
                        </div>
                    ) : (
                        <div className="flex items-center space-x-1 text-gray-500">
                            <ClockIcon size={16} />
                            <span className="text-sm font-medium">No</span>
                        </div>
                    )}
                </div>
            )
        },
        {
            key: 'updatedAt',
            header: 'Last Updated',
            width: 'w-2/12',
            render: (value: string) => (
                <div className="text-sm text-gray-600">
                    <div className="flex items-center space-x-1">
                        <ClockIcon size={14} className="text-gray-400" />
                        <span>{formatDate(value)}</span>
                    </div>
                </div>
            )
        }
    ];

    if (taskLoading) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/tasks')} icon={<ArrowLeftIcon size={16} />}>
                        Back to Tasks
                    </Button>
                    <div className="h-8 bg-gray-200 rounded w-64 animate-pulse"></div>
                </div>
                <Card>
                    <div className="p-6">
                        <TableSkeleton rows={5} columns={6} />
                    </div>
                </Card>
            </div>
        );
    }

    if (!task) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/tasks')} icon={<ArrowLeftIcon size={16} />}>
                        Back to Tasks
                    </Button>
                    <h1 className="text-2xl font-semibold text-gray-900">Task Not Found</h1>
                </div>
                <Card>
                    <div className="p-6 text-center">
                        <p className="text-gray-500">The requested task could not be found.</p>
                    </div>
                </Card>
            </div>
        );
    }

    const completedLeads = taskLeads.filter(isLeadComplete).length;
    const totalLeads = taskLeads.length;
    const completionPercentage = totalLeads > 0 ? Math.round((completedLeads / totalLeads) * 100) : 0;

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/tasks')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <div>
                        <h1 className="text-2xl font-semibold text-gray-900">{task.title}</h1>
                    </div>
                </div>
                {/* <Button variant="outline" onClick={handleRefresh} icon={<RefreshCwIcon size={16} />}>
                    Refresh
                </Button> */}
            </div>

            {/* Task Overview */}
            <Card>
                <div className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div className="space-y-1">
                            <div className="text-xs font-medium text-gray-500 uppercase tracking-wide">Assignee</div>
                            <div className="text-xl font-semibold text-gray-900">{task.assignedToName || 'Unassigned'}</div>
                            <div className="text-sm text-gray-500">{task.assignedToEmail || '—'}</div>
                        </div>

                        <div className="space-y-1">
                            <div className="text-xs font-medium text-gray-500 uppercase tracking-wide">Progress</div>
                            <div className="text-xl font-semibold text-gray-900">{completedLeads}/{totalLeads}</div>
                            <div className="text-sm text-gray-500">{completionPercentage}% completed</div>
                        </div>

                        <div className="space-y-1">
                            <div className="text-xs font-medium text-gray-500 uppercase tracking-wide">Due Date</div>
                            <div className="text-xl font-semibold text-gray-900">{task.dueAt ? formatDate(task.dueAt) : 'No due date'}</div>
                            <div className="text-sm text-gray-500">{task.dueAt && new Date(task.dueAt) < new Date() ? 'Overdue' : 'On time'}</div>
                        </div>

                        <div className="space-y-1">
                            <div className="text-xs font-medium text-gray-500 uppercase tracking-wide">Status</div>
                            <div className={`text-xl font-semibold ${task.status === 'COMPLETED' ? 'text-green-600' : task.status === 'IN_PROGRESS' ? 'text-yellow-700' : 'text-gray-700'}`}>{task.status || 'Unknown'}</div>
                            <div className="text-sm text-gray-500">Created {formatDate(task.createdAt)}</div>
                        </div>
                    </div>

                    {task.description && (
                        <div className="mt-6 pt-6 border-t border-gray-200">
                            <h3 className="text-sm font-medium text-gray-500 mb-2">Description</h3>
                            <p className="text-gray-900">{task.description}</p>
                        </div>
                    )}
                </div>
            </Card>

            {/* Lead Completion Criteria */}
            {/* <Card>
                <div className="p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Lead Completion Criteria</h3>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <div className="flex items-start space-x-3">
                            <CheckCircleIcon size={20} className="text-blue-600 mt-0.5" />
                            <div>
                                <h4 className="text-sm font-medium text-blue-900">Completion Rule</h4>
                                <p className="text-sm text-blue-700 mt-1">
                                    A lead is considered <strong>complete</strong> when its status is <strong>NOT</strong> one of the following:
                                </p>
                                <ul className="text-sm text-blue-700 mt-2 space-y-1">
                                    <li>• <code className="bg-blue-100 px-1 rounded">assigned</code></li>
                                    <li>• <code className="bg-blue-100 px-1 rounded">new</code></li>
                                    <li>• <code className="bg-blue-100 px-1 rounded">unassigned</code></li>
                                </ul>
                                <p className="text-sm text-blue-700 mt-2">
                                    Any other status (contacted, qualified, completed, etc.) marks the lead as complete.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </Card> */}

            {/* Leads Table */}
            <Card>
                <div className="p-6">
                    {/* <div className="flex items-center justify-between mb-6">
                        <div>
                            <h3 className="text-lg font-semibold text-gray-900">Task Leads</h3>
                        </div>
                    </div> */}
                    {/* Filters */}
                    <div className="flex flex-col md:flex-row md:items-end gap-3 mb-6">
                        <div className="md:flex-1">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Search Leads</label>
                            <div className="relative">
                                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <SearchIcon size={18} className="text-gray-400" />
                                </div>
                                <input
                                    type="text"
                                    placeholder="Search by name, phone, or email..."
                                    onChange={handleSearchChange}
                                    className="block w-full pl-10 pr-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400"
                                />
                            </div>
                        </div>

                        <div className="md:w-56">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                            <Select value={statusFilter} onValueChange={handleStatusFilterChange}>
                                <SelectTrigger className="w-full h-11">
                                    <SelectValue placeholder="All Statuses" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Statuses</SelectItem>
                                    {leadStatusOptions.map((opt: any) => (
                                        <SelectItem key={opt._id} value={opt.name}>{opt.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="md:w-56">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Assigned Status</label>
                            <Select
                                value={assignedFilter === undefined ? 'all' : assignedFilter ? 'assigned' : 'unassigned'}
                                onValueChange={(value) => {
                                    if (value === 'all') {
                                        setAssignedFilter(undefined);
                                    } else {
                                        setAssignedFilter(value === 'assigned');
                                    }
                                    setCurrentPage(1);
                                    loadLeads(1, searchQuery, statusFilter, completedFilter, value === 'all' ? undefined : value === 'assigned');
                                }}
                            >
                                <SelectTrigger className="w-full h-11">
                                    <SelectValue placeholder="All" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All</SelectItem>
                                    <SelectItem value="assigned">Assigned</SelectItem>
                                    <SelectItem value="unassigned">Unassigned</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="md:w-56">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Complete</label>
                            <Select value={completedFilter} onValueChange={handleCompletedFilterChange}>
                                <SelectTrigger className="w-full h-11">
                                    <SelectValue placeholder="All Leads" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Leads</SelectItem>
                                    <SelectItem value="completed">Completed Only</SelectItem>
                                    <SelectItem value="incomplete">Incomplete Only</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="md:w-56">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Per Page</label>
                            <Select value={pageSize.toString()} onValueChange={(value) => handlePerPageChange(Number(value))}>
                                <SelectTrigger className="w-full h-11">
                                    <SelectValue placeholder="Per page" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="10">10 per page</SelectItem>
                                    <SelectItem value="20">20 per page</SelectItem>
                                    <SelectItem value="50">50 per page</SelectItem>
                                    <SelectItem value="100">100 per page</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    {/* Bulk actions */}
                    <div className="mb-4">
                        <BulkActionsBar
                            count={selectedIds.length}
                            onClear={handleClearSelection}
                            actions={[{
                                key: 'handover',
                                label: 'Handover',
                                onClick: () => setIsHandoverOpen(true),
                                disabled: selectedIds.length === 0
                            }]}
                        />
                    </div>

                    {/* Table */}
                    {leadsLoading ? (
                        <TableSkeleton rows={5} columns={6} />
                    ) : (
                        <>
                            <Table
                                columns={columns}
                                data={taskLeads}
                                selectable
                                selectedIds={selectedIds}
                                getRowId={getRowId}
                                onToggleRow={handleToggleRow}
                                onToggleAll={handleToggleAll}
                            />
                            {pagination.total_pages > 1 && (
                                <div className="mt-6 border-t border-gray-200 pt-6">
                                    <Pagination
                                        currentPage={pagination.current_page}
                                        totalPages={pagination.total_pages}
                                        totalItems={pagination.total_items}
                                        perPage={pagination.per_page}
                                        onPageChange={handlePageChange}
                                        onPerPageChange={handlePerPageChange}
                                    />
                                </div>
                            )}
                        </>
                    )}

                    {!leadsLoading && taskLeads.length === 0 && (
                        <div className="text-center py-12">
                            <UserIcon size={48} className="mx-auto text-gray-300 mb-4" />
                            <h3 className="text-lg font-medium text-gray-900 mb-2">No leads found</h3>
                            <p className="text-gray-500">
                                {searchQuery || statusFilter !== 'all' || completedFilter !== 'all'
                                    ? 'Try adjusting your search or filter criteria.'
                                    : 'This task has no leads assigned to it.'}
                            </p>
                        </div>
                    )}
                </div>
            </Card>
            <HandoverDrawer
                isOpen={isHandoverOpen}
                onClose={() => setIsHandoverOpen(false)}
                selectedLeads={(taskLeads || []).filter((l: any) => selectedIds.includes(l._id))}
                excludeUserId={task?.assignedTo}
                onSubmit={async (payload: HandoverTaskRequest) => {
                    try {
                        await taskService.handover({ ...payload, sourceTaskId: taskId as string });
                        showSuccess('Task handed over successfully');
                        // Refresh current view
                        loadLeads(currentPage, searchQuery, statusFilter, completedFilter, assignedFilter);
                        setSelectedIds([]);
                        // Optionally navigate to the new task: navigate(`/tasks/${doc._id}`)
                    } catch (err: any) {
                        showErrorWithDetails('Failed to handover task', err?.message);
                        throw err;
                    }
                }}
            />
        </div>
    );
};

export default TaskDetails;
