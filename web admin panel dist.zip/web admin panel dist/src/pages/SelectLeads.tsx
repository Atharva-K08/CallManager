import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useNavigate, useSearchParams, useLocation } from 'react-router-dom';
import { ArrowLeftIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import FormInput from '../components/ui/FormInput';
import SearchInput from '../components/ui/SearchInput';
import Pagination from '../components/ui/Pagination';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { useLeads } from '../hooks/useLeads';
import { TableSkeleton } from '../components/ui/Skeleton';
import leadService from '../services/lead.service';

// Component for Select All checkbox with indeterminate state support
const SelectAllCheckbox: React.FC<{
    checked: boolean;
    indeterminate: boolean;
    onChange: () => void;
}> = ({ checked, indeterminate, onChange }) => {
    const checkboxRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (checkboxRef.current) {
            checkboxRef.current.indeterminate = indeterminate;
        }
    }, [indeterminate]);

    return (
        <input
            ref={checkboxRef}
            type="checkbox"
            className="h-4 w-4 shrink-0"
            checked={checked}
            onChange={onChange}
        />
    );
};

const SelectLeads: React.FC = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [searchParams] = useSearchParams();
    const { data, fetch, loading } = useLeads();

    const returnTo = searchParams.get('returnTo') || '/tasks';
    const selectedIdsParam = searchParams.get('selectedIds') || '';
    const initialSelectedIds = selectedIdsParam ? selectedIdsParam.split(',').filter(Boolean) : [];

    const [selected, setSelected] = useState<string[]>(initialSelectedIds);
    const [limit, setLimit] = useState<number>(50);
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [searchQuery, setSearchQuery] = useState<string>('');
    const [showFilters, setShowFilters] = useState<boolean>(false);
    const [dateFilterMode, setDateFilterMode] = useState<'single' | 'range'>('single');
    const [showOnlySelected, setShowOnlySelected] = useState<boolean>(false);
    const [customSelectCount, setCustomSelectCount] = useState<string>('');

    // Cache for selected leads (stores lead objects by ID)
    const selectedLeadsCache = useRef<Map<string, any>>(new Map());
    const [cacheLoading, setCacheLoading] = useState<boolean>(false);

    const [filters, setFilters] = useState({
        city: '',
        campus: '',
        class: '',
        createdAtFrom: '',
        createdAtTo: '',
        createdAt: '',
        assigned: false as boolean, // Default to unassigned
    });

    const leads = (data as any)?.results || [];
    const pagination = useMemo(() => ({
        current_page: data?.page || 1,
        total_pages: data?.totalPages || 1,
        total_items: data?.totalResults || 0,
        per_page: data?.limit || 50,
    }), [data]);

    // Update selected when param changes
    useEffect(() => {
        setSelected(initialSelectedIds);
    }, [selectedIdsParam]);

    // Cache leads from current response
    useEffect(() => {
        if (leads && leads.length > 0) {
            leads.forEach((lead: any) => {
                if (selected.includes(lead._id)) {
                    selectedLeadsCache.current.set(lead._id, lead);
                }
            });
        }
    }, [leads, selected]);

    // Fetch missing selected leads that aren't in cache or current response
    useEffect(() => {
        const fetchMissingLeads = async () => {
            if (selected.length === 0) return;

            const missingIds = selected.filter(id => {
                const inCache = selectedLeadsCache.current.has(id);
                const inCurrentResponse = leads.some((l: any) => l._id === id);
                return !inCache && !inCurrentResponse;
            });

            if (missingIds.length === 0) return;

            setCacheLoading(true);
            try {
                // Fetch leads in bulk using the list endpoint with ids parameter
                const response = await leadService.list({
                    ids: missingIds,
                    limit: missingIds.length,
                    sortBy: 'updatedAt:desc'
                });

                // Cache all fetched leads
                if (response.results && response.results.length > 0) {
                    response.results.forEach((lead: any) => {
                        selectedLeadsCache.current.set(lead._id, lead);
                    });
                }
            } catch (error) {
                console.error('Error fetching missing leads:', error);
                // Fallback to individual fetches if bulk fetch fails
                try {
                    const fetchPromises = missingIds.map(id =>
                        leadService.getById(id).catch(err => {
                            console.warn(`Failed to fetch lead ${id}:`, err);
                            return null;
                        })
                    );
                    const fetchedLeads = await Promise.all(fetchPromises);

                    fetchedLeads.forEach(lead => {
                        if (lead) {
                            selectedLeadsCache.current.set(lead._id, lead);
                        }
                    });
                } catch (fallbackError) {
                    console.error('Error in fallback fetch:', fallbackError);
                }
            } finally {
                setCacheLoading(false);
            }
        };

        fetchMissingLeads();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selected]);

    // Helper functions for date conversion
    const getStartOfDayUTC = useCallback((dateString: string): string => {
        if (!dateString) return '';
        const localDate = new Date(dateString + 'T00:00:00');
        return localDate.toISOString();
    }, []);

    const getEndOfDayUTC = useCallback((dateString: string): string => {
        if (!dateString) return '';
        const localDate = new Date(dateString + 'T23:59:59.999');
        return localDate.toISOString();
    }, []);

    // Build filter params
    const buildFilterParams = useCallback((page: number, limit: number, search?: string) => {
        const params: any = {
            page,
            limit,
            sortBy: 'updatedAt:desc',
        };

        console.log('[SelectLeads] buildFilterParams - Input:', { page, limit, search, filters, dateFilterMode });

        // Only add search if it has a value
        if (search && search.trim()) {
            params.search = search.trim();
        }

        // Only add filters if they have values
        if (filters.city && filters.city.trim()) {
            params.city = filters.city.trim();
            console.log('[SelectLeads] Adding city filter:', filters.city.trim());
        }
        if (filters.campus && filters.campus.trim()) {
            params.campus = filters.campus.trim();
            console.log('[SelectLeads] Adding campus filter:', filters.campus.trim());
        }
        if (filters.class && filters.class.trim()) {
            params.class = filters.class.trim();
            console.log('[SelectLeads] Adding class filter:', filters.class.trim());
        }

        // Handle date filters - only add if values exist
        if (dateFilterMode === 'single') {
            if (filters.createdAt && filters.createdAt.trim()) {
                const startUTC = getStartOfDayUTC(filters.createdAt);
                const endUTC = getEndOfDayUTC(filters.createdAt);
                params.createdAtFrom = startUTC;
                params.createdAtTo = endUTC;
                console.log('[SelectLeads] Adding single date filter:', { createdAt: filters.createdAt, startUTC, endUTC });
            }
        } else {
            if (filters.createdAtFrom && filters.createdAtFrom.trim()) {
                params.createdAtFrom = getStartOfDayUTC(filters.createdAtFrom);
                console.log('[SelectLeads] Adding dateFrom filter:', filters.createdAtFrom.trim());
            }
            if (filters.createdAtTo && filters.createdAtTo.trim()) {
                params.createdAtTo = getEndOfDayUTC(filters.createdAtTo);
                console.log('[SelectLeads] Adding dateTo filter:', filters.createdAtTo.trim());
            }
        }

        // Handle assigned filter - always set since it defaults to false (unassigned)
        params.assigned = filters.assigned;
        console.log('[SelectLeads] Adding assigned filter:', filters.assigned);

        console.log('[SelectLeads] buildFilterParams - Output params:', params);
        return params;
    }, [filters, dateFilterMode, getStartOfDayUTC, getEndOfDayUTC]);

    // Initial load
    useEffect(() => {
        console.log('[SelectLeads] useEffect - Filters changed, rebuilding params', { currentPage, limit, filters, dateFilterMode });
        const params = buildFilterParams(currentPage, limit);
        console.log('[SelectLeads] useEffect - Calling fetch with params:', params);
        fetch(params);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [limit, currentPage, JSON.stringify(filters), dateFilterMode]);

    const handleSearch = useCallback((query: string) => {
        setSearchQuery(query);
        setCurrentPage(1);
        const params = buildFilterParams(1, limit, query);
        fetch(params);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [limit]);

    const handlePageChange = useCallback((page: number) => {
        setCurrentPage(page);
        const params = buildFilterParams(page, limit, searchQuery);
        fetch(params);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [limit, searchQuery]);

    const handlePerPageChange = useCallback((perPage: number) => {
        setLimit(perPage);
        setCurrentPage(1);
        const params = buildFilterParams(1, perPage, searchQuery);
        fetch(params);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [searchQuery]);

    const toggle = (id: string) => {
        setSelected((prev) => {
            const isSelecting = !prev.includes(id);
            const newSelected = isSelecting ? [...prev, id] : prev.filter((x) => x !== id);

            if (isSelecting) {
                // If selecting, try to cache from current response
                const leadInResponse = leads.find((l: any) => l._id === id);
                if (leadInResponse) {
                    selectedLeadsCache.current.set(id, leadInResponse);
                }
            } else {
                // If deselecting, remove from cache
                selectedLeadsCache.current.delete(id);
            }

            return newSelected;
        });
    };

    const handleFilterChange = useCallback((key: string, value: any) => {
        console.log('[SelectLeads] handleFilterChange - Key:', key, 'Value:', value, 'Type:', typeof value);
        setFilters(prev => {
            const updated = { ...prev, [key]: value };
            console.log('[SelectLeads] handleFilterChange - Previous filters:', prev);
            console.log('[SelectLeads] handleFilterChange - Updated filters:', updated);
            return updated;
        });
        setCurrentPage(1);
    }, []);

    const hasActiveFilters = useMemo(() => {
        return !!(
            filters.city ||
            filters.campus ||
            filters.class ||
            filters.createdAtFrom ||
            filters.createdAtTo ||
            filters.createdAt ||
            filters.assigned !== false // Only show as active if not the default (unassigned)
        );
    }, [filters]);

    const handleClearFilters = useCallback(() => {
        console.log('[SelectLeads] handleClearFilters - Clearing all filters');
        const clearedFilters = {
            city: '',
            campus: '',
            class: '',
            createdAtFrom: '',
            createdAtTo: '',
            createdAt: '',
            assigned: false, // Default to unassigned
        };
        console.log('[SelectLeads] handleClearFilters - Previous filters:', filters);
        console.log('[SelectLeads] handleClearFilters - Cleared filters:', clearedFilters);

        setFilters(clearedFilters);
        setCurrentPage(1);

        // Build params with cleared filters immediately
        const params: any = {
            page: 1,
            limit,
            sortBy: 'updatedAt:desc',
            assigned: false, // Always default to unassigned
        };

        // Only add search if it has a value
        if (searchQuery && searchQuery.trim()) {
            params.search = searchQuery.trim();
        }

        // No other filters since they're all cleared
        console.log('[SelectLeads] handleClearFilters - Final API params:', params);
        fetch(params);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [limit, searchQuery, initialSelectedIds.length]);

    const handleBack = () => {
        const params = new URLSearchParams();
        const returnToParts = returnTo.split('?');
        const currentReturnTo = returnToParts[0];

        // Preserve existing selections if any
        if (selected.length > 0) {
            params.set('leadIds', selected.join(','));
        } else if (initialSelectedIds.length > 0) {
            // If user cleared selections, preserve original
            params.set('leadIds', initialSelectedIds.join(','));
        }

        // Parse existing params from returnTo URL
        if (returnToParts.length > 1) {
            const existingParams = new URLSearchParams(returnToParts[1]);
            existingParams.forEach((value, key) => {
                if (key !== 'leadIds') { // Don't overwrite leadIds we just set
                    params.set(key, value);
                }
            });
        }

        // Preserve filter values if they exist
        if (filters.campus && filters.campus.trim()) {
            params.set('filterCampus', filters.campus.trim());
        }
        if (filters.class && filters.class.trim()) {
            params.set('filterClass', filters.class.trim());
        }
        if (filters.city && filters.city.trim()) {
            params.set('filterCity', filters.city.trim());
        }

        // Preserve location state
        navigate(`${currentReturnTo}${params.toString() ? '?' + params.toString() : ''}`, {
            state: location.state,
        });
    };

    const handleApply = () => {
        const params = new URLSearchParams();
        params.set('leadIds', selected.join(','));

        // Pass filter values for title generation
        if (filters.city && filters.city.trim()) {
            params.set('filterCity', filters.city.trim());
        }
        if (filters.campus && filters.campus.trim()) {
            params.set('filterCampus', filters.campus.trim());
        }
        if (filters.class && filters.class.trim()) {
            params.set('filterClass', filters.class.trim());
        }

        // Preserve any existing params from returnTo URL
        const returnToParts = returnTo.split('?');
        if (returnToParts.length > 1) {
            const existingParams = new URLSearchParams(returnToParts[1]);
            existingParams.forEach((value, key) => {
                if (!params.has(key)) {
                    params.set(key, value);
                }
            });
        }

        navigate(`${returnToParts[0]}?${params.toString()}`, {
            state: location.state,
        });
    };

    // Filter leads: when editing, show only previously selected leads and unassigned leads
    const filteredLeads = useMemo(() => {
        let result = leads;

        if (initialSelectedIds.length > 0) {
            result = result.filter((l: any) =>
                initialSelectedIds.includes(l._id) || !l.assignedTo
            );
        }

        // If "View Selected" mode is active, show only selected leads
        if (showOnlySelected) {
            // Get selected leads from current response
            const selectedFromResponse = result.filter((l: any) => selected.includes(l._id));

            // Get cached selected leads that aren't in current response
            const cachedSelected = selected
                .filter(id => !result.some((l: any) => l._id === id))
                .map(id => selectedLeadsCache.current.get(id))
                .filter(Boolean);

            // Combine both
            result = [...selectedFromResponse, ...cachedSelected];
        }

        return result;
    }, [leads, initialSelectedIds, selected, showOnlySelected]);

    // Check if all visible leads are selected
    const allVisibleSelected = useMemo(() => {
        if (filteredLeads.length === 0) return false;
        return filteredLeads.every((l: any) => selected.includes(l._id));
    }, [filteredLeads, selected]);

    // Check if some (but not all) visible leads are selected
    const someVisibleSelected = useMemo(() => {
        if (filteredLeads.length === 0) return false;
        const selectedCount = filteredLeads.filter((l: any) => selected.includes(l._id)).length;
        return selectedCount > 0 && selectedCount < filteredLeads.length;
    }, [filteredLeads, selected]);

    // Toggle select all visible leads
    const toggleSelectAll = useCallback(() => {
        if (allVisibleSelected) {
            // Deselect all visible leads
            const visibleIds = filteredLeads.map((l: any) => l._id);
            setSelected((prev) => {
                const newSelected = prev.filter((id: string) => !visibleIds.includes(id));
                // Remove from cache
                visibleIds.forEach((id: string) => selectedLeadsCache.current.delete(id));
                return newSelected;
            });
        } else {
            // Select all visible leads
            const visibleIds = filteredLeads.map((l: any) => l._id);
            setSelected((prev) => {
                const newSelected = [...new Set([...prev, ...visibleIds])];
                // Cache all visible leads
                filteredLeads.forEach((lead: any) => {
                    selectedLeadsCache.current.set(lead._id, lead);
                });
                return newSelected;
            });
        }
    }, [allVisibleSelected, filteredLeads]);

    // Select custom number of leads
    const handleSelectCustomCount = useCallback(() => {
        const count = parseInt(customSelectCount, 10);
        if (isNaN(count) || count <= 0) {
            return;
        }

        // Get unselected visible leads
        const unselectedLeads = filteredLeads.filter((l: any) => !selected.includes(l._id));

        // Select up to the requested count
        const leadsToSelect = unselectedLeads.slice(0, count).map((l: any) => l._id);

        if (leadsToSelect.length > 0) {
            setSelected((prev) => {
                const newSelected = [...new Set([...prev, ...leadsToSelect])];
                // Cache selected leads
                unselectedLeads.slice(0, count).forEach((lead: any) => {
                    selectedLeadsCache.current.set(lead._id, lead);
                });
                return newSelected;
            });
            setCustomSelectCount(''); // Clear input after selection

            // Show feedback if fewer leads were selected than requested
            if (leadsToSelect.length < count) {
                console.log(`Only ${leadsToSelect.length} unselected leads available (requested ${count})`);
            }
        } else {
            // No unselected leads available
            console.log('All visible leads are already selected');
        }
    }, [customSelectCount, filteredLeads, selected]);

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={handleBack} icon={<ArrowLeftIcon size={16} />}>
                    Back
                </Button>
                <h1 className="text-2xl font-semibold text-gray-900">Select Leads</h1>
            </div>

            {/* Info message when editing */}
            {initialSelectedIds.length > 0 && (
                <Card>
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-md">
                        <div className="flex items-center gap-2">
                            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                            <span className="text-sm text-blue-700 font-medium">
                                Editing existing task - selected leads are available even if not visible in current page
                            </span>
                        </div>
                    </div>
                </Card>
            )}

            {/* Search and Filters */}
            <Card>
                <div className="p-6 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField label="Search Leads" htmlFor="lead-search">
                            <SearchInput
                                placeholder="Search by name, phone, or email..."
                                onSearch={handleSearch}
                                debounceTime={400}
                            />
                        </FormField>

                        <FormField label="Results per page" htmlFor="limit-select">
                            <Select
                                value={limit.toString()}
                                onValueChange={(value) => handlePerPageChange(Number(value))}
                            >
                                <SelectTrigger className="w-full">
                                    <SelectValue placeholder="Select limit" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="10">10 per page</SelectItem>
                                    <SelectItem value="20">20 per page</SelectItem>
                                    <SelectItem value="50">50 per page</SelectItem>
                                    <SelectItem value="100">100 per page</SelectItem>
                                </SelectContent>
                            </Select>
                        </FormField>
                    </div>

                    {/* Advanced Filters */}
                    <div className="border rounded-md">
                        <button
                            type="button"
                            onClick={() => setShowFilters(!showFilters)}
                            className="w-full flex items-center justify-between p-3 hover:bg-gray-50 transition-colors"
                        >
                            <span className="text-sm font-medium text-gray-700">
                                Advanced Filters
                                {hasActiveFilters && (
                                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                        Active
                                    </span>
                                )}
                            </span>
                            <span className="text-gray-500">
                                {showFilters ? '−' : '+'}
                            </span>
                        </button>

                        {showFilters && (
                            <div className="p-4 border-t space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <FormField label="City" htmlFor="filter-city">
                                        <FormInput
                                            id="filter-city"
                                            type="text"
                                            placeholder="Filter by city"
                                            value={filters.city}
                                            onChange={(e) => handleFilterChange('city', e.target.value)}
                                        />
                                    </FormField>

                                    <FormField label="College" htmlFor="filter-campus">
                                        <FormInput
                                            id="filter-campus"
                                            type="text"
                                            placeholder="Filter by campus"
                                            value={filters.campus}
                                            onChange={(e) => handleFilterChange('campus', e.target.value)}
                                        />
                                    </FormField>

                                    <FormField label="Class" htmlFor="filter-class">
                                        <FormInput
                                            id="filter-class"
                                            type="text"
                                            placeholder="Filter by class"
                                            value={filters.class}
                                            onChange={(e) => handleFilterChange('class', e.target.value)}
                                        />
                                    </FormField>

                                    <FormField label="Assigned Status" htmlFor="filter-assigned">
                                        <Select
                                            value={filters.assigned ? 'assigned' : 'unassigned'}
                                            onValueChange={(value) => {
                                                handleFilterChange('assigned', value === 'assigned');
                                            }}
                                        >
                                            <SelectTrigger className="w-full">
                                                <SelectValue placeholder="Unassigned" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="unassigned">Unassigned</SelectItem>
                                                <SelectItem value="assigned">Assigned</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </FormField>
                                </div>

                                {/* Date Filter */}
                                <div className="space-y-3">
                                    <div className="flex items-center justify-between">
                                        <label className="block text-sm font-medium text-gray-700">Created Date</label>
                                        <div className="flex items-center gap-2">
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    setDateFilterMode('single');
                                                    setFilters(prev => ({ ...prev, createdAtFrom: '', createdAtTo: '' }));
                                                }}
                                                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${dateFilterMode === 'single'
                                                    ? 'bg-blue-100 text-blue-700 border border-blue-300'
                                                    : 'bg-gray-100 text-gray-600 border border-gray-300 hover:bg-gray-200'
                                                    }`}
                                            >
                                                Single Date
                                            </button>
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    setDateFilterMode('range');
                                                    setFilters(prev => ({ ...prev, createdAt: '' }));
                                                }}
                                                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${dateFilterMode === 'range'
                                                    ? 'bg-blue-100 text-blue-700 border border-blue-300'
                                                    : 'bg-gray-100 text-gray-600 border border-gray-300 hover:bg-gray-200'
                                                    }`}
                                            >
                                                Date Range
                                            </button>
                                        </div>
                                    </div>

                                    <div className="h-[82px]">
                                        {dateFilterMode === 'single' ? (
                                            <FormField label="Select Date" htmlFor="filter-date-single" className="mb-0">
                                                <input
                                                    id="filter-date-single"
                                                    type="date"
                                                    lang="en-GB"
                                                    value={filters.createdAt}
                                                    onClick={(e) => {
                                                        e.currentTarget.showPicker?.();
                                                    }}
                                                    onChange={(e) => handleFilterChange('createdAt', e.target.value)}
                                                    className="block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 cursor-pointer"
                                                />
                                            </FormField>
                                        ) : (
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                <FormField label="From" htmlFor="filter-date-from" className="mb-0">
                                                    <input
                                                        id="filter-date-from"
                                                        type="date"
                                                        lang="en-GB"
                                                        value={filters.createdAtFrom}
                                                        onClick={(e) => {
                                                            e.currentTarget.showPicker?.();
                                                        }}
                                                        onChange={(e) => handleFilterChange('createdAtFrom', e.target.value)}
                                                        className="block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 cursor-pointer"
                                                    />
                                                </FormField>

                                                <FormField label="To" htmlFor="filter-date-to" className="mb-0">
                                                    <input
                                                        id="filter-date-to"
                                                        type="date"
                                                        lang="en-GB"
                                                        value={filters.createdAtTo}
                                                        onClick={(e) => {
                                                            e.currentTarget.showPicker?.();
                                                        }}
                                                        onChange={(e) => handleFilterChange('createdAtTo', e.target.value)}
                                                        className="block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 cursor-pointer"
                                                    />
                                                </FormField>
                                            </div>
                                        )}
                                    </div>
                                </div>

                                {hasActiveFilters && (
                                    <div className="flex justify-end">
                                        <Button
                                            variant="outline"
                                            type="button"
                                            onClick={handleClearFilters}
                                        >
                                            Clear Filters
                                        </Button>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </Card>

            {/* Leads List */}
            <Card>
                <div className="p-6">
                    {(loading || cacheLoading) ? (
                        <TableSkeleton rows={5} columns={1} />
                    ) : (
                        <>
                            <div className="border rounded-md divide-y max-h-[420px] overflow-auto">
                                {/* Select All Header */}
                                {filteredLeads.length > 0 && (
                                    <div className="p-3 bg-gray-50 border-b sticky top-0 z-10">
                                        <div className="flex items-center justify-between gap-4 flex-wrap">
                                            <div className="flex items-center gap-3 flex-1 min-w-0">
                                                <SelectAllCheckbox
                                                    checked={allVisibleSelected}
                                                    indeterminate={someVisibleSelected}
                                                    onChange={toggleSelectAll}
                                                />
                                                <div className="text-sm font-medium text-gray-700">
                                                    Select All ({filteredLeads.length} {filteredLeads.length === 1 ? 'lead' : 'leads'})
                                                </div>
                                            </div>
                                            {/* Custom Select Count */}
                                            <div className="flex items-center gap-2">
                                                <span className="text-sm text-gray-600 whitespace-nowrap">Select</span>
                                                <input
                                                    type="number"
                                                    min="1"
                                                    max={filteredLeads.length}
                                                    value={customSelectCount}
                                                    onChange={(e) => {
                                                        const value = e.target.value;
                                                        if (value === '' || (parseInt(value, 10) > 0 && parseInt(value, 10) <= filteredLeads.length)) {
                                                            setCustomSelectCount(value);
                                                        }
                                                    }}
                                                    onKeyDown={(e) => {
                                                        if (e.key === 'Enter') {
                                                            e.preventDefault();
                                                            handleSelectCustomCount();
                                                        }
                                                    }}
                                                    placeholder="N"
                                                    className="w-16 px-2 py-1 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                                    title={`Enter number of leads to select (1-${filteredLeads.length})`}
                                                />
                                                <span className="text-sm text-gray-600 whitespace-nowrap">leads</span>
                                                <Button
                                                    variant="outline"
                                                    size="sm"
                                                    type="button"
                                                    onClick={handleSelectCustomCount}
                                                    disabled={!customSelectCount || parseInt(customSelectCount, 10) <= 0 || parseInt(customSelectCount, 10) > filteredLeads.length}
                                                    className="whitespace-nowrap"
                                                >
                                                    Apply
                                                </Button>
                                            </div>
                                        </div>
                                    </div>
                                )}
                                {filteredLeads.map((l: any) => (
                                    <label key={l._id} className="p-3 flex items-center justify-between hover:bg-gray-50 cursor-pointer">
                                        <div className="flex items-center gap-3 flex-1 min-w-0">
                                            <input
                                                type="checkbox"
                                                className="h-4 w-4 shrink-0"
                                                checked={selected.includes(l._id)}
                                                onChange={() => toggle(l._id)}
                                            />
                                            <div className="flex-1 min-w-0">
                                                <div className="text-sm font-medium text-gray-900">{l.firstName} {l.lastName}</div>
                                                <div className="text-xs text-gray-500 space-x-2">
                                                    <span>{l.phoneNumber}</span>
                                                    {l.email && <span>• {l.email}</span>}
                                                </div>
                                                {(l.city || l.campus || l.class) && (
                                                    <div className="text-xs text-gray-400 mt-1 flex flex-wrap gap-x-3 gap-y-0.5">
                                                        {l.city && <span>City: {l.city}</span>}
                                                        {l.campus && <span>College: {l.campus}</span>}
                                                        {l.class && <span>Class: {l.class}</span>}
                                                    </div>
                                                )}
                                                {l.assignedTo && l.assignedToName && (
                                                    <div className="text-xs mt-1 flex items-center gap-1.5">
                                                        <span className="text-gray-500">Assigned to:</span>
                                                        <span className="font-medium text-blue-600">{l.assignedToName}</span>
                                                        {l.assignedToEmail && (
                                                            <span className="text-gray-400">({l.assignedToEmail})</span>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                        <span className="text-xs text-gray-500 shrink-0 ml-2">{l.status}</span>
                                    </label>
                                ))}
                                {filteredLeads.length === 0 && (
                                    <div className="p-4 text-sm text-gray-500 text-center">No leads found</div>
                                )}
                            </div>

                            {pagination.total_pages > 1 && (
                                <div className="border-t border-gray-200 pt-4 mt-4">
                                    <Pagination
                                        currentPage={pagination.current_page}
                                        totalPages={pagination.total_pages}
                                        totalItems={pagination.total_items}
                                        perPage={pagination.per_page}
                                        onPageChange={handlePageChange}
                                        onPerPageChange={handlePerPageChange}
                                    />
                                </div>
                            )}

                            <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200">
                                <div className="text-sm text-gray-600">
                                    Selected: {selected.length}
                                    {showOnlySelected && (
                                        <span className="ml-2 text-blue-600 font-medium">
                                            (Showing selected only)
                                        </span>
                                    )}
                                </div>
                                <div className="flex gap-2">
                                    {selected.length > 0 && (
                                        <Button
                                            variant="outline"
                                            type="button"
                                            onClick={() => setShowOnlySelected(!showOnlySelected)}
                                        >
                                            {showOnlySelected ? 'Show All' : 'View Selected'}
                                        </Button>
                                    )}
                                    <Button
                                        variant="outline"
                                        type="button"
                                        onClick={() => {
                                            setSelected([]);
                                            setShowOnlySelected(false);
                                            selectedLeadsCache.current.clear();
                                        }}
                                        disabled={selected.length === 0}
                                    >
                                        Clear
                                    </Button>
                                    <Button
                                        variant="primary"
                                        type="button"
                                        onClick={handleApply}
                                        disabled={selected.length === 0}
                                    >
                                        Apply ({selected.length})
                                    </Button>
                                </div>
                            </div>
                        </>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default SelectLeads;

