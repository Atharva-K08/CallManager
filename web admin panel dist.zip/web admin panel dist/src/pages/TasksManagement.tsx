import React, { useEffect, useMemo, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusIcon, EditIcon, SearchIcon, TrashIcon, EyeIcon, XIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Table from '../components/ui/Table';
import Button from '../components/ui/Button';
import Pagination from '../components/ui/Pagination';
import { TableSkeleton } from '../components/ui/Skeleton';
import ConfirmDialog from '../components/ui/ConfirmDialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { debounce } from '../utils/performance';
import { useTasks } from '../hooks/useTasks';
import { useUsers } from '../hooks/useUsers';

const TasksManagement: React.FC = () => {
    const navigate = useNavigate();
    const { data, fetch, remove, loading } = useTasks();
    const { users, usersLoading, getUsers } = useUsers();
    const tasks = data?.results || [];
    const pagination = useMemo(() => ({
        current_page: data?.page || 1,
        total_pages: data?.totalPages || 1,
        total_items: data?.totalResults || 0,
        per_page: data?.limit || 10,
    }), [data]);

    const [searchQuery, setSearchQuery] = useState('');
    const [filters, setFilters] = useState<{ status: 'all' | 'PENDING' | 'IN_PROGRESS' | 'COMPLETED'; assignedTo?: string; sortBy: string }>({ status: 'all', sortBy: 'createdAt:desc' });
    const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
    const [taskToDelete, setTaskToDelete] = useState<any>(null);

    // Assignee autocomplete state
    const [assigneeSearch, setAssigneeSearch] = useState('');
    const [selectedAssignee, setSelectedAssignee] = useState<{ _id: string; name: string; email?: string } | null>(null);
    const [showAssigneeSuggestions, setShowAssigneeSuggestions] = useState(false);
    const assigneeInputRef = useRef<HTMLInputElement>(null);
    const assigneeDropdownRef = useRef<HTMLDivElement>(null);

    const columns = [
        { key: 'title', header: 'Title', width: 'w-3/12' },
        { key: 'assignedToName', header: 'Assignee', width: 'w-2/12' },
        { key: 'status', header: 'Status', width: 'w-2/12' },
        {
            key: 'completedCount', header: 'Progress', width: 'w-2/12', render: (_: any, item: any) => {
                // Use leadIds length if available (actual count of assigned leads), otherwise fall back to totalCount or targetCount
                const totalLeads = item.leadIds?.length ?? item.totalCount ?? item.targetCount ?? '-';
                return (
                    <span className="text-sm text-gray-700">{item.completedCount ?? 0}/{totalLeads}</span>
                );
            }
        },
        { key: 'dueAt', header: 'Due', width: 'w-2/12', render: (v: string) => <span className="text-sm text-gray-600">{v ? new Date(v).toLocaleDateString('en-GB') : '-'}</span> },
        {
            key: 'actions', header: 'Actions', width: 'w-1/12', render: (_: any, item: any) => (
                <div className="flex space-x-1 justify-end">
                    <button onClick={(e) => { e.stopPropagation(); handleViewDetails(item); }} className="p-1.5 rounded-full text-green-600 hover:text-green-800 hover:bg-green-50 transition-colors" title="View Details">
                        <EyeIcon size={16} />
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); handleEdit(item); }} className="p-1.5 rounded-full text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition-colors" title="Edit Task">
                        <EditIcon size={16} />
                    </button>
                    <button onClick={(e) => { e.stopPropagation(); handleDelete(item); }} className="p-1.5 rounded-full text-red-600 hover:text-red-800 hover:bg-red-50 transition-colors" title="Delete Task">
                        <TrashIcon size={16} />
                    </button>
                </div>
            )
        },
    ];

    useEffect(() => { fetch({ page: 1, limit: 10, sortBy: filters.sortBy }); }, []);

    // Debounced user search for assignee autocomplete (only callers)
    const debouncedUserSearch = useMemo(
        () => debounce((query: string) => {
            if (query.trim()) {
                getUsers({ role: 'caller', isActive: true, name: query.trim(), limit: 10, sortBy: 'createdAt:desc' } as any);
            } else {
                getUsers({ role: 'caller', isActive: true, limit: 10, sortBy: 'createdAt:desc' } as any);
            }
        }, 300),
        // eslint-disable-next-line react-hooks/exhaustive-deps
        []
    );

    // Handle assignee search input
    useEffect(() => {
        if (assigneeSearch.trim()) {
            debouncedUserSearch(assigneeSearch);
            setShowAssigneeSuggestions(true);
        } else {
            setShowAssigneeSuggestions(false);
        }
    }, [assigneeSearch, debouncedUserSearch]);

    // Close suggestions when clicking outside
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (
                assigneeInputRef.current &&
                !assigneeInputRef.current.contains(event.target as Node) &&
                assigneeDropdownRef.current &&
                !assigneeDropdownRef.current.contains(event.target as Node)
            ) {
                setShowAssigneeSuggestions(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const handleAssigneeSelect = (user: any) => {
        setSelectedAssignee({ _id: user._id, name: user.name || '', email: user.email });
        setAssigneeSearch(user.name || '');
        setShowAssigneeSuggestions(false);
        const newFilters = { ...filters, assignedTo: user._id };
        setFilters(newFilters);
        const api = convertFiltersToApi(newFilters);
        fetch({ ...api, page: 1 });
    };

    const handleAssigneeClear = () => {
        setSelectedAssignee(null);
        setAssigneeSearch('');
        setShowAssigneeSuggestions(false);
        const newFilters = { ...filters };
        delete newFilters.assignedTo;
        setFilters(newFilters);
        const api = convertFiltersToApi(newFilters);
        fetch({ ...api, page: 1 });
    };

    const convertFiltersToApi = (local: typeof filters) => {
        const api: any = {
            sortBy: local.sortBy,
        };

        // Only add status if it's not 'all'
        if (local.status && local.status !== 'all') {
            api.status = local.status;
        }

        // Only add assignedTo if it exists
        if (local.assignedTo) {
            api.assignedTo = local.assignedTo;
        }

        return api;
    };

    const debouncedSearch = debounce((query: string) => { const api = convertFiltersToApi(filters); fetch({ ...api, search: query, page: 1 }); }, 500);
    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => { const q = e.target.value; setSearchQuery(q); debouncedSearch(q); };
    const handleFilterChange = (key: keyof typeof filters, value: any) => { const nf = { ...filters, [key]: value }; setFilters(nf); const api = convertFiltersToApi(nf); fetch({ ...api, page: 1 }); };
    const handlePageChange = (page: number) => { const api = convertFiltersToApi(filters); fetch({ ...api, page }); };
    const handlePerPageChange = (perPage: number) => { const api = convertFiltersToApi(filters); fetch({ ...api, limit: perPage, page: 1 }); };

    const handleAdd = () => {
        navigate('/tasks/create');
    };
    const handleEdit = (task: any) => {
        navigate(`/tasks/${task._id}/update`);
    };

    const handleDelete = (task: any) => {
        setTaskToDelete(task);
        setIsConfirmDialogOpen(true);
    };

    const handleViewDetails = (task: any) => {
        navigate(`/tasks/${task._id}`);
    };

    const handleDeleteUser = async () => {
        if (taskToDelete) {
            const taskId = taskToDelete._id;
            if (taskId) {
                try {
                    await remove(taskId);
                    setIsConfirmDialogOpen(false);
                    setTaskToDelete(null);
                } catch (error) {
                    console.error('Error deleting task:', error);
                }
            }
        }
    };


    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-semibold text-gray-900">Tasks</h1>
                </div>
                <Button variant="primary" onClick={handleAdd} icon={<PlusIcon size={16} />}>Create Task</Button>
            </div>

            <Card>
                <div className="p-3 space-y-2">
                    <div className="flex flex-col md:flex-row md:items-end gap-3">
                        <div className="md:flex-1">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Search Tasks</label>
                            <div className="relative"><div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none"><SearchIcon size={18} className="text-gray-400" /></div>
                                <input type="text" placeholder="Search by title or assignee..." value={searchQuery} onChange={handleSearchChange} className="block w-full pl-10 pr-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400" />
                            </div>
                        </div>
                        <div className="md:w-56">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Assignee</label>
                            <div className="relative" ref={assigneeInputRef}>
                                <div className="relative">
                                    <input
                                        type="text"
                                        placeholder="Search assignee..."
                                        value={assigneeSearch}
                                        onChange={(e) => setAssigneeSearch(e.target.value)}
                                        onFocus={() => {
                                            if (assigneeSearch.trim() || users.length > 0) {
                                                setShowAssigneeSuggestions(true);
                                            }
                                        }}
                                        className="block w-full pl-3 pr-10 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400"
                                    />
                                    {selectedAssignee && (
                                        <button
                                            type="button"
                                            onClick={handleAssigneeClear}
                                            className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                                        >
                                            <XIcon size={16} />
                                        </button>
                                    )}
                                </div>
                                {showAssigneeSuggestions && (
                                    <div
                                        ref={assigneeDropdownRef}
                                        className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-auto"
                                    >
                                        {usersLoading ? (
                                            <div className="p-3 text-sm text-gray-500 text-center">Loading...</div>
                                        ) : users.length === 0 ? (
                                            <div className="p-3 text-sm text-gray-500 text-center">No users found</div>
                                        ) : (
                                            users.map((user: any) => (
                                                <div
                                                    key={user._id}
                                                    onClick={() => handleAssigneeSelect(user)}
                                                    className={`p-3 cursor-pointer hover:bg-gray-50 transition-colors ${selectedAssignee?._id === user._id ? 'bg-blue-50' : ''
                                                        }`}
                                                >
                                                    <div className="text-sm font-medium text-gray-900">{user.name || '—'}</div>
                                                    {user.email && (
                                                        <div className="text-xs text-gray-500">{user.email}</div>
                                                    )}
                                                </div>
                                            ))
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="md:w-56">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                            <Select value={filters.status} onValueChange={(v: any) => handleFilterChange('status', v)}>
                                <SelectTrigger className="w-full h-11"><SelectValue placeholder="All" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All</SelectItem>
                                    <SelectItem value="PENDING">Pending</SelectItem>
                                    <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
                                    <SelectItem value="COMPLETED">Completed</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                </div>
            </Card>

            <Card>
                {loading ? (<div className="p-6"><TableSkeleton rows={5} columns={6} /></div>) : (<>
                    <Table columns={columns} data={tasks} />
                    {pagination.total_pages > 1 && (<div className="p-6 border-t border-gray-200">
                        <Pagination currentPage={pagination.current_page} totalPages={pagination.total_pages} totalItems={pagination.total_items} perPage={pagination.per_page} onPageChange={handlePageChange} onPerPageChange={handlePerPageChange} />
                    </div>)}
                </>)}
            </Card>

            {/* Confirm Delete Dialog */}
            <ConfirmDialog
                isOpen={isConfirmDialogOpen}
                onClose={() => setIsConfirmDialogOpen(false)}
                onConfirm={handleDeleteUser}
                title="Delete Task"
                message={`Are you sure you want to delete "${taskToDelete?.title || 'Untitled Task'}"? This action cannot be undone.`}
                confirmText="Delete"
                type="danger"
            />
        </div>
    );
};


export default TasksManagement;
