import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeftIcon, KeyIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import FormInput from '../components/ui/FormInput';
import { useUsers } from '../hooks/useUsers';
import { userService } from '../services/user.service';
import { useToastNotifications } from '../lib/toast';
import { TableSkeleton } from '../components/ui/Skeleton';

const UserPassword: React.FC = () => {
    const navigate = useNavigate();
    const { id } = useParams<{ id: string }>();
    const { getUser } = useUsers();
    const { showSuccess, showErrorWithDetails } = useToastNotifications();

    const [user, setUser] = useState<any>(null);
    const [userLoading, setUserLoading] = useState(true);
    const [passwordLoading, setPasswordLoading] = useState(false);
    const [passwordForm, setPasswordForm] = useState({
        newPassword: '',
        confirmPassword: '',
    });
    const [passwordErrors, setPasswordErrors] = useState<{ [key: string]: string }>({});

    useEffect(() => {
        const loadUser = async () => {
            if (!id) return;
            try {
                setUserLoading(true);
                const userData = await getUser(id);
                setUser(userData.data || userData);
            } catch (error: any) {
                showErrorWithDetails('Failed to load user', error?.message);
            } finally {
                setUserLoading(false);
            }
        };
        loadUser();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [id]);

    const handlePasswordChange = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!id || !user) return;

        const errors: { [key: string]: string } = {};
        if (!passwordForm.newPassword) {
            errors.newPassword = 'New password is required';
        } else if (passwordForm.newPassword.length < 8) {
            errors.newPassword = 'Password must be at least 8 characters long';
        } else if (!passwordForm.newPassword.match(/\d/) || !passwordForm.newPassword.match(/[a-zA-Z]/)) {
            errors.newPassword = 'Password must contain at least one letter and one number';
        }
        if (!passwordForm.confirmPassword) {
            errors.confirmPassword = 'Please confirm your new password';
        } else if (passwordForm.newPassword !== passwordForm.confirmPassword) {
            errors.confirmPassword = 'Passwords do not match';
        }

        if (Object.keys(errors).length > 0) {
            setPasswordErrors(errors);
            return;
        }

        setPasswordLoading(true);
        setPasswordErrors({});

        try {
            await userService.updateUserPasswordByAdmin(String(id), {
                newPassword: passwordForm.newPassword,
                confirmPassword: passwordForm.confirmPassword,
            });

            showSuccess('Password updated successfully');
            navigate('/users');
        } catch (error: any) {
            showErrorWithDetails('Failed to update password', error?.message);
        } finally {
            setPasswordLoading(false);
        }
    };

    if (userLoading) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/users')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <div className="h-8 bg-gray-200 rounded w-64 animate-pulse"></div>
                </div>
                <Card>
                    <div className="p-6">
                        <TableSkeleton rows={3} columns={1} />
                    </div>
                </Card>
            </div>
        );
    }

    if (!user) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/users')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <h1 className="text-2xl font-semibold text-gray-900">User Not Found</h1>
                </div>
                <Card>
                    <div className="p-6 text-center">
                        <p className="text-gray-500">The requested user could not be found.</p>
                    </div>
                </Card>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={() => navigate('/users')} icon={<ArrowLeftIcon size={16} />}>
                    Back
                </Button>
                <h1 className="text-2xl font-semibold text-gray-900">Change Password - {user.name}</h1>
            </div>

            <Card>
                <div className="p-6">
                    <div className="bg-purple-50 border-l-4 border-purple-500 p-4 mb-6 rounded-md">
                        <div className="flex">
                            <div className="flex-shrink-0">
                                <KeyIcon className="h-5 w-5 text-purple-500" />
                            </div>
                            <div className="ml-3">
                                <h3 className="text-sm font-medium text-purple-800">
                                    Change User Password
                                </h3>
                                <div className="mt-1 text-sm text-purple-700">
                                    Set a new password for {user.name}. The user will need to use this password for their next login.
                                </div>
                            </div>
                        </div>
                    </div>

                    <form onSubmit={handlePasswordChange} className="space-y-5">
                        <div className="space-y-4">
                            <FormField label="New Password" htmlFor="newPassword" required error={passwordErrors.newPassword}>
                                <FormInput
                                    type="password"
                                    id="newPassword"
                                    name="newPassword"
                                    placeholder="Enter new password"
                                    value={passwordForm.newPassword}
                                    onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                                    disabled={passwordLoading}
                                    error={passwordErrors.newPassword}
                                />
                                <p className="mt-1 text-xs text-gray-500">
                                    Password must be at least 8 characters long and include a number and a letter.
                                </p>
                            </FormField>

                            <FormField label="Confirm New Password" htmlFor="confirmPassword" required error={passwordErrors.confirmPassword}>
                                <FormInput
                                    type="password"
                                    id="confirmPassword"
                                    name="confirmPassword"
                                    placeholder="Confirm new password"
                                    value={passwordForm.confirmPassword}
                                    onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                                    disabled={passwordLoading}
                                    error={passwordErrors.confirmPassword}
                                />
                            </FormField>
                        </div>

                        <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => navigate('/users')}
                                disabled={passwordLoading}
                            >
                                Cancel
                            </Button>
                            <Button
                                type="submit"
                                variant="primary"
                                disabled={passwordLoading}
                            >
                                {passwordLoading ? 'Updating...' : 'Update Password'}
                            </Button>
                        </div>
                    </form>
                </div>
            </Card>
        </div>
    );
};

export default UserPassword;

