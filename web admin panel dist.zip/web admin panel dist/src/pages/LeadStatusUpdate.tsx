import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeftIcon, SaveIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import FormInput from '../components/ui/FormInput';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { useLeadStatus } from '../hooks/useLeadStatus';
import { UpdateLeadStatusRequest } from '../services/leadStatus.service';
import leadStatusService from '../services/leadStatus.service';
import { TableSkeleton } from '../components/ui/Skeleton';

const COLOR_OPTIONS: { label: string; value: string }[] = [
    { label: 'Blue', value: '#2563EB' },
    { label: 'Green', value: '#16A34A' },
    { label: 'Orange', value: '#EA580C' },
    { label: 'Red', value: '#DC2626' },
    { label: 'Purple', value: '#7C3AED' },
    { label: 'Teal', value: '#0D9488' },
    { label: 'Gray', value: '#4B5563' },
];

const LeadStatusUpdate: React.FC = () => {
    const navigate = useNavigate();
    const { id } = useParams<{ id: string }>();
    const { update, loading } = useLeadStatus();

    const [status, setStatus] = useState<any>(null);
    const [statusLoading, setStatusLoading] = useState(true);
    const [form, setForm] = useState<UpdateLeadStatusRequest & { _id?: string }>({
        name: '',
        type: 'leadStatus',
        order: 0,
        isActive: true,
        color: '',
        description: '',
    });

    useEffect(() => {
        const loadStatus = async () => {
            if (!id) return;
            try {
                setStatusLoading(true);
                // Use the list endpoint to find the status, or add getById to service
                const response = await leadStatusService.list({ page: 1, limit: 1000 });
                const foundStatus = response.results.find((s: any) => s._id === id);
                if (foundStatus) {
                    setStatus(foundStatus);
                    setForm({
                        _id: foundStatus._id,
                        name: foundStatus.name,
                        type: foundStatus.type,
                        order: foundStatus.order,
                        isActive: foundStatus.isActive,
                        color: foundStatus.color || '',
                        description: foundStatus.description || '',
                    });
                }
            } catch (error: any) {
                console.error('Failed to load lead status:', error);
            } finally {
                setStatusLoading(false);
            }
        };
        loadStatus();
    }, [id]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!id) return;

        try {
            await update(id, {
                name: form.name,
                type: form.type,
                order: form.order,
                isActive: form.isActive,
                color: form.color || null,
                description: form.description || null,
            });
            navigate('/settings?tab=leadStatus');
        } catch (error) {
            console.error('Failed to update lead status:', error);
        }
    };

    if (statusLoading) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/settings?tab=leadStatus')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <div className="h-8 bg-gray-200 rounded w-64 animate-pulse"></div>
                </div>
                <Card>
                    <div className="p-6">
                        <TableSkeleton rows={5} columns={1} />
                    </div>
                </Card>
            </div>
        );
    }

    if (!status) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/settings?tab=leadStatus')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <h1 className="text-2xl font-semibold text-gray-900">Status Not Found</h1>
                </div>
                <Card>
                    <div className="p-6 text-center">
                        <p className="text-gray-500">The requested status could not be found.</p>
                    </div>
                </Card>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={() => navigate('/settings?tab=leadStatus')} icon={<ArrowLeftIcon size={16} />}>
                    Back
                </Button>
                <h1 className="text-2xl font-semibold text-gray-900">Edit Status</h1>
            </div>

            <Card>
                <div className="p-6">
                    <form onSubmit={handleSubmit} className="space-y-5">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Name" htmlFor="statusName" required>
                                <FormInput
                                    id="statusName"
                                    name="name"
                                    value={form.name || ''}
                                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                                    disabled={loading}
                                    className="h-11"
                                />
                            </FormField>
                            <FormField label="Status Type" htmlFor="statusType" required>
                                <Select value={form.type} onValueChange={(value: string) => setForm({ ...form, type: value as any })}>
                                    <SelectTrigger className="w-full h-11">
                                        <SelectValue placeholder="Select status type" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="leadStatus">
                                            <span className="inline-flex items-center">
                                                <span className="inline-block w-3 h-3 rounded-full mr-2 bg-blue-500"></span>
                                                Lead Status
                                            </span>
                                        </SelectItem>
                                    </SelectContent>
                                </Select>
                            </FormField>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Color" htmlFor="color">
                                <Select value={form.color || ''} onValueChange={(value: string) => setForm({ ...form, color: value })}>
                                    <SelectTrigger className="w-full h-11">
                                        <SelectValue placeholder="Pick a color" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {COLOR_OPTIONS.map((opt) => (
                                            <SelectItem key={opt.value} value={opt.value}>
                                                <span className="inline-flex items-center">
                                                    <span className="inline-block w-3 h-3 rounded-full mr-2" style={{ backgroundColor: opt.value }}></span>
                                                    {opt.label} ({opt.value})
                                                </span>
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </FormField>
                            <FormField label="Order" htmlFor="order">
                                <FormInput
                                    type="number"
                                    id="order"
                                    name="order"
                                    value={form.order || 0}
                                    onChange={(e) => setForm({ ...form, order: Number(e.target.value) })}
                                    disabled={loading}
                                    className="h-11"
                                />
                            </FormField>
                        </div>
                        <FormField label="Description" htmlFor="description">
                            <textarea
                                id="description"
                                name="description"
                                className="block w-full px-3 py-2.5 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 resize-none"
                                rows={5}
                                placeholder="Add a description for this status (optional)"
                                value={form.description || ''}
                                onChange={(e) => setForm({ ...form, description: e.target.value })}
                            />
                        </FormField>
                        <div className="flex items-center space-x-2">
                            <input
                                id="isActive"
                                type="checkbox"
                                className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                checked={form.isActive}
                                onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
                            />
                            <label htmlFor="isActive" className="text-sm text-gray-700">Active</label>
                        </div>
                        <div className="flex justify-end space-x-2 pt-4 border-t border-gray-200">
                            <Button variant="outline" type="button" onClick={() => navigate('/settings?tab=leadStatus')}>Cancel</Button>
                            <Button variant="primary" type="submit" icon={<SaveIcon size={16} />} disabled={loading}>
                                {loading ? 'Saving...' : 'Save Changes'}
                            </Button>
                        </div>
                    </form>
                </div>
            </Card>
        </div>
    );
};

export default LeadStatusUpdate;

