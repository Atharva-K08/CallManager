import React, { useState } from 'react';
import { PhoneCallIcon, MailIcon, LockIcon } from 'lucide-react';
import Button from '../components/ui/Button';
import FormInput from '../components/ui/FormInput';
import { useAuth } from '../hooks/useAuth';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login, loading, error } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await login({ email, password });
  };

  return <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
    <div className="max-w-md w-full space-y-8">
      <div className="text-center">
        <div className="mx-auto h-16 w-16 bg-blue-600 rounded-full flex items-center justify-center">
          <PhoneCallIcon size={32} className="text-white" />
        </div>
        <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
          Call Tracker
        </h2>
        <p className="mt-2 text-sm text-gray-600">Sign in to your account</p>
      </div>
      <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
        {error && <div className="bg-red-50 text-red-700 p-3 rounded-md text-sm">
          {error.message || 'Login failed. Please check your credentials.'}
        </div>}
        <div className="rounded-md shadow-sm space-y-4">
          <div>
            <label htmlFor="email-address" className="block text-sm font-medium text-gray-700 mb-1">
              Email address
            </label>
            <FormInput
              id="email-address"
              name="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="Enter Your Email"
              icon={MailIcon}
            />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Password
              </label>
              <a href="#" className="text-sm text-blue-600 hover:text-blue-500">
                Forgot your password?
              </a>
            </div>
            <FormInput
              id="password"
              name="password"
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Enter Your Password"
              icon={LockIcon}
            />
          </div>
        </div>
        <div>
          <Button type="submit" variant="primary" fullWidth size="lg" disabled={loading}>
            {loading ? 'Signing in...' : 'Sign in'}
          </Button>
        </div>
      </form>
      <div className="text-center text-sm text-gray-600">
        <p>Demo credentials: admin@example.com / Admin@123</p>
      </div>
    </div>
  </div>;
};
export default Login;