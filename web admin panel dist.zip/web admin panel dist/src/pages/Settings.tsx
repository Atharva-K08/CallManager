import React, { useEffect, useMemo, useState } from 'react';
import { SaveIcon, PlusIcon, PencilIcon, CheckCircleIcon, XCircleIcon, SearchIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { useLeadStatus } from '../hooks/useLeadStatus';
import Drawer from '../components/ui/Drawer';
import FormField from '../components/ui/FormField';
import FormInput from '../components/ui/FormInput';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { userService } from '../services/user.service';
import { authService } from '../services/auth.service';
import { User } from '../types/api.types';
import { useToastNotifications } from '../lib/toast';
import leadStatusService from '../services/leadStatus.service';

type LeadStatusForm = {
  _id?: string;
  name: string;
  type: 'leadStatus';
  color?: string | null;
  order: number;
  isActive: boolean;
  description?: string | null;
};
const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('profile');
  const { showSuccess, showErrorWithDetails } = useToastNotifications();

  // User profile state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileForm, setProfileForm] = useState({
    name: '',
    phoneNumber: '',
  });
  const [profileErrors, setProfileErrors] = useState<{ [key: string]: string }>({});

  // Password change state
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [passwordErrors, setPasswordErrors] = useState<{ [key: string]: string }>({});
  const [passwordLoading, setPasswordLoading] = useState(false);

  // Lead Status state & logic
  const {
    data: leadStatusData,
    fetch: fetchLeadStatuses,
    create: createLeadStatus,
    update: updateLeadStatus,
    activate: activateLeadStatus,
    deactivate: deactivateLeadStatus,
    loading: leadStatusLoading,
  } = useLeadStatus();

  const [statusTypeFilter, setStatusTypeFilter] = useState<'leadStatus' | 'all'>('all');
  const [search, setSearch] = useState<string>('');
  const [formOpen, setFormOpen] = useState<boolean>(false);
  const [editing, setEditing] = useState<boolean>(false);
  const [form, setForm] = useState<LeadStatusForm>({ name: '', type: 'leadStatus', order: 0, isActive: true, color: '', description: '' });
  const [defaultImportStatusId, setDefaultImportStatusId] = useState<string | null>(null);
  const [loadingDefaultImport, setLoadingDefaultImport] = useState(false);

  const COLOR_OPTIONS: { label: string; value: string }[] = useMemo(() => ([
    // Tailwind 600 tone equivalents for consistent darkness with app badges
    { label: 'Blue', value: '#2563EB' },   // blue-600
    { label: 'Green', value: '#16A34A' },  // green-600
    { label: 'Orange', value: '#EA580C' }, // orange-600
    { label: 'Red', value: '#DC2626' },    // red-600
    { label: 'Purple', value: '#7C3AED' }, // purple-600
    { label: 'Teal', value: '#0D9488' },   // teal-600
    { label: 'Gray', value: '#4B5563' },   // gray-600
  ]), []);

  // Load current user when component mounts or profile tab is active
  useEffect(() => {
    if (activeTab === 'profile' && !currentUser) {
      loadCurrentUser();
    }
  }, [activeTab, currentUser]);

  useEffect(() => {
    if (activeTab === 'leadStatus') {
      fetchLeadStatuses({ page: 1, limit: 100, sortBy: 'order:asc' });
      loadDefaultImportStatus();
    }
  }, [activeTab]);

  const loadDefaultImportStatus = async () => {
    try {
      const result = await leadStatusService.getDefaultImport();
      setDefaultImportStatusId(result.default?._id || null);
    } catch (error) {
      // Silently fail - default will just be null
    }
  };

  const handleSetDefaultImport = async (statusId: string | null) => {
    if (!statusId) return;
    setLoadingDefaultImport(true);
    try {
      await leadStatusService.setDefaultImport(statusId);
      setDefaultImportStatusId(statusId);
      showSuccess('Default import status updated');
      await fetchLeadStatuses({ page: 1, limit: 100, sortBy: 'order:asc' });
    } catch (error: any) {
      showErrorWithDetails('Failed to set default import status', error?.message);
    } finally {
      setLoadingDefaultImport(false);
    }
  };

  // Load current user
  const loadCurrentUser = async () => {
    try {
      const user = await authService.getCurrentUser();
      setCurrentUser(user);
      setProfileForm({
        name: user.name || '',
        phoneNumber: user.phoneNumber || '',
      });
    } catch (error) {
      showErrorWithDetails('Failed to load user profile', 'Please try again later');
    }
  };

  // Handle profile update
  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setProfileLoading(true);
    setProfileErrors({});

    try {
      await userService.updateUserProfile(currentUser._id, profileForm);
      await loadCurrentUser(); // Reload user data
      showSuccess('Profile updated successfully');
    } catch (error: any) {
      showErrorWithDetails('Failed to update profile', error?.message || 'Please try again');
    } finally {
      setProfileLoading(false);
    }
  };

  // Handle password change
  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    // Validate passwords
    const errors: { [key: string]: string } = {};
    if (!passwordForm.currentPassword) {
      errors.currentPassword = 'Current password is required';
    }
    if (!passwordForm.newPassword) {
      errors.newPassword = 'New password is required';
    } else if (passwordForm.newPassword.length < 8) {
      errors.newPassword = 'Password must be at least 8 characters long';
    } else if (!passwordForm.newPassword.match(/\d/) || !passwordForm.newPassword.match(/[a-zA-Z]/)) {
      errors.newPassword = 'Password must contain at least one letter and one number';
    }
    if (!passwordForm.confirmPassword) {
      errors.confirmPassword = 'Please confirm your new password';
    } else if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }

    if (Object.keys(errors).length > 0) {
      setPasswordErrors(errors);
      return;
    }

    setPasswordLoading(true);
    setPasswordErrors({});

    try {
      await userService.updateUserPassword(currentUser._id, {
        currentPassword: passwordForm.currentPassword,
        newPassword: passwordForm.newPassword,
        confirmPassword: passwordForm.confirmPassword,
      });

      // Clear form
      setPasswordForm({
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      });

      showSuccess('Password updated successfully');
    } catch (error: any) {
      showErrorWithDetails('Failed to update password', error?.message || 'Please try again');
    } finally {
      setPasswordLoading(false);
    }
  };

  const filteredStatuses = useMemo(() => {
    const items = leadStatusData?.results || [];
    return items.filter((s) =>
      (statusTypeFilter === 'all' || s.type === statusTypeFilter) &&
      (search.trim().length === 0 || s.name.toLowerCase().includes(search.toLowerCase()))
    );
  }, [leadStatusData, statusTypeFilter, search]);

  const openCreateForm = () => {
    setEditing(false);
    setForm({ name: '', type: 'leadStatus', order: 0, isActive: true, color: '', description: '' });
    setFormOpen(true);
  };

  const openEditForm = (item: any) => {
    setEditing(true);
    setForm({
      _id: item._id,
      name: item.name,
      type: item.type,
      order: item.order,
      isActive: item.isActive,
      color: item.color || '',
      description: item.description || '',
    });
    setFormOpen(true);
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editing && form._id) {
      await updateLeadStatus(form._id, {
        name: form.name,
        type: form.type,
        order: form.order,
        isActive: form.isActive,
        color: form.color || null,
        description: form.description || null,
      });
    } else {
      await createLeadStatus({
        name: form.name,
        type: form.type,
        order: form.order,
        isActive: form.isActive,
        color: form.color || null,
        description: form.description || null,
      });
    }
    setFormOpen(false);
  };
  return <div className="space-y-6">
    <div>
      <h1 className="text-2xl font-semibold text-gray-900">Settings</h1>
      <p className="mt-1 text-sm text-gray-500">
        Manage your account and system preferences
      </p>
    </div>
    <div className="flex border-b border-gray-200">
      <button className={`py-3 px-6 font-medium text-sm ${activeTab === 'profile' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('profile')}>
        User Profile
      </button>
      <button className={`py-3 px-6 font-medium text-sm ${activeTab === 'password' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('password')}>
        Change Password
      </button>
      <button className={`py-3 px-6 font-medium text-sm ${activeTab === 'leadStatus' ? 'border-b-2 border-blue-500 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`} onClick={() => setActiveTab('leadStatus')}>
        Lead Status
      </button>
    </div>
    {activeTab === 'profile' && <Card>
      <form onSubmit={handleProfileUpdate} className="space-y-6">
        <div className="flex items-center space-x-6">
          <div className="w-20 h-20 rounded-full bg-blue-100 flex items-center justify-center">
            {currentUser?.profilePicture ? (
              <img
                src={currentUser.profilePicture}
                alt="Profile"
                className="w-20 h-20 rounded-full object-cover"
              />
            ) : (
              <span className="text-2xl font-medium text-blue-600">
                {currentUser?.name?.charAt(0)?.toUpperCase() || 'U'}
              </span>
            )}
          </div>
          <div>
            <h3 className="text-lg font-medium text-gray-900">{currentUser?.name || 'User'}</h3>
            <p className="text-sm text-gray-500">{currentUser?.email || ''}</p>
            <p className="text-sm text-gray-500 capitalize">{currentUser?.role || ''}</p>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
          <FormField label="Full Name" htmlFor="name" required error={profileErrors.name}>
            <FormInput
              id="name"
              name="name"
              placeholder="e.g., John Doe"
              value={profileForm.name}
              onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
              error={profileErrors.name}
            />
          </FormField>
          <FormField label="Email Address" htmlFor="email">
            <FormInput
              id="email"
              name="email"
              type="email"
              placeholder="e.g., john@example.com"
              value={currentUser?.email || ''}
              disabled
            />
            <p className="mt-1 text-xs text-gray-500">Email cannot be changed</p>
          </FormField>
          <FormField label="Phone Number" htmlFor="phoneNumber" error={profileErrors.phoneNumber}>
            <FormInput
              id="phoneNumber"
              name="phoneNumber"
              type="tel"
              placeholder="e.g., +1 555 123 4567"
              value={profileForm.phoneNumber}
              onChange={(e) => setProfileForm({ ...profileForm, phoneNumber: e.target.value })}
              error={profileErrors.phoneNumber}
            />
          </FormField>
          <FormField label="Role" htmlFor="role">
            <FormInput
              id="role"
              name="role"
              placeholder="User role"
              value={currentUser?.role || ''}
              disabled
            />
            <p className="mt-1 text-xs text-gray-500">Role cannot be changed</p>
          </FormField>
        </div>
        <div className="flex justify-end">
          <Button variant="primary" icon={<SaveIcon size={16} />} type="submit" disabled={profileLoading}>
            {profileLoading ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </form>
    </Card>}
    {activeTab === 'password' && <Card>
      <form onSubmit={handlePasswordChange} className="space-y-6">
        <div className="space-y-4">
          <FormField label="Current Password" htmlFor="currentPassword" required error={passwordErrors.currentPassword}>
            <FormInput
              id="currentPassword"
              name="currentPassword"
              type="password"
              placeholder="Enter your current password"
              value={passwordForm.currentPassword}
              onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
              error={passwordErrors.currentPassword}
            />
          </FormField>
          <FormField label="New Password" htmlFor="newPassword" required error={passwordErrors.newPassword}>
            <FormInput
              id="newPassword"
              name="newPassword"
              type="password"
              placeholder="Enter your new password"
              value={passwordForm.newPassword}
              onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
              error={passwordErrors.newPassword}
            />
            <p className="mt-1 text-xs text-gray-500">
              Password must be at least 8 characters long and include a number and a letter.
            </p>
          </FormField>
          <FormField label="Confirm New Password" htmlFor="confirmPassword" required error={passwordErrors.confirmPassword}>
            <FormInput
              id="confirmPassword"
              name="confirmPassword"
              type="password"
              placeholder="Confirm your new password"
              value={passwordForm.confirmPassword}
              onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
              error={passwordErrors.confirmPassword}
            />
          </FormField>
        </div>
        <div className="flex justify-end">
          <Button variant="primary" icon={<SaveIcon size={16} />} type="submit" disabled={passwordLoading}>
            {passwordLoading ? 'Updating...' : 'Update Password'}
          </Button>
        </div>
      </form>
    </Card>}
    {activeTab === 'leadStatus' && <Card title="Lead Status Management">
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-900 mb-2">Manage Lead Statuses</h3>
        <p className="text-sm text-gray-600 mb-4">Create and manage lead statuses (New, Contacted, Qualified, etc.)</p>
      </div>

      {/* Default Import Status Setting */}
      <Card className="mb-4">
        <div className="p-3">
          <FormField label="Default Status for Excel Import" htmlFor="defaultImportStatus">
            <Select
              value={defaultImportStatusId || ''}
              onValueChange={handleSetDefaultImport}
              disabled={loadingDefaultImport || leadStatusLoading}
            >
              <SelectTrigger className="w-full h-11">
                <SelectValue placeholder="Select default import status" />
              </SelectTrigger>
              <SelectContent>
                {(leadStatusData?.results || [])
                  .filter((s: any) => s.type === 'leadStatus' && s.isActive)
                  .map((opt: any) => (
                    <SelectItem key={opt._id} value={opt._id}>
                      <span className="inline-flex items-center">
                        <span className="inline-block w-3 h-3 rounded-full mr-2" style={{ backgroundColor: opt.color || '#e5e7eb' }}></span>
                        {opt.name}
                        {opt._id === defaultImportStatusId && <span className="ml-2 text-xs text-blue-600">(Current)</span>}
                      </span>
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
            <p className="mt-1 text-xs text-gray-500">
              This status will be automatically assigned to leads imported via Excel when no status is provided.
            </p>
          </FormField>
        </div>
      </Card>

      {/* Filter and Search */}
      <Card>
        <div className="p-3">
          <div className="space-y-2">
            <div className="flex flex-col md:flex-row md:items-end gap-3">
              {/* Search - flexible width */}
              <div className="md:flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Search Statuses
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <SearchIcon size={18} className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search status names..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400"
                  />
                </div>
              </div>

              {/* Filter by Type */}
              <div className="md:w-56">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Filter by Type
                </label>
                <Select value={statusTypeFilter} onValueChange={(value: string) => setStatusTypeFilter(value as any)}>
                  <SelectTrigger className="w-full h-11">
                    <SelectValue placeholder="All Lead Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Lead Statuses</SelectItem>
                    <SelectItem value="leadStatus">Lead Status Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </div>
      </Card>

      <div className="mt-4 flex justify-end mb-4">
        <Button variant="primary" size="sm" icon={<PlusIcon size={16} />} onClick={openCreateForm}>
          Add New Status
        </Button>
      </div>

      <div className="overflow-x-auto border rounded-md">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Color</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Active</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
              <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {(leadStatusLoading ? Array.from({ length: 5 }) : filteredStatuses).map((item: any, idx: number) => (
              <tr key={item?._id || idx}>
                <td className="px-4 py-2 text-sm text-gray-700">
                  {leadStatusLoading ? '...' : (
                    <span className="inline-flex items-center gap-2">
                      {item.name}
                      {item.isDefaultForImport && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-700">
                          Default for Import
                        </span>
                      )}
                    </span>
                  )}
                </td>
                <td className="px-4 py-2 text-sm text-gray-700">
                  {leadStatusLoading ? '...' : (
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-700">
                      Lead Status
                    </span>
                  )}
                </td>
                <td className="px-4 py-2 text-sm">
                  {leadStatusLoading ? '...' : (
                    item.color ? <span className="inline-flex items-center space-x-2"><span className="inline-block w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></span><span className="text-gray-700">{item.color}</span></span> : <span className="text-gray-400">-</span>
                  )}
                </td>
                <td className="px-4 py-2 text-sm text-gray-700">{leadStatusLoading ? '...' : item.order}</td>
                <td className="px-4 py-2 text-sm">
                  {leadStatusLoading ? '...' : (
                    <span className={`px-2 py-1 rounded-full text-xs ${item.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>{item.isActive ? 'Active' : 'Inactive'}</span>
                  )}
                </td>
                <td className="px-4 py-2 text-sm text-gray-700 max-w-xs truncate" title={item?.description || ''}>{leadStatusLoading ? '...' : (item?.description || '-')}</td>
                <td className="px-4 py-2 text-right whitespace-nowrap">
                  {!leadStatusLoading && (
                    <div className="flex space-x-1 justify-end">
                      <button
                        onClick={() => openEditForm(item)}
                        className="p-1.5 rounded-full text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition-colors"
                        title="Edit Status"
                      >
                        <PencilIcon size={16} />
                      </button>
                      <button
                        onClick={async () => { item.isActive ? await deactivateLeadStatus(item._id) : await activateLeadStatus(item._id); }}
                        className={`p-1.5 rounded-full transition-colors ${item.isActive ? 'text-orange-600 hover:text-orange-800 hover:bg-orange-50' : 'text-green-600 hover:text-green-800 hover:bg-green-50'}`}
                        title={item.isActive ? 'Deactivate Status' : 'Activate Status'}
                      >
                        {item.isActive ? <XCircleIcon size={16} /> : <CheckCircleIcon size={16} />}
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Drawer
        isOpen={formOpen}
        onClose={() => setFormOpen(false)}
        title={editing ? 'Edit Status' : 'Add Status'}
      >
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Name" htmlFor="statusName" required>
              <FormInput
                id="statusName"
                name="name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                disabled={leadStatusLoading}
                className="h-11"
              />
            </FormField>
            <FormField label="Status Type" htmlFor="statusType" required>
              <Select value={form.type} onValueChange={(value: string) => setForm({ ...form, type: value as any })}>
                <SelectTrigger className="w-full h-11">
                  <SelectValue placeholder="Select status type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="leadStatus">
                    <span className="inline-flex items-center">
                      <span className="inline-block w-3 h-3 rounded-full mr-2 bg-blue-500"></span>
                      Lead Status
                    </span>
                  </SelectItem>
                </SelectContent>
              </Select>
            </FormField>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Color" htmlFor="color">
              <Select value={form.color || ''} onValueChange={(value: string) => setForm({ ...form, color: value })}>
                <SelectTrigger className="w-full h-11">
                  <SelectValue placeholder="Pick a color" />
                </SelectTrigger>
                <SelectContent>
                  {COLOR_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      <span className="inline-flex items-center"><span className="inline-block w-3 h-3 rounded-full mr-2" style={{ backgroundColor: opt.value }}></span>{opt.label} ({opt.value})</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </FormField>
            <FormField label="Order" htmlFor="order">
              <FormInput
                type="number"
                id="order"
                name="order"
                value={form.order}
                onChange={(e) => setForm({ ...form, order: Number(e.target.value) })}
                disabled={leadStatusLoading}
                className="h-11"
              />
            </FormField>
          </div>
          <FormField label="Description" htmlFor="description">
            <textarea
              id="description"
              name="description"
              className="block w-full px-3 py-2.5 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 resize-none"
              rows={5}
              placeholder="Add a description for this status (optional)"
              value={form.description || ''}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </FormField>
          <div className="flex items-center space-x-2">
            <input
              id="isActive"
              type="checkbox"
              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              checked={form.isActive}
              onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
            />
            <label htmlFor="isActive" className="text-sm text-gray-700">Active</label>
          </div>
          <div className="flex justify-end space-x-2 pt-4 border-t border-gray-200">
            <Button variant="outline" type="button" onClick={() => setFormOpen(false)}>Cancel</Button>
            <Button variant="primary" type="submit" icon={<SaveIcon size={16} />} disabled={leadStatusLoading}>{editing ? 'Save Changes' : 'Create'}</Button>
          </div>
        </form>
      </Drawer>
    </Card>}
  </div>;
};
export default Settings;