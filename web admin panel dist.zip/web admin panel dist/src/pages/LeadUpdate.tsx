import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeftIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import FormInput from '../components/ui/FormInput';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { useLeads } from '../hooks/useLeads';
import { useLeadStatus } from '../hooks/useLeadStatus';
import { UpdateLeadRequest } from '../services/lead.service';
import leadService from '../services/lead.service';
import { useToastNotifications } from '../lib/toast';
import { TableSkeleton } from '../components/ui/Skeleton';

const sanitizePhoneNumber = (phoneNumber: string): string => {
    if (!phoneNumber) return '';
    const digitsOnly = phoneNumber.replace(/\D/g, '');
    return digitsOnly.slice(-10);
};

const LeadUpdate: React.FC = () => {
    const navigate = useNavigate();
    const { id } = useParams<{ id: string }>();
    const { update, loading } = useLeads();
    const { data: leadStatusData, fetch: fetchLeadStatuses, loading: leadStatusLoading } = useLeadStatus();
    const { showErrorWithDetails } = useToastNotifications();

    const [lead, setLead] = useState<any>(null);
    const [leadLoading, setLeadLoading] = useState(true);
    const [formErrors, setFormErrors] = useState<{ [k: string]: string }>({});
    const [formData, setFormData] = useState<UpdateLeadRequest & { _id?: string }>({
        firstName: '',
        lastName: '',
        phoneNumber: '',
        email: '',
        campus: '',
        class: '',
        city: '',
        status: '',
        remark: '',
        assignedTo: '',
        source: '',
        priority: 0,
    });

    useEffect(() => {
        fetchLeadStatuses({ page: 1, limit: 100, sortBy: 'order:asc' });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        const loadLead = async () => {
            if (!id) return;
            try {
                setLeadLoading(true);
                const leadData = await leadService.getById(id);
                setLead(leadData);
                setFormData({
                    _id: leadData._id,
                    firstName: leadData.firstName || '',
                    lastName: leadData.lastName || '',
                    phoneNumber: leadData.phoneNumber || '',
                    email: leadData.email || '',
                    campus: leadData.campus || '',
                    class: leadData.class || '',
                    city: leadData.city || '',
                    status: leadData.status || '',
                    remark: leadData.remark || '',
                    assignedTo: leadData.assignedTo || '',
                    source: leadData.source || '',
                    priority: leadData.priority || 0,
                });
            } catch (error: any) {
                showErrorWithDetails('Failed to load lead', error?.message);
            } finally {
                setLeadLoading(false);
            }
        };
        loadLead();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [id]);

    const leadStatusOptions = useMemo(
        () => (leadStatusData?.results || []).filter((s: any) => s.type === 'leadStatus' && s.isActive),
        [leadStatusData]
    );

    const validateForm = () => {
        const errors: { [k: string]: string } = {};
        if (!formData.firstName?.trim()) errors.firstName = 'First name is required';
        if (!formData.lastName?.trim()) errors.lastName = 'Last name is required';
        if (!formData.phoneNumber?.trim()) {
            errors.phoneNumber = 'Phone number is required';
        } else {
            const digitsOnly = formData.phoneNumber.replace(/\D/g, '');
            if (digitsOnly.length < 10) {
                errors.phoneNumber = 'Phone number must have at least 10 digits';
            }
        }
        return errors;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!id) return;

        const errors = validateForm();
        if (Object.keys(errors).length) {
            setFormErrors(errors);
            return;
        }

        try {
            const payload: UpdateLeadRequest = { ...formData };
            delete (payload as any)._id;
            if (payload.phoneNumber) {
                payload.phoneNumber = sanitizePhoneNumber(payload.phoneNumber);
            }
            await update(id, payload);
            navigate('/leads');
        } catch (error: any) {
            showErrorWithDetails('Failed to update lead', error?.message);
        }
    };

    if (leadLoading) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/leads')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <div className="h-8 bg-gray-200 rounded w-64 animate-pulse"></div>
                </div>
                <Card>
                    <div className="p-6">
                        <TableSkeleton rows={5} columns={1} />
                    </div>
                </Card>
            </div>
        );
    }

    if (!lead) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/leads')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <h1 className="text-2xl font-semibold text-gray-900">Lead Not Found</h1>
                </div>
                <Card>
                    <div className="p-6 text-center">
                        <p className="text-gray-500">The requested lead could not be found.</p>
                    </div>
                </Card>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={() => navigate('/leads')} icon={<ArrowLeftIcon size={16} />}>
                    Back
                </Button>
                <h1 className="text-2xl font-semibold text-gray-900">Edit Lead</h1>
            </div>

            <Card>
                <div className="p-6">
                    <form onSubmit={handleSubmit} className="space-y-5">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="First Name" htmlFor="firstName" required error={formErrors.firstName}>
                                <FormInput
                                    id="firstName"
                                    name="firstName"
                                    placeholder="e.g., John"
                                    value={formData.firstName || ''}
                                    onChange={(e) => {
                                        setFormData({ ...formData, firstName: e.target.value });
                                        if (formErrors.firstName) {
                                            setFormErrors({ ...formErrors, firstName: '' });
                                        }
                                    }}
                                    error={formErrors.firstName}
                                />
                            </FormField>
                            <FormField label="Last Name" htmlFor="lastName" required error={formErrors.lastName}>
                                <FormInput
                                    id="lastName"
                                    name="lastName"
                                    placeholder="e.g., Doe"
                                    value={formData.lastName || ''}
                                    onChange={(e) => {
                                        setFormData({ ...formData, lastName: e.target.value });
                                        if (formErrors.lastName) {
                                            setFormErrors({ ...formErrors, lastName: '' });
                                        }
                                    }}
                                    error={formErrors.lastName}
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Phone Number" htmlFor="phoneNumber" required error={formErrors.phoneNumber}>
                                <FormInput
                                    id="phoneNumber"
                                    name="phoneNumber"
                                    placeholder="e.g., +1 555 123 4567"
                                    value={formData.phoneNumber || ''}
                                    onChange={(e) => {
                                        const value = e.target.value;
                                        setFormData({ ...formData, phoneNumber: value });
                                        if (formErrors.phoneNumber) {
                                            setFormErrors({ ...formErrors, phoneNumber: '' });
                                        }
                                    }}
                                    onBlur={() => {
                                        if (formData.phoneNumber) {
                                            const sanitized = sanitizePhoneNumber(formData.phoneNumber);
                                            if (sanitized !== formData.phoneNumber) {
                                                setFormData({ ...formData, phoneNumber: sanitized });
                                            }
                                        }
                                    }}
                                    error={formErrors.phoneNumber}
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Email" htmlFor="email">
                                <FormInput
                                    id="email"
                                    name="email"
                                    type="email"
                                    placeholder="e.g., john@example.com"
                                    value={formData.email || ''}
                                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                />
                            </FormField>
                            <FormField label="College" htmlFor="campus">
                                <FormInput
                                    id="campus"
                                    name="campus"
                                    placeholder="e.g., North Campus"
                                    value={formData.campus || ''}
                                    onChange={(e) => setFormData({ ...formData, campus: e.target.value })}
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Class" htmlFor="class">
                                <FormInput
                                    id="class"
                                    name="class"
                                    placeholder="e.g., MBA, BBA"
                                    value={formData.class || ''}
                                    onChange={(e) => setFormData({ ...formData, class: e.target.value })}
                                />
                            </FormField>
                            <FormField label="City" htmlFor="city">
                                <FormInput
                                    id="city"
                                    name="city"
                                    placeholder="e.g., New York"
                                    value={formData.city || ''}
                                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Lead Status" htmlFor="status">
                                <Select
                                    value={formData.status}
                                    onValueChange={(value: string) => setFormData({ ...formData, status: value })}
                                    disabled={leadStatusLoading}
                                >
                                    <SelectTrigger className="w-full h-11">
                                        <SelectValue placeholder="Select status" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {leadStatusOptions.map((opt: any) => (
                                            <SelectItem key={opt._id} value={opt.name}>
                                                <span className="inline-flex items-center">
                                                    <span className="inline-block w-3 h-3 rounded-full mr-2" style={{ backgroundColor: opt.color || '#e5e7eb' }}></span>
                                                    {opt.name}
                                                </span>
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </FormField>
                            <FormField label="Source" htmlFor="source">
                                <FormInput
                                    id="source"
                                    name="source"
                                    placeholder="e.g., Website, Referral, Campaign"
                                    value={formData.source || ''}
                                    onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                                />
                            </FormField>
                        </div>

                        <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                            <Button type="button" variant="outline" onClick={() => navigate('/leads')}>Cancel</Button>
                            <Button type="submit" variant="primary" disabled={loading}>
                                {loading ? 'Saving...' : 'Save Changes'}
                            </Button>
                        </div>
                    </form>
                </div>
            </Card>
        </div>
    );
};

export default LeadUpdate;

