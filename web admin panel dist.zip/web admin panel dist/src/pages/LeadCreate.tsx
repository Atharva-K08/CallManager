import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeftIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import FormInput from '../components/ui/FormInput';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { useLeads } from '../hooks/useLeads';
import { useLeadStatus } from '../hooks/useLeadStatus';
import { CreateLeadRequest } from '../services/lead.service';
import { useToastNotifications } from '../lib/toast';

const sanitizePhoneNumber = (phoneNumber: string): string => {
    if (!phoneNumber) return '';
    const digitsOnly = phoneNumber.replace(/\D/g, '');
    return digitsOnly.slice(-10);
};

const LeadCreate: React.FC = () => {
    const navigate = useNavigate();
    const { create, loading } = useLeads();
    const { data: leadStatusData, fetch: fetchLeadStatuses, loading: leadStatusLoading } = useLeadStatus();
    const { showErrorWithDetails } = useToastNotifications();

    const [formErrors, setFormErrors] = useState<{ [k: string]: string }>({});
    const [formData, setFormData] = useState<CreateLeadRequest>({
        firstName: '',
        lastName: '',
        phoneNumber: '',
        email: '',
        campus: '',
        class: '',
        city: '',
        status: '',
        remark: '',
        assignedTo: '',
        source: '',
        priority: 0,
    });

    useEffect(() => {
        fetchLeadStatuses({ page: 1, limit: 100, sortBy: 'order:asc' });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const leadStatusOptions = useMemo(
        () => (leadStatusData?.results || []).filter((s: any) => s.type === 'leadStatus' && s.isActive),
        [leadStatusData]
    );

    // Set default status when lead statuses are loaded
    useEffect(() => {
        if (leadStatusOptions.length > 0 && !formData.status) {
            // First, try to find status with isDefaultForImport: true
            const defaultStatus = leadStatusOptions.find((s: any) => s.isDefaultForImport === true);
            // If not found, try to find status with name "New"
            const newStatus = defaultStatus || leadStatusOptions.find((s: any) => s.name === 'New');
            // If found, set it as default
            if (newStatus) {
                setFormData(prev => ({ ...prev, status: newStatus.name }));
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [leadStatusOptions]);

    const validateForm = () => {
        const errors: { [k: string]: string } = {};
        if (!formData.firstName.trim()) errors.firstName = 'First name is required';
        if (!formData.lastName.trim()) errors.lastName = 'Last name is required';
        if (!formData.phoneNumber.trim()) {
            errors.phoneNumber = 'Phone number is required';
        } else {
            const digitsOnly = formData.phoneNumber.replace(/\D/g, '');
            if (digitsOnly.length < 10) {
                errors.phoneNumber = 'Phone number must have at least 10 digits';
            }
        }
        return errors;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const errors = validateForm();
        if (Object.keys(errors).length) {
            setFormErrors(errors);
            return;
        }

        try {
            const payload: CreateLeadRequest = { ...formData };
            if (payload.phoneNumber) {
                payload.phoneNumber = sanitizePhoneNumber(payload.phoneNumber);
            }
            await create(payload);
            navigate('/leads');
        } catch (error: any) {
            showErrorWithDetails('Failed to create lead', error?.message);
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={() => navigate('/leads')} icon={<ArrowLeftIcon size={16} />}>
                    Back
                </Button>
                <h1 className="text-2xl font-semibold text-gray-900">Add New Lead</h1>
            </div>

            <Card>
                <div className="p-6">
                    <form onSubmit={handleSubmit} className="space-y-5">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="First Name" htmlFor="firstName" required error={formErrors.firstName}>
                                <FormInput
                                    id="firstName"
                                    name="firstName"
                                    placeholder="e.g., John"
                                    value={formData.firstName}
                                    onChange={(e) => {
                                        setFormData({ ...formData, firstName: e.target.value });
                                        if (formErrors.firstName) {
                                            setFormErrors({ ...formErrors, firstName: '' });
                                        }
                                    }}
                                    error={formErrors.firstName}
                                />
                            </FormField>
                            <FormField label="Last Name" htmlFor="lastName" required error={formErrors.lastName}>
                                <FormInput
                                    id="lastName"
                                    name="lastName"
                                    placeholder="e.g., Doe"
                                    value={formData.lastName}
                                    onChange={(e) => {
                                        setFormData({ ...formData, lastName: e.target.value });
                                        if (formErrors.lastName) {
                                            setFormErrors({ ...formErrors, lastName: '' });
                                        }
                                    }}
                                    error={formErrors.lastName}
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Phone Number" htmlFor="phoneNumber" required error={formErrors.phoneNumber}>
                                <FormInput
                                    id="phoneNumber"
                                    name="phoneNumber"
                                    placeholder="e.g., +1 555 123 4567"
                                    value={formData.phoneNumber}
                                    onChange={(e) => {
                                        const value = e.target.value;
                                        setFormData({ ...formData, phoneNumber: value });
                                        if (formErrors.phoneNumber) {
                                            setFormErrors({ ...formErrors, phoneNumber: '' });
                                        }
                                    }}
                                    onBlur={() => {
                                        if (formData.phoneNumber) {
                                            const sanitized = sanitizePhoneNumber(formData.phoneNumber);
                                            if (sanitized !== formData.phoneNumber) {
                                                setFormData({ ...formData, phoneNumber: sanitized });
                                            }
                                        }
                                    }}
                                    error={formErrors.phoneNumber}
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Email" htmlFor="email">
                                <FormInput
                                    id="email"
                                    name="email"
                                    type="email"
                                    placeholder="e.g., john@example.com"
                                    value={formData.email || ''}
                                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                />
                            </FormField>
                            <FormField label="College" htmlFor="campus">
                                <FormInput
                                    id="campus"
                                    name="campus"
                                    placeholder="e.g., North Campus"
                                    value={formData.campus || ''}
                                    onChange={(e) => setFormData({ ...formData, campus: e.target.value })}
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Class" htmlFor="class">
                                <FormInput
                                    id="class"
                                    name="class"
                                    placeholder="e.g., MBA, BBA"
                                    value={formData.class || ''}
                                    onChange={(e) => setFormData({ ...formData, class: e.target.value })}
                                />
                            </FormField>
                            <FormField label="City" htmlFor="city">
                                <FormInput
                                    id="city"
                                    name="city"
                                    placeholder="e.g., New York"
                                    value={formData.city || ''}
                                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Lead Status" htmlFor="status">
                                <Select
                                    value={formData.status}
                                    onValueChange={(value: string) => setFormData({ ...formData, status: value })}
                                    disabled={leadStatusLoading}
                                >
                                    <SelectTrigger className="w-full h-11">
                                        <SelectValue placeholder="Select status" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {leadStatusOptions.map((opt: any) => (
                                            <SelectItem key={opt._id} value={opt.name}>
                                                <span className="inline-flex items-center">
                                                    <span className="inline-block w-3 h-3 rounded-full mr-2" style={{ backgroundColor: opt.color || '#e5e7eb' }}></span>
                                                    {opt.name}
                                                </span>
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </FormField>
                            <FormField label="Source" htmlFor="source">
                                <FormInput
                                    id="source"
                                    name="source"
                                    placeholder="e.g., Website, Referral, Campaign"
                                    value={formData.source || ''}
                                    onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                                />
                            </FormField>
                        </div>

                        <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                            <Button type="button" variant="outline" onClick={() => navigate('/leads')}>Cancel</Button>
                            <Button type="submit" variant="primary" disabled={loading}>
                                {loading ? 'Creating...' : 'Create Lead'}
                            </Button>
                        </div>
                    </form>
                </div>
            </Card>
        </div>
    );
};

export default LeadCreate;

