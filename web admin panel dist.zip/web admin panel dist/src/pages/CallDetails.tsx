import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { 
  UserIcon, 
  ClockIcon, 
  CalendarIcon, 
  PhoneIcon, 
  FileTextIcon, 
  CheckCircleIcon, 
  XCircleIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  SmartphoneIcon,
  GlobeIcon,
  MailIcon,
  InfoIcon,
  ArrowLeftIcon
} from 'lucide-react';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import Button from '../components/ui/Button';
import { useCallRecords } from '../hooks/useCallRecords';

const CallDetails: React.FC = () => {
  const { userId, callId } = useParams<{ userId: string; callId: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { data, loading, fetch } = useCallRecords();
  const [call, setCall] = useState<any>(null);

  // Get call data from location state (passed from UserCallRecords)
  const callDataFromState = location.state as { callData?: any } | null;

  useEffect(() => {
    // If call data is passed via location state, use it directly
    if (callDataFromState?.callData) {
      formatCallData(callDataFromState.callData);
      return;
    }

    // Otherwise, fetch from API
    const loadCall = async () => {
      if (userId && callId) {
        // Fetch call details
        await fetch({
          createdBy: userId,
          page: 1,
          limit: 1000,
        });
      }
    };
    loadCall();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId, callId, callDataFromState]);

  useEffect(() => {
    // Only fetch from API if we don't have data from state
    if (!callDataFromState?.callData && data?.results && callId) {
      // Find the specific call from the results
      const callRecords = data.results;
      const foundCall = callRecords.find((c: any) => c._id === callId || c.id === callId);
      if (foundCall) {
        formatCallData(foundCall);
      }
    }
  }, [data, callId, callDataFromState]);

  const formatCallData = (callData: any) => {
    // Use leadId firstName/lastName if contactName is null or "Unknown Contact"
    const leadFullName = callData.leadId && typeof callData.leadId === 'object' 
      ? `${callData.leadId.firstName || ''} ${callData.leadId.lastName || ''}`.trim() 
      : null;
    const contactName = callData.contactName || leadFullName || 'Unknown Contact';
    const userName = callData.createdBy?.name || 'Unknown User';
    const userEmail = callData.createdBy?.email || '';

    // Format duration
    const durationSeconds = callData.durationSeconds || 0;
    const formattedDuration = durationSeconds > 0
      ? `${Math.floor(durationSeconds / 60)}:${Math.floor(durationSeconds % 60).toString().padStart(2, '0')}`
      : '00:00';

    // Format dates
    const initiatedDate = callData.initiatedAt ? new Date(callData.initiatedAt) : null;
    const connectedDate = callData.connectedAt ? new Date(callData.connectedAt) : null;
    const endedDate = callData.endedAt ? new Date(callData.endedAt) : null;

    const formattedDateTime = initiatedDate ? initiatedDate.toLocaleDateString('en-GB') + ' ' + initiatedDate.toLocaleTimeString() : 'N/A';
    const formattedConnectedAt = connectedDate ? connectedDate.toLocaleDateString('en-GB') + ' ' + connectedDate.toLocaleTimeString() : 'N/A';
    const formattedEndedAt = endedDate ? endedDate.toLocaleDateString('en-GB') + ' ' + endedDate.toLocaleTimeString() : 'N/A';

    // Format status text
    const statusText = callData.statusText || callData.status.replace(/CALL_/g, '').replace(/_/g, ' ');

    setCall({
      id: callData._id || callData.id,
      studentName: contactName,
      userName: userName,
      userEmail: userEmail,
      phone: callData.phoneNumber,
      status: statusText,
      originalStatus: callData.status,
      duration: formattedDuration,
      durationSeconds: durationSeconds,
      dateTime: formattedDateTime,
      initiatedAt: formattedDateTime,
      connectedAt: formattedConnectedAt,
      endedAt: formattedEndedAt,
      isOutgoing: callData.isOutgoing !== undefined ? callData.isOutgoing : true,
      source: callData.source || 'Unknown',
      deviceInfo: callData.deviceInfo || 'Unknown',
      notes: callData.metadata?.notes || callData.notes || '',
      recordingUrl: callData.status.includes('CONNECTED') ? 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' : undefined,
      leadId: callData.leadId?._id || callData.leadId || null,
      leadName: callData.leadId && typeof callData.leadId === 'object' 
        ? `${callData.leadId.firstName || ''} ${callData.leadId.lastName || ''}`.trim() || null
        : null,
      leadPhone: callData.leadId?.phoneNumber || null,
    });
  };

  const getCallIcon = (isOutgoing: boolean | undefined, durationSeconds: number | undefined) => {
    const hasDuration = durationSeconds && durationSeconds > 0;
    const isOutgoingCall = isOutgoing !== undefined ? isOutgoing : true;
    
    if (hasDuration) {
      // Call was successful (has duration)
      if (isOutgoingCall) {
        return <ArrowUpIcon size={24} className="text-blue-600" />;
      } else {
        return <ArrowDownIcon size={24} className="text-green-600" />;
      }
    } else {
      // Call didn't connect (no duration)
      if (isOutgoingCall) {
        return <ArrowUpIcon size={24} className="text-gray-400" />;
      } else {
        return <ArrowDownIcon size={24} className="text-gray-400" />;
      }
    }
  };

  // Only show loading if we don't have data from state and are fetching
  if (loading && !callDataFromState?.callData) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            icon={<ArrowLeftIcon size={16} />}
            onClick={() => navigate(userId ? `/calls/${userId}` : '/calls')}
          >
            Back
          </Button>
          <h1 className="text-2xl font-semibold text-gray-900">Loading...</h1>
        </div>
      </div>
    );
  }

  if (!call) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            icon={<ArrowLeftIcon size={16} />}
            onClick={() => navigate(userId ? `/calls/${userId}` : '/calls')}
          >
            Back
          </Button>
          <h1 className="text-2xl font-semibold text-gray-900">Call Not Found</h1>
        </div>
        <Card>
          <div className="p-6 text-center">
            <p className="text-gray-500">The requested call could not be found.</p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button
          variant="outline"
          size="sm"
          icon={<ArrowLeftIcon size={16} />}
          onClick={() => navigate(userId ? `/calls/${userId}` : '/calls')}
        >
          Back
        </Button>
        <h1 className="text-2xl font-semibold text-gray-900">Call Details</h1>
      </div>

      {/* Header Section */}
      <Card>
        <div className="bg-gradient-to-br from-blue-50 via-blue-50 to-indigo-50 p-6 rounded-xl border border-blue-100">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-start space-x-4 flex-1">
              <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-md border-2 border-blue-200">
                {getCallIcon(call.isOutgoing, call.durationSeconds)}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-xl font-semibold text-gray-900 mb-1 truncate">
                  {call.studentName}
                </h3>
                <div className="flex items-center space-x-2 mt-2">
                  <div className="flex items-center text-sm text-gray-600">
                    <PhoneIcon size={14} className="mr-1.5" />
                    <span className="font-mono">{call.phone}</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="ml-4 flex items-center">
              {call.isOutgoing !== undefined && (
                <Badge 
                  variant={call.isOutgoing ? 'primary' : 'success'} 
                  size="sm"
                >
                  {call.isOutgoing ? (
                    <>
                      <ArrowUpIcon size={12} className="mr-1" />
                      Outgoing
                    </>
                  ) : (
                    <>
                      <ArrowDownIcon size={12} className="mr-1" />
                      Incoming
                    </>
                  )}
                </Badge>
              )}
            </div>
          </div>

          {/* Quick Info Grid */}
          <div className="grid grid-cols-2 gap-3 mt-4">
            <div className="bg-white rounded-lg p-3 border border-blue-100">
              <div className="flex items-center text-xs text-gray-500 mb-1">
                <ClockIcon size={14} className="mr-1.5" />
                Duration
              </div>
              <div className="text-sm font-semibold text-gray-900">
                {call.duration}
              </div>
            </div>
            <div className="bg-white rounded-lg p-3 border border-blue-100">
              <div className="flex items-center text-xs text-gray-500 mb-1">
                <CalendarIcon size={14} className="mr-1.5" />
                Call Time
              </div>
              <div className="text-sm font-semibold text-gray-900">
                {call.initiatedAt || call.dateTime}
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Caller Information */}
      <Card>
        <h4 className="text-sm font-semibold text-gray-900 mb-4 flex items-center">
          <UserIcon size={16} className="mr-2 text-blue-500" />
          Caller Information
        </h4>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Name</span>
            <span className="text-sm font-medium text-gray-900">{call.userName}</span>
          </div>
          {call.userEmail && (
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 flex items-center">
                <MailIcon size={14} className="mr-1.5" />
                Email
              </span>
              <span className="text-sm font-medium text-gray-900">{call.userEmail}</span>
            </div>
          )}
        </div>
      </Card>

      {/* Contact Information */}
      {(call.leadName || call.leadPhone) && (
        <Card>
          <h4 className="text-sm font-semibold text-gray-900 mb-4 flex items-center">
            <UserIcon size={16} className="mr-2 text-green-500" />
            Contact Information
          </h4>
          <div className="space-y-3">
            {call.leadName && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Lead Name</span>
                <span className="text-sm font-medium text-gray-900">{call.leadName}</span>
              </div>
            )}
            {call.leadPhone && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 flex items-center">
                  <PhoneIcon size={14} className="mr-1.5" />
                  Phone
                </span>
                <span className="text-sm font-medium text-gray-900 font-mono">{call.leadPhone}</span>
              </div>
            )}
          </div>
        </Card>
      )}

      {/* Call Timeline */}
      <Card>
        <h4 className="text-sm font-semibold text-gray-900 mb-4 flex items-center">
          <ClockIcon size={16} className="mr-2 text-purple-500" />
          Call Timeline
        </h4>
        <div className="space-y-3">
          <div className="flex items-center justify-between py-2 border-b border-gray-100">
            <span className="text-sm text-gray-600">Initiated</span>
            <span className="text-sm font-medium text-gray-900">{call.initiatedAt || call.dateTime}</span>
          </div>
          {call.connectedAt && call.connectedAt !== 'N/A' && (
            <div className="flex items-center justify-between py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600 flex items-center">
                <CheckCircleIcon size={14} className="mr-1.5 text-green-500" />
                Connected
              </span>
              <span className="text-sm font-medium text-gray-900">{call.connectedAt}</span>
            </div>
          )}
          {call.endedAt && call.endedAt !== 'N/A' && (
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-gray-600 flex items-center">
                <XCircleIcon size={14} className="mr-1.5 text-gray-500" />
                Ended
              </span>
              <span className="text-sm font-medium text-gray-900">{call.endedAt}</span>
            </div>
          )}
        </div>
      </Card>

      {/* Technical Details */}
      {(call.source || call.deviceInfo) && (
        <Card>
          <h4 className="text-sm font-semibold text-gray-900 mb-4 flex items-center">
            <InfoIcon size={16} className="mr-2 text-gray-500" />
            Technical Details
          </h4>
          <div className="space-y-3">
            {call.source && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 flex items-center">
                  <GlobeIcon size={14} className="mr-1.5" />
                  Source
                </span>
                <Badge variant="gray" size="sm">{call.source}</Badge>
              </div>
            )}
            {call.deviceInfo && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600 flex items-center">
                  <SmartphoneIcon size={14} className="mr-1.5" />
                  Device
                </span>
                <span className="text-sm font-medium text-gray-900">{call.deviceInfo}</span>
              </div>
            )}
          </div>
        </Card>
      )}

      {/* Call Recording */}
      {call.recordingUrl && (
        <Card>
          <h4 className="text-sm font-semibold text-gray-900 mb-4 flex items-center">
            <FileTextIcon size={16} className="mr-2 text-blue-500" />
            Call Recording
          </h4>
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <audio controls className="w-full">
              <source src={call.recordingUrl} type="audio/mpeg" />
              Your browser does not support the audio element.
            </audio>
          </div>
        </Card>
      )}
    </div>
  );
};

export default CallDetails;

