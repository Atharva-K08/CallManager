import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusIcon, EditIcon, TrashIcon, UserIcon, MailIcon, ShieldIcon, CheckCircleIcon, XCircleIcon, SearchIcon, KeyIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Table from '../components/ui/Table';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import Pagination from '../components/ui/Pagination';
import { TableSkeleton } from '../components/ui/Skeleton';
import ConfirmDialog from '../components/ui/ConfirmDialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { useUsers } from '../hooks/useUsers';
import { userService } from '../services/user.service';
import { User, UserFilters } from '../types/api.types';
import { Role } from '../types/roles';
import { getRoleDisplayName } from '../utils/roleUtils';
import { debounce } from '../utils/performance';
const UserManagement: React.FC = () => {
  const navigate = useNavigate();
  // API hooks
  const {
    users,
    pagination,
    usersLoading,
    deleteLoading,
    getUsers,
    deleteUser,
    activateUser,
    deactivateUser,
    searchUsers,
  } = useUsers();

  // Local state
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    role: 'all',
    isActive: 'all',
    sortBy: 'createdAt:desc',
  });
  // Table columns
  const columns = [
    {
      key: 'id',
      header: 'ID',
      width: 'w-1/12',
      render: (value: number) => <span className="text-sm text-gray-600">#{value}</span>
    },
    {
      key: 'name',
      header: 'Name',
      width: 'w-3/12',
      render: (value: string, item: User) => (
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
            <UserIcon size={16} className="text-blue-600" />
          </div>
          <div>
            <div className="font-medium text-gray-900">{value}</div>
            <div className="text-sm text-gray-500">{item.email}</div>
          </div>
        </div>
      )
    },
    {
      key: 'role',
      header: 'Role',
      width: 'w-2/12',
      render: (value: string) => {
        const role = value as Role;
        const variant = role === 'admin' ? 'primary' : role === 'superadmin' ? 'danger' : 'gray';
        return (
          <Badge variant={variant}>
            {getRoleDisplayName(role)}
          </Badge>
        );
      }
    },
    {
      key: 'isActive',
      header: 'Status',
      width: 'w-2/12',
      render: (value: boolean) => (
        <Badge variant={value ? 'success' : 'danger'}>
          {value ? 'Active' : 'Inactive'}
        </Badge>
      )
    },
    {
      key: 'createdAt',
      header: 'Created',
      width: 'w-2/12',
      render: (value: string) => (
        <span className="text-sm text-gray-600">
          {new Date(value).toLocaleDateString('en-GB')}
        </span>
      )
    },
    {
      key: 'actions',
      header: 'Actions',
      width: 'w-2/12',
      render: (_: any, item: User) => (
        <div className="flex space-x-1">
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleEditUser(item);
            }}
            className="p-1.5 rounded-full text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition-colors"
            title="Edit User"
          >
            <EditIcon size={16} />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleChangePassword(item);
            }}
            className="p-1.5 rounded-full text-purple-600 hover:text-purple-800 hover:bg-purple-50 transition-colors"
            title="Change Password"
          >
            <KeyIcon size={16} />
          </button>
          <button
            onClick={async (e) => {
              e.stopPropagation();
              console.log('Toggle status clicked for user:', item);
              await handleToggleStatus(item);
            }}
            className={`p-1.5 rounded-full transition-colors ${item.isActive
              ? 'text-orange-600 hover:text-orange-800 hover:bg-orange-50'
              : 'text-green-600 hover:text-green-800 hover:bg-green-50'
              }`}
            title={item.isActive ? 'Deactivate User' : 'Activate User'}
          >
            {item.isActive ? <XCircleIcon size={16} /> : <CheckCircleIcon size={16} />}
          </button>
          {/* <button
            onClick={(e) => {
              e.stopPropagation();
              console.log('Delete confirmation clicked for user:', item);
              handleDeleteConfirmation(item);
            }}
            className="p-1.5 rounded-full text-red-600 hover:text-red-800 hover:bg-red-50 transition-colors"
            title="Delete User"
          >
            <TrashIcon size={16} />
          </button> */}
        </div>
      )
    }
  ];
  // Initialize data
  useEffect(() => {
    getUsers();
  }, []);

  // Helper function to convert filters to API format
  const convertFiltersToApi = (localFilters: typeof filters): UserFilters => {
    const api: any = {};
    
    // Only add role if it's not 'all'
    if (localFilters.role && localFilters.role !== 'all') {
      api.role = localFilters.role as 'user' | 'admin' | 'superadmin';
    }
    
    // Only add isActive if it's not 'all'
    if (localFilters.isActive && localFilters.isActive !== 'all') {
      api.isActive = localFilters.isActive === 'true' ? true : localFilters.isActive === 'false' ? false : undefined;
    }
    
    // Only add search if it has a value
    if (localFilters.search && localFilters.search.trim()) {
      api.search = localFilters.search.trim();
    }
    
    return api;
  };

  // Debounced search
  const debouncedSearch = debounce((query: string) => {
    const apiFilters = convertFiltersToApi(filters);

    if (query.trim()) {
      searchUsers({ query, ...apiFilters });
    } else {
      getUsers(apiFilters);
    }
  }, 500);

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    debouncedSearch(query);
  };

  // Handle filter change
  const handleFilterChange = (key: string, value: string) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);

    const apiFilters = convertFiltersToApi(newFilters);
    getUsers(apiFilters);
  };

  // Handle pagination
  const handlePageChange = (page: number) => {
    const apiFilters = convertFiltersToApi(filters);
    getUsers({ ...apiFilters, page });
  };

  const handlePerPageChange = (perPage: number) => {
    const apiFilters = convertFiltersToApi(filters);
    getUsers({ ...apiFilters, per_page: perPage, page: 1 });
  };

  const handleAddUser = () => {
    navigate('/users/create');
  };

  const handleEditUser = (user: User) => {
    navigate(`/users/${user._id || user.id}/update`);
  };

  const handleToggleStatus = async (user: User) => {
    const userId = user._id || user.id;
    if (userId) {
      try {
        if (user.isActive) {
          await deactivateUser(userId);
        } else {
          await activateUser(userId);
        }
      } catch (error) {
        console.error('Error toggling user status:', error);
      }
    }
  };

  const handleDeleteConfirmation = (user: User) => {
    setUserToDelete(user);
    setIsConfirmDialogOpen(true);
  };

  const handleChangePassword = (user: User) => {
    navigate(`/users/${user._id || user.id}/password`);
  };


  const handleDeleteUser = async () => {
    if (userToDelete) {
      const userId = userToDelete._id || userToDelete.id;
      if (userId) {
        try {
          await deleteUser(userId);
          setIsConfirmDialogOpen(false);
          setUserToDelete(null);
        } catch (error) {
          console.error('Error deleting user:', error);
        }
      }
    }
  };
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">
            User Management
          </h1>
        </div>
        <Button
          variant="primary"
          onClick={handleAddUser}
          icon={<PlusIcon size={16} />}
        >
          Add New User
        </Button>
      </div>

      {/* Filters and Search */}
      <Card>
        <div className="p-3">
          <div className="space-y-2">
            {/* Search and Filters - single row on md+ */}
            <div className="flex flex-col md:flex-row md:items-end gap-3">
              {/* Search - flexible width */}
              <div className="md:flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Search Users
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <SearchIcon size={18} className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search by name, email, or phone..."
                    value={searchQuery}
                    onChange={handleSearchChange}
                    className="block w-full pl-10 pr-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400"
                  />
                </div>
              </div>

              {/* Role Filter */}
              {/* <div className="lg:col-span-3">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Role
                </label>
                <Select value={filters.role} onValueChange={(value: string) => handleFilterChange('role', value)}>
                  <SelectTrigger className="w-full">
                    <div className="flex items-center">
                      <ShieldIcon size={18} className="text-gray-400 mr-2" />
                      <SelectValue placeholder="All Roles" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    {ROLE_FILTER_OPTIONS.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div> */}

              {/* Status Filter */}
              <div className="md:w-56">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Status
                </label>
                <Select value={filters.isActive} onValueChange={(value: string) => handleFilterChange('isActive', value)}>
                  <SelectTrigger className="w-full h-11">
                    <div className="flex items-center">
                      <SelectValue placeholder="All Status" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="true">Active</SelectItem>
                    <SelectItem value="false">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Users Table */}
      <Card>
        {usersLoading ? (
          <div className="p-6">
            <TableSkeleton rows={5} columns={6} />
          </div>
        ) : (
          <>
            <Table columns={columns} data={users} />
            {pagination.total_pages > 1 && (
              <div className="p-6 border-t border-gray-200">
                <Pagination
                  currentPage={pagination.current_page}
                  totalPages={pagination.total_pages}
                  totalItems={pagination.total_items}
                  perPage={pagination.per_page}
                  onPageChange={handlePageChange}
                  onPerPageChange={handlePerPageChange}
                />
              </div>
            )}
          </>
        )}
      </Card>
      {/* Confirm Delete Dialog */}
      <ConfirmDialog
        isOpen={isConfirmDialogOpen}
        onClose={() => setIsConfirmDialogOpen(false)}
        onConfirm={handleDeleteUser}
        title="Delete User"
        message={`Are you sure you want to delete ${userToDelete?.name}? This action cannot be undone.`}
        confirmText={deleteLoading ? 'Deleting...' : 'Delete'}
        type="danger"
      />
    </div>
  );
};
export default UserManagement;