import React, { useEffect, useMemo, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusIcon, SearchIcon, EditIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Table from '../components/ui/Table';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import FormInput from '../components/ui/FormInput';
import Pagination from '../components/ui/Pagination';
import { TableSkeleton } from '../components/ui/Skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { debounce } from '../utils/performance';
import { useLeads } from '../hooks/useLeads';
import { useLeadStatus } from '../hooks/useLeadStatus';

// Utility function to sanitize phone number to last 10 digits
const sanitizePhoneNumber = (phoneNumber: string): string => {
    if (!phoneNumber) return '';
    // Remove all non-digit characters
    const digitsOnly = phoneNumber.replace(/\D/g, '');
    // Return last 10 digits
    return digitsOnly.slice(-10);
};

const LeadsManagement: React.FC = () => {
    const navigate = useNavigate();
    const {
        data,
        fetch,
        loading,
    } = useLeads();

    const leads = data?.results || [];
    const pagination = useMemo(() => ({
        current_page: data?.page || 1,
        total_pages: data?.totalPages || 1,
        total_items: data?.totalResults || 0,
        per_page: data?.limit || 10,
    }), [data]);

    const [searchQuery, setSearchQuery] = useState('');
    const [showFilters, setShowFilters] = useState<boolean>(false);
    const [dateFilterMode, setDateFilterMode] = useState<'single' | 'range'>('single');
    const [filters, setFilters] = useState({
        leadStatus: 'all',
        // callStatus: 'all',
        sortBy: 'createdAt:desc',
        assigned: undefined as boolean | undefined,
        city: '',
        campus: '',
        class: '',
        createdAtFrom: '',
        createdAtTo: '',
        createdAt: '', // For single date mode
    });

    // Load lead statuses from DB for form selects
    const {
        data: leadStatusData,
        fetch: fetchLeadStatuses,
        loading: leadStatusLoading,
    } = useLeadStatus();

    useEffect(() => {
        // Fetch active lead status options (both types)
        fetchLeadStatuses({ page: 1, limit: 100, sortBy: 'order:asc' });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const leadStatusOptions = useMemo(
        () => (leadStatusData?.results || []).filter((s: any) => s.type === 'leadStatus' && s.isActive),
        [leadStatusData]
    );
    // const callStatusOptions = useMemo(
    //     () => (leadStatusData?.results || []).filter((s: any) => s.type === 'callStatus' && s.isActive),
    //     [leadStatusData]
    // );

    const statusColorMap = useMemo(() => {
        const map: Record<string, string> = {};
        (leadStatusOptions || []).forEach((s: any) => { if (s?.name) map[s.name] = s.color || '#e5e7eb'; });
        return map;
    }, [leadStatusOptions]);
    // const callStatusColorMap = useMemo(() => {
    //     const map: Record<string, string> = {};
    //     (callStatusOptions || []).forEach((s: any) => { if (s?.name) map[s.name] = s.color || '#e5e7eb'; });
    //     return map;
    // }, [callStatusOptions]);

    const hexToRgba = (hex: string, alpha = 1): string => {
        const sanitized = hex.replace('#', '');
        const bigint = parseInt(sanitized.length === 3 ? sanitized.split('').map((c) => c + c).join('') : sanitized, 16);
        const r = (bigint >> 16) & 255;
        const g = (bigint >> 8) & 255;
        const b = bigint & 255;
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    };

    const columns = [
        {
            key: 'name', header: 'Name', width: 'w-2/12', render: (_: any, item: any) => (
                <span className="text-sm text-gray-900">{`${item.firstName || ''} ${item.lastName || ''}`.trim() || 'Unknown'}</span>
            )
        },
        { key: 'phoneNumber', header: 'Phone', width: 'w-2/12' },
        {
            key: 'status', header: 'Status', width: 'w-2/12', render: (value: string) => {
                const base = statusColorMap[value] || '#9ca3af';
                const bg = hexToRgba(base, 0.15);
                return (
                    <span
                        className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium"
                        style={{ backgroundColor: bg, color: base }}
                    >
                        {value}
                    </span>
                );
            }
        },
        {
            key: 'city', header: 'City', width: 'w-1/12', render: (value: string) => (
                <span className="text-sm text-gray-600">{value || '—'}</span>
            )
        },
        {
            key: 'campus', header: 'College', width: 'w-2/12', render: (value: string) => (
                <span className="text-sm text-gray-600">{value || '—'}</span>
            )
        },
        {
            key: 'class', header: 'Class', width: 'w-1/12', render: (value: string) => (
                <span className="text-sm text-gray-600">{value || '—'}</span>
            )
        },
        {
            key: 'createdAt', header: 'Created', width: 'w-2/12', render: (value: string) => (
                <span className="text-sm text-gray-600">{new Date(value).toLocaleDateString('en-GB')}</span>
            )
        },
        {
            key: 'actions', header: 'Actions', width: 'w-1/12', render: (_: any, item: any) => (
                <div className="flex space-x-1 justify-center">
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            handleEditLead(item);
                        }}
                        className="p-1.5 rounded-full text-blue-600 hover:text-blue-800 hover:bg-blue-50 transition-colors"
                        title="Edit Lead"
                    >
                        <EditIcon size={16} />
                    </button>
                </div>
            )
        }
    ];

    useEffect(() => {
        const api = convertFiltersToApi(filters);
        fetch({ ...api, page: 1, limit: 10 });
    }, []);

    // Helper function to convert date to UTC start of day
    const getStartOfDayUTC = (dateString: string): string => {
        if (!dateString) return '';
        // Create date in local timezone at start of day
        const localDate = new Date(dateString + 'T00:00:00');
        // Convert to ISO string (UTC)
        return localDate.toISOString();
    };

    // Helper function to convert date to UTC end of day
    const getEndOfDayUTC = (dateString: string): string => {
        if (!dateString) return '';
        // Create date in local timezone at end of day
        const localDate = new Date(dateString + 'T23:59:59.999');
        // Convert to ISO string (UTC)
        return localDate.toISOString();
    };

    const convertFiltersToApi = (local: typeof filters) => {
        const api: any = {
            sortBy: local.sortBy,
        };
        
        console.log('[LeadsManagement] convertFiltersToApi - Input filters:', local);
        
        // Only add status if it's not 'all'
        if (local.leadStatus && local.leadStatus !== 'all') {
            api.status = local.leadStatus;
            console.log('[LeadsManagement] Adding status filter:', local.leadStatus);
        }
        
        // Only add assigned if it's explicitly set (not undefined)
        if (local.assigned !== undefined) {
            api.assigned = local.assigned;
            console.log('[LeadsManagement] Adding assigned filter:', local.assigned);
        }
        
        // Add advanced filters only if they have values
        if (local.city && local.city.trim()) {
            api.city = local.city.trim();
            console.log('[LeadsManagement] Adding city filter:', local.city.trim());
        }
        if (local.campus && local.campus.trim()) {
            api.campus = local.campus.trim();
            console.log('[LeadsManagement] Adding campus filter:', local.campus.trim());
        }
        if (local.class && local.class.trim()) {
            api.class = local.class.trim();
            console.log('[LeadsManagement] Adding class filter:', local.class.trim());
        }
        
        // Handle date filters based on mode
        if (dateFilterMode === 'single') {
            if (local.createdAt && local.createdAt.trim()) {
                // Single date: use same date for both from and to
                const startUTC = getStartOfDayUTC(local.createdAt);
                const endUTC = getEndOfDayUTC(local.createdAt);
                api.createdAtFrom = startUTC;
                api.createdAtTo = endUTC;
                console.log('[LeadsManagement] Adding single date filter:', { createdAt: local.createdAt, startUTC, endUTC });
            }
        } else {
            // Range mode - only add if values exist
            if (local.createdAtFrom && local.createdAtFrom.trim()) {
                api.createdAtFrom = getStartOfDayUTC(local.createdAtFrom);
                console.log('[LeadsManagement] Adding dateFrom filter:', local.createdAtFrom.trim());
            }
            if (local.createdAtTo && local.createdAtTo.trim()) {
                api.createdAtTo = getEndOfDayUTC(local.createdAtTo);
                console.log('[LeadsManagement] Adding dateTo filter:', local.createdAtTo.trim());
            }
        }
        
        console.log('[LeadsManagement] convertFiltersToApi - Output params:', api);
        return api;
    };

    const debouncedSearch = debounce((query: string) => {
        const api = convertFiltersToApi(filters);
        fetch({ ...api, search: query, page: 1 });
    }, 500);

    // Debounced filter update for text fields (city, campus, class)
    // Using useMemo to ensure the debounced function is stable
    const debouncedFilterUpdate = useMemo(
        () => debounce((updatedFilters: typeof filters) => {
            const api = convertFiltersToApi(updatedFilters);
            console.log('[LeadsManagement] debouncedFilterUpdate - Calling fetch with params:', api);
            fetch({ ...api, page: 1 });
        }, 500),
        // eslint-disable-next-line react-hooks/exhaustive-deps
        []
    );

    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const q = e.target.value;
        setSearchQuery(q);
        debouncedSearch(q);
    };

    const handleFilterChange = (key: keyof typeof filters, value: string | boolean) => {
        console.log('[LeadsManagement] handleFilterChange - Key:', key, 'Value:', value, 'Type:', typeof value);
        const nf = { ...filters, [key]: value };
        console.log('[LeadsManagement] handleFilterChange - Previous filters:', filters);
        console.log('[LeadsManagement] handleFilterChange - Updated filters:', nf);
        setFilters(nf);
        const api = convertFiltersToApi(nf);
        console.log('[LeadsManagement] handleFilterChange - Calling fetch with params:', api);
        fetch({ ...api, page: 1 });
    };

    const handleAssignedChange = (value: string) => {
        if (value === 'all') {
            handleFilterChange('assigned', undefined);
        } else {
            handleFilterChange('assigned', value === 'assigned');
        }
    };

    // Clear advanced filters
    const handleClearFilters = () => {
        console.log('[LeadsManagement] handleClearFilters - Clearing all filters');
        const clearedFilters = {
            ...filters,
            city: '',
            campus: '',
            class: '',
            createdAtFrom: '',
            createdAtTo: '',
            createdAt: '',
        };
        console.log('[LeadsManagement] handleClearFilters - Previous filters:', filters);
        console.log('[LeadsManagement] handleClearFilters - Cleared filters:', clearedFilters);
        
        setFilters(clearedFilters);
        
        // Build API params with cleared filters
        const api: any = {
            sortBy: filters.sortBy,
        };
        
        // Only add status if it's not 'all'
        if (filters.leadStatus && filters.leadStatus !== 'all') {
            api.status = filters.leadStatus;
        }
        
        // Only add assigned if it's explicitly set
        if (filters.assigned !== undefined) {
            api.assigned = filters.assigned;
        }
        
        // No other filters since they're all cleared
        console.log('[LeadsManagement] handleClearFilters - Final API params:', api);
        fetch({ ...api, page: 1 });
    };

    // Check if any advanced filters are active
    const hasActiveFilters = useMemo(() => {
        return !!(
            filters.city ||
            filters.campus ||
            filters.class ||
            filters.createdAtFrom ||
            filters.createdAtTo ||
            filters.createdAt
        );
    }, [filters]);

    const handlePageChange = (page: number) => {
        const api = convertFiltersToApi(filters);
        fetch({ ...api, page });
    };

    const handlePerPageChange = (perPage: number) => {
        const api = convertFiltersToApi(filters);
        fetch({ ...api, limit: perPage, page: 1 });
    };

    const handleAddLead = () => {
        navigate('/leads/create');
    };

    const handleEditLead = (lead: any) => {
        navigate(`/leads/${lead._id}/update`);
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-2xl font-semibold text-gray-900">Leads Management</h1>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" onClick={() => navigate('/leads/import')}>Import</Button>
                    <Button variant="primary" onClick={handleAddLead} icon={<PlusIcon size={16} />}>
                        Add New Lead
                    </Button>
                </div>
            </div>

            <Card>
                <div className="p-3 space-y-4">
                    {/* Basic Filters */}
                    <div className="flex flex-col md:flex-row md:items-end gap-3">
                        <div className="md:flex-1">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Search Leads</label>
                            <div className="relative">
                                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <SearchIcon size={18} className="text-gray-400" />
                                </div>
                                <input
                                    type="text"
                                    placeholder="Search by first name, last name, phone, email..."
                                    value={searchQuery}
                                    onChange={handleSearchChange}
                                    className="block w-full pl-10 pr-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400"
                                />
                            </div>
                        </div>
                        <div className="md:w-56">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Lead Status</label>
                            <Select value={filters.leadStatus} onValueChange={(v: string) => handleFilterChange('leadStatus', v)}>
                                <SelectTrigger className="w-full h-11"><SelectValue placeholder="All" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All</SelectItem>
                                    {leadStatusOptions.map((opt: any) => (
                                        <SelectItem key={opt._id} value={opt.name}>{opt.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="md:w-56">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Assigned Status</label>
                            <Select
                                value={filters.assigned === undefined ? 'all' : filters.assigned ? 'assigned' : 'unassigned'}
                                onValueChange={handleAssignedChange}
                            >
                                <SelectTrigger className="w-full h-11">
                                    <SelectValue placeholder="All" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All</SelectItem>
                                    <SelectItem value="assigned">Assigned</SelectItem>
                                    <SelectItem value="unassigned">Unassigned</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        {/* <div className="md:w-56">
                            <label className="block text-sm font-medium text-gray-700 mb-2">Call Status</label>
                            <Select value={filters.callStatus} onValueChange={(v: string) => handleFilterChange('callStatus', v)}>
                                <SelectTrigger className="w-full h-11"><SelectValue placeholder="All" /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All</SelectItem>
                                    {callStatusOptions.map((opt: any) => (
                                        <SelectItem key={opt._id} value={opt.name}>{opt.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div> */}
                    </div>

                    {/* Advanced Filters Section */}
                    <div className="border-t pt-4">
                        <button
                            type="button"
                            onClick={() => setShowFilters(!showFilters)}
                            className="w-full flex items-center justify-between p-2.5 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors bg-white"
                        >
                            <span className="text-sm font-medium text-gray-700">
                                Advanced Filters
                                {hasActiveFilters && (
                                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                        Active
                                    </span>
                                )}
                            </span>
                            <span className="text-gray-500">
                                {showFilters ? '−' : '+'}
                            </span>
                        </button>

                        {showFilters && (
                            <div className="pt-4 space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <FormField label="City" htmlFor="filter-city">
                                        <FormInput
                                            id="filter-city"
                                            type="text"
                                            placeholder="Filter by city"
                                            value={filters.city}
                                            onChange={(e) => {
                                                const newValue = e.target.value;
                                                const updatedFilters = { ...filters, city: newValue };
                                                setFilters(updatedFilters);
                                                debouncedFilterUpdate(updatedFilters);
                                            }}
                                        />
                                    </FormField>

                                    <FormField label="College" htmlFor="filter-campus">
                                        <FormInput
                                            id="filter-campus"
                                            type="text"
                                            placeholder="Filter by campus"
                                            value={filters.campus}
                                            onChange={(e) => {
                                                const newValue = e.target.value;
                                                const updatedFilters = { ...filters, campus: newValue };
                                                setFilters(updatedFilters);
                                                debouncedFilterUpdate(updatedFilters);
                                            }}
                                        />
                                    </FormField>

                                    <FormField label="Class" htmlFor="filter-class">
                                        <FormInput
                                            id="filter-class"
                                            type="text"
                                            placeholder="Filter by class"
                                            value={filters.class}
                                            onChange={(e) => {
                                                const newValue = e.target.value;
                                                const updatedFilters = { ...filters, class: newValue };
                                                setFilters(updatedFilters);
                                                debouncedFilterUpdate(updatedFilters);
                                            }}
                                        />
                                    </FormField>
                                </div>

                                {/* Date Filter Section */}
                                <div className="space-y-3">
                                    <div className="flex items-center justify-between">
                                        <label className="block text-sm font-medium text-gray-700">Created Date</label>
                                        <div className="flex items-center gap-2">
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    setDateFilterMode('single');
                                                    // Clear range dates when switching to single
                                                    setFilters(prev => ({ ...prev, createdAtFrom: '', createdAtTo: '' }));
                                                }}
                                                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                                                    dateFilterMode === 'single'
                                                        ? 'bg-blue-100 text-blue-700 border border-blue-300'
                                                        : 'bg-gray-100 text-gray-600 border border-gray-300 hover:bg-gray-200'
                                                }`}
                                            >
                                                Single Date
                                            </button>
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    setDateFilterMode('range');
                                                    // Clear single date when switching to range
                                                    setFilters(prev => ({ ...prev, createdAt: '' }));
                                                }}
                                                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                                                    dateFilterMode === 'range'
                                                        ? 'bg-blue-100 text-blue-700 border border-blue-300'
                                                        : 'bg-gray-100 text-gray-600 border border-gray-300 hover:bg-gray-200'
                                                }`}
                                            >
                                                Date Range
                                            </button>
                                        </div>
                                    </div>

                                    {/* Fixed height container to prevent layout shift */}
                                    <div className="h-[82px]">
                                        {dateFilterMode === 'single' ? (
                                            <FormField label="Select Date" htmlFor="filter-date-single" className="mb-0">
                                                <input
                                                    id="filter-date-single"
                                                    type="date"
                                                    lang="en-GB"
                                                    value={filters.createdAt}
                                                    onClick={(e) => {
                                                        e.currentTarget.showPicker?.();
                                                    }}
                                                    onChange={(e) => {
                                                        const newValue = e.target.value;
                                                        const updatedFilters = { ...filters, createdAt: newValue };
                                                        setFilters(updatedFilters);
                                                        const api = convertFiltersToApi(updatedFilters);
                                                        console.log('[LeadsManagement] CreatedAt filter onChange - Calling fetch with params:', api);
                                                            fetch({ ...api, page: 1 });
                                                    }}
                                                    className="block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 cursor-pointer"
                                                />
                                            </FormField>
                                        ) : (
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                <FormField label="From" htmlFor="filter-date-from" className="mb-0">
                                                    <input
                                                        id="filter-date-from"
                                                        type="date"
                                                        lang="en-GB"
                                                        value={filters.createdAtFrom}
                                                        onClick={(e) => {
                                                            e.currentTarget.showPicker?.();
                                                        }}
                                                        onChange={(e) => {
                                                            const newValue = e.target.value;
                                                            const updatedFilters = { ...filters, createdAtFrom: newValue };
                                                            setFilters(updatedFilters);
                                                            const api = convertFiltersToApi(updatedFilters);
                                                            console.log('[LeadsManagement] CreatedAtFrom filter onChange - Calling fetch with params:', api);
                                                            fetch({ ...api, page: 1 });
                                                        }}
                                                        className="block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 cursor-pointer"
                                                    />
                                                </FormField>

                                                <FormField label="To" htmlFor="filter-date-to" className="mb-0">
                                                    <input
                                                        id="filter-date-to"
                                                        type="date"
                                                        lang="en-GB"
                                                        value={filters.createdAtTo}
                                                        onClick={(e) => {
                                                            e.currentTarget.showPicker?.();
                                                        }}
                                                        onChange={(e) => {
                                                            const newValue = e.target.value;
                                                            const updatedFilters = { ...filters, createdAtTo: newValue };
                                                            setFilters(updatedFilters);
                                                            const api = convertFiltersToApi(updatedFilters);
                                                            console.log('[LeadsManagement] CreatedAtTo filter onChange - Calling fetch with params:', api);
                                                            fetch({ ...api, page: 1 });
                                                        }}
                                                        className="block w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 cursor-pointer"
                                                    />
                                                </FormField>
                                            </div>
                                        )}
                                    </div>
                                </div>

                                {hasActiveFilters && (
                                    <div className="flex justify-end pt-2">
                                        <Button
                                            variant="outline"
                                            type="button"
                                            onClick={handleClearFilters}
                                        >
                                            Clear Filters
                                        </Button>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </Card>

            <Card>
                {loading ? (
                    <div className="p-6"><TableSkeleton rows={5} columns={6} /></div>
                ) : (
                    <>
                        <Table columns={columns} data={leads} />
                        {pagination.total_pages > 1 && (
                            <div className="p-6 border-t border-gray-200">
                                <Pagination
                                    currentPage={pagination.current_page}
                                    totalPages={pagination.total_pages}
                                    totalItems={pagination.total_items}
                                    perPage={pagination.per_page}
                                    onPageChange={handlePageChange}
                                    onPerPageChange={handlePerPageChange}
                                />
                            </div>
                        )}
                    </>
                )}
            </Card>
        </div>
    );
};

export default LeadsManagement;


