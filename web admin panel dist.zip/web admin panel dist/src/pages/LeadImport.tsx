import React, { useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeftIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Table from '../components/ui/Table';
import leadService from '../services/lead.service';
import { useToastNotifications } from '../lib/toast';

const LeadImport: React.FC = () => {
    const navigate = useNavigate();
    const { showSuccess, showErrorWithDetails } = useToastNotifications();

    const [uploading, setUploading] = useState(false);
    const [confirming, setConfirming] = useState(false);
    const [preview, setPreview] = useState<{ totalRows: number; validCount: number; invalidCount: number; validRows: any[]; invalidRows: any[] } | null>(null);
    const [file, setFile] = useState<File | null>(null);
    const [dragOver, setDragOver] = useState(false);
    const inputRef = useRef<HTMLInputElement | null>(null);

    const validColumns = useMemo(() => ([
        { key: 'firstName', header: 'First Name' },
        { key: 'lastName', header: 'Last Name' },
        { key: 'phoneNumber', header: 'Phone' },
        { key: 'email', header: 'Email' },
        { key: 'campus', header: 'College' },
        { key: 'class', header: 'Class' },
        { key: 'city', header: 'City' },
        { key: 'source', header: 'Source' },
    ]), []);

    const invalidColumns = useMemo(() => ([
        { key: 'rowNumber', header: 'Row' },
        { key: 'data.firstName', header: 'First Name', render: (_: any, row: any) => row?.data?.firstName },
        { key: 'data.lastName', header: 'Last Name', render: (_: any, row: any) => row?.data?.lastName },
        { key: 'data.phoneNumber', header: 'Phone', render: (_: any, row: any) => row?.data?.phoneNumber },
        { key: 'errors', header: 'Errors', render: (value: string[]) => (Array.isArray(value) ? value.join('; ') : '') },
    ]), []);

    const handleDownloadValid = async () => {
        if (!preview) return;
        const rows = preview.validRows || [];
        const XLSX = await import('xlsx');
        const worksheet = XLSX.utils.json_to_sheet(rows, {
            header: ['firstName', 'lastName', 'phoneNumber', 'email', 'campus', 'class', 'city', 'source']
        });
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Valid Leads');
        const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'valid_leads.xlsx';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const handleDownloadInvalid = async () => {
        if (!preview) return;
        const rows = (preview.invalidRows || []).map((r: any) => ({
            row: r.rowNumber,
            firstName: r?.data?.firstName,
            lastName: r?.data?.lastName,
            phoneNumber: r?.data?.phoneNumber,
            email: r?.data?.email,
            campus: r?.data?.campus,
            class: r?.data?.class,
            city: r?.data?.city,
            source: r?.data?.source,
            errors: Array.isArray(r.errors) ? r.errors.join('; ') : ''
        }));
        const XLSX = await import('xlsx');
        const worksheet = XLSX.utils.json_to_sheet(rows, { header: ['row', 'firstName', 'lastName', 'phoneNumber', 'email', 'campus', 'class', 'city', 'source', 'errors'] });
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Invalid Leads');
        const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'invalid_leads.xlsx';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const handleDownloadTemplate = async () => {
        await leadService.downloadImportTemplate();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const f = e.target.files?.[0] || null;
        setFile(f);
    };

    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setDragOver(false);
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            const f = e.dataTransfer.files[0];
            if (f && (f.name.endsWith('.xlsx') || f.name.endsWith('.xls'))) {
                setFile(f);
            }
            e.dataTransfer.clearData();
        }
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setDragOver(true);
    };

    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setDragOver(false);
    };

    const handlePreview = async () => {
        if (!file) return;
        setUploading(true);
        try {
            const rep = await leadService.previewImport(file);
            setPreview(rep);
        } catch (error: any) {
            showErrorWithDetails('Failed to preview import', error?.message);
        } finally {
            setUploading(false);
        }
    };

    const handleConfirm = async () => {
        if (!preview) return;
        setConfirming(true);
        try {
            const result = await leadService.confirmImport(preview.validRows || []);
            showSuccess(`Successfully imported ${result.imported} leads`);
            navigate('/leads');
        } catch (error: any) {
            showErrorWithDetails('Failed to import leads', error?.message);
        } finally {
            setConfirming(false);
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={() => navigate('/leads')} icon={<ArrowLeftIcon size={16} />}>
                    Back
                </Button>
                <h1 className="text-2xl font-semibold text-gray-900">Import Leads</h1>
            </div>

            {!preview && (
                <Card>
                    <div className="p-6">
                        <div
                            className={`p-8 border-2 border-dashed rounded-lg text-center transition-colors ${dragOver ? 'border-blue-500 bg-blue-50' : 'border-gray-300 bg-white'}`}
                            onDrop={handleDrop}
                            onDragOver={handleDragOver}
                            onDragLeave={handleDragLeave}
                            onClick={() => inputRef.current?.click()}
                            role="button"
                            aria-label="Upload file dropzone"
                        >
                            <input
                                ref={inputRef}
                                type="file"
                                accept=".xlsx,.xls"
                                className="hidden"
                                onChange={handleFileChange}
                            />
                            <div className="flex flex-col items-center justify-center gap-2">
                                <div className="text-lg font-medium">Drag and drop your Excel file here</div>
                                <div className="text-sm text-gray-500">or</div>
                                <Button variant="primary">Choose File</Button>
                                <div className="text-xs text-gray-500 mt-1">Accepted: .xlsx, .xls</div>
                                {file && (
                                    <div className="text-sm text-gray-700 mt-2">Selected: <span className="font-medium">{file.name}</span></div>
                                )}
                                <div className="mt-4 flex gap-2">
                                    <Button variant="outline" onClick={(e) => { e.stopPropagation(); handleDownloadTemplate(); }}>Download Template</Button>
                                    <Button variant="secondary" onClick={(e) => { e.stopPropagation(); if (file) handlePreview(); }} disabled={!file || uploading}>{uploading ? 'Validating...' : 'Upload & Preview'}</Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </Card>
            )}

            {preview && (
                <>
                    <Card>
                        <div className="p-6">
                            <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center gap-2">
                                    <span className="text-sm font-medium text-gray-700">Total:</span>
                                    <span className="text-sm font-semibold">{preview.totalRows}</span>
                                    <span className="text-sm text-gray-400">|</span>
                                    <span className="text-sm font-medium text-green-600">Valid:</span>
                                    <span className="text-sm font-semibold text-green-600">{preview.validCount}</span>
                                    <span className="text-sm text-gray-400">|</span>
                                    <span className="text-sm font-medium text-red-600">Invalid:</span>
                                    <span className="text-sm font-semibold text-red-600">{preview.invalidCount}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Button variant="outline" size="sm" onClick={handleDownloadTemplate}>Template</Button>
                                    <Button
                                        variant="secondary"
                                        size="sm"
                                        onClick={() => { setPreview(null); setFile(null); }}
                                    >
                                        Cancel
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </Card>

                    {preview.validCount > 0 && (
                        <Card>
                            <div className="p-6">
                                <div className="flex items-center justify-between mb-4">
                                    <h3 className="text-lg font-semibold text-gray-900">Valid Rows</h3>
                                    <Button variant="outline" size="sm" onClick={handleDownloadValid}>Download (.xlsx)</Button>
                                </div>
                                <div className="overflow-x-auto">
                                    <Table columns={validColumns} data={preview.validRows} />
                                </div>
                            </div>
                        </Card>
                    )}

                    {preview.invalidCount > 0 && (
                        <Card>
                            <div className="p-6">
                                <div className="flex items-center justify-between mb-4">
                                    <h3 className="text-lg font-semibold text-gray-900">Invalid Rows</h3>
                                    <Button variant="outline" size="sm" onClick={handleDownloadInvalid}>Download (.xlsx)</Button>
                                </div>
                                <div className="overflow-x-auto">
                                    <Table columns={invalidColumns as any} data={preview.invalidRows} />
                                </div>
                            </div>
                        </Card>
                    )}

                    <Card>
                        <div className="p-6">
                            <div className="flex justify-end">
                                <Button variant="primary" onClick={handleConfirm} disabled={confirming || (preview.validCount || 0) === 0}>
                                    {confirming ? 'Importing...' : 'Confirm Import'}
                                </Button>
                            </div>
                        </div>
                    </Card>
                </>
            )}
        </div>
    );
};

export default LeadImport;

