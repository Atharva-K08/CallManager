import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeftIcon, UserIcon, MailIcon, ShieldIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import FormInput from '../components/ui/FormInput';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { useUsers } from '../hooks/useUsers';
import { UpdateUserRequest } from '../types/api.types';
import { ROLES } from '../types/roles';
import { userService } from '../services/user.service';
import { TableSkeleton } from '../components/ui/Skeleton';

const UserUpdate: React.FC = () => {
    const navigate = useNavigate();
    const { id } = useParams<{ id: string }>();
    const { updateUser, updateLoading, getUser } = useUsers();

    const [user, setUser] = useState<any>(null);
    const [userLoading, setUserLoading] = useState(true);
    const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
    const [formData, setFormData] = useState<UpdateUserRequest>({
        name: '',
        email: '',
        role: ROLES.CALLER,
        phoneNumber: '',
        isActive: true,
    });

    useEffect(() => {
        const loadUser = async () => {
            if (!id) return;
            try {
                setUserLoading(true);
                const userData = await getUser(id);
                setUser(userData.data || userData);
                const userObj = userData.data || userData;
                setFormData({
                    name: userObj.name || '',
                    email: userObj.email || '',
                    role: userObj.role || ROLES.CALLER,
                    phoneNumber: userObj.phoneNumber || '',
                    isActive: userObj.isActive,
                });
            } catch (error: any) {
                console.error('Failed to load user:', error);
            } finally {
                setUserLoading(false);
            }
        };
        loadUser();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [id]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        const checked = (e.target as HTMLInputElement).checked;

        setFormData({
            ...formData,
            [name]: type === 'checkbox' ? checked : value
        });

        if (formErrors[name]) {
            setFormErrors({
                ...formErrors,
                [name]: ''
            });
        }
    };

    const validateForm = () => {
        const errors: { [key: string]: string } = {};

        if (!formData.name?.trim()) {
            errors.name = 'Name is required';
        }

        if (!formData.email?.trim()) {
            errors.email = 'Email is required';
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            errors.email = 'Email is invalid';
        }

        if (!formData.role) {
            errors.role = 'Role is required';
        }

        return errors;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!id) return;

        const errors = validateForm();
        if (Object.keys(errors).length > 0) {
            setFormErrors(errors);
            return;
        }

        try {
            const updateData: UpdateUserRequest = {
                name: formData.name,
                email: formData.email,
                role: formData.role,
                phoneNumber: formData.phoneNumber,
                isActive: formData.isActive,
            };
            await updateUser({ id, data: updateData });
            navigate('/users');
        } catch (error) {
            console.error('Form submission error:', error);
        }
    };

    if (userLoading) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/users')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <div className="h-8 bg-gray-200 rounded w-64 animate-pulse"></div>
                </div>
                <Card>
                    <div className="p-6">
                        <TableSkeleton rows={5} columns={1} />
                    </div>
                </Card>
            </div>
        );
    }

    if (!user) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/users')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <h1 className="text-2xl font-semibold text-gray-900">User Not Found</h1>
                </div>
                <Card>
                    <div className="p-6 text-center">
                        <p className="text-gray-500">The requested user could not be found.</p>
                    </div>
                </Card>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={() => navigate('/users')} icon={<ArrowLeftIcon size={16} />}>
                    Back
                </Button>
                <h1 className="text-2xl font-semibold text-gray-900">Edit User</h1>
            </div>

            <Card>
                <div className="p-6">
                    <form onSubmit={handleSubmit} className="space-y-5">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Full Name" htmlFor="name" required error={formErrors.name}>
                                <FormInput
                                    type="text"
                                    id="name"
                                    name="name"
                                    placeholder="Enter full name"
                                    value={formData.name || ''}
                                    onChange={handleInputChange}
                                    disabled={updateLoading}
                                    icon={UserIcon}
                                    error={formErrors.name}
                                    className="h-11"
                                />
                            </FormField>

                            <FormField label="Email Address" htmlFor="email" required error={formErrors.email}>
                                <FormInput
                                    type="email"
                                    id="email"
                                    name="email"
                                    placeholder="Enter email address"
                                    value={formData.email || ''}
                                    onChange={handleInputChange}
                                    disabled={updateLoading}
                                    icon={MailIcon}
                                    error={formErrors.email}
                                    className="h-11"
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Role" htmlFor="role" required error={formErrors.role}>
                                <Select value={formData.role} disabled>
                                    <SelectTrigger className="w-full h-11">
                                        <div className="flex items-center">
                                            <ShieldIcon size={16} className="text-gray-400 mr-2" />
                                            <SelectValue placeholder="Caller" />
                                        </div>
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value={ROLES.CALLER}>Caller</SelectItem>
                                    </SelectContent>
                                </Select>
                            </FormField>

                            <FormField label="Phone Number" htmlFor="phoneNumber" error={formErrors.phoneNumber}>
                                <FormInput
                                    type="tel"
                                    id="phoneNumber"
                                    name="phoneNumber"
                                    placeholder="Enter phone number"
                                    value={formData.phoneNumber || ''}
                                    onChange={handleInputChange}
                                    disabled={updateLoading}
                                    error={formErrors.phoneNumber}
                                    className="h-11"
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Status" htmlFor="isActive">
                                <div className="flex items-center space-x-3">
                                    <label className="flex items-center">
                                        <input
                                            type="checkbox"
                                            name="isActive"
                                            checked={formData.isActive}
                                            onChange={handleInputChange}
                                            disabled={updateLoading}
                                            className="form-checkbox h-4 w-4 text-blue-600"
                                        />
                                        <span className="ml-2 text-sm text-gray-700">Active</span>
                                    </label>
                                </div>
                            </FormField>
                        </div>

                        <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => navigate('/users')}
                                disabled={updateLoading}
                            >
                                Cancel
                            </Button>
                            <Button
                                type="submit"
                                variant="primary"
                                disabled={updateLoading}
                            >
                                {updateLoading ? 'Updating...' : 'Save Changes'}
                            </Button>
                        </div>
                    </form>
                </div>
            </Card>
        </div>
    );
};

export default UserUpdate;

