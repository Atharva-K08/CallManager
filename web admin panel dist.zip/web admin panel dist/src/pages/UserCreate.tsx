import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeftIcon, UserIcon, MailIcon, ShieldIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import FormInput from '../components/ui/FormInput';
import PasswordInput from '../components/ui/PasswordInput';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/Select';
import { useUsers } from '../hooks/useUsers';
import { CreateUserRequest } from '../types/api.types';
import { ROLES } from '../types/roles';

const UserCreate: React.FC = () => {
    const navigate = useNavigate();
    const { createUser, createLoading } = useUsers();

    const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
    const [formData, setFormData] = useState<CreateUserRequest & { confirmPassword?: string }>({
        name: '',
        email: '',
        password: '',
        role: ROLES.CALLER,
        phoneNumber: '',
        isActive: true,
        confirmPassword: '',
    });

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        const checked = (e.target as HTMLInputElement).checked;

        setFormData({
            ...formData,
            [name]: type === 'checkbox' ? checked : value
        });

        if (formErrors[name]) {
            setFormErrors({
                ...formErrors,
                [name]: ''
            });
        }
    };

    const validateForm = () => {
        const errors: { [key: string]: string } = {};

        if (!formData.name.trim()) {
            errors.name = 'Name is required';
        }

        if (!formData.email.trim()) {
            errors.email = 'Email is required';
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            errors.email = 'Email is invalid';
        }

        if (!formData.role) {
            errors.role = 'Role is required';
        }

        if (!formData.password) {
            errors.password = 'Password is required';
        } else if (formData.password.length < 8) {
            errors.password = 'Password must be at least 8 characters';
        }

        if (formData.password !== formData.confirmPassword) {
            errors.confirmPassword = 'Passwords do not match';
        }

        return errors;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const errors = validateForm();
        if (Object.keys(errors).length > 0) {
            setFormErrors(errors);
            return;
        }

        try {
            const createData: CreateUserRequest = {
                name: formData.name,
                email: formData.email,
                password: formData.password,
                role: formData.role,
                phoneNumber: formData.phoneNumber,
                isActive: formData.isActive,
            };
            await createUser(createData);
            navigate('/users');
        } catch (error) {
            console.error('Form submission error:', error);
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={() => navigate('/users')} icon={<ArrowLeftIcon size={16} />}>
                    Back
                </Button>
                <h1 className="text-2xl font-semibold text-gray-900">Add New User</h1>
            </div>

            <Card>
                <div className="p-6">
                    <form onSubmit={handleSubmit} className="space-y-5">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Full Name" htmlFor="name" required error={formErrors.name}>
                                <FormInput
                                    type="text"
                                    id="name"
                                    name="name"
                                    placeholder="Enter full name"
                                    value={formData.name}
                                    onChange={handleInputChange}
                                    disabled={createLoading}
                                    icon={UserIcon}
                                    error={formErrors.name}
                                    className="h-11"
                                />
                            </FormField>

                            <FormField label="Email Address" htmlFor="email" required error={formErrors.email}>
                                <FormInput
                                    type="email"
                                    id="email"
                                    name="email"
                                    placeholder="Enter email address"
                                    value={formData.email}
                                    onChange={handleInputChange}
                                    disabled={createLoading}
                                    icon={MailIcon}
                                    error={formErrors.email}
                                    className="h-11"
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Role" htmlFor="role" required error={formErrors.role}>
                                <Select value={formData.role} disabled>
                                    <SelectTrigger className="w-full h-11">
                                        <div className="flex items-center">
                                            <ShieldIcon size={16} className="text-gray-400 mr-2" />
                                            <SelectValue placeholder="Caller" />
                                        </div>
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value={ROLES.CALLER}>Caller</SelectItem>
                                    </SelectContent>
                                </Select>
                            </FormField>

                            <FormField label="Phone Number" htmlFor="phoneNumber" error={formErrors.phoneNumber}>
                                <FormInput
                                    type="tel"
                                    id="phoneNumber"
                                    name="phoneNumber"
                                    placeholder="Enter phone number"
                                    value={formData.phoneNumber}
                                    onChange={handleInputChange}
                                    disabled={createLoading}
                                    error={formErrors.phoneNumber}
                                    className="h-11"
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Status" htmlFor="isActive">
                                <div className="flex items-center space-x-3">
                                    <label className="flex items-center">
                                        <input
                                            type="checkbox"
                                            name="isActive"
                                            checked={formData.isActive}
                                            onChange={handleInputChange}
                                            disabled={createLoading}
                                            className="form-checkbox h-4 w-4 text-blue-600"
                                        />
                                        <span className="ml-2 text-sm text-gray-700">Active</span>
                                    </label>
                                </div>
                            </FormField>
                        </div>

                        <div className="pt-3 border-t border-gray-100">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <FormField label="Password" htmlFor="password" required error={formErrors.password}>
                                    <PasswordInput
                                        id="password"
                                        name="password"
                                        placeholder="Enter password"
                                        value={formData.password}
                                        onChange={handleInputChange}
                                        disabled={createLoading}
                                        error={formErrors.password}
                                        className="h-11"
                                    />
                                </FormField>
                                <FormField label="Confirm Password" htmlFor="confirmPassword" required error={formErrors.confirmPassword}>
                                    <PasswordInput
                                        id="confirmPassword"
                                        name="confirmPassword"
                                        placeholder="Confirm password"
                                        value={formData.confirmPassword}
                                        onChange={handleInputChange}
                                        disabled={createLoading}
                                        error={formErrors.confirmPassword}
                                        className="h-11"
                                    />
                                </FormField>
                            </div>
                        </div>

                        <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => navigate('/users')}
                                disabled={createLoading}
                            >
                                Cancel
                            </Button>
                            <Button
                                type="submit"
                                variant="primary"
                                disabled={createLoading}
                            >
                                {createLoading ? 'Creating...' : 'Create User'}
                            </Button>
                        </div>
                    </form>
                </div>
            </Card>
        </div>
    );
};

export default UserCreate;

