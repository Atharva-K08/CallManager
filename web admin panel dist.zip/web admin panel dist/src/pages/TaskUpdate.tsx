import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useParams, useSearchParams, useLocation } from 'react-router-dom';
import { ArrowLeftIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import FormInput from '../components/ui/FormInput';
import { useTasks } from '../hooks/useTasks';
import { UpdateTaskRequest } from '../services/task.service';
import { useToastNotifications } from '../lib/toast';
import { TableSkeleton } from '../components/ui/Skeleton';

const TaskUpdate: React.FC = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const { id } = useParams<{ id: string }>();
    const [searchParams] = useSearchParams();
    const { getTaskById, update, loading } = useTasks();
    const { showErrorWithDetails } = useToastNotifications();

    // Get form state from location state (preserved across navigation)
    const savedFormData = location.state as (UpdateTaskRequest & { leadIds?: string[] }) | null;

    const [task, setTask] = useState<any>(null);
    const [taskLoading, setTaskLoading] = useState(true);
    const [formErrors, setFormErrors] = useState<{ [k: string]: string }>({});
    const [formData, setFormData] = useState<UpdateTaskRequest & { _id?: string; leadIds?: string[] }>({
        title: '',
        description: '',
        assignedTo: '',
        assignedToName: '',
        assignedToEmail: '',
        leadIds: [],
        targetCount: undefined,
        dueAt: undefined,
    });

    // Get updated values from query params (for navigation from selection pages)
    const assignedToFromParams = searchParams.get('assignedTo');
    const assignedToNameFromParams = searchParams.get('assignedToName');
    const assignedToEmailFromParams = searchParams.get('assignedToEmail');
    const leadIdsFromParams = useMemo(() => {
        return searchParams.get('leadIds')?.split(',').filter(Boolean) || [];
    }, [searchParams]);

    // Load task data - but check for URL params first to avoid race condition
    useEffect(() => {
        const loadTask = async () => {
            if (!id) return;
            
            // Check if we have URL params (returning from selection)
            const hasUrlParams = assignedToFromParams || leadIdsFromParams.length > 0;
            
            try {
                setTaskLoading(true);
                const taskData = await getTaskById(id);
                setTask(taskData);
                
                // If we have URL params, prioritize them (user just made selections)
                // Otherwise, use loaded data or saved form data
                setFormData({
                    _id: taskData._id,
                    title: savedFormData?.title || taskData.title || '',
                    description: savedFormData?.description || taskData.description || '',
                    assignedTo: hasUrlParams && assignedToFromParams 
                        ? assignedToFromParams 
                        : (savedFormData?.assignedTo || taskData.assignedTo || ''),
                    assignedToName: hasUrlParams && assignedToNameFromParams
                        ? assignedToNameFromParams
                        : (savedFormData?.assignedToName || taskData.assignedToName || ''),
                    assignedToEmail: hasUrlParams && assignedToEmailFromParams
                        ? assignedToEmailFromParams
                        : (savedFormData?.assignedToEmail || taskData.assignedToEmail || ''),
                    leadIds: hasUrlParams && leadIdsFromParams.length > 0
                        ? leadIdsFromParams
                        : (savedFormData?.leadIds || taskData.leadIds || []),
                    targetCount: savedFormData?.targetCount ?? taskData.targetCount,
                    dueAt: savedFormData?.dueAt || taskData.dueAt,
                });
            } catch (error: any) {
                showErrorWithDetails('Failed to load task', error?.message);
            } finally {
                setTaskLoading(false);
            }
        };
        loadTask();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [id]); // Only depend on id, not URL params

    // Memoize leadIds string for stable comparison
    const leadIdsFromParamsStr = useMemo(() => {
        return leadIdsFromParams.join(',');
    }, [leadIdsFromParams]);

    // Update form data when params change (after returning from selection pages)
    useEffect(() => {
        // Only update if values actually changed
        setFormData(prev => {
            let updated = false;
            const updates: Partial<typeof formData> = {};
            
            if (assignedToFromParams && prev.assignedTo !== assignedToFromParams) {
                updates.assignedTo = assignedToFromParams;
                updates.assignedToName = assignedToNameFromParams || '';
                updates.assignedToEmail = assignedToEmailFromParams || '';
                updated = true;
            }
            
            // Compare arrays by comparing their string representation
            const prevLeadIdsStr = (prev.leadIds || []).join(',');
            if (leadIdsFromParams.length > 0 && prevLeadIdsStr !== leadIdsFromParamsStr) {
                updates.leadIds = leadIdsFromParams;
                updated = true;
            }
            
            return updated ? { ...prev, ...updates } : prev;
        });
    }, [assignedToFromParams, assignedToNameFromParams, assignedToEmailFromParams, leadIdsFromParamsStr]);

    const validateForm = () => {
        const errors: { [k: string]: string } = {};
        if (!formData.title?.trim()) errors.title = 'Title is required';
        if (!formData.assignedTo) errors.assignedTo = 'Assignee is required';
        return errors;
    };

    const formatDateTimeLocal = (iso?: string) => {
        if (!iso) return '';
        const d = new Date(iso);
        const pad = (n: number) => String(n).padStart(2, '0');
        const yyyy = d.getFullYear();
        const MM = pad(d.getMonth() + 1);
        const dd = pad(d.getDate());
        const hh = pad(d.getHours());
        const mm = pad(d.getMinutes());
        return `${yyyy}-${MM}-${dd}T${hh}:${mm}`;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!id) return;

        const errors = validateForm();
        if (Object.keys(errors).length) {
            setFormErrors(errors);
            return;
        }

        try {
            const payload: UpdateTaskRequest = { ...formData };
            delete (payload as any)._id;
            await update(id, payload);
            navigate('/tasks');
        } catch (error: any) {
            showErrorWithDetails('Failed to update task', error?.message);
        }
    };

    const handleSelectCaller = () => {
        const params = new URLSearchParams();
        params.set('returnTo', `/tasks/${id}/update`);
        if (formData.assignedTo) {
            params.set('selectedId', formData.assignedTo);
        }
        // Preserve leadIds in URL
        if (formData.leadIds && formData.leadIds.length > 0) {
            params.set('leadIds', formData.leadIds.join(','));
        }
        // Navigate with form state in location state
        navigate(`/users/select/caller?${params.toString()}`, {
            state: formData, // Preserve form state
        });
    };

    const handleSelectLeads = () => {
        const params = new URLSearchParams();
        params.set('returnTo', `/tasks/${id}/update`);
        if (formData.leadIds && formData.leadIds.length > 0) {
            params.set('selectedIds', formData.leadIds.join(','));
        }
        // Preserve assignedTo in URL
        if (formData.assignedTo) {
            params.set('assignedTo', formData.assignedTo);
            params.set('assignedToName', formData.assignedToName || '');
            params.set('assignedToEmail', formData.assignedToEmail || '');
        }
        // Navigate with form state in location state
        navigate(`/leads/select?${params.toString()}`, {
            state: formData, // Preserve form state
        });
    };

    if (taskLoading) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/tasks')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <div className="h-8 bg-gray-200 rounded w-64 animate-pulse"></div>
                </div>
                <Card>
                    <div className="p-6">
                        <TableSkeleton rows={5} columns={1} />
                    </div>
                </Card>
            </div>
        );
    }

    if (!task) {
        return (
            <div className="space-y-6">
                <div className="flex items-center space-x-4">
                    <Button variant="outline" onClick={() => navigate('/tasks')} icon={<ArrowLeftIcon size={16} />}>
                        Back
                    </Button>
                    <h1 className="text-2xl font-semibold text-gray-900">Task Not Found</h1>
                </div>
                <Card>
                    <div className="p-6 text-center">
                        <p className="text-gray-500">The requested task could not be found.</p>
                    </div>
                </Card>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={() => navigate('/tasks')} icon={<ArrowLeftIcon size={16} />}>
                    Back
                </Button>
                <h1 className="text-2xl font-semibold text-gray-900">Edit Task</h1>
            </div>

            {/* Form */}
            <Card>
                <div className="p-6">
                    <form onSubmit={handleSubmit} className="space-y-5">
                        <FormField label="Title" htmlFor="title" required error={formErrors.title}>
                            <FormInput
                                id="title"
                                name="title"
                                placeholder="e.g., Call 50 new MBA leads"
                                value={formData.title || ''}
                                onChange={(e) => {
                                    setFormData({ ...formData, title: e.target.value });
                                    if (formErrors.title) {
                                        setFormErrors({ ...formErrors, title: '' });
                                    }
                                }}
                                error={formErrors.title}
                                className="h-11"
                            />
                        </FormField>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField label="Due Date & Time" htmlFor="dueAt">
                                <input
                                    id="dueAt"
                                    name="dueAt"
                                    type="datetime-local"
                                    lang="en-GB"
                                    className="block w-full px-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 cursor-pointer"
                                    value={formatDateTimeLocal(formData.dueAt)}
                                    onClick={(e) => {
                                        e.currentTarget.showPicker?.();
                                    }}
                                    onChange={(e) => {
                                        setFormData({ ...formData, dueAt: e.target.value });
                                        if (formErrors.dueAt) {
                                            setFormErrors({ ...formErrors, dueAt: '' });
                                        }
                                    }}
                                />
                            </FormField>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="md:col-span-3">
                                <FormField label="Assign To" htmlFor="assignee" required error={formErrors.assignedTo}>
                                    <div
                                        role="button"
                                        tabIndex={0}
                                        onClick={handleSelectCaller}
                                        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleSelectCaller(); }}
                                        className={`w-full flex items-center justify-between gap-3 rounded-lg border ${formErrors.assignedTo ? 'border-red-300' : (formData.assignedTo ? 'border-gray-200' : 'border-dashed border-gray-300')} bg-white px-3 py-2 shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-primary/40`}
                                    >
                                        <div className="flex items-center gap-3 min-w-0">
                                            <div className={`h-10 w-10 rounded-full ${formData.assignedTo ? 'bg-blue-100 text-blue-700' : 'bg-gray-200 text-gray-500'} flex items-center justify-center text-sm font-semibold`}>
                                                {formData.assignedToName
                                                    ? String(formData.assignedToName)
                                                        .split(' ')
                                                        .map((p) => p[0])
                                                        .filter(Boolean)
                                                        .slice(0, 2)
                                                        .join('')
                                                        .toUpperCase()
                                                    : '?'}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                {formData.assignedToName ? (
                                                    <>
                                                        <div className="truncate text-sm font-medium text-gray-900" title={formData.assignedToName}>{formData.assignedToName}</div>
                                                        <div className="truncate text-xs text-gray-500" title={formData.assignedToEmail || ''}>{formData.assignedToEmail || '—'}</div>
                                                    </>
                                                ) : (
                                                    <div className="text-sm text-gray-500">Select a caller</div>
                                                )}
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2 shrink-0">
                                            <Button variant='outline' size='sm' type='button' onClick={(e) => { e.stopPropagation(); handleSelectCaller(); }}>{formData.assignedTo ? 'Change' : 'Select'}</Button>
                                        </div>
                                    </div>
                                    <p className="mt-1 text-xs text-gray-500">Choose a caller responsible for this task.</p>
                                </FormField>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="md:col-span-3">
                                <FormField label="Assign Leads" htmlFor="leads">
                                    <div
                                        role="button"
                                        tabIndex={0}
                                        onClick={handleSelectLeads}
                                        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleSelectLeads(); }}
                                        className={`w-full flex items-center justify-between gap-3 rounded-lg border ${(formData.leadIds?.length || 0) > 0 ? 'border-gray-200' : 'border-dashed border-gray-300'} bg-white px-3 py-2 shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-primary/40`}
                                    >
                                        <div className="flex items-center gap-3 min-w-0">
                                            <div className={`h-10 w-10 rounded-full ${(formData.leadIds?.length || 0) > 0 ? 'bg-green-100 text-green-700' : 'bg-gray-200 text-gray-500'} flex items-center justify-center text-sm font-semibold`}>
                                                {(formData.leadIds?.length || 0) > 0 ? (formData.leadIds?.length || 0) : '+'}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                {(formData.leadIds?.length || 0) > 0 ? (
                                                    <div className="truncate text-sm font-medium text-gray-900">{formData.leadIds?.length} lead(s) selected</div>
                                                ) : (
                                                    <div className="text-sm text-gray-500">Select one or more leads</div>
                                                )}
                                                <div className="text-xs text-gray-500">These leads will be included in this task.</div>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2 shrink-0">
                                            <Button variant='outline' size='sm' type='button' onClick={(e) => { e.stopPropagation(); handleSelectLeads(); }}>{(formData.leadIds?.length || 0) > 0 ? 'Change' : 'Select'}</Button>
                                        </div>
                                    </div>
                                </FormField>
                            </div>
                        </div>

                        <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                            <Button type="button" variant="outline" onClick={() => navigate('/tasks')}>Cancel</Button>
                            <Button type="submit" variant="primary" disabled={loading}>
                                {loading ? 'Saving...' : 'Save Changes'}
                            </Button>
                        </div>
                    </form>
                </div>
            </Card>
        </div>
    );
};

export default TaskUpdate;

