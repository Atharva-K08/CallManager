import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeftIcon, EyeIcon, ArrowUpIcon, ArrowDownIcon, SearchIcon } from 'lucide-react';
import Card from '../components/ui/Card';
import Table from '../components/ui/Table';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import Pagination from '../components/ui/Pagination';
import { useCallRecords } from '../hooks/useCallRecords';
import { useUsers } from '../hooks/useUsers';
import { debounce } from '../utils/performance';

const UserCallRecords: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();

  const [dateRange, setDateRange] = useState<{
    start: string;
    end: string;
  }>({
    start: '',
    end: ''
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [perPage, setPerPage] = useState(10);

  // Use hooks
  const {
    data,
    statistics,
    loading,
    fetch,
    fetchStatistics,
  } = useCallRecords();

  const { getUser, userLoading } = useUsers();
  const [user, setUser] = useState<any>(null);

  // Load user info
  useEffect(() => {
    if (userId) {
      getUser(userId).then((response) => {
        if (response) {
          setUser(response.data);
        }
      });
    }
  }, [userId]);

  // Debounced search function
  const debouncedSearch = debounce((query: string) => {
    if (userId) {
      setCurrentPage(1); // Reset to first page on search
      const filters: any = {
        createdBy: userId,
        page: 1,
        limit: perPage,
      };

      if (dateRange.start) filters.from = dateRange.start;
      if (dateRange.end) filters.to = dateRange.end;
      if (query.trim()) filters.search = query;

      fetch(filters);
    }
  }, 500);

  // Load call records for this user
  useEffect(() => {
    if (userId) {
      const filters: any = {
        createdBy: userId,
        page: currentPage,
        limit: perPage,
      };

      if (dateRange.start) filters.from = dateRange.start;
      if (dateRange.end) filters.to = dateRange.end;
      if (searchQuery) filters.search = searchQuery;

      fetch(filters);
      fetchStatistics({ createdBy: userId, from: dateRange.start, to: dateRange.end });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId, dateRange.start, dateRange.end, currentPage, perPage]);

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    debouncedSearch(query);
  };

  // Handle date filter change
  const handleDateChange = (field: 'start' | 'end', value: string) => {
    const newDateRange = { ...dateRange, [field]: value };
    setDateRange(newDateRange);
    setCurrentPage(1); // Reset to first page on date filter change

    if (userId) {
      const filters: any = {
        createdBy: userId,
        page: 1,
        limit: perPage,
      };

      if (newDateRange.start) filters.from = newDateRange.start;
      if (newDateRange.end) filters.to = newDateRange.end;
      if (searchQuery) filters.search = searchQuery;

      fetch(filters);
      fetchStatistics({ createdBy: userId, from: newDateRange.start, to: newDateRange.end });
    }
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    if (userId) {
      const filters: any = {
        createdBy: userId,
        page: page,
        limit: perPage,
      };

      if (dateRange.start) filters.from = dateRange.start;
      if (dateRange.end) filters.to = dateRange.end;
      if (searchQuery) filters.search = searchQuery;

      fetch(filters);
    }
  };

  // Handle per page change
  const handlePerPageChange = (newPerPage: number) => {
    setPerPage(newPerPage);
    setCurrentPage(1); // Reset to first page when changing per page
    if (userId) {
      const filters: any = {
        createdBy: userId,
        page: 1,
        limit: newPerPage,
      };

      if (dateRange.start) filters.from = dateRange.start;
      if (dateRange.end) filters.to = dateRange.end;
      if (searchQuery) filters.search = searchQuery;

      fetch(filters);
    }
  };

  const columns = [
    {
      key: 'contactName',
      header: 'Contact Name',
      width: 'w-2/12',
      render: (_: string, item: any) => {
        // Use leadId firstName/lastName if contactName is null or "Unknown Contact"
        const leadFullName = item.leadId && typeof item.leadId === 'object'
          ? `${item.leadId.firstName || ''} ${item.leadId.lastName || ''}`.trim()
          : null;
        const displayName = item.contactName || leadFullName || 'Unknown Contact';
        return (
          <span className="text-sm text-gray-900">{displayName}</span>
        );
      }
    },
    {
      key: 'phoneNumber',
      header: 'Phone Number',
      width: 'w-2/12',
      render: (_: string, item: any) => (
        <span className="text-sm text-gray-900 font-mono">{item.phoneNumber}</span>
      )
    },
    {
      key: 'isOutgoing',
      header: 'Direction',
      width: 'w-1/12',
      render: (_: string, item: any) => {
        const isOutgoing = item.isOutgoing !== undefined ? item.isOutgoing : true;
        return (
          <div className="flex items-center">
            {isOutgoing ? (
              <>
                <ArrowUpIcon size={14} className="text-blue-600 mr-1" />
                <Badge variant="primary" size="sm">Outgoing</Badge>
              </>
            ) : (
              <>
                <ArrowDownIcon size={14} className="text-green-600 mr-1" />
                <Badge variant="success" size="sm">Incoming</Badge>
              </>
            )}
          </div>
        );
      }
    },
    {
      key: 'formattedDuration',
      header: 'Duration',
      width: 'w-1/12',
      render: (_: string, item: any) => {
        const durationSeconds = item.durationSeconds || 0;
        const formattedDuration = durationSeconds > 0
          ? `${Math.floor(durationSeconds / 60)}:${Math.floor(durationSeconds % 60).toString().padStart(2, '0')}`
          : '00:00';
        return (
          <span className="text-sm text-gray-900">
            {formattedDuration}
          </span>
        );
      }
    },
    {
      key: 'initiatedAt',
      header: 'Date & Time',
      width: 'w-2/12',
      render: (_: string, item: any) => {
        const date = new Date(item.initiatedAt);
        return (
          <span className="text-sm text-gray-900">
            {date.toLocaleDateString('en-GB')} {date.toLocaleTimeString()}
          </span>
        );
      }
    },
    {
      key: 'actions',
      header: 'Actions',
      width: 'w-1/12',
      render: (_: any, item: any) => (
        <button
          className="p-1 text-blue-600 hover:text-blue-800 rounded-full hover:bg-blue-50"
          onClick={() => handleViewCallDetails(item)}
          title="View Details"
        >
          <EyeIcon size={16} />
        </button>
      )
    }
  ];

  const callRecords = data?.results || [];

  const handleViewCallDetails = (call: any) => {
    const callId = call._id || call.id;
    // Pass call data via location state to avoid API call
    navigate(`/calls/${userId}/${callId}`, {
      state: { callData: call }
    });
  };

  return (
    <div className="space-y-6">
      {/* Header with back button */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            icon={<ArrowLeftIcon size={16} />}
            onClick={() => navigate('/calls')}
          >
            Back to Callers
          </Button>
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">
              {userLoading ? 'Loading...' : user?.name || 'Call Records'}
            </h1>
            {user && (
              <p className="text-sm text-gray-500 mt-1">
                {user.email} • Viewing call records
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Search and filters */}
      <Card>
        <div className="p-3">
          <div className="space-y-2">
            {/* Search and Filters - single row on md+ */}
            <div className="flex flex-col md:flex-row md:items-end gap-3">
              {/* Search - flexible width */}
              <div className="md:flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Search Calls
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <SearchIcon size={18} className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search by contact name, phone number..."
                    value={searchQuery}
                    onChange={handleSearchChange}
                    className="block w-full pl-10 pr-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400"
                  />
                </div>
              </div>

              {/* Start Date Filter */}
              <div className="md:w-56" lang="en-GB">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Start Date
                </label>
                <input
                  type="date"
                  lang="en-GB"
                  className="block w-full px-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 cursor-pointer"
                  value={dateRange.start}
                  onClick={(e) => {
                    e.currentTarget.showPicker?.();
                  }}
                  onChange={(e) => handleDateChange('start', e.target.value)}
                />
              </div>

              {/* End Date Filter */}
              <div className="md:w-56" lang="en-GB">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  End Date
                </label>
                <input
                  type="date"
                  lang="en-GB"
                  className="block w-full px-3 py-2.5 h-11 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white hover:border-gray-400 cursor-pointer"
                  value={dateRange.end}
                  onClick={(e) => {
                    e.currentTarget.showPicker?.();
                  }}
                  onChange={(e) => handleDateChange('end', e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Call Records */}
      <Card>
        <div className="mb-4 flex justify-between items-center">
          <h3 className="text-lg font-medium text-gray-800">Call Records</h3>
          {data && (
            <span className="text-sm text-gray-500">
              Showing {callRecords.length} of {data.totalResults} calls
            </span>
          )}
        </div>
        <Table
          columns={columns}
          data={callRecords}
          loading={loading}
          onRowClick={handleViewCallDetails}
        />
        {data && (
          <div className="p-6 border-t border-gray-200">
            <Pagination
              currentPage={data.page || currentPage}
              totalPages={data.totalPages}
              totalItems={data.totalResults}
              perPage={data.limit || perPage}
              onPageChange={handlePageChange}
              onPerPageChange={handlePerPageChange}
            />
          </div>
        )}
      </Card>

      {/* User-specific Stats */}
      {/* {statistics && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="hover:shadow-md transition-shadow duration-200">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">Total Calls</p>
              <p className="mt-2 text-3xl font-semibold text-gray-900">
                {statistics.totalCalls || 0}
              </p>
              <div className="mt-2 inline-flex items-center text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">
                <span>{statistics.outgoingCalls || 0} outgoing, {statistics.incomingCalls || 0} incoming</span>
              </div>
            </div>
          </Card>
          <Card className="hover:shadow-md transition-shadow duration-200">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">Connected Calls</p>
              <p className="mt-2 text-3xl font-semibold text-green-600">
                {statistics.connectedCalls || 0}
              </p>
              <div className="mt-2 flex justify-center">
                <div className="bg-gray-200 h-2 w-36 rounded-full overflow-hidden">
                  <div
                    className="bg-green-500 h-2"
                    style={{
                      width: `${statistics.totalCalls ? (statistics.connectedCalls / statistics.totalCalls * 100) : 0}%`
                    }}
                  />
                </div>
              </div>
              <p className="mt-1 text-xs text-gray-500">
                {statistics.totalCalls ? Math.round(statistics.connectedCalls / statistics.totalCalls * 100) : 0}
                % success rate
              </p>
            </div>
          </Card>
          <Card className="hover:shadow-md transition-shadow duration-200">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">Average Call Duration</p>
              <p className="mt-2 text-3xl font-semibold text-blue-600">
                {statistics.avgDuration
                  ? `${Math.floor(statistics.avgDuration / 60)}:${Math.floor(statistics.avgDuration % 60).toString().padStart(2, '0')}`
                  : '0:00'}
              </p>
              <div className="mt-2 inline-flex items-center text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full">
                <span>Total: {statistics.totalDuration ? Math.floor(statistics.totalDuration / 60) : 0} minutes</span>
              </div>
            </div>
          </Card>
        </div>
      )} */}

    </div>
  );
};

export default UserCallRecords;

