import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const Landing: React.FC = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  
  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      @keyframes blob {
        0%, 100% {
          transform: translate(0px, 0px) scale(1);
        }
        33% {
          transform: translate(30px, -50px) scale(1.1);
        }
        66% {
          transform: translate(-20px, 20px) scale(0.9);
        }
      }
      .animate-blob {
        animation: blob 7s infinite;
      }
      .animation-delay-2000 {
        animation-delay: 2s;
      }
      .animation-delay-4000 {
        animation-delay: 4s;
      }
    `;
    document.head.appendChild(style);
    return () => {
      if (document.head.contains(style)) {
        document.head.removeChild(style);
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-blue-50 backdrop-blur-md border-b border-blue-100 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              <div className="relative">
                <div className="h-9 w-9 rounded-xl bg-blue-600 shadow-lg group-hover:shadow-xl group-hover:scale-105 transition-all duration-300 flex items-center justify-center">
                  <svg className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                </div>
                <div className="absolute -top-0.5 -right-0.5 h-3.5 w-3.5 rounded-full bg-green-500 border-2 border-white shadow-sm"></div>
                <div className="absolute -top-0.5 -right-0.5 h-3.5 w-3.5 rounded-full bg-green-400 animate-ping opacity-75"></div>
              </div>
              <span className="text-lg font-bold text-blue-600 group-hover:text-blue-700 transition-all duration-200">CallTracker</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1">
              <a
                href="#features"
                className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-blue-600 rounded-lg hover:bg-blue-50 transition-all duration-200 relative group"
              >
                Features
                <span className="absolute bottom-1 left-1/2 w-0 h-0.5 bg-blue-600 rounded-full group-hover:w-8 group-hover:left-1/4 transition-all duration-300"></span>
              </a>
              <a
                href="#how"
                className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-indigo-600 rounded-lg hover:bg-indigo-50 transition-all duration-200 relative group"
              >
                How it works
                <span className="absolute bottom-1 left-1/2 w-0 h-0.5 bg-indigo-600 rounded-full group-hover:w-8 group-hover:left-1/4 transition-all duration-300"></span>
              </a>
              <a
                href="#testimonials"
                className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-purple-600 rounded-lg hover:bg-purple-50 transition-all duration-200 relative group"
              >
                Testimonials
                <span className="absolute bottom-1 left-1/2 w-0 h-0.5 bg-purple-600 rounded-full group-hover:w-8 group-hover:left-1/4 transition-all duration-300"></span>
              </a>
              <a
                href="#contact"
                className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-pink-600 rounded-lg hover:bg-pink-50 transition-all duration-200 relative group"
              >
                Contact
                <span className="absolute bottom-1 left-1/2 w-0 h-0.5 bg-pink-600 rounded-full group-hover:w-8 group-hover:left-1/4 transition-all duration-300"></span>
              </a>
            </nav>

            {/* Desktop CTA Buttons */}
            <div className="hidden lg:flex items-center gap-3">
              <Link
                to="/login"
                className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-blue-700 rounded-lg hover:bg-blue-50 border border-transparent hover:border-blue-200 transition-all duration-200"
              >
                Sign in
              </Link>
              <Link
                to="/login"
                className="px-6 py-2.5 text-sm font-semibold text-white bg-blue-600 rounded-lg shadow-lg hover:shadow-xl hover:bg-blue-700 transform hover:-translate-y-0.5 transition-all duration-200"
              >
                Get started
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="lg:hidden inline-flex items-center justify-center h-10 w-10 rounded-lg text-blue-600 hover:bg-blue-50 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              aria-label="Toggle menu"
              aria-expanded={mobileOpen}
              onClick={() => setMobileOpen(v => !v)}
            >
              <div className="relative w-5 h-5">
                <span className={`absolute top-0 left-0 w-5 h-0.5 bg-current transform transition-all duration-300 ${mobileOpen ? 'rotate-45 top-2 bg-blue-600' : 'bg-blue-600'}`}></span>
                <span className={`absolute top-2 left-0 w-5 h-0.5 bg-current transform transition-all duration-300 ${mobileOpen ? 'opacity-0' : 'bg-blue-600'}`}></span>
                <span className={`absolute top-4 left-0 w-5 h-0.5 bg-current transform transition-all duration-300 ${mobileOpen ? '-rotate-45 top-2 bg-blue-600' : 'bg-blue-600'}`}></span>
              </div>
            </button>
          </div>

          {/* Mobile Menu */}
          <div className={`lg:hidden overflow-hidden transition-all duration-300 ease-in-out ${mobileOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
            <div className="px-4 pt-4 pb-6 space-y-1 border-t border-blue-100 bg-white">
              <a
                href="#features"
                className="block px-4 py-3 text-base font-medium text-gray-700 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all duration-200"
                onClick={() => setMobileOpen(false)}
              >
                Features
              </a>
              <a
                href="#how"
                className="block px-4 py-3 text-base font-medium text-gray-700 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all duration-200"
                onClick={() => setMobileOpen(false)}
              >
                How it works
              </a>
              <a
                href="#testimonials"
                className="block px-4 py-3 text-base font-medium text-gray-700 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-all duration-200"
                onClick={() => setMobileOpen(false)}
              >
                Testimonials
              </a>
              <a
                href="#contact"
                className="block px-4 py-3 text-base font-medium text-gray-700 hover:text-pink-600 hover:bg-pink-50 rounded-lg transition-all duration-200"
                onClick={() => setMobileOpen(false)}
              >
                Contact
              </a>
              <div className="pt-4 space-y-2 border-t border-blue-100">
                <Link
                  to="/login"
                  className="block px-4 py-3 text-center text-base font-medium text-gray-700 hover:text-blue-700 bg-white hover:bg-blue-50 border border-blue-200 rounded-lg transition-all duration-200"
                  onClick={() => setMobileOpen(false)}
                >
                  Sign in
                </Link>
                <Link
                  to="/login"
                  className="block px-4 py-3 text-center text-base font-semibold text-white bg-blue-600 rounded-lg shadow-lg hover:shadow-xl hover:bg-blue-700 transition-all duration-200"
                  onClick={() => setMobileOpen(false)}
                >
                  Get started
                </Link>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden bg-blue-50">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-2000"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-4000"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-6 pt-8 pb-16 lg:pt-12 lg:pb-24">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Left Column - Content */}
            <div className="relative z-10">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-100 backdrop-blur-sm border border-blue-200 text-blue-700 text-sm font-semibold mb-6 shadow-sm">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                </span>
                Built for modern sales teams
              </div>

              {/* Main Heading */}
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight mb-6 flex flex-wrap items-center gap-3">
                <span className="text-blue-600">
                  Track calls.
                </span>
                <span className="text-emerald-600">
                  Convert leads.
                </span>
                <span className="text-purple-600">
                  Delight customers.
                </span>
              </h1>

              {/* Description */}
              <p className="text-lg sm:text-xl text-gray-600 leading-relaxed mb-8 max-w-xl">
                Run your entire follow-up workflow from one place: calls, reminders, tasks, and reporting. 
                <span className="font-semibold text-gray-700"> Everything you need to close more deals.</span>
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <Link 
                  to="/login" 
                  className="group px-8 py-4 rounded-xl bg-blue-600 text-white font-semibold text-base shadow-lg hover:shadow-xl hover:bg-blue-700 transform hover:-translate-y-0.5 transition-all duration-300 flex items-center justify-center gap-2"
                >
                  Get started
                  <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </Link>
                <a 
                  href="#features" 
                  className="px-8 py-4 rounded-xl bg-white text-gray-800 font-semibold text-base border-2 border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-all duration-300 flex items-center justify-center gap-2 shadow-sm hover:shadow-md"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                  Explore features
                </a>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-3 gap-4">
                {[
                  {value: '98%', label: 'On-time follow-ups', color: 'blue', icon: '✓'},
                  {value: '3x', label: 'Faster response', color: 'green', icon: '⚡'},
                  {value: '99.9%', label: 'Uptime', color: 'purple', icon: '🔒'}
                ].map((stat) => (
                  <div 
                    key={stat.label}
                    className={`group relative p-5 rounded-2xl bg-white/80 backdrop-blur-sm border border-gray-200/50 hover:shadow-lg transition-all duration-300 overflow-hidden ${
                      stat.color === 'blue' ? 'hover:border-blue-300' :
                      stat.color === 'green' ? 'hover:border-green-300' :
                      'hover:border-purple-300'
                    }`}
                  >
                    <div className={`absolute inset-0 opacity-0 group-hover:opacity-5 transition-opacity duration-300 ${
                      stat.color === 'blue' ? 'bg-blue-500' :
                      stat.color === 'green' ? 'bg-green-500' :
                      'bg-purple-500'
                    }`}></div>
                    <div className="relative">
                      <div className={`text-3xl font-bold mb-2 ${
                        stat.color === 'blue' ? 'text-blue-600' :
                        stat.color === 'green' ? 'text-green-600' :
                        'text-purple-600'
                      }`}>
                        {stat.value}
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-gray-600">
                        <span className="text-base">{stat.icon}</span>
                        <span className="font-medium">{stat.label}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          <div className="relative">
            {/* Demo Photos Grid */}
            <div className="grid grid-cols-2 gap-4">
              {/* Dashboard Preview */}
              <div className="rounded-xl border-2 border-gray-200 bg-white shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="h-48 bg-blue-600 relative">
                  <div className="absolute inset-0 bg-white/10 backdrop-blur-sm flex items-center justify-center">
                    <div className="text-center text-white">
                      <svg className="w-16 h-16 mx-auto mb-2 opacity-80" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                      </svg>
                      <p className="text-sm font-medium">Dashboard</p>
                    </div>
                  </div>
                </div>
                <div className="p-3 bg-gray-50">
                  <p className="text-xs font-semibold text-gray-700">Analytics Dashboard</p>
                  <p className="text-xs text-gray-500 mt-1">Real-time metrics & insights</p>
                </div>
              </div>

              {/* Leads Management */}
              <div className="rounded-xl border-2 border-gray-200 bg-white shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="h-48 bg-green-500 relative">
                  <div className="absolute inset-0 bg-white/10 backdrop-blur-sm flex items-center justify-center">
                    <div className="text-center text-white">
                      <svg className="w-16 h-16 mx-auto mb-2 opacity-80" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                      </svg>
                      <p className="text-sm font-medium">Leads</p>
                    </div>
                  </div>
                </div>
                <div className="p-3 bg-gray-50">
                  <p className="text-xs font-semibold text-gray-700">Lead Management</p>
                  <p className="text-xs text-gray-500 mt-1">Organize & track all leads</p>
                </div>
              </div>

              {/* Task Management */}
              <div className="rounded-xl border-2 border-gray-200 bg-white shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="h-48 bg-purple-600 relative">
                  <div className="absolute inset-0 bg-white/10 backdrop-blur-sm flex items-center justify-center">
                    <div className="text-center text-white">
                      <svg className="w-16 h-16 mx-auto mb-2 opacity-80" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                      </svg>
                      <p className="text-sm font-medium">Tasks</p>
                    </div>
                  </div>
                </div>
                <div className="p-3 bg-gray-50">
                  <p className="text-xs font-semibold text-gray-700">Task Management</p>
                  <p className="text-xs text-gray-500 mt-1">Assign & track team tasks</p>
                </div>
              </div>

              {/* Follow-ups */}
              <div className="rounded-xl border-2 border-gray-200 bg-white shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="h-48 bg-orange-500 relative">
                  <div className="absolute inset-0 bg-white/10 backdrop-blur-sm flex items-center justify-center">
                    <div className="text-center text-white">
                      <svg className="w-16 h-16 mx-auto mb-2 opacity-80" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <p className="text-sm font-medium">Follow-ups</p>
                    </div>
                  </div>
                </div>
                <div className="p-3 bg-gray-50">
                  <p className="text-xs font-semibold text-gray-700">Follow-up Tracking</p>
                  <p className="text-xs text-gray-500 mt-1">Never miss a follow-up call</p>
                </div>
              </div>
            </div>
          </div>
          </div>
        </div>
        {/* Trust bar */}
        {/* <div className="max-w-7xl mx-auto px-6 pb-12">
          <div className="rounded-xl border bg-white px-6 py-4 text-xs text-gray-500 flex flex-col sm:flex-row items-center justify-between gap-4">
            <span>Trusted by growing teams</span>
            <div className="flex items-center gap-6 opacity-80">
              <span>Acme Co.</span>
              <span>Northstar</span>
              <span>BluePeak</span>
              <span>NextWare</span>
            </div>
          </div>
        </div> */}
      </section>

      {/* Features */}
      <section id="features" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-2xl sm:text-3xl font-semibold text-gray-900">Everything your team needs</h2>
          <p className="mt-2 text-gray-600">Purpose‑built workflows to keep calls and follow‑ups on track.</p>
          <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: 'Call Tracking', desc: 'Capture and review call outcomes with context for every lead.' },
              { title: 'Follow‑ups', desc: 'Automated reminders and queues to prevent dropped leads.' },
              { title: 'Lead Management', desc: 'Filter, segment, and prioritize to focus on what matters.' },
              { title: 'Team Tasks', desc: 'Assign targets and track progress with real‑time updates.' },
              { title: 'Reporting', desc: 'Understand performance with clear, actionable metrics.' },
              { title: 'Secure Access', desc: 'Granular roles for callers, employees, and admins.' },
            ].map((f, i) => (
              <div key={f.title} className="rounded-xl border bg-white p-5 hover:shadow-sm transition-shadow">
                <div className="flex items-center gap-2">
                  <span className="inline-flex h-6 w-6 items-center justify-center rounded-md bg-blue-600 text-white text-xs font-semibold">{i+1}</span>
                  <div className="text-base font-semibold text-gray-900">{f.title}</div>
                </div>
                <div className="mt-2 text-sm text-gray-600">{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-semibold text-gray-900">How it works</h2>
            <p className="mt-2 text-gray-600">Simple, focused steps to keep momentum.</p>
          </div>
          <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="relative">
              <div className="absolute -top-4 -left-4 h-12 w-12 rounded-full bg-blue-600 text-white flex items-center justify-center text-xl font-bold shadow-lg">
                1
              </div>
              <div className="rounded-xl border bg-white p-6 pt-8 shadow-sm hover:shadow-md transition-shadow">
                <div className="text-lg font-semibold text-gray-900 mb-2">Log calls</div>
                <div className="text-sm text-gray-600 leading-relaxed">Capture every outcome with notes and next steps.</div>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -top-4 -left-4 h-12 w-12 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xl font-bold shadow-lg">
                2
              </div>
              <div className="rounded-xl border bg-white p-6 pt-8 shadow-sm hover:shadow-md transition-shadow">
                <div className="text-lg font-semibold text-gray-900 mb-2">Auto‑schedule</div>
                <div className="text-sm text-gray-600 leading-relaxed">Create follow‑ups with smart reminders.</div>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -top-4 -left-4 h-12 w-12 rounded-full bg-purple-600 text-white flex items-center justify-center text-xl font-bold shadow-lg">
                3
              </div>
              <div className="rounded-xl border bg-white p-6 pt-8 shadow-sm hover:shadow-md transition-shadow">
                <div className="text-lg font-semibold text-gray-900 mb-2">Track progress</div>
                <div className="text-sm text-gray-600 leading-relaxed">Monitor conversions and act on insights.</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-semibold text-gray-900">Why teams choose CallTracker</h2>
            <p className="mt-2 text-gray-600">Built to help your sales team close more deals, faster.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {[
              { 
                icon: '⚡', 
                title: 'Save time', 
                desc: 'Automate follow-ups and reduce manual work by 40%.' 
              },
              { 
                icon: '📊', 
                title: 'Better visibility', 
                desc: 'Real-time dashboards show what\'s working and what\'s not.' 
              },
              { 
                icon: '🔒', 
                title: 'Secure & compliant', 
                desc: 'Enterprise-grade security with role-based access control.' 
              },
              { 
                icon: '🚀', 
                title: 'Scale easily', 
                desc: 'Grows with your team from 5 to 500+ users seamlessly.' 
              },
            ].map((b) => (
              <div key={b.title} className="rounded-xl border bg-white p-4 md:p-6 hover:shadow-lg transition-all duration-300">
                <div className="text-3xl md:text-4xl mb-2 md:mb-3">{b.icon}</div>
                <div className="text-base md:text-lg font-semibold text-gray-900 mb-1 md:mb-2">{b.title}</div>
                <div className="text-xs md:text-sm text-gray-600 leading-relaxed">{b.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-semibold mb-2">Trusted by growing sales teams</h2>
            <p className="text-blue-100">See the impact CallTracker has on conversion rates.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: '10K+', label: 'Calls tracked' },
              { value: '5K+', label: 'Active leads' },
              { value: '98%', label: 'Satisfaction rate' },
              { value: '24/7', label: 'Support available' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-4xl md:text-5xl font-bold mb-2">{stat.value}</div>
                <div className="text-blue-100 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-semibold text-gray-900">What teams say</h2>
            <p className="mt-2 text-gray-600">Real feedback from teams using CallTracker daily.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { 
                quote: 'We moved our entire follow‑up workflow to CallTracker and saw conversion lift within weeks. The automated reminders alone saved us hours each day.',
                author: 'Sarah Chen',
                role: 'Sales Manager',
                company: 'TechStart Inc.'
              },
              { 
                quote: 'The UI is fast and focused. Our callers love it and managers finally have the right visibility into team performance.',
                author: 'Michael Rodriguez',
                role: 'VP of Sales',
                company: 'GrowthCo'
              },
              { 
                quote: 'Setup took minutes. The built‑in roles match how our team actually works, and the reporting gives us insights we never had before.',
                author: 'Emily Watson',
                role: 'Operations Lead',
                company: 'ScaleUp Solutions'
              },
            ].map((testimonial, i) => (
              <div key={i} className="rounded-xl border bg-white p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, j) => (
                    <svg key={j} className="w-4 h-4 text-yellow-400 fill-current" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-sm text-gray-700 leading-6 mb-4">"{testimonial.quote}"</p>
                <div className="border-t pt-4">
                  <div className="text-sm font-semibold text-gray-900">{testimonial.author}</div>
                  <div className="text-xs text-gray-500">{testimonial.role} at {testimonial.company}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      {/* <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-semibold text-gray-900">Perfect for every sales team</h2>
            <p className="mt-2 text-gray-600">Whether you're a startup or enterprise, CallTracker scales with you.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { 
                title: 'Small teams', 
                desc: 'Start tracking calls immediately with our intuitive interface. No training needed.',
                features: ['Up to 10 users', 'Unlimited calls', 'Email support']
              },
              { 
                title: 'Growing companies', 
                desc: 'Scale your sales operations with advanced features and team management.',
                features: ['Unlimited users', 'Advanced analytics', 'Priority support']
              },
              { 
                title: 'Enterprise', 
                desc: 'Custom integrations, dedicated support, and enterprise-grade security.',
                features: ['Custom integrations', 'Dedicated support', 'SLA guarantees']
              },
            ].map((useCase) => (
              <div key={useCase.title} className="rounded-xl border-2 border-gray-200 bg-white p-6 hover:border-blue-300 hover:shadow-lg transition-all duration-300">
                <div className="text-xl font-semibold text-gray-900 mb-2">{useCase.title}</div>
                <div className="text-sm text-gray-600 mb-4">{useCase.desc}</div>
                <ul className="space-y-2">
                  {useCase.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-gray-700">
                      <svg className="w-4 h-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section> */}

      {/* CTA */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="rounded-2xl bg-blue-600 p-8 sm:p-10 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div>
              <h3 className="text-xl sm:text-2xl font-semibold">Ready to accelerate your follow‑ups?</h3>
              <p className="mt-1 text-white/80 text-sm">Log in to your admin panel to get started in minutes.</p>
            </div>
            <div className="flex items-center gap-3">
              <Link to="/login" className="px-5 py-3 rounded-md bg-white text-blue-700 font-semibold shadow hover:bg-gray-100">Sign in</Link>
              <a href="#features" className="px-5 py-3 rounded-md bg-white/10 text-white font-medium ring-1 ring-white/30 hover:bg-white/15">Explore features</a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-6 py-16">
          <div className="grid grid-cols-3 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-8 mb-12">
            {/* Product Column - First Row Mobile */}
            <div className="order-1">
              <h3 className="text-sm md:text-base font-semibold text-white mb-3 md:mb-4">Product</h3>
              <ul className="space-y-2 md:space-y-3">
                <li>
                  <a href="#features" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 text-xs md:text-sm">
                    Features
                  </a>
                </li>
                <li>
                  <a href="#how" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 text-xs md:text-sm">
                    How it works
                  </a>
                </li>
                <li>
                  <Link to="/login" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 text-xs md:text-sm">
                    Get started
                  </Link>
                </li>
                <li>
                  <a href="#testimonials" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 text-xs md:text-sm">
                    Testimonials
                  </a>
                </li>
              </ul>
            </div>

            {/* Resources Column - First Row Mobile */}
            <div className="order-2">
              <h3 className="text-sm md:text-base font-semibold text-white mb-3 md:mb-4">Resources</h3>
              <ul className="space-y-2 md:space-y-3">
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 text-xs md:text-sm">
                    Documentation
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 text-xs md:text-sm">
                    Guides & Tutorials
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 text-xs md:text-sm">
                    API Reference
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 text-xs md:text-sm">
                    Status Page
                  </a>
                </li>
              </ul>
            </div>

            {/* Company Column - First Row Mobile */}
            <div className="order-3">
              <h3 className="text-sm md:text-base font-semibold text-white mb-3 md:mb-4">Company</h3>
              <ul className="space-y-2 md:space-y-3">
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 text-xs md:text-sm">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#contact" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 text-xs md:text-sm">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 text-xs md:text-sm">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 text-xs md:text-sm">
                    Terms of Service
                  </a>
                </li>
              </ul>
            </div>

            {/* Brand Column - Second Row Mobile, Full Width on Desktop */}
            <div className="order-4 col-span-3 md:col-span-1 lg:col-span-2 lg:order-last mt-6 md:mt-0">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-10 w-10 rounded-xl bg-blue-600 shadow-lg flex items-center justify-center">
                  <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                </div>
                <span className="text-lg md:text-xl font-bold text-blue-400">CallTracker</span>
              </div>
              <p className="text-gray-300 text-xs md:text-sm leading-relaxed mb-4 max-w-sm">
                Modern call and follow-up management platform designed to help sales teams convert more leads and close deals faster.
              </p>
              <div className="flex items-center gap-4">
                <a href="#" className="h-8 w-8 md:h-9 md:w-9 rounded-lg bg-white/10 hover:bg-blue-500 flex items-center justify-center transition-colors duration-200">
                  <svg className="w-4 h-4 md:w-5 md:h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                </a>
                <a href="#" className="h-8 w-8 md:h-9 md:w-9 rounded-lg bg-white/10 hover:bg-blue-400 flex items-center justify-center transition-colors duration-200">
                  <svg className="w-4 h-4 md:w-5 md:h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                  </svg>
                </a>
                <a href="#" className="h-8 w-8 md:h-9 md:w-9 rounded-lg bg-white/10 hover:bg-blue-600 flex items-center justify-center transition-colors duration-200">
                  <svg className="w-4 h-4 md:w-5 md:h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                  </svg>
                </a>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="pt-8 border-t border-white/10">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-gray-400 text-sm">
                © {new Date().getFullYear()} CallTracker. All rights reserved.
              </div>
              <div className="flex items-center gap-6 text-sm">
                <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors duration-200">
                  Terms
                </a>
                <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors duration-200">
                  Privacy
                </a>
                <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors duration-200">
                  Support
                </a>
                <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors duration-200">
                  Cookies
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;



