# Call Tracker Admin Panel

## 🚀 Features

### Core Features
- ✅ **Complete API Infrastructure** - Axios, TypeScript, auto token refresh
- ✅ **Toast Notifications** - Beautiful user feedback with react-hot-toast
- ✅ **Real-Time Updates** - WebSocket notifications with Socket.IO
- ✅ **Offline Support** - Auto-detection and retry logic
- ✅ **Loading Skeletons** - Better UX with loading placeholders
- ✅ **Performance Utilities** - Debounce, throttle, memoization
- ✅ **Desktop Notifications** - Browser notifications support
- ✅ **Sound Alerts** - Audio notifications
- ✅ **Error Handling** - Comprehensive error management
- ✅ **TypeScript** - Full type safety

### Pages
- Dashboard with real-time stats
- User Management (CRUD)
- Student Management (CRUD + Import/Export)
- Call Tracking with filters
- Reports & Analytics
- Settings

## 📦 Installation

### 1. Install Dependencies

```bash
npm install
```

This will install all required packages including:
- `axios` - HTTP client
- `react-hot-toast` - Toast notifications
- `socket.io-client` - Real-time WebSocket
- `zustand` - State management

### 2. Configure Environment

Create `.env` file:

```bash
cp env.example .env
```

Update with your settings:

```env
VITE_API_BASE_URL=http://localhost:8000/api
VITE_WS_URL=http://localhost:8000
VITE_ENABLE_SOUND_NOTIFICATIONS=true
VITE_ENABLE_DESKTOP_NOTIFICATIONS=true
```

### 3. Start Development Server

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)


### Toast Notifications

```typescript
import showToast from './lib/toast';

showToast.success('User created successfully!');
showToast.error('Failed to save');

// Promise-based
await showToast.promise(
  apiCall(),
  {
    loading: 'Saving...',
    success: 'Saved!',
    error: 'Failed',
  }
);
```

### API Calls with Hooks

```typescript
import { useUsers } from './hooks';

function UserList() {
  const { getUsers, users, usersLoading, createUser } = useUsers();

  useEffect(() => {
    getUsers();
  }, []);

  if (usersLoading) return <Skeleton />;
  
  return <Table data={users?.data || []} />;
}
```

### Real-Time Notifications

```typescript
import { useRealTimeNotifications, useNotifications } from './hooks';

function App() {
  const token = apiClient.getToken();
  useRealTimeNotifications(token); // Auto-connects

  const { notifications, unreadCount } = useNotifications();
  
  return <NotificationBell count={unreadCount} />;
}
```

### Offline Detection

```typescript
import { useOnlineStatus } from './hooks';

function MyComponent() {
  const { isOnline } = useOnlineStatus();

  if (!isOnline) {
    return <OfflineMessage />;
  }

  return <Content />;
}
```

## 🏗️ Project Structure

```
src/
├── components/         # UI components
│   ├── dashboard/     # Dashboard components
│   ├── layout/        # Layout components
│   └── ui/            # Reusable UI components
├── config/            # Configuration
├── hooks/             # Custom React hooks
├── lib/               # Core libraries (API, WebSocket, Toast)
├── pages/             # Page components
├── services/          # API service layer
├── stores/            # State management (Zustand)
├── types/             # TypeScript types
└── utils/             # Utility functions
```

## 🔧 Available Scripts

```bash
npm run dev      # Start development server
npm run build    # Build for production
npm run preview  # Preview production build
npm run lint     # Run ESLint
```

## 🔌 Backend Integration

### Required API Endpoints

Your backend should implement these endpoints:

- `POST /auth/login` - User login
- `POST /auth/logout` - User logout
- `GET /auth/me` - Get current user
- `GET /users` - List users
- `POST /users` - Create user
- `PUT /users/:id` - Update user
- `DELETE /users/:id` - Delete user
- `GET /students` - List students
- `POST /students/import` - Import students
- `GET /calls` - List calls
- `POST /calls` - Create call
- `GET /reports/overview` - Get reports

### WebSocket Events (Optional)

For real-time features, implement Socket.IO:

```javascript
// Server sends
io.emit('new_call', { userName, studentName });
io.emit('students_assigned', { count, userName });
io.emit('notification', { title, message, type });
```

## 🎨 Tech Stack

- **React 18** - UI framework
- **TypeScript** - Type safety
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **React Router** - Routing
- **Axios** - HTTP client
- **Socket.IO Client** - Real-time
- **Zustand** - State management
- **React Hot Toast** - Notifications
- **Recharts** - Charts
- **Lucide React** - Icons

## 🚦 Getting Started Checklist

- [ ] Install dependencies (`npm install`)
- [ ] Create `.env` file with API URL
- [ ] Start dev server (`npm run dev`)
- [ ] Update API base URL in `.env`
- [ ] Setup backend API
- [ ] Setup WebSocket (optional)
- [ ] Test login functionality
- [ ] Test API calls
- [ ] Test real-time notifications

## 🐛 Troubleshooting

### Common Issues

**API calls not working:**
- Check `VITE_API_BASE_URL` in `.env`
- Ensure backend is running
- Check browser console for errors

**WebSocket not connecting:**
- Verify `VITE_WS_URL` is correct
- Check backend WebSocket server
- Verify CORS settings

**Toast not showing:**
- Ensure `<AppProviders>` wraps your app
- Check z-index conflicts

## 📄 License

This project is private.
