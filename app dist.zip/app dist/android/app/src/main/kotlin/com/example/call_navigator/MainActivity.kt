package com.example.call_navigator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
